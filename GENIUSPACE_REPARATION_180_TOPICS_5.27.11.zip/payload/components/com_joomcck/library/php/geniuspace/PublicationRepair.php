<?php
declare(strict_types=1);
namespace Geniuspace;

/** Owner-authorized resumable publication: every content batch has its own native transaction. */
final class PublicationRepair
{
    private const KEY='geniuspace_publication_repair_52711';
    private const PACKS=[
        'images-A'=>['GENIUSPACE_IMAGES_5.27.6_A.zip','3049363062596070a52e081d7d31343ad3757428f1598637b38d291da8ced067'],
        'images-B'=>['GENIUSPACE_IMAGES_5.27.6_B.zip','64c9bce7d0d4178ba7af4057588415da6df9026d002c7c4d8a2c27920bfdab24']
    ];
    private static function admin(): void
    {
        $u=ProductAccess::user();if(!$u->id||$u->block||!$u->authorise('core.admin'))throw new \DomainException('Réparation réservée aux super administrateurs.',403);
    }
    private static function load(bool $lock=false): ?array
    {
        $p=json_decode((string)ProductAccess::store()->db->setQuery("SELECT params FROM #__extensions WHERE element='com_joomcck' AND type='component'".($lock?' FOR UPDATE':''))->loadResult(),true)?:[];return $p[self::KEY]??null;
    }
    private static function save(array $state): void
    {
        $db=ProductAccess::store()->db;$row=$db->setQuery("SELECT extension_id,params FROM #__extensions WHERE element='com_joomcck' AND type='component' FOR UPDATE")->loadAssoc();$p=json_decode($row['params'],true)?:[];$p[self::KEY]=$state;$db->setQuery('UPDATE #__extensions SET params='.$db->quote(Seo::json($p)).' WHERE extension_id='.(int)$row['extension_id'])->execute();
    }
    public static function start(bool $restart=false): array
    {
        self::admin();$old=self::load();if($old&&(!$restart||!in_array($old['status'],['done','complete_with_exclusions'],true)))return self::publicState($old);$all=json_decode((string)file_get_contents(__DIR__.'/editorial/collection-240.json'),true,64,JSON_THROW_ON_ERROR);$keys=array_values(array_unique(array_column($all,'universe')));
        $map=ForumProvisioner::manifest();if(!$map||count($keys)!==12)throw new \DomainException('Collection native complète absente.',409);
        $ctx=UniverseBlueprint::context((int)$map['section']);$roots=[];foreach($ctx['roots']as$r)$roots[]=UniverseBlueprint::rootKey($r,$ctx['flat']);if(array_diff($keys,$roots))throw new \DomainException('Des univers natifs manquent.',409);
        $base=dirname(JPATH_ROOT).'/.nexus-publication-repair';if(!is_dir($base)&&!mkdir($base,0700,true))throw new \RuntimeException('Journal privé indisponible.');$id=bin2hex(random_bytes(12));$dir=$base.'/'.$id;if(!mkdir($dir,0700))throw new \RuntimeException('Journal privé indisponible.');
        $state=['id'=>$id,'status'=>'pending','index'=>0,'phases'=>array_merge(['images-A','images-B','category-links','homepage','test-content'],$keys,['verify']),'receipts'=>[],'created_at'=>gmdate('c'),'backup_dir'=>$dir,'error'=>null];
        ProductAccess::store()->atomic(static function()use($state,$restart){$current=self::load(true);if(!$current||($restart&&in_array($current['status'],['done','complete_with_exclusions'],true)))self::save($state);});return self::publicState(self::load());
    }
    private static function publicState(array $s): array
    {
        unset($s['backup_dir']);$s['current_phase']=$s['phases'][$s['index']]??null;$s['total_phases']=count($s['phases']);return $s;
    }
    public static function status(): ?array {self::admin();$s=self::load();return $s?self::publicState($s):null;}
    private static function backup(array $s,string $name,array $data): void
    {
        if(!preg_match('/^[A-Z0-9-]+\.json$/D',$name))throw new \LogicException('Nom de journal invalide.');$dir=realpath($s['backup_dir']);$base=realpath(dirname(JPATH_ROOT).'/.nexus-publication-repair');if(!$dir||!$base||!str_starts_with($dir,$base.DIRECTORY_SEPARATOR))throw new \RuntimeException('Journal privé invalide.');$file=$dir.'/'.$name;$text=Seo::json($data);if(file_put_contents($file,$text)!==strlen($text))throw new \RuntimeException('Journal privé incomplet.');chmod($file,0600);
    }
    public static function step(string $id): array
    {
        self::admin();$s=self::load();if(!$s||!hash_equals($s['id'],$id))throw new \DomainException('Réparation inconnue.',404);if(in_array($s['status'],['done','complete_with_exclusions'],true))return self::publicState($s);
        $store=ProductAccess::store();$db=$store->db;$lock='nexus-repair-52711';if((int)$db->setQuery('SELECT GET_LOCK('.$db->quote($lock).',0)')->loadResult()!==1)throw new \DomainException('Une étape est déjà en cours. Réessayez dans un instant.',409);
        $start=(int)$s['index'];
        try{
            $s=self::load();$phase=$s['phases'][$s['index']]??null;if(!$phase)return self::publicState($s);$start=(int)$s['index'];
            if(isset(self::PACKS[$phase]))$receipt=self::images($phase);
            else $receipt=null;
            $result=$store->atomic(static function()use($s,$phase,$receipt){
                $receipt??=self::apply($phase,$s);$fresh=self::load();if((int)$fresh['index']!==(int)$s['index'])throw new \DomainException('État modifié. Reprenez la réparation.',409);
                self::backup($s,'PHASE-'.(int)$s['index'].'.json',$receipt);$fresh['receipts'][]=['phase'=>$phase,'completed_at'=>gmdate('c'),'result'=>$receipt];$fresh['index']++;$fresh['status']=$phase==='verify'?(!empty($receipt['excluded'])?'complete_with_exclusions':'done'):'pending';$fresh['error']=null;self::save($fresh);return self::publicState($fresh);
            });
            try{foreach(['com_joomcck','com_menus','page']as$group)\Joomla\CMS\Cache\Cache::getInstance('callback')->clean($group);}catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Repair cache: '.get_class($e),\Joomla\CMS\Log\Log::WARNING,'joomcck');}return $result;
        }catch(\Throwable $e){
            $fresh=self::load();if((int)$fresh['index']!==$start)return self::publicState($fresh);
            $error=$e instanceof \DomainException?$e->getMessage():'Étape interrompue. Consultez le journal Joomla puis reprenez.';$store->atomic(static function()use($fresh,$error){$fresh['status']='failed';$fresh['error']=$error;self::save($fresh);});\Joomla\CMS\Log\Log::add('Publication repair: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');throw new \DomainException($error,409);
        }finally{$db->setQuery('SELECT RELEASE_LOCK('.$db->quote($lock).')')->loadResult();}
    }
    private static function apply(string $phase,array $state): array
    {
        $map=ForumProvisioner::manifest();$hub=(int)$map['section'];
        if($phase==='homepage')return NativeHome::install($hub,static fn($name,$data)=>self::backup($state,$name,$data));
        if($phase==='category-links')return CategoryBridge::repair($hub,static fn($name,$data)=>self::backup($state,$name,$data));
        if($phase==='test-content')return self::tests($state,$map);
        if($phase==='verify')return self::verify();
        $articles=EditorialPack::collection2026($phase);$topics=EditorialPack::topics2026($phase);$gate=new NativeAccess();$a=0;$t=0;
        foreach($articles['articles']as$id)if(PublicMaterial::projection((int)$id,true,$gate))$a++;
        foreach($topics['topics']as$id)if(PublicMaterial::projection((int)$id,true,$gate))$t++;
        return ['articles_created'=>$articles['created'],'articles_preserved'=>$articles['preserved'],'topics_created'=>$topics['created'],'topics_preserved'=>$topics['preserved'],'public_articles'=>$a,'public_topics'=>$t];
    }
    private static function tests(array $s,array $map): array
    {
        $known=['test'=>'test','test2'=>'test2','vxvxvxvwxv'=>'vxvxvxvwxv','bvxvxvx-test-sonyxcsdsdfsd'=>'bvxvxvx test sonyxcsdsdfsd'];$db=ProductAccess::store()->db;$changed=[];$skipped=[];
        foreach($known as$alias=>$text){$rows=$db->setQuery('SELECT * FROM #__js_res_record WHERE alias='.$db->quote($alias).' AND section_id='.(int)$map['section'].' FOR UPDATE')->loadAssocList();if(count($rows)!==1){$skipped[]=$alias;continue;}$r=$rows[0];$fields=json_decode($r['fields'],true)?:[];$body=Text::plain((string)($fields[(int)$map['fields']['body']['id']]??''));
            $comments=(int)$db->setQuery('SELECT COUNT(*) FROM #__js_res_comments WHERE record_id='.(int)$r['id'].' AND published=1 AND hide=0 AND private=0')->loadResult();$public=PublicMaterial::projection((int)$r['id'],false,new NativeAccess());$media=$public?PublicMaterial::visuals($public):['images'=>[],'videos'=>[]];$rich=(bool)($media['images']||$media['videos']);
            if($public)foreach($public['fields']as$f)if(in_array($f['field_type'],['file','files','upload','attachment','gpattachment','gpaudio','audio','video','gpavsvideo','gallery','picture','image'],true)&&self::uploadPayload($public['values'][(int)$f['id']]??null))$rich=true;
            foreach(['cover','images_upload','video_upload','audio_upload','files_upload','audio','timed_media','avs_video']as$key)if(!empty($map['fields'][$key]['id'])&&self::uploadPayload($fields[(int)$map['fields'][$key]['id']]??null))$rich=true;
            if(!$public||$rich||$r['title']!==$text||$body!==$text||$comments||(int)$r['type_id']!==(int)$map['type']||(int)$r['published']!==1||str_contains(strtolower((string)$r['meta_index']),'noindex')){$skipped[]=$alias;continue;}
            self::backup($s,'TEST-'.(int)$r['id'].'.json',$r);$change=(object)['id'=>(int)$r['id'],'meta_index'=>'noindex, follow','mtime'=>gmdate('Y-m-d H:i:s')];$db->updateObject('#__js_res_record',$change,'id');LinkIndex::record(new Store($db),(int)$r['id']);if(class_exists(NexusKnowledge::class))NexusKnowledge::indexRecord((int)$r['id']);$changed[]=['id'=>(int)$r['id'],'alias'=>$alias,'previous_robots'=>$r['meta_index']];
        }return ['noindex_applied'=>$changed,'skipped_changed_or_absent'=>$skipped,'records_deleted'=>0];
    }
    private static function uploadPayload(mixed $value,string $key=''): bool
    {
        if(is_string($value)&&($json=json_decode($value,true))!==null)$value=$json;
        if(is_array($value)){foreach($value as$k=>$v)if(self::uploadPayload($v,is_int($k)?$key:(string)$k))return true;return false;}
        if(!is_scalar($value)||trim((string)$value)==='')return false;
        if(is_numeric($value))return (float)$value>0&&in_array($key,['','files','file','id','video','audio','source'],true);
        return in_array($key,['filename','url','link','embed','source','transcript'],true)||($key===''&&preg_match('~https?://|\.(?:mp4|mp3|wav|webp|jpe?g|png|pdf|zip)$~i',(string)$value));
    }
    private static function verify(): array
    {
        $gate=new NativeAccess();$db=ProductAccess::store()->db;$out=['native_articles'=>0,'native_topics'=>0,'public_articles'=>0,'public_topics'=>0,'excluded'=>[]];
        foreach(['collection-240.json'=>['geniuspace-guide-2026-','articles'],'topics-180.json'=>['geniuspace-discussion-2026-','topics']]as$file=>[$prefix,$kind])foreach(json_decode((string)file_get_contents(__DIR__.'/editorial/'.$file),true)as$item){$rows=$db->setQuery('SELECT id FROM #__js_res_record WHERE alias='.$db->quote($prefix.$item['slug']))->loadColumn();if(count($rows)!==1)throw new \DomainException('Publication native absente ou ambiguë : '.$item['slug'],409);$out['native_'.$kind]++;if(PublicMaterial::projection((int)$rows[0],true,$gate))$out['public_'.$kind]++;else$out['excluded'][]=['id'=>(int)$rows[0],'reason'=>'Visibilité ou exclusion native conservée.'];}
        return $out;
    }
    private static function images(string $phase): array
    {
        $all=json_decode((string)file_get_contents(__DIR__.'/editorial/collection-240.json'),true);$chosen=array_slice($all,$phase==='images-A'?0:120,120);$expected=[];foreach($chosen as$a)foreach($a['illustration']['variants']as$v)$expected[basename($v['path'])]=$v['sha256'];$base=JPATH_ROOT.'/media/com_joomcck/nexus/editorial-2026';
        $missing=[];foreach($expected as$name=>$sha){$target=$base.'/'.$name;for($p=$target;strlen($p)>strlen(JPATH_ROOT);$p=dirname($p))if(is_link($p))throw new \DomainException('Lien symbolique refusé dans les images.',409);if(is_file($target)){if(!hash_equals($sha,hash_file('sha256',$target)))throw new \DomainException('Image personnalisée conservée : '.$name,409);}else$missing[$name]=$sha;}
        if(!$missing)return ['already_present'=>count($expected),'copied'=>0];
        [$file,$sha]=self::PACKS[$phase];$temp=tempnam(\Joomla\CMS\Factory::getApplication()->get('tmp_path'),'gp-images-');if(!$temp)throw new \RuntimeException('Dossier temporaire indisponible.');
        try{
            self::download('https://github.com/GUILLAUMEDEPLANQUE-geniuspace/cck2027/raw/refs/heads/main/'.$file,$temp);if(!hash_equals($sha,hash_file('sha256',$temp)))throw new \DomainException('Empreinte du pack d’images invalide.',409);
            $zip=new \ZipArchive();if($zip->open($temp)!==true)throw new \RuntimeException('Pack d’images illisible.');$copied=0;
            try{foreach($missing as$name=>$hash){$entry='images/'.$name;$stream=$zip->getStream($entry);if(!$stream)throw new \RuntimeException('Image attendue absente du pack.');$target=$base.'/'.$name;if(!is_dir($base)&&!mkdir($base,0755,true))throw new \RuntimeException('Médias inaccessibles.');$part=$target.'.repair-'.bin2hex(random_bytes(6));$out=fopen($part,'wb');if(!$out){fclose($stream);throw new \RuntimeException('Média non enregistrable.');}stream_copy_to_stream($stream,$out);fclose($stream);fclose($out);if(!hash_equals($hash,hash_file('sha256',$part))){unlink($part);throw new \RuntimeException('Image altérée.');}chmod($part,0644);if(!rename($part,$target)){unlink($part);throw new \RuntimeException('Image non enregistrée.');}$copied++;}}
            finally{$zip->close();}return ['already_present'=>count($expected)-count($missing),'copied'=>$copied];
        }finally{if(is_file($temp))unlink($temp);}
    }
    private static function download(string $url,string $target): void
    {
        if(!function_exists('curl_init'))throw new \DomainException('Activez cURL ou installez les packs d’images A et B, puis reprenez.',409);
        for($i=0;$i<6;$i++){
            $parts=parse_url($url);if(($parts['scheme']??'')!=='https'||!in_array($parts['host']??'',['github.com','raw.githubusercontent.com','objects.githubusercontent.com','release-assets.githubusercontent.com'],true)||isset($parts['user'])||isset($parts['pass'])||isset($parts['port']))throw new \DomainException('Redirection du pack d’images refusée.',409);
            $fp=fopen($target,'wb');if(!$fp)throw new \RuntimeException('Téléchargement non enregistrable.');$location='';$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_FILE=>$fp,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>70,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_USERAGENT=>'Geniuspace-Media-Repair/5.27.11',CURLOPT_NOPROGRESS=>false,CURLOPT_XFERINFOFUNCTION=>static fn($h,$total,$now)=>$total>65000000||$now>65000000?1:0,CURLOPT_HEADERFUNCTION=>static function($h,$line)use(&$location){if(strncasecmp($line,'Location:',9)===0)$location=trim(substr($line,9));return strlen($line);}]);$ca=getenv('CURL_CA_BUNDLE')?:getenv('SSL_CERT_FILE');if($ca&&is_file($ca))curl_setopt($ch,CURLOPT_CAINFO,$ca);
            try{$ok=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);}finally{curl_close($ch);fclose($fp);}
            if(!$ok)throw new \DomainException('Téléchargement interrompu. Réessayez ou installez les packs A et B.',409);
            if($code===200)return;if(!in_array($code,[301,302,303,307,308],true)||!$location)throw new \DomainException('Pack d’images momentanément inaccessible.',409);
            $url=str_starts_with($location,'/')?'https://'.$parts['host'].$location:$location;
        }throw new \DomainException('Trop de redirections du pack d’images.',409);
    }
    public static function panel(): string
    {
        $s=self::status();if(!$s)return '';$app=\Joomla\CMS\Factory::getApplication();$entry=\Joomla\CMS\Uri\Uri::root().($app->isClient('administrator')?'administrator/index.php':'');$e=[Text::class,'escape'];
        return '<aside data-publication-job data-job="'.$e($s['id']).'" data-endpoint="'.$e($entry).'" data-csrf="'.\Joomla\CMS\Session\Session::getFormToken().'" style="position:fixed;right:16px;bottom:16px;z-index:1100;max-width:min(440px,94vw);padding:18px;border-radius:16px;background:#fff;border:2px solid #6d28d9;box-shadow:0 12px 40px #0f172a30;color:#172033"><strong>Réparation des douze univers</strong><p role="status" data-job-status>Contrôle de la réparation…</p><progress data-job-progress max="'.$s['total_phases'].'" value="'.$s['index'].'"></progress><p><button type="button" data-job-resume>Reprendre</button> <button type="button" data-job-close>Réduire</button></p><details><summary>Reçus de publication</summary><ol data-job-receipts style="max-height:200px;overflow:auto"></ol></details></aside><script type="module" src="'.$e(\Joomla\CMS\Uri\Uri::root().'media/com_joomcck/nexus/publication-job.js?v=5.27.11').'"></script>';
    }
}
