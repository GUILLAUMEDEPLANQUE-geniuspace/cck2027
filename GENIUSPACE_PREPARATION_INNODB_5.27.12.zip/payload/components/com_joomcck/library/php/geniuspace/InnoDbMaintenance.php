<?php
declare(strict_types=1);
namespace Geniuspace;

/** Explicit administrator maintenance; installation itself performs no engine conversion. */
final class InnoDbMaintenance
{
    private const REQUIRED=['js_res_record','js_res_record_values','js_res_record_category','js_res_categories','gp_social_links','gp_social_knowledge_chunks','menu','extensions','assets'];
    private const MODERATION=['js_res_comments','gp_social_record_versions','gp_social_audit'];
    private static function db(): object {return ProductAccess::store()->db;}
    private static function admin(): void
    {
        $u=ProductAccess::user();if(!$u->id||$u->block||!$u->authorise('core.admin'))throw new \DomainException('Accès super administrateur requis.',403);
    }
    private static function offline(): void
    {
        if(!\Joomla\CMS\Factory::getConfig()->get('offline'))throw new \DomainException('Mettez d’abord le site hors ligne dans Configuration globale. L’administration reste accessible.',409);
        if(Store::active(self::db()))throw new \DomainException('La conversion doit être exécutée hors d’une transaction de publication.',409);
    }
    public static function audit(): array
    {
        self::admin();$db=self::db();$prefix=$db->getPrefix();$tables=[];$required=[];
        foreach($db->setQuery('SELECT TABLE_NAME,ENGINE,TABLE_TYPE,TABLE_ROWS,DATA_LENGTH,INDEX_LENGTH FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() ORDER BY TABLE_NAME')->loadAssocList()as$r){
            if(!str_starts_with($r['TABLE_NAME'],$prefix))continue;$suffix=substr($r['TABLE_NAME'],strlen($prefix));
            if(!in_array($suffix,self::REQUIRED,true)&&!preg_match('/^(?:js_res_|gp_social_|joomsubscription_)[a-z0-9_]+$/D',$suffix))continue;
            $isRequired=in_array($suffix,self::REQUIRED,true);$row=['name'=>$r['TABLE_NAME'],'suffix'=>$suffix,'engine'=>$r['ENGINE'],'rows_estimated'=>(int)$r['TABLE_ROWS'],'bytes_estimated'=>(int)$r['DATA_LENGTH']+(int)$r['INDEX_LENGTH'],'required'=>$isRequired,'moderation'=>in_array($suffix,self::MODERATION,true),'convertible'=>$r['TABLE_TYPE']==='BASE TABLE'&&in_array(strtoupper((string)$r['ENGINE']),['MYISAM','ARIA'],true),'transactional'=>strcasecmp((string)$r['ENGINE'],'InnoDB')===0];$tables[]=$row;if($isRequired)$required[]=$suffix;
        }
        $support=(string)$db->setQuery("SELECT SUPPORT FROM information_schema.ENGINES WHERE ENGINE='InnoDB'")->loadResult();
        return ['offline'=>(bool)\Joomla\CMS\Factory::getConfig()->get('offline'),'innodb_available'=>in_array(strtoupper($support),['YES','DEFAULT'],true),'missing_required'=>array_values(array_diff(self::REQUIRED,$required)),'tables'=>$tables,'ready'=>!array_filter($tables,static fn($r)=>$r['required']&&!$r['transactional'])&&!array_diff(self::REQUIRED,$required)];
    }
    private static function base(): string
    {
        $root=realpath(JPATH_ROOT);$document=!empty($_SERVER['DOCUMENT_ROOT'])?realpath((string)$_SERVER['DOCUMENT_ROOT']):false;$public=$document&&($root===$document||str_starts_with($root,$document.DIRECTORY_SEPARATOR))?$document:$root;
        $path=dirname($public).'/.nexus-innodb-maintenance';if(is_link($path))throw new \RuntimeException('Répertoire privé invalide.');if(!is_dir($path)&&!mkdir($path,0700,true))throw new \RuntimeException('Impossible de créer les sauvegardes hors de la racine publique.');chmod($path,0700);$real=realpath($path);if(!$real||!$public||$real===$public||str_starts_with($real,$public.DIRECTORY_SEPARATOR))throw new \RuntimeException('Les sauvegardes doivent rester hors de la racine publique.');
        $deny=$real.'/.htaccess';if(!is_file($deny)){file_put_contents($deny,"<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");chmod($deny,0600);}return $real;
    }
    private static function identity(): string {return hash('sha256',JPATH_ROOT.':'.\Joomla\CMS\Factory::getConfig()->get('host').':'.self::db()->getPrefix().':'.self::db()->setQuery('SELECT DATABASE()')->loadResult());}
    private static function pointer(): string {return self::base().'/active-'.substr(self::identity(),0,24).'.json';}
    private static function write(string $path,array $data): void
    {
        if(is_link($path))throw new \RuntimeException('Journal privé invalide.');$text=json_encode($data,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);$tmp=$path.'.'.bin2hex(random_bytes(8));
        if(file_put_contents($tmp,$text,LOCK_EX)!==strlen($text)){@unlink($tmp);throw new \RuntimeException('Journal incomplet : espace ou permissions à vérifier.');}chmod($tmp,0600);if(!rename($tmp,$path)){@unlink($tmp);throw new \RuntimeException('Journal non enregistré.');}
    }
    private static function directory(string $id): string
    {
        if(!preg_match('/^[a-f0-9]{32}$/D',$id))throw new \DomainException('Migration inconnue.',404);$path=self::base().'/'.$id;if(is_link($path)||!is_dir($path))throw new \DomainException('Migration inconnue.',404);return $path;
    }
    private static function load(?string $id=null): ?array
    {
        if($id===null){$p=self::pointer();if(!is_file($p))return null;$id=json_decode((string)file_get_contents($p),true,8,JSON_THROW_ON_ERROR)['id'];}
        $path=self::directory($id).'/state.json';if(is_link($path)||!is_file($path))throw new \DomainException('Journal de migration absent.',404);$s=json_decode((string)file_get_contents($path),true,64,JSON_THROW_ON_ERROR);
        if(!hash_equals(self::identity(),$s['database_identity'])||$s['id']!==$id)throw new \DomainException('Cette migration appartient à une autre base.',409);return $s;
    }
    private static function save(array $s): void {self::write(self::directory($s['id']).'/state.json',$s);}
    private static function publicState(?array $s): array
    {
        if(!$s)return ['status'=>'not_started'];$receipts=[];foreach($s['receipts']as$r)$receipts[]=array_intersect_key($r,array_flip(['table','stage','rows','backup_sha256','engine_before','engine_after','schema_verified','data_verified','at']));
        return ['id'=>$s['id'],'status'=>$s['status'],'index'=>$s['index'],'total'=>count($s['steps']),'current'=>$s['steps'][$s['index']]??null,'tables'=>array_map(static fn($r)=>array_intersect_key($r,array_flip(['name','engine','rows_estimated','required','moderation'])),$s['tables']),'receipts'=>$receipts,'error'=>$s['error'],'site_reopened'=>false];
    }
    private static function locked(callable $fn): mixed
    {
        $f=fopen(self::base().'/lock-'.substr(self::identity(),0,24),'c');if(!$f)throw new \RuntimeException('Verrou de maintenance inaccessible.');chmod(self::base().'/lock-'.substr(self::identity(),0,24),0600);
        if(!flock($f,LOCK_EX|LOCK_NB)){fclose($f);throw new \DomainException('Une étape est déjà en cours.',409);}try{return $fn();}finally{flock($f,LOCK_UN);fclose($f);}
    }
    public static function status(): array {self::admin();return self::publicState(self::load());}
    public static function start(string $scope,bool $writersStopped): array
    {
        self::admin();self::offline();if(!$writersStopped)throw new \DomainException('Arrêtez les tâches cron, imports et traitements qui écrivent dans la base avant de démarrer.',409);
        return self::locked(static function()use($scope){
            $old=self::load();if($old&&$old['status']!=='done')return self::publicState($old);$audit=self::audit();if(!$audit['innodb_available']||$audit['missing_required'])throw new \DomainException('InnoDB indisponible ou tables requises absentes : migration interrompue.',409);
            if(!in_array($scope,['repair','all'],true))throw new \DomainException('Périmètre inconnu.',400);$tables=[];$bytes=0;
            foreach($audit['tables']as$t)if(!$t['transactional']&&($scope==='all'||$t['required']||$t['moderation'])){if(!$t['convertible'])throw new \DomainException('Conversion manuelle requise pour '.$t['name'].' (moteur '.$t['engine'].').',409);$tables[]=$t;$bytes+=$t['bytes_estimated'];}
            $free=disk_free_space(self::base());if($free!==false&&$free<4*$bytes+16777216)throw new \DomainException('Espace disque insuffisant pour sauvegarde, contrôle et conversion. Libérez de l’espace puis reprenez.',409);
            foreach($tables as$t)self::checkTable($t['name']);$id=bin2hex(random_bytes(16));if(!mkdir(self::base().'/'.$id,0700))throw new \RuntimeException('Journal privé inaccessible.');$steps=[];
            foreach($tables as$i=>$t)$steps[]=['stage'=>'backup','table'=>$i];$steps[]=['stage'=>'precheck'];foreach($tables as$i=>$t)$steps[]=['stage'=>'convert','table'=>$i];$steps[]=['stage'=>'verify'];
            $s=['id'=>$id,'database_identity'=>self::identity(),'created'=>gmdate('c'),'status'=>'pending','index'=>0,'scope'=>$scope,'tables'=>$tables,'steps'=>$steps,'receipts'=>[],'backups'=>[],'error'=>null,'shadow'=>null];self::save($s);self::write(self::pointer(),['id'=>$id]);return self::publicState($s);
        });
    }
    private static function ddl(string $name): string {$r=self::db()->setQuery('SHOW CREATE TABLE '.self::db()->quoteName($name))->loadRow();return (string)$r[1];}
    private static function schemaHash(string $ddl): string
    {
        return hash('sha256',preg_replace('/\b(?:ENGINE=[A-Za-z0-9_]+|AUTO_INCREMENT=\d+)\s*/i','',$ddl));
    }
    private static function engine(string $name): string
    {
        return (string)self::db()->setQuery('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='.self::db()->quote($name))->loadResult();
    }
    private static function checkTable(string $name): void
    {
        $db=self::db();$ddl=self::ddl($name);if(preg_match('/\b(?:DATA\s+DIRECTORY|INDEX\s+DIRECTORY|TABLESPACE|CONNECTION)\b/i',$ddl))throw new \DomainException('Options de stockage particulières : vérification manuelle requise pour '.$name.'.',409);
        if($db->setQuery('SHOW TRIGGERS WHERE `Table`='.$db->quote($name))->loadAssocList())throw new \DomainException('Cette table possède des déclencheurs : migration par l’administrateur de base requise ('.$name.').',409);
        foreach($db->setQuery('SHOW FULL COLUMNS FROM '.$db->quoteName($name))->loadAssocList()as$c)if(str_contains(strtoupper($c['Extra']??''),'GENERATED'))throw new \DomainException('Colonne calculée : migration manuelle requise pour '.$name.'.',409);
        foreach($db->setQuery('CHECK TABLE '.$db->quoteName($name))->loadAssocList()as$r)if(strtolower((string)$r['Msg_type'])==='error')throw new \DomainException('CHECK TABLE signale une erreur sur '.$name.'.',409);
    }
    /** A multiset digest preserves duplicate rows and is independent of engine scan order. */
    private static function digestAdd(string $sum,string $line): string
    {
        $a=hex2bin($sum);$b=hash('sha256',$line,true);$carry=0;$out='';for($i=31;$i>=0;$i--){$n=ord($a[$i])+ord($b[$i])+$carry;$out=chr($n&255).$out;$carry=$n>>8;}return bin2hex($out);
    }
    private static function line(array $row): string {return json_encode(array_map(static fn($v)=>$v===null?null:base64_encode((string)$v),array_values($row)),JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES)."\n";}
    private static function scan(string $name,?callable $each=null): array
    {
        $db=self::db();$offset=0;$sum=str_repeat('0',64);$columns=null;
        do{$rows=$db->setQuery('SELECT * FROM '.$db->quoteName($name),$offset,100)->loadAssocList();foreach($rows as$r){$columns??=array_keys($r);$line=self::line($r);$sum=self::digestAdd($sum,$line);if($each)$each($r,$line);}$offset+=count($rows);}while(count($rows)===100);
        return ['rows'=>$offset,'multiset_sha256_sum'=>$sum];
    }
    private static function gzWrite($f,string $text): void
    {
        $offset=0;while($offset<strlen($text)){$n=gzwrite($f,substr($text,$offset));if($n===false||$n===0)throw new \RuntimeException('Sauvegarde interrompue : vérifiez l’espace disque.');$offset+=$n;}
    }
    private static function sqlValues(array $values): string {return implode(',',array_map(static fn($v)=>$v===null?'NULL':"X'".bin2hex((string)$v)."'",$values));}
    private static function compatibleMode(): string
    {
        $mode=(string)self::db()->setQuery('SELECT @@SESSION.sql_mode')->loadResult();$parts=array_diff(explode(',',$mode),['NO_ZERO_DATE','NO_ZERO_IN_DATE']);$parts[]='NO_AUTO_VALUE_ON_ZERO';return implode(',',array_unique(array_filter($parts)));
    }
    private static function preserveLegacyValues(callable $fn): mixed
    {
        $db=self::db();$old=(string)$db->setQuery('SELECT @@SESSION.sql_mode')->loadResult();$mode=self::compatibleMode();$db->setQuery('SET SESSION sql_mode='.$db->quote($mode))->execute();try{return $fn();}finally{$db->setQuery('SET SESSION sql_mode='.$db->quote($old))->execute();}
    }
    private static function gzLine($f): ?string
    {
        $line='';while(($part=gzgets($f,65536))!==false){$line.=$part;if(str_ends_with($part,"\n"))return $line;}if($line!=='')throw new \RuntimeException('Ligne de sauvegarde tronquée.');return null;
    }
    private static function backup(array &$s,int $i): array
    {
        $db=self::db();$t=$s['tables'][$i];$name=$t['name'];if(strcasecmp(self::engine($name),$t['engine'])!==0)throw new \DomainException('Le moteur a changé : relancez le diagnostic ('.$name.').',409);self::checkTable($name);$dir=self::directory($s['id']);
        $data=$dir.'/table-'.$i.'.rows.jsonl.gz';$sql=$dir.'/table-'.$i.'.sql.gz';foreach([$data,$sql]as$file)if(is_link($file))throw new \RuntimeException('Chemin de sauvegarde invalide.');$f=gzopen($data,'wb6');$g=gzopen($sql,'wb6');if(!$f||!$g)throw new \RuntimeException('Sauvegarde non enregistrable.');chmod($data,0600);chmod($sql,0600);
        $columns=array_column($db->setQuery('SHOW FULL COLUMNS FROM '.$db->quoteName($name))->loadAssocList(),'Field');$insert='INSERT INTO '.$db->quoteName($name).' ('.implode(',',array_map([$db,'quoteName'],$columns)).') VALUES (';
        $mode=self::compatibleMode();$db->setQuery('LOCK TABLES '.$db->quoteName($name).' READ')->execute();
        try{$ddl=self::ddl($name);$schema=self::schemaHash($ddl);self::gzWrite($g,"-- Geniuspace : sauvegarde logique avant InnoDB\n-- Restaurer en maintenance dans une base contrôlée. Aucun DROP automatique.\nSET NAMES utf8mb4;\nSET @GENIUSPACE_OLD_SQL_MODE=@@SESSION.sql_mode;\nSET SESSION sql_mode=".$db->quote($mode).";\n".$ddl.";\n");$fingerprint=self::scan($name,static function($row,$line)use($f,$g,$insert){self::gzWrite($f,$line);self::gzWrite($g,$insert.self::sqlValues(array_values($row)).");\n");});self::gzWrite($g,"SET SESSION sql_mode=@GENIUSPACE_OLD_SQL_MODE;\n");}
        finally{$db->setQuery('UNLOCK TABLES')->execute();gzclose($f);gzclose($g);}
        preg_match('/\bAUTO_INCREMENT=(\d+)/',$ddl,$auto);
        $meta=['table'=>$name,'engine'=>$t['engine'],'columns'=>$columns,'ddl'=>$ddl,'auto_increment'=>$auto[1]??null,'schema_hash'=>$schema,'fingerprint'=>$fingerprint,'data_sha256'=>hash_file('sha256',$data),'sql_sha256'=>hash_file('sha256',$sql)];self::write($dir.'/table-'.$i.'.meta.json',$meta);
        $s['backups'][$i]=$meta;self::save($s);self::verifyBackup($s,$i);
        return ['table'=>$name,'stage'=>'backup','rows'=>$fingerprint['rows'],'backup_sha256'=>$meta['sql_sha256'],'engine_before'=>$t['engine'],'schema_verified'=>true,'data_verified'=>true,'at'=>gmdate('c')];
    }
    private static function verifyBackup(array &$s,int $i): void
    {
        $db=self::db();$meta=$s['backups'][$i];$name=$meta['table'];$file=self::directory($s['id']).'/table-'.$i.'.rows.jsonl.gz';if(!hash_equals($meta['data_sha256'],hash_file('sha256',$file))||!hash_equals($meta['schema_hash'],self::schemaHash(self::ddl($name))))throw new \DomainException('La sauvegarde ou la structure a changé : '.$name.'.',409);
        $shadow='gp_innodb_verify_'.substr(hash('sha256',$s['id'].':'.$i),0,24);$s['shadow']=['name'=>$shadow,'index'=>$i,'created'=>false];self::save($s);
        // A unique table is created only by this job; never reuse an unrelated table.
        if($db->setQuery('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='.$db->quote($shadow))->loadResult())throw new \DomainException('Une copie temporaire subsiste. Reprenez pour la contrôler.',409);
        $db->setQuery('CREATE TABLE '.$db->quoteName($shadow).' LIKE '.$db->quoteName($name))->execute();$s['shadow']['created']=true;self::save($s);
        try{$f=gzopen($file,'rb');if(!$f)throw new \RuntimeException('Sauvegarde illisible.');$insert='INSERT INTO '.$db->quoteName($shadow).' ('.implode(',',array_map([$db,'quoteName'],$meta['columns'])).') VALUES (';
            try{self::preserveLegacyValues(static function()use($f,$meta,$db,$insert){while(($line=self::gzLine($f))!==null){$cells=json_decode($line,true,512,JSON_THROW_ON_ERROR);if(count($cells)!==count($meta['columns']))throw new \RuntimeException('Ligne de sauvegarde invalide.');$cells=array_map(static function($v){if($v===null)return null;$x=base64_decode($v,true);if($x===false)throw new \RuntimeException('Valeur de sauvegarde invalide.');return $x;},$cells);$db->setQuery($insert.self::sqlValues($cells).')')->execute();}});}finally{gzclose($f);}
            if(self::scan($shadow)!==$meta['fingerprint'])throw new \DomainException('La restauration de contrôle diffère de la sauvegarde : '.$name.'.',409);
        }finally{$db->setQuery('DROP TABLE '.$db->quoteName($shadow))->execute();$s['shadow']=null;self::save($s);}
    }
    private static function cleanupShadow(array &$s): void
    {
        if(!$s['shadow'])return;$db=self::db();$i=(int)$s['shadow']['index'];$expected='gp_innodb_verify_'.substr(hash('sha256',$s['id'].':'.$i),0,24);if($s['shadow']['name']!==$expected)throw new \RuntimeException('Identité de copie temporaire invalide.');$exists=$db->setQuery('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='.$db->quote($expected))->loadResult();
        if($exists){if(empty($s['shadow']['created']))throw new \DomainException('La création de la copie temporaire n’a pas été confirmée. Inspection manuelle requise : '.$expected.'.',409);$ddl=self::ddl($expected);$original=self::ddl($s['backups'][$i]['table']);$ddl=str_replace($db->quoteName($expected),$db->quoteName($s['backups'][$i]['table']),$ddl);if(!hash_equals(self::schemaHash($ddl),self::schemaHash($original)))throw new \DomainException('La copie temporaire a changé : inspection requise.',409);$db->setQuery('DROP TABLE '.$db->quoteName($expected))->execute();}$s['shadow']=null;self::save($s);
    }
    private static function unchanged(array $s,int $i): void
    {
        $meta=$s['backups'][$i];$dir=self::directory($s['id']);if(!hash_equals($meta['data_sha256'],hash_file('sha256',$dir.'/table-'.$i.'.rows.jsonl.gz'))||!hash_equals($meta['sql_sha256'],hash_file('sha256',$dir.'/table-'.$i.'.sql.gz')))throw new \DomainException('Empreinte de sauvegarde invalide : '.$meta['table'].'.',409);
        if(!hash_equals($meta['schema_hash'],self::schemaHash(self::ddl($meta['table'])))||self::scan($meta['table'])!==$meta['fingerprint'])throw new \DomainException('La table a changé depuis sa sauvegarde. Gardez le site hors ligne et arrêtez les tâches qui écrivent : '.$meta['table'].'.',409);
    }
    public static function step(string $id): array
    {
        self::admin();self::offline();return self::locked(static function()use($id){$s=self::load($id);if($s['status']==='done')return self::publicState($s);if($s['status']==='archived')throw new \DomainException('Ce journal est archivé. Relancez un diagnostic pour préparer une nouvelle migration.',409);
            try{self::cleanupShadow($s);$step=$s['steps'][$s['index']];$stage=$step['stage'];
                if($stage==='backup')$receipt=self::backup($s,(int)$step['table']);
                elseif($stage==='precheck'){foreach(array_keys($s['backups'])as$i)self::unchanged($s,(int)$i);$receipt=['stage'=>'precheck','data_verified'=>true,'at'=>gmdate('c')];}
                elseif($stage==='convert'){$i=(int)$step['table'];$name=$s['tables'][$i]['name'];self::unchanged($s,$i);$before=self::engine($name);if(strcasecmp($before,'InnoDB')!==0){if(strcasecmp($before,$s['tables'][$i]['engine'])!==0)throw new \DomainException('Moteur modifié depuis la préparation : '.$name.'.',409);self::checkTable($name);$db=self::db();$db->setQuery('SET SESSION lock_wait_timeout=10')->execute();$counter=$s['backups'][$i]['auto_increment'];if($counter!==null&&!preg_match('/^[1-9][0-9]{0,19}$/D',$counter))throw new \RuntimeException('Compteur natif invalide.');self::preserveLegacyValues(static fn()=>$db->setQuery('ALTER TABLE '.$db->quoteName($name).' ENGINE=InnoDB'.($counter!==null?', AUTO_INCREMENT='.$counter:''))->execute());}self::unchanged($s,$i);if(strcasecmp(self::engine($name),'InnoDB')!==0)throw new \RuntimeException('Le moteur n’a pas changé.');$receipt=['table'=>$name,'stage'=>'convert','engine_before'=>$before,'engine_after'=>'InnoDB','rows'=>$s['backups'][$i]['fingerprint']['rows'],'schema_verified'=>true,'data_verified'=>true,'at'=>gmdate('c')];}
                else{$audit=self::audit();if(!$audit['ready'])throw new \DomainException('Certaines tables requises ne sont pas encore InnoDB.',409);foreach(array_keys($s['backups'])as$i){self::unchanged($s,(int)$i);if(strcasecmp(self::engine($s['tables'][$i]['name']),'InnoDB')!==0)throw new \DomainException('Un moteur a changé pendant la migration.',409);}$receipt=['stage'=>'verify','data_verified'=>true,'at'=>gmdate('c')];}
                $s['receipts'][]=$receipt;$s['index']++;$s['status']=$stage==='verify'?'done':'pending';$s['error']=null;self::save($s);return self::publicState($s);
            }catch(\Throwable $e){$s['status']='failed';$s['error']=$e->getMessage();self::save($s);throw $e;}
        });
    }
    public static function backupFile(string $id,int $i): string
    {
        self::admin();$s=self::load($id);if(!isset($s['backups'][$i]))throw new \DomainException('Sauvegarde inconnue.',404);$p=self::directory($id).'/table-'.$i.'.sql.gz';if(is_link($p)||!is_file($p)||!hash_equals($s['backups'][$i]['sql_sha256'],hash_file('sha256',$p)))throw new \DomainException('Sauvegarde indisponible ou modifiée.',409);return $p;
    }
    public static function archive(string $id): array
    {
        self::admin();self::offline();return self::locked(static function()use($id){$s=self::load($id);self::cleanupShadow($s);$s['status']='archived';self::save($s);if(is_file(self::pointer()))unlink(self::pointer());return ['status'=>'not_started','backups_retained'=>true,'engines_rolled_back'=>false];});
    }
}
