# Choisir une configuration PC à partir des jeux et de l’écran, pas d’une liste de composants

Un PC de jeu se choisit à partir d’une situation : quels jeux, sur quel écran, avec quels réglages et quelle tolérance aux ralentissements ? Commencer par une carte graphique ou un processeur inverse le problème. Une machine peut être adaptée à un jeu compétitif peu exigeant visuellement et décevante pour une simulation chargée, sans que son prix explique à lui seul cette différence.

## Décrire le résultat attendu avant le matériel

Écrivez trois scénarios représentatifs. Pour chacun, notez le jeu, sa version, la définition de l’écran, les réglages importants et le type de séquence : exploration, combat, ville dense ou partie en ligne. Ajoutez une contrainte de bruit, d’encombrement ou de consommation si elle compte réellement. Une configuration silencieuse sous le bureau ne répond pas au même cahier des charges qu’un ordinateur transporté chaque semaine.

La fréquence de l’écran indique le nombre de rafraîchissements possibles par seconde ; elle ne garantit pas que le jeu produira autant d’images régulières. Pour suivre le mouvement, le temps entre les images compte aussi. À cadence constante, 60 images par seconde correspondent à environ 16,7 millisecondes par image ; 120 correspondent à environ 8,3 millisecondes. Ce calcul explique un objectif de cadence, pas le comportement d’un jeu particulier.

## Construire une fiche de décision comparable

| Question | Information à conserver | Pourquoi elle change le choix |
|---|---|---|
| Que jouerez-vous ? | Trois jeux et leurs versions | Les charges diffèrent selon le moteur et la scène |
| Que doit afficher l’écran ? | Définition, fréquence, réglages | Une comparaison doit garder le même objectif visuel |
| Qu’acceptez-vous de réduire ? | Réglages négociables et indispensables | Le compromis devient explicite avant l’achat |
| Que faut-il financer ? | Tour, écran, périphériques et marge de maintenance | Le budget ne se limite pas à un composant |

Un benchmark devient exploitable lorsqu’il décrit sa configuration, ses réglages et sa procédure. Deux chiffres pris sur des scènes différentes ne constituent pas une confrontation équitable. Conservez aussi la date du test : une mise à jour du jeu ou des pilotes peut rendre une conclusion moins représentative.

## Un budget fictif pour mettre les compromis à plat

Supposons une enveloppe totale de 1 400 euros, dont 250 pour l’écran et 150 pour les périphériques et petits équipements. Il reste 1 000 euros pour la tour. Ce sont des hypothèses de calcul, pas des prix de marché. Si une proposition consacre déjà 1 350 euros à la tour, elle ne respecte pas le besoin de départ, même si son rapport performances/prix paraît séduisant.

Comparez ensuite deux configurations candidates sur les trois mêmes scénarios. Une proposition qui gagne nettement dans un jeu rarement utilisé peut être moins pertinente qu’une autre, plus régulière dans le jeu principal et plus compatible avec le bruit accepté. Documentez la raison du compromis plutôt que de désigner un vainqueur universel.

## Vérifier la décision après l’achat

Gardez la fiche de départ pour la réception. Vérifiez le modèle des pièces, les branchements, l’affichage et les conditions d’un essai reproductible. Si un résultat diffère fortement d’un test, cherchez d’abord une différence de réglage ou de contexte avant de conclure à une panne.

- Définissez les usages avant de choisir des références.
- Comparez des tests dont les conditions sont explicites.
- Faites entrer tous les achats dans la même enveloppe.
- Notez le compromis accepté et la condition qui ferait changer de choix.

L’étape suivante consiste à examiner les temps de trame et les ralentissements, puis à ouvrir une discussion avec les paramètres de votre scénario. Une réponse communautaire sera plus précise avec ce dossier qu’avec la seule question « Quelle est la meilleure configuration ? ».

## Lire les temps de trame sans se laisser piéger par une moyenne

Une série fictive de dix images comporte neuf durées de 8 ms et une durée de 80 ms. Sa durée totale est de 152 ms : dix images produites dans cet intervalle correspondent à environ 65,8 images par seconde. Pourtant, l’arrêt de 80 ms reste perceptible. La moyenne résume le débit de cette série ; elle ne raconte pas la régularité du mouvement. Présentez le graphe des durées et localisez les écarts au lieu de publier uniquement un grand chiffre de FPS.

Un « 1 % low » doit être accompagné de sa méthode de calcul : le terme seul ne garantit pas que deux outils agrègent les données de la même façon. Indiquez aussi si vous mesurez des images calculées, présentées ou effectivement affichées. La documentation de PresentMon distingue notamment des durées et latences CPU, GPU et d’affichage. Elle signale des limites d’instrumentation selon les API et certains réglages de planification GPU : conserver ces conditions dans le compte rendu aide à comparer des résultats.

## Un protocole de comparaison que l’on peut reprendre

Choisissez une séquence reproductible, par exemple une sauvegarde et un trajet décrits. Notez les versions du système, du pilote et du jeu, l’alimentation, la température ambiante si elle est mesurée et les tâches actives. Faites un passage de préparation, puis plusieurs captures comparables. Cette proposition de procédure ne remplace pas les recommandations de l’outil et ne prouve pas qu’un nombre fixe de passages convient à tous les jeux.

Si vous changez simultanément la définition, la génération d’images et un réglage de qualité, vous comparez deux expériences complètes. Pour attribuer un gain à un seul réglage, modifiez une variable à la fois. Conservez le fichier brut et expliquez toute exclusion d’une séquence. Une compilation de shaders ou un chargement ne disparaît pas du vécu du joueur parce que son retrait améliore la moyenne.

## Quand faut-il conserver sa machine ?

Avant un achat, vérifiez si le scénario principal échoue réellement : réglage trop ambitieux, écran mal configuré, problème thermique ou limite matérielle observée. Si un compromis acceptable rétablit l’usage voulu, le remplacement peut attendre. À l’inverse, un défaut dans la scène indispensable mérite davantage de poids qu’une victoire dans une démonstration rarement utilisée. Le carnet joint sert à enregistrer ce choix et sa justification, pas à produire une recommandation automatique de matériel.
