<?php
declare(strict_types=1);
namespace Geniuspace;

final class ProjectWorkspace
{
    public static function render(): string
    {
        static $done=false;if($done||!ProductAccess::user()->id)return '';$done=true;Ergonomics::assets();
        $base=\Joomla\CMS\Uri\Uri::root(true).'/media/com_joomcck/nexus/';$doc=\Joomla\CMS\Factory::getApplication()->getDocument();$doc->addStyleSheet($base.'project-workspace.css',['version'=>'5.27.0']);$doc->addScript($base.'project-workspace.js',['version'=>'5.27.0'],['type'=>'module']);
        $endpoint=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.';
        return '<dialog class="nx-project-dialog" data-project-dialog data-endpoint="'.Text::escape($endpoint).'" data-csrf="'.Text::escape(\Joomla\CMS\Session\Session::getFormToken()).'" aria-labelledby="nx-project-title"><header><div><small>GENIUSPACE · DU PROJET AU RÉSULTAT</small><h2 id="nx-project-title">Mes missions & dossiers</h2></div><button type="button" data-project-close aria-label="Fermer les missions">×</button></header><nav class="nx-project-tabs" aria-label="Mon espace de travail"><button type="button" data-project-view="projects" aria-pressed="true">✦ Missions</button><button type="button" data-project-view="work_queue">💼 Travail pro</button><button type="button" data-project-view="ai_progress">✧ Progrès IA</button></nav><p role="status" data-project-status></p><div data-project-content></div></dialog>';
    }
}
