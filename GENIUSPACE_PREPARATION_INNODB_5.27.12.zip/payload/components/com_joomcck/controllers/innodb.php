<?php
defined('_JEXEC') or die;
require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php';

/** Separate native controller: installing this helper does not replace 5.27.11 files. */
class JoomcckControllerInnodb extends MControllerBase
{
    private function guard(bool $post=true): void
    {
        $app=\Joomla\CMS\Factory::getApplication();$u=$app->getIdentity();if(!$app->isClient('administrator')||!$u->id||$u->block||!$u->authorise('core.admin'))throw new \DomainException('Accès super administrateur requis.',403);
        if($post&&($app->getInput()->getMethod()!=='POST'||!\Geniuspace\Tokens::valid()))throw new \DomainException('Jeton ou méthode invalide.',403);
        $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');if($origin!==''&&!hash_equals($authority,$origin))throw new \DomainException('Origine invalide.',403);
    }
    public function operation(): void
    {
        $app=\Joomla\CMS\Factory::getApplication();$input=$app->getInput();$status=200;
        try{$this->guard();$stage=$input->post->getCmd('stage','audit');
            $body=match($stage){
                'audit'=>\Geniuspace\InnoDbMaintenance::audit(),
                'status'=>\Geniuspace\InnoDbMaintenance::status(),
                'start'=>\Geniuspace\InnoDbMaintenance::start($input->post->getCmd('scope','repair'),$input->post->getInt('writers_stopped')===1),
                'step'=>\Geniuspace\InnoDbMaintenance::step($input->post->getCmd('job')),
                'archive'=>\Geniuspace\InnoDbMaintenance::archive($input->post->getCmd('job')),
                default=>throw new \DomainException('Action inconnue.',400)
            };
        }catch(\DomainException $e){$status=in_array($e->getCode(),[400,403,404,409],true)?$e->getCode():400;$body=['error'=>$e->getMessage()];if($e->getMessage()==='Une étape est déjà en cours.')$body['retry_after']=2;}
        catch(\Throwable $e){$status=503;$body=['error'=>'Étape interrompue. Gardez le site en maintenance et consultez le journal Joomla avant de reprendre.'];\Joomla\CMS\Log\Log::add('InnoDB maintenance: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex, nofollow',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function backup(): void
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{$this->guard(false);if($app->getInput()->getMethod()!=='GET')throw new \DomainException('Méthode interdite.',405);$i=$app->getInput()->getInt('table',-1);$p=\Geniuspace\InnoDbMaintenance::backupFile($app->getInput()->getCmd('job'),$i);$app->setHeader('Content-Type','application/gzip',true);$app->setHeader('Content-Disposition','attachment; filename="geniuspace-avant-innodb-table-'.$i.'.sql.gz"',true);$app->setHeader('Content-Length',(string)filesize($p),true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->setHeader('X-Robots-Tag','noindex, nofollow',true);$app->sendHeaders();readfile($p);$app->close();}
        catch(\DomainException $e){http_response_code(in_array($e->getCode(),[403,404,405,409],true)?$e->getCode():400);$app->setHeader('Content-Type','text/plain; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->sendHeaders();echo 'Sauvegarde indisponible.';$app->close();}
    }
}
