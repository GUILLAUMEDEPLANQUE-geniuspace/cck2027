# Reprendre une activité physique : préparer un objectif et un contexte avant un programme

Reprendre une activité physique commence par une situation réelle : temps disponible, pratique envisagée, expérience, contraintes et besoin éventuel d’un avis professionnel. Choisir immédiatement un programme standard peut masquer la question la plus utile : qu’est-ce qui rendra la prochaine séance appropriée et réellement praticable ? Ce dossier aide à préparer cet échange ; il ne prescrit pas un entraînement individuel.

## Définir un objectif que l’on peut observer

« Me remettre en forme » peut recouvrir des attentes très différentes. Une personne souhaite rejoindre un cours collectif ; une autre veut retrouver une habitude de déplacement ou préparer une pratique particulière. Décrivez l’activité visée et une situation qui montrerait une amélioration, sans choisir un indicateur uniquement parce qu’il est facile à afficher.

Un objectif n’est pas une obligation de progresser à la même vitesse qu’un autre membre. Il doit pouvoir être ajusté lorsque le contexte change. Si un problème de santé, une douleur ou une inquiétude particulière intervient, la décision adaptée relève d’un professionnel compétent, pas d’un classement communautaire.

## Préparer les informations utiles à l’encadrant

| Dimension | Ce qu’il est utile de clarifier | Ce qui peut rester privé dans la communauté |
|---|---|---|
| Pratique | Activité envisagée et expérience pertinente | Détails personnels sans intérêt pour la discussion |
| Organisation | Créneaux, déplacements et régularité possible | Adresse ou emploi du temps détaillé |
| Accompagnement | Accueil des débutants et modalités de progression | Documents de santé à transmettre uniquement au bon interlocuteur |
| Conditions | Équipement, règles et coûts annoncés | Informations financières personnelles |
| Réexamen | Quand faire le point et avec qui ? | Données que l’on ne souhaite pas partager publiquement |

Pour un club, demandez comment se déroule une première séance, qui encadre et comment sont gérées les différences de niveau. Les réponses doivent être concrètes : déroulé, interlocuteur et conditions d’accueil. Une promesse générale d’adaptation ne remplace pas cette compréhension.

## Réduire la friction avant de rechercher l’intensité

Prenons un exemple d’organisation, sans prescription d’effort. Une personne dispose de deux créneaux possibles dans sa semaine, mais l’un exige un trajet difficile à tenir. Choisir le créneau le plus réaliste peut être plus utile que construire un calendrier théorique qui échoue dès la deuxième semaine.

Préparer le sac, comprendre la réservation et identifier le trajet de retour sont de petites décisions, mais elles influencent la possibilité de participer. Ce raisonnement porte sur l’organisation ; le contenu et l’intensité des séances doivent être adaptés au contexte et à l’encadrement.

## Tenir une trace courte et interprétable

Après une séance, quelques informations peuvent suffire : activité réalisée, contexte, ressenti utile et question à poser. Évitez de transformer chaque mesure issue d’un appareil en diagnostic ou en obligation quotidienne.

Une observation isolée demande souvent du contexte. Un mauvais résultat ou une séance manquée ne démontre pas à lui seul que le projet est mal choisi. La trace sert à préparer une discussion et à repérer une tendance, pas à produire automatiquement une conclusion médicale.

## Prévoir un point de révision

Fixez avec l’interlocuteur approprié le moment où l’on vérifiera si l’organisation et les objectifs conviennent. Notez aussi les questions qui ne peuvent pas être résolues par des conseils généraux.

Une communauté accueillante aide à formuler ces questions, à comprendre les conditions d’une pratique et à partager des expériences bien délimitées. Elle ne doit pas transformer une reprise en compétition de chiffres ni attribuer à tous les membres le même besoin d’entraînement.
