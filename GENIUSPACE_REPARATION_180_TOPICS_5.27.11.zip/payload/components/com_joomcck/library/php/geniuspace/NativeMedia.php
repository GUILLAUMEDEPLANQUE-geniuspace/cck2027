<?php
declare(strict_types=1);
namespace Geniuspace;
/** Media bytes stay outside the web root; content and ownership stay in native CCK tables. */
final class NativeMedia
{
    public static function root(int $field): string
    {return dirname(JPATH_ROOT).'/.nexus-native-media/'.substr(hash('sha256',JPATH_ROOT),0,16).'/'.max(0,$field);}
    public static function path(array|object $file): string
    {
        $f=(array)$file;if(empty($f['field_id']))$f=ProductAccess::store()->rows('SELECT * FROM #__js_res_files WHERE id='.(int)($f['id']??0),1)[0]??[];
        $path=str_replace('\\','/',(string)($f['fullpath']??''));if(!$path||str_starts_with($path,'/')||str_contains($path,"\0")||in_array('..',explode('/',$path),true))throw new \DomainException('Fichier introuvable.',404);
        return self::root((int)$f['field_id']).'/'.$path;
    }
    public static function url(int $id,int $width=0): string
    {return \Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.nativeMedia&file='.$id.($width?'&w='.$width:'');}
    public static function protectedFile(array|object $file,int $field=0): bool
    {try{$f=(array)$file;if($field)$f['field_id']=$field;return is_file(self::path($f));}catch(\DomainException){return false;}}
    public static function stream(int $id): void
    {
        $app=\Joomla\CMS\Factory::getApplication();$method=strtoupper($_SERVER['REQUEST_METHOD']??'GET');if(!in_array($method,['GET','HEAD'],true))throw new \DomainException('Lecture seule.',405);
        $s=ProductAccess::store();$file=$s->rows('SELECT * FROM #__js_res_files WHERE id='.max(0,$id),1)[0]??null;if(!$file||(int)$file['saved']===2)throw new \DomainException('Fichier introuvable.',404);
        $field=$s->rows('SELECT * FROM #__js_res_fields WHERE id='.(int)$file['field_id'].' AND published=1',1)[0]??null;$params=new \Joomla\Registry\Registry($field['params']??'{}');if(!$field)throw new \DomainException('Fichier introuvable.',404);
        if(ProductAccess::user()->id&&ProductAccess::user()->block)throw new \DomainException('Compte désactivé.',403);
        if((int)$file['saved']!==1){if(!ProductAccess::user()->id||(int)ProductAccess::user()->id!==(int)$file['user_id'])throw new \DomainException('Média non publié.',404);if((int)$file['record_id'])ProductAccess::editable((int)$file['record_id']);}
        else{$r=ProductAccess::visible((int)$file['record_id']);$levels=ProductAccess::user()->getAuthorisedViewLevels();if((int)$r['type_id']!==(int)$field['type_id']||!in_array((int)$field['access'],$levels,true)||!in_array((int)$params->get('core.field_view_access',1),$levels,true)||!\CEmeraldHelper::allowField('view',(object)array_replace($field,['params'=>$params]),(int)ProductAccess::user()->id,\ItemsStore::getSection((int)$r['section_id']),(object)$r,false,false))throw new \DomainException('Field inaccessible.',404);$values=json_decode($r['fields'],true)?:[];$a=['value'=>$values[(int)$file['field_id']]??''];$has=false;$walk=function($v)use(&$walk,&$has,$file){if(is_array($v)){foreach($v as$x)$walk($x);}elseif($v===$file['filename'])$has=true;};$walk($a['value']);if(!$has)throw new \DomainException('Média retiré de ce field.',404);}
        $path=self::path($file);
        // An existing legacy file is not moved implicitly when an administrator enables the option.
        if(!is_file($path)){$base=(string)\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck')->get('general_upload');$path=JPATH_ROOT.'/'.trim($base,'/').'/'.trim((string)$params->get('params.subfolder',$field['field_type']),'/').'/'.$file['fullpath'];}
        if(!is_file($path))throw new \DomainException('Média indisponible.',404);
        $mime=(new \finfo(FILEINFO_MIME_TYPE))->file($path);$width=$app->input->getInt('w');
        if($width&&str_starts_with($mime,'image/')&&in_array($width,[64,256,768,1200],true)&&function_exists('imagewebp')){
            $cache=self::root((int)$file['field_id']).'/.variants/'.hash('sha256',$file['filename'].filemtime($path)).'-'.$width.'.webp';
            if(!is_file($cache)){$dimensions=@getimagesize($path);$limit=ini_get('memory_limit');$bytes=(int)$limit;if(str_ends_with(strtolower($limit),'g'))$bytes*=1073741824;elseif(str_ends_with(strtolower($limit),'m'))$bytes*=1048576;elseif(str_ends_with(strtolower($limit),'k'))$bytes*=1024;
                if($dimensions&&($bytes<0||$dimensions[0]*$dimensions[1]*5+filesize($path)*2<$bytes-memory_get_usage(true)-16777216)){
                    $source=@imagecreatefromstring((string)file_get_contents($path));if($source){$w=min($width,imagesx($source));$h=max(1,(int)round(imagesy($source)*$w/imagesx($source)));$dest=imagecreatetruecolor($w,$h);imagealphablending($dest,false);imagesavealpha($dest,true);imagecopyresampled($dest,$source,0,0,0,0,$w,$h,imagesx($source),imagesy($source));if(!is_dir(dirname($cache)))\Joomla\Filesystem\Folder::create(dirname($cache),0700);$tmp=$cache.'.'.bin2hex(random_bytes(6));if(imagewebp($dest,$tmp,82))rename($tmp,$cache);imagedestroy($source);imagedestroy($dest);}
                }
            }
            if(is_file($cache)){$path=$cache;$mime='image/webp';}
        }
        if(strtolower($file['ext'])==='vtt')$mime='text/vtt';
        $size=filesize($path);$start=0;$end=$size-1;$range=(string)($_SERVER['HTTP_RANGE']??'');
        if($range){if(!preg_match('/^bytes=(\d*)-(\d*)$/D',$range,$m)||($m[1]===''&&$m[2]===''))throw new \DomainException('Plage invalide.',416);if($m[1]==='')$start=max(0,$size-(int)$m[2]);else{$start=(int)$m[1];if($m[2]!=='')$end=min($end,(int)$m[2]);}if($start>$end||$start>=$size)throw new \DomainException('Plage invalide.',416);http_response_code(206);$app->setHeader('Content-Range','bytes '.$start.'-'.$end.'/'.$size,true);}
        $app->setHeader('Content-Type',$mime,true);$app->setHeader('Content-Length',(string)($end-$start+1),true);$app->setHeader('Accept-Ranges','bytes',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Content-Type-Options','nosniff',true);
        if(!str_starts_with($mime,'video/')&&!in_array($mime,['image/jpeg','image/png','image/webp','image/avif','image/gif'],true)&&!str_starts_with($mime,'audio/')&&$mime!=='text/vtt')$app->setHeader('Content-Disposition',"attachment; filename*=UTF-8''".rawurlencode($file['realname']),true);
        $app->getSession()->close();if(function_exists('set_time_limit'))@set_time_limit(0);
        $app->sendHeaders();if($method!=='HEAD'){$handle=fopen($path,'rb');fseek($handle,$start);$remaining=$end-$start+1;while($remaining>0&&!feof($handle)&&!connection_aborted()){$bytes=fread($handle,min(1048576,$remaining));if($bytes===false)break;echo$bytes;$remaining-=strlen($bytes);}fclose($handle);}$app->close();
    }
}
