<?php
declare(strict_types=1);
namespace Geniuspace;

/** Local bounded extraction. The author reviews returned text before placing it in a public native field. */
final class DocumentInsights
{
    public static function pdfBytes(string $bytes): string
    {
        if(!str_starts_with($bytes,'%PDF-')||strlen($bytes)>2*1024*1024)throw new \InvalidArgumentException('PDF privé de 2 Mo maximum.');
        $tmp=tempnam(sys_get_temp_dir(),'gp-vault-');if(!$tmp)throw new \DomainException('Stockage temporaire indisponible.',503);
        try{chmod($tmp,0600);file_put_contents($tmp,$bytes);return self::run(['/usr/bin/pdftotext','-f','1','-l','20','-layout','-nopgbrk',$tmp,'-']);}
        finally{if(is_file($tmp))unlink($tmp);}
    }
    public static function extract(int $record,int $field,int $file): array
    {
        $access=new NativeAccess();$r=$access->record($record);if(!$r||!isset($r['fields'][$field])||$r['fields'][$field]['field_type']!=='uploads')throw new \DomainException('Champ documentaire public inaccessible.',404);
        $p=FieldOptions::params($r['fields'][$field]['params']);if(empty($p['geniuspace_extract']))throw new \DomainException('Extraction désactivée pour ce champ.',403);
        $store=new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class));$row=$store->rows('SELECT fullpath,realname FROM #__js_res_files WHERE id='.$file.' AND field_id='.$field.' AND record_id='.$record.' AND saved=1',1)[0]??null;
        if(!$row)throw new \DomainException('Fichier introuvable.',404);
        $params=\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck');$root=realpath(JPATH_ROOT.'/'.$params->get('general_upload','images/joomcck').'/'.($p['subfolder']??'uploads'));
        $path=$root?realpath($root.'/'.$row['fullpath']):false;
        if(!$root||!$path||!str_starts_with($path,$root.DIRECTORY_SEPARATOR)||!is_file($path)||filesize($path)>5*1024*1024)throw new \InvalidArgumentException('Chemin ou taille de fichier refusé.');
        $ext=strtolower(pathinfo($path,PATHINFO_EXTENSION));$mime=(new \finfo(FILEINFO_MIME_TYPE))->file($path);$text='';$method='texte';
        if(in_array($ext,['txt','csv'],true)&&in_array($mime,['text/plain','text/csv'],true))$text=(string)file_get_contents($path,false,null,0,100001);
        elseif($ext==='pdf'&&$mime==='application/pdf'){$text=self::run(['/usr/bin/pdftotext','-f','1','-l','50','-layout','-nopgbrk',$path,'-']);$method='PDF texte (50 premières pages maximum)';}
        elseif(in_array($ext,['png','jpg','jpeg','webp'],true)&&str_starts_with($mime,'image/')&&!empty($p['geniuspace_ocr'])){$size=@getimagesize($path);if(!$size||$size[0]*$size[1]>12000000)throw new \InvalidArgumentException('Image trop grande pour OCR.');$text=self::run(['/usr/bin/tesseract',$path,'stdout','--psm','3']);$method='OCR à corriger';}
        else throw new \InvalidArgumentException('Format non extractible : texte UTF-8, PDF textuel ou image avec OCR activé.');
        if(!mb_check_encoding($text,'UTF-8'))throw new \InvalidArgumentException('L’extraction ne produit pas de texte UTF-8.');
        $truncated=strlen($text)>100000;$text=mb_strcut($text,0,100000,'UTF-8');
        return ['filename'=>Text::plain($row['realname']),'checksum'=>hash_file('sha256',$path),'method'=>$method,'text'=>trim($text),'truncated'=>$truncated,'review_required'=>true];
    }
    private static function run(array $command): string
    {
        if(!function_exists('proc_open')||!is_executable($command[0]))throw new \DomainException('Extracteur local non disponible. Installer pdftotext ou Tesseract sur le serveur.',503);
        $process=proc_open($command,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,null,['PATH'=>'/usr/bin:/bin','OMP_THREAD_LIMIT'=>'1']);if(!is_resource($process))throw new \DomainException('Extracteur indisponible.',503);
        fclose($pipes[0]);stream_set_blocking($pipes[1],false);stream_set_blocking($pipes[2],false);$out='';$start=microtime(true);$last=null;
        try{do{$out.=(string)stream_get_contents($pipes[1],max(0,100001-strlen($out)));stream_get_contents($pipes[2],8192);$last=proc_get_status($process);if(strlen($out)>100000)break;if(microtime(true)-$start>8){proc_terminate($process,9);throw new \DomainException('Extraction trop longue : utiliser un extrait plus court.',503);}if($last['running'])usleep(20000);}while($last['running']);if($last['exitcode']!==0&&!$last['running'])throw new \InvalidArgumentException('Le fichier ne peut pas être extrait.');}
        finally{if($last&&$last['running'])proc_terminate($process,9);fclose($pipes[1]);fclose($pipes[2]);proc_close($process);}return $out;
    }
    public static function tools(object $record,int $field): string
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id||((int)$record->user_id!==(int)$user->id&&!$user->authorise('core.admin')))return '';
        $store=new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class));$files=$store->rows('SELECT id,realname FROM #__js_res_files WHERE record_id='.(int)$record->id.' AND field_id='.$field.' AND saved=1 ORDER BY id',40);if(!$files)return '';
        $doc=\Joomla\CMS\Factory::getDocument();$doc->addScript(\Joomla\CMS\Uri\Uri::root(true).'/components/com_joomcck/library/php/geniuspace/media/content-insights.js',[],['defer'=>true]);
        $out='<details class="gp-document-tools" data-record="'.(int)$record->id.'" data-field="'.$field.'" data-api="'.Text::escape(\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.assist').'" data-csrf="'.Text::escape(\Joomla\CMS\Session\Session::getFormToken()).'"><summary>Extraire un texte à vérifier pour cette fiche</summary>';
        foreach($files as$file)$out.='<button type="button" data-extract="'.(int)$file['id'].'">'.Text::escape($file['realname']).'</button>';
        return $out.'<textarea rows="8" readonly aria-label="Texte extrait à vérifier"></textarea><output aria-live="polite"></output><p>Corrigez l’extrait et ajoutez un résumé sourcé à votre champ HTML/JCE. Le fichier d’origine reste inchangé.</p></details>';
    }
}
