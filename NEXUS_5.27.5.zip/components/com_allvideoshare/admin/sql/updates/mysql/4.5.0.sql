ALTER TABLE `#__allvideoshare_cache` MODIFY `value` MEDIUMTEXT NULL;
