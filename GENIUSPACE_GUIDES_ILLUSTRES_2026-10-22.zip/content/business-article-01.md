# Choisir un modèle économique à partir du problème client et des coûts réels

Un modèle économique est une façon de relier un besoin client à une offre, des coûts et une capacité de livraison. Le choisir ne consiste pas seulement à fixer un prix ou à copier un abonnement qui fonctionne ailleurs. La question décisive est plus concrète : qui obtient quel résultat, qui paie et qu’est-ce que l’entreprise doit mobiliser pour tenir sa promesse ?

## Décrire une transaction avant de dessiner un grand marché

Prenez un client plausible et une situation précise. Écrivez le problème, l’alternative qu’il utilise déjà, le résultat attendu et les conditions d’achat. « Les petites entreprises ont besoin de visibilité » est trop large pour dimensionner une offre. « Un atelier veut recevoir des demandes de devis mieux renseignées » permet déjà de discuter d’un livrable et de ses limites.

Ne transformez pas un entretien intéressé en preuve d’achat. Notez ce que la personne a expliqué, les documents ou usages observés et les questions encore ouvertes. L’intérêt, l’engagement et le paiement sont des étapes distinctes.

## Séparer valeur, prix et coût de livraison

| Élément | Question à résoudre | Trace utile |
|---|---|---|
| Valeur proposée | Quel problème est suffisamment important pour être traité ? | Situation et alternative actuelles du client |
| Prix | Quel montant et quelles conditions seront réellement proposés ? | Offre datée, périmètre et exclusions |
| Coût variable | Que coûte une livraison supplémentaire ? | Temps, achats, sous-traitance et support |
| Capacité | Combien de livraisons peuvent être tenues correctement ? | Planning et responsabilités |
| Trésorerie | Quand les dépenses et encaissements auront-ils lieu ? | Calendrier des flux, pas seulement une marge |

## Faire un calcul limité mais honnête

Supposons un service vendu 800 euros, avec 200 euros de dépenses variables identifiées. La différence de 600 euros ne constitue pas automatiquement un bénéfice : il reste notamment à traiter les autres charges, le temps de travail, la structure de l’activité et les obligations applicables. Les montants de cet exemple sont fictifs.

Si une livraison demande douze heures, quatre ventes mobilisent quarante-huit heures avant les tâches commerciales et administratives. Une promesse de dix livraisons peut donc être incohérente avec le temps disponible, même si chaque vente semble rentable dans un tableau incomplet.

Ce test sert à trouver la question suivante : réduire le périmètre, changer la méthode, déléguer une partie ou revoir le prix. Il ne remplace pas une simulation professionnelle adaptée au statut et au pays de l’activité.

## Tester l’offre sans masquer son niveau de maturité

Présentez un périmètre que vous pouvez réellement livrer. Définissez un résultat, un délai, ce qui est fourni par le client et une règle d’acceptation. Si l’offre est un pilote, dites-le ; ne lui attribuez pas des références ou des performances inexistantes.

Choisissez ensuite un critère pour poursuivre, modifier ou arrêter le test. Ce peut être la qualité des demandes reçues, le temps réel de livraison ou une étape d’engagement définie à l’avance. Un simple nombre de visites ne répond pas à toutes ces questions.

## Conserver une décision révisable

Le dossier doit montrer les hypothèses qui ont justifié le choix et ce qui pourrait les invalider. Une entreprise pourra ainsi expliquer pourquoi son offre a évolué, au lieu de présenter chaque modification comme une nouvelle certitude.

La prochaine étape est de confronter le coût et le calendrier d’encaissement, puis de transformer les questions clients en améliorations du périmètre. Cette continuité rend le modèle économique plus utile qu’un diagramme rempli une seule fois.

## Vérifier la capacité avant de multiplier les clients

Prenons un service fictif facturé 800 euros, avec 200 euros de coûts variables identifiés et huit heures de travail prévues. L’écart de 600 euros n’est ni un salaire net ni un bénéfice : restent notamment les charges fixes, la prospection, les corrections, les prélèvements applicables et les périodes sans mission. Si quatre heures supplémentaires deviennent nécessaires, le revenu rapporté au temps change alors que le chiffre d’affaires est identique.

Définissez donc l’unité vendue : résultat attendu, livrables, nombre de révisions, responsabilités, délai et conditions d’acceptation. Une prestation dont la frontière est floue ne devient pas rentable par l’ajout d’un tableau de bord. Avant de promettre une date, retirez du calendrier les obligations déjà engagées et les temps indispensables de gestion.

## Un seuil de rentabilité illustré, avec ses hypothèses

Dans une seconde simulation, une activité supporte 1 200 euros de coûts fixes mensuels et conserve 150 euros de marge sur coûts variables par vente, selon les coûts retenus. Le seuil arithmétique est de huit ventes pour couvrir ces seuls coûts fixes. Ce calcul ne démontre ni l’existence de huit acheteurs ni une rémunération suffisante pour l’exploitant. Si le périmètre des coûts change, le seuil doit être recalculé.

Distinguez ensuite commande, facture et encaissement. Une activité peut vendre sans disposer immédiatement de l’argent nécessaire à ses dépenses. Le carnet sépare date prévue d’encaissement, coûts engagés et incertitudes ; aucune prévision ne doit être présentée comme une recette garantie.

## Tester une offre sans construire tout le dispositif

Choisissez une hypothèse à tester : le problème est-il assez important, le périmètre est-il compréhensible, le client accepte-t-il les modalités proposées ? Un entretien n’est pas une commande. Une intention positive n’est pas un paiement. Notez ce qui a été observé et ce qui reste à vérifier. La prochaine version de l’offre doit répondre à un résultat du test, plutôt qu’ajouter des fonctionnalités pour rendre le projet plus impressionnant.

Dans un univers communautaire, une entreprise peut relier sa présentation, une ressource utile et une question ouverte. Elle gagne davantage à expliquer ce qu’elle sait résoudre et sous quelles conditions qu’à répéter son nom dans toutes les discussions.
