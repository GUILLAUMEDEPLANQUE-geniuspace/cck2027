# Documenter une observation inhabituelle avant de chercher une explication

Devant une observation inhabituelle, la première décision utile n’est pas de nommer sa cause. C’est de conserver assez d’informations pour que quelqu’un d’autre puisse examiner le dossier. Une vidéo impressionnante accompagnée de quelques mots peut laisser beaucoup moins de possibilités d’analyse qu’un document moins spectaculaire mais correctement contextualisé.

## Préserver le document reçu et décrire son origine

Gardez une copie du fichier tel qu’il a été obtenu, puis travaillez sur une copie distincte. Notez qui l’a fourni, par quel canal et si une recompression ou un montage est déjà connu. Le terme « original » doit être réservé à ce que l’on peut effectivement établir ; un fichier transmis par messagerie peut déjà avoir été transformé.

Une empreinte cryptographique permet de comparer des fichiers : la même empreinte calculée avec le même algorithme sert à vérifier que les données comparées sont identiques selon ce contrôle. Elle ne prouve ni l’auteur de l’image, ni la date réelle de la scène, ni l’explication du phénomène. Il faut distinguer l’intégrité suivie dans le dossier et l’authenticité revendiquée du contenu.

## Recueillir les observations avant les interprétations

Demandez ce qui a été vu, pendant combien de temps et dans quelles conditions. Conservez séparément le récit spontané et les hypothèses apparues ensuite. Des réponses obtenues après avoir proposé une explication peuvent être plus difficiles à interpréter.

| Information | Ce qu’il faut conserver | Limite à rappeler |
|---|---|---|
| Temps | Heure annoncée, fuseau et origine de l’horodatage | L’heure d’un appareil peut être incorrecte |
| Lieu | Zone utile et direction d’observation | Une adresse personnelle n’a pas à être publiée |
| Prise de vue | Appareil, réglages connus, zoom, mouvements | Une information absente ne se devine pas de façon fiable |
| Transmission | Fichier reçu, canal et transformations connues | Une copie partagée n’est pas nécessairement le fichier de capture |

## Comparer des hypothèses qui peuvent être mises en difficulté

Écrivez plusieurs explications possibles et, pour chacune, l’information qui permettrait de la tester. Évitez de compter une même source plusieurs fois : dix republications d’une vidéo ne sont pas dix observations indépendantes.

Supposons qu’une lumière paraisse se déplacer rapidement dans une séquence. Sans distance suffisamment connue, un déplacement dans l’image ne fournit pas directement une vitesse réelle. Le dossier doit d’abord préciser ce qui est mesuré : pixels, angle estimé, durée ou distance. Transformer une donnée manquante en valeur implicite produit un résultat apparemment exact mais fragile.

## Montrer les manipulations et les limites

Si vous stabilisez, recadrez ou augmentez le contraste d’une image, conservez les paramètres et l’objectif de la manipulation. Une version améliorée pour la lecture ne doit pas remplacer silencieusement le document de départ.

Les métadonnées et les recherches d’images peuvent aider à poser des questions, mais leurs résultats se vérifient dans leur contexte. L’absence d’une correspondance ou d’un champ ne suffit pas à démontrer qu’un document est nouveau ou authentique.

## Publier un état du dossier, pas une conclusion forcée

Un compte rendu utile distingue documents disponibles, observations, hypothèses écartées et questions ouvertes. Il doit accepter une correction et garder son historique. La boîte à outils publique de Bellingcat peut servir de point d’entrée vers des moyens d’enquête ; elle ne dispense pas de comprendre les limites de chaque outil.

La formulation « non expliqué avec les éléments disponibles » décrit un état de connaissance. Elle ne donne pas, à elle seule, une cause au phénomène.
