<?php
/** TalentNexus Multivers Absolu: public native projections, never mock counters. */
defined('_JEXEC') or die;
final class NexusAbsolu
{
    public static function assets(): void
    {
        static $loaded=false;if($loaded)return;$loaded=true;
        $doc=\Joomla\CMS\Factory::getApplication()->getDocument();$base=\Joomla\CMS\Uri\Uri::root(true).'/media/com_joomcck/nexus/';
        $doc->addStyleSheet($base.'absolu.css',['version'=>'5.27.8']);
    }
    /** All fields in this projection have passed the public native field and subscription gates. */
    public static function material(int $section): array
    {
        static $cache=[];if(isset($cache[$section]))return$cache[$section];$out=[];$s=\Geniuspace\ProductAccess::store();$access=new \Geniuspace\NativeAccess();
        $sections=array_values(array_unique(array_merge([$section],\Geniuspace\ShellBindings::sections($section))));
        foreach($s->rows('SELECT id FROM #__js_res_record WHERE published=1 AND hidden=0 AND section_id IN ('.implode(',',$sections).') ORDER BY mtime DESC,id DESC',120)as$row){
            $p=$access->record((int)$row['id']);if(!$p)continue;
            $out[]=$p;if(count($out)>=30)break;
        }
        return$cache[$section]=$out;
    }
    public static function value(array $projection,$params,string $slot): mixed
    {
        $key=NexusPlatform::config($params,$slot);
        foreach($projection['fields']as$id=>$field)if($key!==''&&($field['key']===$key||(string)$id===$key))return$projection['values'][$id]??'';
        // Field keys differ between native types. Only use an identically named,
        // already-public native field when this type has no mapped field.
        $alias=str_replace('_','-',preg_replace('/^field_/','',$slot));
        foreach($projection['fields']as$id=>$field)if(($field['alias']??'')===$alias)return$projection['values'][$id]??'';
        return'';
    }
    private static function text(mixed $value): string
    {if(is_array($value))$value=implode(' ',array_filter($value,'is_scalar'));return is_scalar($value)?NexusSuite::plain((string)$value):'';}
    public static function ticker(int $section,$params,array $items=[]): string
    {
        if(NexusPlatform::config($params,'ticker_enabled','1')==='0')return'';
        $flash=\Geniuspace\UniverseAnnouncements::ticker($section);
        if($native=NexusMultivers::ticker($items,$params)){$native=preg_replace('~(<div class="ticker">)~','$1'.$flash,$native,1)??$native;return preg_replace('~(<div class="ticker">)([\s\S]*?)(</div><button)~','$1<div class="ticker-sequence">$2</div><div class="ticker-sequence" aria-hidden="true" inert>$2</div>$3',$native,1)??$native;}
        $all=self::material($section);$selected=[];
        foreach($all as$p){$flag=self::text(self::value($p,$params,'field_news'));if(in_array(mb_strtolower($flag),['1','oui','yes','actualite','actualité'],true))$selected[]=$p;}
        if(!$selected&&NexusPlatform::config($params,'ticker_recent_fallback','1')!=='0')$selected=array_slice($all,0,8);
        $out=$flash;foreach(\Geniuspace\MultiverseMechanisms::ticker(array_map(static fn($i)=>(int)$i->id,$items))as$event)$out.='<a class="ticker-item" data-live-multiverse-event href="'.NexusSuite::e($event['url']).'"><span>'.NexusSuite::e($event['label']).' :</span> '.NexusSuite::e($event['title']).'</a>';
        foreach(array_slice($selected,0,10)as$p){$url=NexusPlatform::sameSite($p['record']['url']);if(!$url)continue;$out.='<a class="ticker-item" href="'.NexusSuite::e($url).'"><span>'.NexusConnect::icon('bolt').' À LA UNE :</span> '.NexusSuite::e($p['record']['title']).'</a>';}
        if(!$out&&NexusPlatform::config($params,'ticker_recent_fallback','1')!=='0')foreach(self::publicCategories($section)as$c)$out.='<a class="ticker-item" href="'.NexusSuite::e($c->link).'"><span>'.NexusConnect::icon((string)$c->params->get('icon','hashtag')).' EXPLORER :</span> '.NexusSuite::e($c->title).'</a>';
        return$out?'<div class="ticker-wrap" role="region" aria-label="Les actualités de la communauté"><div class="ticker"><div class="ticker-sequence">'.$out.'</div><div class="ticker-sequence" aria-hidden="true" inert>'.$out.'</div></div><button type="button" class="ticker-toggle" data-meta-ticker-pause aria-label="Suspendre le fil d’actualités" aria-pressed="false">Ⅱ</button></div>':'';
    }
    public static function slider(int $section,$params,array $items=[]): string
    {
        if(NexusPlatform::config($params,'slider_enabled','1')==='0')return'';$all=self::material($section);$selected=[];
        foreach($all as$p){$badge=self::text(self::value($p,$params,'field_promoted'));if($badge!==''&&!in_array(mb_strtolower($badge),['0','non','no','false'],true))$selected[]=$p;}
        if(!$selected&&NexusPlatform::config($params,'slider_recent_fallback','1')!=='0')$selected=array_slice($all,0,6);
        $out='';foreach(NexusMultivers::regionFields($items,$params,'slider')as[$record,$field])$out.='<div class="topic-slide absolu-slide-native">'.$field->result.'</div>';
        $colors=['gaming','travel','web3'];foreach(array_slice($selected,0,12)as$index=>$p){$url=NexusPlatform::sameSite($p['record']['url']);if(!$url)continue;
            $badge=self::text(self::value($p,$params,'field_promoted'))?:'À découvrir';$excerpt=self::text(self::value($p,$params,'field_excerpt'))?:$p['record']['description'];
            $out.='<a href="'.NexusSuite::e($url).'" class="topic-slide absolu-slide absolu-slide-'.$colors[$index%3].'"><span class="absolu-slide-badge">'.NexusConnect::icon(['gaming'=>'gamepad','travel'=>'earth-asia','web3'=>'bolt'][$colors[$index%3]]).' '.NexusSuite::e($badge).'</span><h2>'.NexusSuite::e($p['record']['title']).'</h2><p>'.NexusSuite::e(mb_substr($excerpt,0,180)).'</p><footer><span>Communauté Geniuspace</span><span>Explorer →</span></footer></a>';
        }
        if(!$out&&NexusPlatform::config($params,'slider_recent_fallback','1')!=='0')foreach(array_slice(self::publicCategories($section),0,8)as$index=>$c)$out.='<a href="'.NexusSuite::e($c->link).'" class="topic-slide absolu-slide absolu-slide-'.$colors[$index%3].'"><span class="absolu-slide-badge">'.NexusConnect::icon((string)$c->params->get('icon','hashtag')).' Explorer un univers</span><h2>'.NexusSuite::e($c->title).'</h2><p>'.NexusSuite::e(mb_substr(NexusSuite::plain($c->description),0,180)).'</p><footer>Découvrir les discussions →</footer></a>';
        return$out?'<section class="absolu-highlights" aria-label="Raids, coalitions et sujets à découvrir"><header><h2>À la une, dans tous les univers</h2><div><button type="button" data-absolu-slide="-1" aria-label="Cartes précédentes">'.NexusConnect::icon('arrow-left').'</button><button type="button" data-absolu-slide="1" aria-label="Cartes suivantes">'.NexusConnect::icon('arrow-right').'</button></div></header><div class="topic-slider hide-scroll" data-absolu-slider tabindex="0">'.$out.'</div></section>':'';
    }
    private static function publicCategories(int $section): array
    {
        return array_values(array_filter(NexusForumSeven::categories($section),static fn($c)=>\Geniuspace\ForumCategories::public((array)$c)));
    }
    /** New positions reuse the exact selected native field templates and access rules. */
    public static function regions(array $items,$params,string $position,string $slot=''): string
    {
        $out='';foreach(NexusMultivers::regionFields($items,$params,$position,$slot)as[$record,$field])$out.='<div class="absolu-native-block" data-native-field="'.(int)$field->id.'">'.$field->result.'</div>';return$out;
    }
    /** Different native types can implement the same roles using their own field keys. */
    public static function paramsFor(object $item,$params): \Joomla\Registry\Registry
    {
        $p=clone$params;$fields=(array)($item->fields_by_id??[]);$by=[];foreach($fields as$f)if(isset($f->result))$by[str_replace('-','_',(string)$f->alias)]=$f;
        foreach((array)$p->get('tmpl_params',[])as$role=>$key){if(!str_starts_with($role,'field_')||!is_scalar($key)||!(string)$key)continue;$mapped=$item->fields_by_key[(string)$key]??$fields[(int)$key]??null;if($mapped)continue;$alias=substr($role,6);if(isset($by[$alias]))$p->set('tmpl_params.'.$role,$by[$alias]->key);}
        foreach(['body','excerpt','author','content_type','cover','cover_alt','topic']as$alias)if(!NexusPlatform::config($p,'field_'.$alias)&&isset($by[$alias]))$p->set('tmpl_params.field_'.$alias,$by[$alias]->key);
        return$p;
    }
    /** Never drop an added native output field merely because it has no design role yet. */
    public static function additional(object $item,$params): string
    {
        require_once __DIR__.'/NexusAuthorForms.php';if(NexusPlatform::config($params,'automatic_extra_fields','1')==='0')return'';$used=[];
        $collect=function($value)use(&$collect,&$used){if(is_scalar($value))$used[(string)$value]=true;elseif(is_array($value)||is_object($value))foreach($value as$v)$collect($v);};
        foreach((array)$params->get('tmpl_params',[])as$key=>$value)if(str_starts_with($key,'field_')||str_starts_with($key,'extra_')||$key==='multi_bindings')$collect($value);
        $out='';foreach((array)($item->fields_by_id??[])as$field){if(isset($used[(string)$field->id])||isset($used[$field->key])||!isset($field->result)||trim((string)$field->result)===''||!NexusAuthorForms::hasValue($field->value??null))continue;
            if(in_array($field->alias,['content-type','content_type','news','promoted'],true))continue;
            if(isset($field->params)&&!$field->params->get('core.show_full',1))continue;
            $out.='<section class="nx-extra-field absolu-extra-field" data-nx-field="'.(int)$field->id.'"><h2>'.NexusSuite::e($field->label).'</h2>'.$field->result.'</section>';
        }return$out?'<section class="absolu-additional" aria-label="Informations complémentaires">'.$out.'</section>':'';
    }
    /** Private author overview explains why a saved post is not in the public feed. */
    public static function publications(int $section): string
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id)return'';
        $sections=array_values(array_unique(array_map('intval',array_merge([$section],\Geniuspace\ShellBindings::sections($section)))));
        $rows=\Geniuspace\ProductAccess::store()->rows('SELECT id,title,type_id,section_id,published,hidden,archive,access,pubtime,extime FROM #__js_res_record WHERE section_id IN ('.implode(',',$sections).') AND user_id='.(int)$user->id.' ORDER BY id DESC',12);
        $out='<details class="absolu-my-posts"><summary>'.NexusConnect::icon('pen-to-square').' Mes publications <small>'.count($rows).'</small></summary><ul>';
        foreach($rows as$r){$public=(bool)(new \Geniuspace\NativeAccess())->record((int)$r['id']);$status=$public?'Publiée et visible':((int)$r['published']!==1?'En attente de publication ou de validation':(!empty($r['hidden'])?'Masquée':(!empty($r['archive'])?'Archivée':(strtotime((string)$r['pubtime'])>time()?'Publication programmée':'Accès, catégorie ou date à vérifier'))));
            $url=NexusAurora::formUrl((int)$r['section_id'],(int)$r['type_id']);$uri=new \Joomla\CMS\Uri\Uri($url);$uri->setVar('id',(int)$r['id']);$target=$public?NexusPlatform::recordUrl((object)$r):$uri->toString();$out.='<li><a href="'.NexusSuite::e($target).'">'.NexusSuite::e($r['title']).'</a><small>'.NexusSuite::e($status).'</small><a class="nx-post-edit" href="'.NexusSuite::e($uri->toString()).'">Modifier</a></li>';
        }return$out.($rows?'':'<li>Vos messages enregistrés apparaîtront ici.</li>').'</ul></details>';
    }
    /** Place selected field groups between article sections without parsing their programs. */
    public static function article(string $body,object $item,$params): array
    {
        $groups=[];foreach(NexusConnect::groups($item,$params)as$group)if($group['position']==='article')$groups[]=$group;
        if(!$groups)return['html'=>$body,'fields'=>[]];
        preg_match_all('~<(script|style|pre|code)\b[^>]*>[\s\S]*?</\1\s*>(*SKIP)(*F)|<(h[23])([^>]*)>([\s\S]*?)</\2>~i',$body,$headings,PREG_SET_ORDER|PREG_OFFSET_CAPTURE);
        $insertions=[];$fields=[];foreach($groups as$group){$offset=strlen($body);$anchor=mb_strtolower(trim((string)($group['anchor']??'')));
            foreach($headings as$index=>$heading){preg_match('/\bid=["\']([^"\']+)["\']/',$heading[3][0],$id);if(!$anchor||!in_array($anchor,[mb_strtolower(NexusSuite::plain($heading[4][0])),mb_strtolower($id[1]??'')],true))continue;
                $offset=$heading[0][1]+strlen($heading[0][0]);
                if(($group['placement']??'section')==='section'){$offset=strlen($body);for($n=$index+1;$n<count($headings);$n++)if(strcmp(strtolower($headings[$n][2][0]),strtolower($heading[2][0]))<=0){$offset=$headings[$n][0][1];break;}}
                break;
            }
            $insertions[$offset]=($insertions[$offset]??'').NexusConnect::block($group);foreach($group['fields']as$field)$fields[(int)$field->id]=true;
        }
        krsort($insertions,SORT_NUMERIC);foreach($insertions as$offset=>$html)$body=substr_replace($body,$html,(int)$offset,0);
        return['html'=>$body,'fields'=>array_keys($fields)];
    }
    public static function widget(object $item,$params,string $slot,array $skip=[]): string
    {
        $field=NexusConnect::field($item,NexusPlatform::config($params,$slot));return$field&&!in_array((int)$field->id,$skip,true)?(string)$field->result:'';
    }
    public static function profileLabel(object $item): string
    {
        $params=$item->params??'{}';$params=$params instanceof \Joomla\Registry\Registry?$params:new \Joomla\Registry\Registry($params);$slug=(string)$params->get('nexus_publication_form','');if(!$slug)return'';
        require_once __DIR__.'/NexusAuthorForms.php';require_once __DIR__.'/NexusForumApp.php';$profiles=NexusAuthorForms::definitions(NexusForumApp::listParams((int)$item->section_id));return(string)($profiles[$slug]['label']??'');
    }
    /** Optional, closed statistics do not scan the whole community during the first render. */
    public static function radarPreview(int $section): string
    {
        $url=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.forumRadar&section='.$section;
        return '<div data-forum-radar="'.NexusSuite::e($url).'" aria-live="polite"><p>Les tendances de la communauté se chargent à l’ouverture.</p><a href="'.NexusSuite::e($url).'" data-radar-retry rel="nofollow">Afficher le radar inter-univers</a></div>';
    }
    public static function radar(int $section): string
    {
        $now=new \DateTimeImmutable('now',new \DateTimeZone('UTC'));$week=$now->modify('-7 days')->format('Y-m-d H:i:s');$prior=$now->modify('-14 days')->format('Y-m-d H:i:s');$rows=[];$roots=NexusForumSeven::categories($section);$store=\Geniuspace\ProductAccess::store();$access=new \Geniuspace\NativeAccess();
        foreach($store->rows('SELECT id,ctime,categories FROM #__js_res_record WHERE section_id='.$section.' AND published=1 AND hidden=0 AND ctime>='.$store->q($prior).' ORDER BY id DESC',500)as$r){if(!$access->record((int)$r['id']))continue;$rows[]=$r;}
        $body='';foreach($roots as$category){$ids=array_fill_keys(array_merge([(int)$category->id],array_keys(NexusForumSeven::flat($category->children))),true);$current=0;$previous=0;
            foreach($rows as$r){$categories=json_decode($r['categories'],true)?:[];if(!array_intersect_key($categories,$ids))continue;if($r['ctime']>=$week)$current++;else$previous++;}
            if(!$current&&!$previous)continue;$change=$previous?(int)round(($current-$previous)*100/$previous):null;
            $body.='<li><a href="'.NexusSuite::e($category->link).'">'.NexusConnect::icon((string)$category->params->get('icon','hashtag')).' '.NexusSuite::e($category->title).'</a><strong>'.$current.' sujets'.($change!==null?' <small>('.($change>=0?'+':'').$change.' %)</small>':'').'</strong></li>';
        }
        return'<section class="absolu-radar"><span class="absolu-radar-label">Radar inter-univers</span><h2>Ce qui bouge dans la communauté</h2><p>Publications publiques · 7 derniers jours</p>'.($body?'<ul>'.$body.'</ul>':'<p>Les tendances apparaîtront au fil des publications.</p>').'<small>Comparaison avec les 7 jours précédents. Aucun profil financier individuel.</small></section>';
    }
}
