<?php
declare(strict_types=1);
namespace Geniuspace;
/** One native public projection supplies every JSitemap presentation and local discovery format. */
final class JmapBridge
{
    public static function boot(): bool
    {
        $base=JPATH_ROOT.'/components/com_joomcck';if(!is_file($base.'/api.php'))return false;
        require_once $base.'/libraries/vendor/autoload.php';\Joomcck\Assets\Webassets\Webassets::init();require_once $base.'/api.php';require_once $base.'/library/php/geniuspace/NexusPlatform.php';return true;
    }
    public static function install(): void
    {
        $s=ProductAccess::store();if(!in_array($s->db->getPrefix().'jmap',$s->db->getTableList(),true))return;
        if($s->rows("SELECT id FROM #__jmap WHERE type='plugin' AND name='Nexusjoomcck'",1))return;
        $s->run("INSERT INTO #__jmap (type,name,description,published,ordering,params) VALUES ('plugin','Nexusjoomcck','Native JoomCCK sections, categories, records, fields, media and public comments',1,50,".$s->q(Seo::json(['priority'=>'0.5','changefreq'=>'weekly','include_comments'=>1,'include_categories'=>1])).')');
    }
    public static function data(object $params,object $db,object $model): array
    {
        $format=(string)$model->getState('format','xml');$levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();$where="published=1 AND hidden=0 AND archive=0 AND access IN (".implode(',',$levels?:[0]).") AND COALESCE(meta_index,'') NOT LIKE '%noindex%'";$sections=array_values(array_filter(array_map('intval',explode(',',(string)$params->get('section_ids',''))),static fn($v)=>$v>0));if($sections)$where.=' AND section_id IN ('.implode(',',$sections).')';
        $limit=(int)($model->limitRows??0);$start=(int)($model->limitStart??0);$rows=$db->setQuery('SELECT id FROM #__js_res_record WHERE '.$where.' ORDER BY id',$start,$limit?:0)->loadColumn();$model->setState('affected_rows',count($rows));
        $items=[];$tree=[];$cats=[];$sectionsSeen=[];$live=rtrim(\Joomla\CMS\Uri\Uri::root(),'/');
        foreach($rows as$id){if(!($m=PublicMaterial::record((int)$id)))continue;$r=$m['projection']['raw'];$tp=$m['projection']['type_params'];$selection=$tp['properties']['tmpl_article']??'';
            if($format==='gnews'&&(!preg_match('/article|blog|editorial/',$selection)||strtotime($m['created'])<time()-2*86400))continue;
            $link=str_starts_with($m['url'],$live)?substr($m['url'],strlen($live)):parse_url($m['url'],PHP_URL_PATH);$items[]=$item=(object)['title'=>$m['title'],'link'=>$link,'lastmod'=>$m['modified'],'publish_up'=>$m['created'],'metakey'=>$r['meta_key']??'','access'=>1,'jsitemap_rss_desc'=>self::summary($m),'catname'=>'JoomCCK','native_cck_id'=>(int)$id,'native_canonical'=>$m['url'],'native_images'=>$m['images'],'native_videos'=>$m['videos'],'native_comments'=>$params->get('include_comments',1)?$m['comments']:[]];
            if($format==='rss'&&$params->get('include_comments',1))foreach($m['comments']as$c)$items[]=(object)['title'=>'Contribution de '.$c['author'].' · '.$m['title'],'link'=>$link.'#comment-'.$c['id'],'lastmod'=>$c['date'],'publish_up'=>$c['date'],'access'=>1,'jsitemap_rss_desc'=>$c['text'],'catname'=>'Discussion'];
            $sectionsSeen[(int)$r['section_id']]=true;$categories=array_keys(json_decode($r['categories']??'{}',true)?:[]);if(!$categories)$tree[-(int)$r['section_id']][]=$item;foreach($categories as$cat)$tree[(int)$cat][]=$item;
        }
        if($params->get('include_categories',1)){
            // Include native Forum 7 categories even before their first thread is published.
            // The same projection covers categories added later and respects ancestor ACLs.
            $corpus=ForumCategories::corpus($sections);$existing=[];foreach($cats as$list)foreach($list as$c)$existing[(int)$c->category_id]=true;
            foreach($corpus as$c){$id=$c['id'];$link=substr($c['url'],strlen($live));$parent=$c['parent']<=1?-$c['section']:$c['parent'];
                if(!isset($existing[$id]))$cats[$parent][]=(object)['category_id'=>$id,'category_title'=>$c['title'],'category_link'=>$link,'title'=>$c['title'],'lastmod'=>$c['modified']];
                $items[]=(object)['title'=>$c['title'],'link'=>$link,'lastmod'=>$c['modified'],'access'=>1,'native_category_id'=>$id];$tree[$id]??=[];$sectionsSeen[$c['section']]=true;
            }
            $levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();
            $seen=[];foreach(array_keys($tree)as$id){$depth=0;while($id>1&&!isset($seen[$id])&&$depth++<80){$cat=$db->setQuery('SELECT * FROM #__js_res_categories WHERE id='.$id.' AND published=1 AND access IN ('.implode(',',$levels?:[0]).')')->loadAssoc();if(!$cat)break;$seen[$id]=true;
                $url=\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=records&section_id='.(int)$cat['section_id'].'&cat_id='.$id,false);$parent=(int)$cat['parent_id'];$parent=$parent<=1?-(int)$cat['section_id']:$parent;
                $cats[$parent][]=(object)['category_id'=>$id,'category_title'=>$cat['title'],'category_link'=>$url,'title'=>$cat['title'],'lastmod'=>''];$id=$parent;
            }}
            foreach(array_keys($sectionsSeen)as$id){$name=$db->setQuery('SELECT name FROM #__js_res_sections WHERE id='.$id)->loadResult();$url=\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=records&section_id='.$id,false);$cats[0][]=(object)['category_id'=>-$id,'category_title'=>$name,'category_link'=>$url,'title'=>$name,'lastmod'=>''];$items[]=(object)['title'=>$name,'link'=>$url,'lastmod'=>'','native_cck_section'=>$id];}

        }
        if(!$cats||!$tree)return ['items'=>$items];return ['items'=>$items,'items_tree'=>$tree,'categories_tree'=>$cats];
    }
    public static function summary(array $m): string
    {
        $text=$m['description'];if(!$text){$passages=array_filter($m['passages'],static fn($p)=>in_array($m['fields'][$p['field']]['type']??'', ['html','textarea','text','gpaudio','gpmedia','gpskillterm','gpelement'],true));$text=implode(' ',array_column($passages,'text'));}return mb_substr(Text::plain($text),0,3000);
    }
    public static function feed(array $existing): array
    {
        if(!self::boot())return $existing;$s=ProductAccess::store();$out=[];
        foreach($existing as$r){$url=(string)$r->linkurl;
            // Never reuse stale JoomCCK overrides as a public corpus after withdrawal or route changes.
            $native=str_contains($url,'com_joomcck')||(bool)$s->rows('SELECT record_id FROM #__gp_social_jmap_identity WHERE canonical='.$s->q($url),1);
            if(!$native&&\NexusPlatform::sameSite($url)){try{$uri=new \Joomla\CMS\Uri\Uri($url);$vars=\Joomla\CMS\Router\Router::getInstance('site')->parse($uri,false);$native=($vars['option']??'')==='com_joomcck';}catch(\Throwable){}}
            if($native)continue;$out[]=$r;
        }
        $after=max(0,\Joomla\CMS\Factory::getApplication()->input->getInt('after'));if($after)$out=[];$batch=$s->rows('SELECT id FROM #__js_res_record WHERE id>'.$after.' ORDER BY id',1000);$last=$batch?(int)end($batch)['id']:0;if($last&&$s->rows('SELECT id FROM #__js_res_record WHERE id>'.$last,1)){\Joomla\CMS\Factory::getApplication()->setHeader('Link','<'.\Joomla\CMS\Uri\Uri::root().'?option=com_jmap&view=sitemap&format=aifeed&after='.$last.'>; rel="next"',true);}
        foreach($batch as$r)if($m=PublicMaterial::record((int)$r['id'])){
            $out[]=(object)['meta_title'=>$m['title'],'meta_desc'=>self::summary($m),'linkurl'=>$m['url'],'meta_image'=>$m['images'][0]['url']??'','native_cck_id'=>$m['id'],'native_hash'=>$m['hash'],'native_modified'=>$m['modified'],'native_passages'=>$m['passages'],'native_comments'=>$m['comments']];
            $s->run('INSERT INTO #__gp_social_jmap_identity (record_id,url_hash,canonical,mtime) VALUES ('.$m['id'].','.$s->q(hash('sha256',$m['url'])).','.$s->q($m['url']).','.$s->q($m['modified']).') ON DUPLICATE KEY UPDATE canonical=VALUES(canonical),url_hash=VALUES(url_hash),mtime=VALUES(mtime)');
        }
        if(!$after)foreach(ForumCategories::corpus()as$c)$out[]=(object)['meta_title'=>$c['seo_title'],'meta_desc'=>$c['description'],'linkurl'=>$c['url'],'meta_image'=>$c['image'],'native_category_id'=>$c['id'],'native_modified'=>$c['modified'],'native_hash'=>hash('sha256',Seo::json($c)),'native_passages'=>[],'native_comments'=>[]];
        return $out;
    }
    public static function media(array $items,string $format): void
    {
        $e=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_XML1,'UTF-8');foreach($items as$item){
            if($format==='images'&&!empty($item->native_category_id)){$s=ProductAccess::store();$c=$s->rows('SELECT * FROM #__js_res_categories WHERE id='.(int)$item->native_category_id,1)[0]??null;if($c&&ForumCategories::public($c)&&($image=ForumCategories::image($c,768)))echo '<url><loc>'.$e(ForumRoutes::categoryUrl((int)$c['section_id'],(int)$c['id'])).'</loc><image:image><image:loc>'.$e($image).'</image:loc><image:title>'.$e(ForumCategories::alt($c)).'</image:title></image:image></url>';continue;}
            if(empty($item->native_cck_id))continue;$m=PublicMaterial::record((int)$item->native_cck_id);if(!$m)continue;
            $media=$format==='images'?$m['images']:$m['videos'];if(!$media)continue;$body='';foreach($media as$a){if($format==='images'){$body.='<image:image><image:loc>'.$e($a['url']).'</image:loc>'.($a['title']?'<image:title>'.$e($a['title']).'</image:title>':'').'</image:image>';}else{
                if(!$a['title']||!$a['description']||!$a['thumbnail'])continue;$body.='<video:video><video:thumbnail_loc>'.$e($a['thumbnail']).'</video:thumbnail_loc><video:title>'.$e($a['title']).'</video:title><video:description>'.$e(mb_substr($a['description'],0,2048)).'</video:description><video:content_loc>'.$e($a['url']).'</video:content_loc>'.($a['duration']?'<video:duration>'.$a['duration'].'</video:duration>':'').'</video:video>';
            }}if($body)echo '<url><loc>'.$e($m['url']).'</loc>'.$body.'</url>';
        }
    }
}
