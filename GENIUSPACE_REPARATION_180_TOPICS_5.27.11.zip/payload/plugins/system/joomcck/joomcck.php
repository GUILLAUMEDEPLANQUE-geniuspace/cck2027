<?php
/**
 * Joomcck system plugin for Joomla
 *
 * @version    $Id: jq_alphauserpoints.php 2009-11-16 17:30:15
 * @package    Coablt
 * @subpackage joomcck.php
 * @author     joomcoder Team
 * @Copyright  Copyright (C) joomcoder, www.joomcoder.com
 * @license    GNU/GPL http://www.gnu.org/copyleft/gpl.html
 */

defined('_JEXEC') or die('Restricted access');

jimport('joomla.plugin.plugin');

class plgSystemJoomcck extends \Joomla\CMS\Plugin\CMSPlugin
{
    function onAfterRoute()
    {
        $app=\Joomla\CMS\Factory::getApplication();$boot=JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php';if(!is_file($boot))return;require_once $boot;
        if(class_exists(\Geniuspace\BrandSeo::class)&&($target=\Geniuspace\BrandSeo::redirect(\Joomla\CMS\Uri\Uri::getInstance()->toString(),strtoupper($_SERVER['REQUEST_METHOD']??'GET'),$app->isClient('site')))){$app->redirect($target,301);return;}
        if(class_exists(\Geniuspace\CategoryBridge::class)&&($target=\Geniuspace\CategoryBridge::redirect())){$app->redirect($target,301);return;}
        \Geniuspace\AllVideoBridge::guard();if(!$app->isClient('site')||strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='GET'||$app->input->getCmd('task')||$app->input->getCmd('format','html')!=='html')return;
        $base=JPATH_ROOT.'/components/com_joomcck';if(!is_file($base.'/library/php/geniuspace/bootstrap.php'))return;
        require_once $base.'/library/php/geniuspace/bootstrap.php';$db=\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
        if(!in_array($db->getPrefix().'gp_social_native_url_history',$db->getTableList(),true))return;
        $url=\Joomla\CMS\Uri\Uri::getInstance()->toString();$hash=hash('sha256',$url);
        $recordId=(int)$db->setQuery('SELECT record_id FROM #__gp_social_native_url_history WHERE url_hash='.$db->quote($hash))->loadResult();if(!$recordId)return;if($app->input->getCmd('option')==='com_joomcck'&&$app->input->getCmd('view')==='record'&&$app->input->getInt('id')!==$recordId)return;
        \Geniuspace\JmapBridge::boot();if($target=\Geniuspace\NativeUrls::target($url)){$app->redirect($target,301);}
    }
    public function onAfterRender()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        if($app->isClient('administrator')&&$app->getDocument()->getType()==='html'&&$app->getIdentity()->id&&$app->getIdentity()->authorise('core.admin')&&str_contains($app->getBody(),'</body>')&&!str_contains($app->getBody(),'data-publication-job')){
            $boot=JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php';if(is_file($boot)){require_once $boot;try{if(class_exists(\Geniuspace\PublicationRepair::class)&&($job=\Geniuspace\PublicationRepair::status())&&!in_array($job['status'],['done','complete_with_exclusions'],true))$app->setBody(str_replace('</body>',\Geniuspace\PublicationRepair::panel().'</body>',$app->getBody()));}catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Publication repair panel: '.get_class($e),\Joomla\CMS\Log\Log::WARNING,'joomcck');}}
        }
        if($app->isClient('site')&&$app->input->getCmd('option')==='com_joomcck'){$boot=JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php';if(is_file($boot)){require_once $boot;if(class_exists(\Geniuspace\BrandSeo::class))$app->setBody(\Geniuspace\BrandSeo::render($app->getBody(),\Joomla\CMS\Uri\Uri::root()));}}
        if(!$app->isClient('site')||$app->input->getCmd('option')!=='com_allvideoshare'||$app->input->getCmd('view')!=='player'||$app->input->getCmd('format')!=='raw')return;
        $body=$app->getBody();if(!str_contains($body,'</head>'))return;
        $src=\Joomla\CMS\Uri\Uri::root(true).'/media/com_joomcck/nexus/allvideo-bridge.js?v=5.23.0';$app->setBody(str_replace('</head>','<script src="'.htmlspecialchars($src,ENT_QUOTES,'UTF-8').'"></script></head>',$body));
    }
    public function onBeforeCompileHead()
    {
        $app=\Joomla\CMS\Factory::getApplication();if(!$app->isClient('site'))return;
        $app->getDocument()->addScriptOptions('csrf.token',\Joomla\CMS\Session\Session::getFormToken());
    }

	function onJQuizFinished($params)
	{

		if(empty($params['passed']))
		{
			return;
		}
		$quizId = filter_var($params['quiz_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
		if($quizId === false) return;
		$user = \Joomla\CMS\Factory::getApplication()->getIdentity();
		if(!$user->id || $user->block) return;
		$db = \Joomla\CMS\Factory::getDbo();
		$db->setQuery("SELECT DISTINCT record_id, field_id FROM #__js_res_record_values WHERE value_index = 'quiz' AND field_value = " . $db->quote((string) $quizId) . " AND field_type = 'dripcontent'");
		$ids = $db->loadObjectList();

		if(empty($ids))
		{
			return;
		}

		$user = \Joomla\CMS\Factory::getApplication()->getIdentity();

		\Joomla\CMS\Table\Table::addIncludePath(JPATH_ROOT . '/components/com_joomcck/fields/dripcontent/tables');
		$table = \Joomla\CMS\Table\Table::getInstance('Stepaccess', 'JoomcckTable');

		foreach($ids AS $id)
		{

			$data['user_id']   = $user->get('id');
			$data['record_id'] = $id->record_id;
			$data['field_id']  = $id->field_id;

			$table->load($data);

			if(!$table->id)
			{
				$data['id']    = NULL;
				$data['ctime'] = \Joomla\CMS\Factory::getDate()->toSql();
				$table->bind($data);
				$table->store();
			}

			$table->reset();
			$table->id = NULL;
		}
	}

	function onJ2StoreAfterGetProduct(&$product)
	{

		if(!(isset($product->product_source) && $product->product_source == 'com_joomcck'))
		{
			return;
		}

		include_once JPATH_ROOT . '/components/com_joomcck/api.php';
		$record = \Joomla\CMS\Table\Table::getInstance('Record', 'JoomcckTable');
		$record->load($product->product_source_id);

		if(!$record->id)
		{
			return;
		}

		$product->source           = $record;
		$product->product_name     = $record->title;
		$product->product_edit_url = str_replace('administrator/', '', \Joomla\CMS\Router\Route::_(Url::edit($record->id), TRUE, -1));
		$product->product_view_url = str_replace('administrator/', '', \Joomla\CMS\Router\Route::_(Url::record($record), TRUE, -1));
		$product->exists           = $record->published;
	}

	function onJ2StoreAfterGetCartItems(&$items)
	{
		include_once JPATH_ROOT . '/components/com_joomcck/api.php';
		$record = \Joomla\CMS\Table\Table::getInstance('Record', 'JoomcckTable');

		foreach($items as $key => $item)
		{
			if($item->product_source == 'com_joomcck')
			{
				$article = $record->load($item->product_source_id);
				if($article->published != 1)
				{
					unset($items[$key]);
				}
			}
		}
	}

	public function onJ2StoreAfterProductListQuery(&$query, &$model)
	{
		/*$db = \Joomla\CMS\Factory::getDbo();
		$query->select('cob.title as product_name, 0 as catid');
		$query->join('LEFT OUTER', '#__js_res_record AS cob ON #__j2store_products.product_source_id=cob.id AND #__j2store_products.product_source=' . $db->q('com_joomcck'));

		$search = $model->getState('search', '', 'string');
		if(!empty($search))
		{
			$query->where($db->qn('cob') . '.' . $db->qn('title') . ' LIKE ' . $db->q('%' . $search . '%'));
		}*/
	}

	function onRecordDelete($record)
	{
        require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php';if(!empty($record->id))\Geniuspace\AllVideoBridge::withdraw((int)$record->id);
		if(empty($record->id))
		{
			return;
		}
		if(!defined('F0F_INCLUDED') && is_file(JPATH_LIBRARIES . '/f0f/include.php'))
		{
			require_once JPATH_LIBRARIES . '/f0f/include.php';
		}

		if(class_exists("F0FModel"))
		{
			$productModel = F0FModel::getTmpInstance('Products', 'J2StoreModel');
			$itemlist     = $productModel->getProductsBySource('com_joomcck', $record->id);
			foreach($itemlist as $item)
			{
				$productModel->setId($item->j2store_product_id)->delete();
			}
		}


		return TRUE;
	}

	public function onUserAfterDelete($user, $success, $msg)
	{
		$this->db = \Joomla\CMS\Factory::getDbo();

		$this->db->setQuery("SELECT id FROM `#__js_res_record` WHERE user_id = " . $user['id']);
		$records   = $this->db->loadColumn();
		$records[] = 0;

		$this->db->setQuery("DELETE FROM `#__js_res_record`WHERE user_id = " . $user['id']);
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_audit_log` WHERE user_id = {$user['id']} OR record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_audit_restore` WHERE record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_audit_versions` WHERE user_id = {$user['id']} OR record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_category_user` WHERE user_id = {$user['id']}");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_comments` WHERE user_id = {$user['id']} OR record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_favorite` WHERE user_id = {$user['id']} OR record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_hits` WHERE user_id = {$user['id']} OR record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_import` WHERE user_id = {$user['id']}");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_moderators` WHERE user_id = {$user['id']}");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_notifications` WHERE user_id = {$user['id']} OR ref_1 IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_record_category` WHERE record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_record_repost` WHERE record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_record_values` WHERE record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_sales` WHERE user_id = {$user['id']} OR record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_subscribe` WHERE user_id = {$user['id']} OR (ref_id IN(" . implode($records, ',') . ") AND `type` = 'record')");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_subscribe_cat` WHERE user_id = {$user['id']}");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_subscribe_user` WHERE user_id = {$user['id']} OR u_id = {$user['id']}");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_tags_history` WHERE user_id = {$user['id']} OR record_id IN(" . implode($records, ',') . ")");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_user_options` WHERE user_id = {$user['id']}");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_user_options_autofollow` WHERE user_id = {$user['id']}");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_user_post_map` WHERE user_id = {$user['id']}");
		$this->db->execute();

		$this->db->setQuery("DELETE FROM `#__js_res_vote` WHERE user_id = {$user['id']} OR (ref_id IN(" . implode($records, ',') . ") AND `ref_type` = 'record')");
		$this->db->execute();

		return TRUE;
	}





}
