<?php
declare(strict_types=1);
namespace Geniuspace;

/** Aggregate native Joomla sessions; no identity list and no external presence service. */
final class ForumPresence
{
    public static function count(): ?int
    {
        $db=ProductAccess::store()->db;
        if(!in_array($db->getPrefix().'session',$db->getTableList(),true))return null;
        $columns=$db->getTableColumns('#__session');foreach(['userid','guest','client_id','time']as$c)if(!isset($columns[$c]))return null;
        return (int)$db->setQuery('SELECT COUNT(DISTINCT s.userid) FROM #__session AS s INNER JOIN #__users AS u ON u.id=s.userid WHERE s.client_id=0 AND s.guest=0 AND s.userid>0 AND u.block=0 AND s.time>'.(time()-300))->loadResult();
    }
    /** Opt-in typing transmits a short-lived boolean, never the draft text. */
    public static function write(array $data): void
    {
        SchemaHealth::require('forum_presence');$user=ProductAccess::authenticated();$record=(int)($data['record']??0);
        if(!PublicMaterial::record($record,false))throw new \DomainException('Discussion indisponible.',404);
        $s=ProductAccess::store();$s->run('DELETE FROM #__gp_social_forum_presence WHERE expires_at<'.time());
        if(empty($data['active'])){$s->run('DELETE FROM #__gp_social_forum_presence WHERE record_id='.$record.' AND user_id='.$user);return;}
        $s->run('INSERT INTO #__gp_social_forum_presence(record_id,user_id,typing,expires_at) VALUES('.$record.','.$user.',1,'.(time()+20).') ON DUPLICATE KEY UPDATE typing=1,expires_at=VALUES(expires_at)');
    }
    public static function typing(int $record): array
    {
        if(!PublicMaterial::record($record,false))throw new \DomainException('Discussion indisponible.',404);
        if(!SchemaHealth::has('forum_presence'))return['count'=>0,'names'=>[]];$s=ProductAccess::store();
        $where='p.record_id='.$record.' AND p.typing=1 AND p.expires_at>'.time().' AND u.block=0 AND p.user_id<>'.(int)ProductAccess::user()->id;
        $count=(int)($s->rows('SELECT COUNT(*) AS n FROM #__gp_social_forum_presence p INNER JOIN #__users u ON u.id=p.user_id WHERE '.$where,1)[0]['n']??0);
        $rows=$s->rows('SELECT u.name FROM #__gp_social_forum_presence p INNER JOIN #__users u ON u.id=p.user_id WHERE '.$where,3);return['count'=>$count,'names'=>array_column($rows,'name')];
    }
    public static function controls(int $record): string
    {
        $e=[Text::class,'escape'];$base=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.product';
        return'<div class="forum8-writing-presence" data-writing-presence data-record="'.$record.'" data-endpoint="'.$e($base).'" data-token="'.\Joomla\CMS\Session\Session::getFormToken().'"><p role="status" data-writing-status></p>'.(ProductAccess::user()->id?'<label><input type="checkbox" data-writing-optin> Signaler quand j’écris une réponse</label>':'').'</div>';
    }
    public static function visit(array $data): array
    {
        SchemaHealth::require('forum_readers');$user=ProductAccess::authenticated();$record=(int)($data['record']??0);$s=ProductAccess::store();
        if(empty($data['active'])){$s->run('DELETE FROM #__gp_social_forum_readers WHERE record_id='.$record.' AND user_id='.$user);return['message'=>'Votre présence n’est plus affichée.'];}
        if(!(new NativeAccess())->record($record))throw new \DomainException('Discussion indisponible.',404);
        $role=$data['role']??'reader';if(!in_array($role,['reader','recruiter','expert'],true))throw new \InvalidArgumentException('Rôle inconnu.');
        $s->run('DELETE FROM #__gp_social_forum_readers WHERE expires_at<'.time());
        $s->run('INSERT INTO #__gp_social_forum_readers(record_id,user_id,role,expires_at) VALUES('.$record.','.$user.','.$s->q($role).','.(time()+90).') ON DUPLICATE KEY UPDATE role=VALUES(role),expires_at=VALUES(expires_at)');
        return['message'=>'Votre présence est affichée pour 90 secondes, puis renouvelée pendant votre lecture.'];
    }
    public static function readers(int $record): array
    {
        if(!(new NativeAccess())->record($record))throw new \DomainException('Discussion indisponible.',404);
        $counts=['reader'=>0,'recruiter'=>0,'expert'=>0];if(!SchemaHealth::has('forum_readers'))return['count'=>0,'roles'=>$counts];$s=ProductAccess::store();
        foreach($s->rows('SELECT p.role,COUNT(*) AS n FROM #__gp_social_forum_readers p INNER JOIN #__users u ON u.id=p.user_id AND u.block=0 WHERE p.record_id='.$record.' AND p.expires_at>'.time().' GROUP BY p.role',3)as$row)if(array_key_exists($row['role'],$counts))$counts[$row['role']]=(int)$row['n'];
        return['count'=>array_sum($counts),'roles'=>$counts];
    }
    public static function readerControls(int $record): string
    {
        $endpoint=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.product';$e=[Text::class,'escape'];
        return'<div class="absolu-readers" data-absolu-readers data-record="'.$record.'" data-endpoint="'.$e($endpoint).'" data-token="'.\Joomla\CMS\Session\Session::getFormToken().'"><p role="status" data-readers-count></p>'.(ProductAccess::user()->id?'<details><summary>Afficher ma présence sur ce sujet</summary><label><input type="checkbox" data-readers-optin> Partager ma présence pendant ma lecture</label><label>Je participe en tant que<select data-readers-role><option value="reader">Lecteur ou lectrice</option><option value="recruiter">Recruteur ou recruteuse</option><option value="expert">Expert ou experte</option></select></label><small>Le rôle est déclaré par le membre. Votre nom et vos revenus ne sont pas affichés.</small></details>':'').'</div>';
    }
    public static function badge(int $record): string
    {
        try{$readers=self::readers($record);}catch(\DomainException){return'';}$count=(int)$readers['count'];$endpoint=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.productRead&kind=readers&record='.$record;
        return'<div class="absolu-presence-badge" data-absolu-presence-badge data-record="'.$record.'" data-endpoint="'.Text::escape($endpoint).'"><span class="absolu-presence-dot" aria-hidden="true"></span><span data-presence-label>'.($count?$count.' membre'.($count===1?'':'s').($count===1?' partage sa présence':' partagent leur présence'):'Aucune présence partagée pour le moment').'</span><small>Présence volontaire · rôles déclarés</small></div>';
    }
}
