from pathlib import Path
from html.parser import HTMLParser
import json,re,hashlib
from PIL import Image
R=Path(__file__).parent;articles=json.loads((R/'articles-premier-lot-12.json').read_text());checks=[]
def ck(ok,l):
 if not ok:raise AssertionError(l)
 checks.append(l)
ck(len(articles)==12,'Twelve written articles');ck(len({a['slug']for a in articles})==12,'Twelve distinct native slugs');bykey={a['key']:a for a in articles}
for a in articles:
 ck(a['word_count']>=800,'Substantive original methodology: '+a['key']);ck(a['body_html'].count('<h2>')>=7,'Document structure: '+a['key']);ck(not re.search(r'<(?:script|iframe|form)\b|\son\w+\s*=|javascript:',a['body_html'],re.I),'No active body markup: '+a['key']);ck(100<=len(a['meta_description'])<=190,'Specific meta description: '+a['key']);ck(a['author']=='GUILLAUME DEPLANQUE — GENIUSPACE','Requested byline: '+a['key']);ck(all(k in bykey for k in a['related_content_keys']),'Only written cross-link targets: '+a['key']);ck((R/a['workbook']).exists(),'Useful local workbook: '+a['key']);im=a['illustration'];ck(im['origin']=='image_generation'and len(im['alt'])>=55,'Original generated illustration with descriptive alt: '+a['key'])
 for v in im['variants']:
  p=R/v['path'];image=Image.open(p);ck(image.size==(v['width'],v['height']),'Real image dimensions: '+p.name);ck(p.stat().st_size==v['bytes'],'Recorded compressed size: '+p.name)
 ck(next(v['bytes']for v in im['variants']if v['width']==480)<60000,'Mobile cover under 60KB: '+a['key'])
 ck(len(set(a['related_content_keys']))==2,'Two distinct routes to a written dossier: '+a['key'])
class LocalLinks(HTMLParser):
 def __init__(self):super().__init__();self.links=[]
 def handle_starttag(self,t,a):
  if t in ['a','img']:
   d=dict(a);url=d.get('href',d.get('src',''))
   if url and not url.startswith(('http:','https:','#','data:')):self.links.append(url)
for p in [R/'index.html',*R.joinpath('content').glob('*.html')]:
 parser=LocalLinks();parser.feed(p.read_text());ck(all((p.parent/url.split('#')[0]).exists()for url in parser.links),'Every local preview link and image resolves: '+p.name)
ck(round(10000*1.04**5-10000*1.03**5,2)==573.79,'Investment arithmetic is correct');ck(round(10/(.008*9+.080),1)==65.8,'Frame-time example arithmetic is correct')
r={'written_articles':12,'written_article_words':sum(a['word_count']for a in articles),'minimum_words':min(a['word_count']for a in articles),'remaining_unwritten_articles':228,'drafted_topics':180,'generated_covers':12,'responsive_webp_files':48,'jpeg_social_files':12,'workbooks':12,'production_publications':0,'fake_accounts':0,'passed':len(checks),'checks':checks};(R/'QUALITY-VALIDATION.json').write_text(json.dumps(r,indent=2,ensure_ascii=False));print(json.dumps({k:v for k,v in r.items()if k!='checks'},ensure_ascii=False))
