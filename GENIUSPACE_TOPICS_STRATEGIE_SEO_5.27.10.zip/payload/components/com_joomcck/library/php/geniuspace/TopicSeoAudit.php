<?php
declare(strict_types=1);
namespace Geniuspace;

/** Private read-only audit of native discussion records and the known editorial topics. */
final class TopicSeoAudit
{
    private static function authorise(): void
    {
        $u=ProductAccess::user();if(!$u->id||$u->block||!$u->authorise('core.manage','com_joomcck'))throw new \DomainException('Audit réservé aux responsables JoomCCK.',403);
    }
    public static function report(string $universe='',int $after=0): array
    {
        self::authorise();require_once __DIR__.'/NexusForumApp.php';$map=ForumProvisioner::manifest();if(!$map)throw new \DomainException('Forum natif non installé.',409);
        $topics=json_decode((string)file_get_contents(__DIR__.'/editorial/topics-180.json'),true,64,JSON_THROW_ON_ERROR);$keys=array_values(array_unique(array_column($topics,'universe')));
        if($universe!==''&&!in_array($universe,$keys,true))throw new \DomainException('Univers inconnu.',404);
        $store=ProductAccess::store();$gate=new NativeAccess();$items=[];$next=null;
        if($universe!==''){
            foreach($topics as$t){if($t['universe']!==$universe)continue;
                $rows=$store->rows('SELECT * FROM #__js_res_record WHERE alias='.$store->q('geniuspace-discussion-2026-'.$t['slug']).' ORDER BY id',3);
                if(!$rows){$items[]=['title'=>$t['title'],'status'=>'absent','issues'=>['Topic prévu mais absent de cette base.'],'notes'=>[],'expected'=>true];continue;}
                foreach($rows as$row){$result=self::record($row,$map,$gate,$t);if(count($rows)>1)$result['issues'][]='Alias occupé par plusieurs fiches : vérifier avant toute publication.';$items[]=$result;}
            }
        }else{
            $after=max(0,$after);$rows=$store->rows('SELECT * FROM #__js_res_record WHERE section_id='.(int)$map['section'].' AND id>'.$after.' ORDER BY id',40);$cursor=$after;
            foreach($rows as$row){$cursor=(int)$row['id'];if(\NexusForumApp::isArticle((object)$row))continue;$items[]=self::record($row,$map,$gate);}
            if($store->rows('SELECT id FROM #__js_res_record WHERE section_id='.(int)$map['section'].' AND id>'.$cursor,1))$next=$cursor;
        }
        return ['universe'=>$universe,'universes'=>$keys,'items'=>$items,'next'=>$next,'checked'=>count($items),'public'=>count(array_filter($items,static fn($r)=>($r['status']??'')==='public')),'missing'=>count(array_filter($items,static fn($r)=>$r['status']==='absent')),'with_issues'=>count(array_filter($items,static fn($r)=>!empty($r['issues']))),'limits'=>['Lecture des fiches, champs, catégories, relations et permissions natives : aucune publication ni modification automatique.','Une fiche accessible et une bonne structure ne prouvent pas son indexation. Search Console indique la canonique sélectionnée et le dernier passage de Google.','Les notes éditoriales demandent une revue humaine ; elles ne sont pas des seuils de classement Google.']];
    }
    private static function record(array $row,array $map,NativeAccess $gate,?array $expected=null): array
    {
        $id=(int)$row['id'];$p=PublicMaterial::projection($id,false,$gate);$issues=[];$notes=[];$url='';$words=0;$images=0;
        if(!$p)$issues[]='Non accessible aux invités : vérifier publication, dates, catégories, type, section et ACL.';
        else{
            $url=(string)$p['record']['url'];if(!PublicMaterial::projection($id,true,$gate))$issues[]='Export public exclu de l’indexation : vérifier noindex, démonstration et réglages natifs.';
            $body='';foreach($p['fields']as$f){$field=(int)$f['id'];$role=$f['params']['semantic']['role']??'';if($field===(int)($map['fields']['body']['id']??0)||in_array($f['alias']??'',['body','article-body'],true)||in_array($role,['articleBody','text'],true)){if(is_scalar($p['values'][$field]??null))$body.=' '.(string)$p['values'][$field];}}
            $text=Text::plain($body);$words=preg_match_all('/[\p{L}\p{N}]+/u',$text);if(trim($text)==='')$issues[]='Corps du sujet vide dans ses champs publics.';
            elseif($words<30)$notes[]='Sujet très court : préciser la question et son contexte si nécessaire.';
            if(!trim((string)($row['meta_descr']??'')))$notes[]='Description native absente : rédiger un résumé propre à ce sujet.';
            $html=SeoAudit::html($body);$notes=array_merge($notes,$html['issues']);$images=count(PublicDiscovery::images($p));
            if(!$images)$notes[]='Illustration facultative : utile si elle apporte une information au sujet.';
            if(\NexusForumApp::isArticle((object)$row))$issues[]='Cette fiche est reconnue comme article, alors qu’un topic était attendu.';
            if($expected){
                $ctx=UniverseBlueprint::context((int)$map['section']);$valid=[];
                foreach($ctx['roots']as$root)if(UniverseBlueprint::rootKey($root,$ctx['flat'])===$expected['universe']){$valid[]=(int)$root->id;foreach(\NexusForumSeven::flat($root->children)as$c)$valid[]=(int)$c->id;}
                $cats=ProductAccess::store()->db->setQuery('SELECT catid FROM #__js_res_record_category WHERE record_id='.$id)->loadColumn();if(!array_intersect($valid,array_map('intval',$cats)))$issues[]='Aucune catégorie native dans l’univers attendu.';
                $guide=ProductAccess::store()->rows('SELECT id FROM #__js_res_record WHERE alias='.ProductAccess::store()->q('geniuspace-guide-2026-'.$expected['guide_slug']),1)[0]??null;
                $targets=array_column(PublicDiscovery::related($p,$gate),'id');if(!$guide||!in_array((int)$guide['id'],$targets,true))$issues[]='Relation native publique vers le guide attendu absente.';
            }
        }
        if(preg_match('/^(?:test\d*|[bvxwsycdfs]{5,})$/iD',trim((string)$row['title'])))$notes[]='Titre de test probable : décider de l’enrichir, de le réserver aux tests ou de lui appliquer noindex dans JoomCCK.';
        return ['id'=>$id,'title'=>$row['title'],'status'=>$p?'public':'restricted','url'=>$url,'expected'=>$expected!==null,'body_words'=>$words,'images'=>$images,'issues'=>array_values(array_unique($issues)),'notes'=>array_values(array_unique($notes))];
    }
}
