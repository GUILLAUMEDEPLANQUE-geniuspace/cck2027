# Évaluer une IA locale : séparer ressources, mémoire, classement et modèle de langage

Une IA locale peut mieux répondre après l’ajout d’un document sans que les paramètres de son modèle de langage aient changé. Cette distinction est essentielle pour mesurer ses progrès. Les ressources disponibles, leur indexation, le classement des passages et la génération de réponse forment des mécanismes différents ; chacun peut améliorer ou dégrader le résultat final.

## Dessiner la chaîne avant de choisir un score

Commencez par identifier les étapes : acquisition d’une ressource, extraction de son contenu, contrôle de ses permissions, recherche de passages, classement, puis réponse. Une erreur d’extraction ne se corrige pas nécessairement en changeant le modèle ; un passage pertinent mais privé ne doit pas devenir une réponse publique.

Conservez une référence de la configuration utilisée : modèle, version de l’index, règles de recherche et paramètres utiles à la reproduction. Il n’est pas nécessaire d’exposer ces détails à chaque utilisateur, mais l’équipe doit pouvoir savoir ce qui a changé entre deux évaluations.

| Couche | Amélioration possible | Test adapté |
|---|---|---|
| Ressources | Une information autorisée devient disponible | Retrouver le document, sa provenance et sa date |
| Extraction | Le texte ou la transcription devient exploitable | Comparer le passage extrait au document source |
| Recherche et classement | Le bon passage remonte plus haut | Juger les passages trouvés pour les mêmes questions |
| Génération | La réponse utilise correctement les éléments fournis | Vérifier exactitude, citations et traitement de l’incertitude |
| Permissions | Une source retirée cesse d’être révélée | Tester les comptes, niveaux d’accès et changements de statut |

## Construire un jeu de questions qui peut contredire la promesse

Préparez des questions dont la réponse est connue, d’autres qui demandent plusieurs sources et certaines auxquelles le système ne devrait pas répondre. Ajoutez des cas où une source a été modifiée, retirée ou rendue privée. Le test ne doit pas seulement contenir les démonstrations qui réussissent déjà.

Séparez les exemples utilisés pour ajuster le système de ceux qui servent à décider si le changement est retenu. Si les mêmes questions pilotent les réglages et justifient le résultat final, le gain observé peut refléter une adaptation au test plutôt qu’une amélioration utile ailleurs.

## Mesurer plusieurs résultats sans inventer une note d’intelligence

Dans un exemple fictif de vingt questions, douze réponses vérifiables sur une première configuration et quinze sur une seconde correspondent à 60 % et 75 % sur ce petit jeu. Ce calcul ne démontre ni un gain général de quinze points sur toutes les tâches ni une certitude statistique. Il faut examiner les trois améliorations, les éventuelles régressions et la manière dont les réponses ont été jugées.

Une citation doit être vérifiée au niveau du passage : la source contient-elle réellement l’information invoquée, et le lecteur a-t-il le droit d’y accéder ? Afficher un titre de document ne suffit pas à valider le contenu de la réponse.

## Tester les permissions comme une fonction de qualité

L’authentification vérifie le compte ; l’autorisation détermine ce qu’il peut consulter ou modifier. La fiche OWASP sur l’authentification aide à clarifier cette première frontière, mais un accès correct demande aussi des contrôles sur les ressources et leurs champs.

Testez un membre autorisé, un autre membre, un visiteur et une ressource devenue privée. Les réponses, résumés, historiques et caches doivent respecter le changement. Un système qui retrouve davantage de documents mais révèle une information interdite n’est pas simplement « plus performant ».

## Rendre les progrès visibles et réversibles

Publiez le périmètre mesuré, la version retenue, les cas en régression et la possibilité de revenir à une version validée. Si aucune comparaison n’a encore été faite, dites-le au lieu d’afficher un pourcentage de progression.

La prochaine amélioration se choisit alors à partir d’un défaut observé : document manquant, extraction faible, classement inadapté ou réponse non étayée. Cette approche transforme l’ambition d’une IA qui apprend en une suite de décisions vérifiables.

## Concevoir un cycle autonome qui ne confond pas collecte et apprentissage

Un agent de collecte peut trouver davantage de documents sans améliorer une seule réponse. Définissez donc la sortie attendue de chaque cycle : nouvelles sources admissibles, passages extraits, questions mieux couvertes, erreurs corrigées et éventuelles régressions. L’indexation ajoute des connaissances consultables ; elle ne signifie pas que les poids du modèle ont été entraînés. Un ajustement du classement modifie l’ordre des ressources ; il ne constitue pas non plus une mesure générale d’intelligence.

Avant l’autonomie, fixez les sources autorisées, les fréquences, le budget de calcul et les conditions d’arrêt. Une source qui demande une connexion, interdit une réutilisation ou contient des données privées nécessite un traitement compatible avec ses droits. L’agent doit pouvoir échouer proprement sans inventer une acquisition réussie. Les limites de débit et la fraîcheur recherchée se décident par type de ressource, pas par une promesse de collecte illimitée.

## Définir un dossier de provenance pour chaque ressource

Conservez l’URL ou l’emplacement d’origine, le détenteur des droits, la date d’acquisition, la version, le compte qui a apporté le document et les permissions. Pour un PDF numérisé, contrôlez un échantillon d’extraction par rapport à la page. Pour une vidéo, gardez le lien entre transcription et instants du média. Une bonne recherche sur un texte mal extrait peut fournir une mauvaise réponse avec beaucoup d’assurance.

La fiche OWASP consacrée à la sécurité du RAG recommande notamment la provenance, l’intégrité, les métadonnées d’accès au niveau des fragments et l’isolement des locataires. Elle précise qu’une empreinte conforme à une référence protégée vérifie une cohérence avec cette référence, sans établir que le contenu est sain. Une instruction trouvée dans un document reste une donnée à examiner, pas une autorisation d’agir pour l’agent.

## Un tableau d’évaluation qui montre aussi les échecs

| Question du protocole | Mesure proposée | Ce que le résultat ne prouve pas |
|---|---|---|
| Le bon passage est-il retrouvé ? | Part des questions avec un passage pertinent dans les k premiers résultats | Que le modèle rédigera une réponse correcte |
| La réponse est-elle étayée ? | Jugement de chaque affirmation et de sa citation | Une fiabilité universelle sur des sujets absents du test |
| Une source privée reste-t-elle privée ? | Tests par comptes et après changement de droits | Que tous les chemins d’accès possibles ont été testés |
| Le cycle reste-t-il exploitable ? | Durée, échecs, coût et taille d’index observés | Qu’une collecte plus grosse vaut mieux |

Préparez les critères avant d’observer les résultats. Gardez un jeu de validation distinct des questions qui servent à régler le système. Si une mesure progresse mais qu’un cas critique de permission échoue, la version ne doit pas être déclarée meilleure globalement. Présentez le défaut et la décision de maintien ou de retour en arrière.

## Tester le retrait d’une source jusqu’au dernier cache

Ajoutez un document de test reconnaissable, vérifiez son accès avec deux comptes aux droits différents, puis retirez-le. Contrôlez la recherche, les réponses, les résumés, les citations et les historiques accessibles. La fiche OWASP sur l’autorisation recommande de vérifier les permissions à chaque requête et de refuser par défaut les accès non accordés. Cette exigence concerne aussi les fragments retrouvés et les sorties d’outils, pas seulement la page du document.

Le carnet associé propose un journal de version : hypothèse, corpus autorisé, questions, résultats, défauts, décision et retour possible. C’est un modèle de protocole, pas l’annonce que toutes ces fonctions sont déjà déployées dans Geniuspace. Le progrès visible doit rester une conséquence d’observations vérifiables.
