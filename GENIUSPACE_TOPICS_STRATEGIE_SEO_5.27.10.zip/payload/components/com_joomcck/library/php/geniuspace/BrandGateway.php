<?php
declare(strict_types=1);
namespace Geniuspace;

/** A compact brand introduction inside the existing native hub, with crawlable categories. */
final class BrandGateway
{
    public static function identity(): array
    {
        $p=\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck');
        $defaults=['title'=>'Geniuspace : communautés, guides, emploi et formations','heading'=>'Geniuspace : des connaissances aux projets','description'=>'Sur Geniuspace, découvrez des guides, échangez dans les communautés et avancez dans vos projets : emploi, formations, entreprises, jeux vidéo et cultures.'];
        foreach($defaults as$key=>$value){$custom=Text::plain((string)$p->get('geniuspace_brand_'.$key,''));if($custom!=='')$defaults[$key]=mb_substr($custom,0,$key==='description'?500:180);}
        return $defaults;
    }
    public static function redirectToUniverse(): bool
    {
        return (bool)\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck')->get('geniuspace_default_universe_redirect',0);
    }
    public static function render(int $hub,array $roots): string
    {
        $d=self::identity();$e=[Text::class,'escape'];$blog=\NexusForumSeven::modeUrl(ForumRoutes::categoryUrl($hub),'blog');
        $out='<header class="forum7-feed-heading nx-brand-gateway" data-brand-gateway><p class="nx-brand-address">GENIUSPACE.IO · COMMUNAUTÉS ET PROJETS</p><h1>'.$e($d['heading']).'</h1><p>'.$e($d['description']).'</p><details><summary>Découvrir Geniuspace et choisir un univers</summary><p>Geniuspace.io réunit les publications des membres, des créateurs et des entreprises. Les guides servent à comprendre un sujet ; les discussions permettent de poser des questions et de confronter des expériences. Les espaces emploi, formation et entreprise relient ces échanges à des démarches concrètes.</p><nav class="nx-brand-universes" aria-label="Choisir une communauté Geniuspace">';
        foreach($roots as$root)$out.='<a href="'.$e(ForumRoutes::categoryUrl($hub,(int)$root->id)).'">'.$e($root->title).'</a>';
        $out.='</nav><p><a href="'.$e($blog).'">Explorer les articles et reportages du Multi-Blog →</a></p><p>Les publications restent attribuées à leur auteur. Les dossiers de la rédaction distinguent leur méthode, leurs sources, leurs exemples pédagogiques et leurs limites. Les discussions reflètent les contributions de leurs participants.</p></details></header>';
        return $out;
    }
}
