<?php
defined('_JEXEC') or die;

/** A targeted, fingerprinted code/media update plus a real native content publication. */
if(!class_exists('files_geniuspace_japanInstallerScript',false)){
class files_geniuspace_japanInstallerScript
{
    private array $manifest=[];
    private string $source='';
    private string $backup='';
    private array $written=[];
    public function preflight($type,$parent): bool
    {
        if($type==='uninstall')return true;
        try{
            $u=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$u->id||$u->block||!$u->authorise('core.admin'))throw new \RuntimeException('Installation par un super administrateur requise.');
            $this->source=$parent->getParent()->getPath('source');$this->manifest=json_decode((string)file_get_contents($this->source.'/JAPAN-PATCH.json'),true,32,JSON_THROW_ON_ERROR);
            if(PHP_VERSION_ID<80300)throw new \RuntimeException('PHP 8.3 minimum requis.');
            foreach($this->manifest['files']as$path=>$proof){
                if(str_contains($path,'..')||!preg_match('~^(?:components/com_joomcck/(?:library/php/geniuspace/(?:NexusBlogIndex|UniverseBlueprint)\.php|models/forms/category\.xml|views/records/tmpl/default_list_nexus_forum7\.php)|media/com_joomcck/nexus/(?:reference-shell\.css|editorial-2026/[a-z0-9_.-]+))$~D',$path))throw new \RuntimeException('Chemin hors périmètre du correctif.');
                $input=$this->source.'/payload/'.$path;$target=JPATH_ROOT.'/'.$path;
                if(!is_file($input)||!hash_equals($proof['sha256'],hash_file('sha256',$input)))throw new \RuntimeException('Empreinte du correctif invalide.');
                for($walk=$target;strlen($walk)>strlen(JPATH_ROOT);$walk=dirname($walk))if(is_link($walk))throw new \RuntimeException('Lien symbolique refusé.');
                if(is_file($target)){$hash=hash_file('sha256',$target);if($hash!==$proof['sha256']&&$hash!==($proof['previous_sha256']??''))throw new \RuntimeException('Un fichier a été personnalisé depuis Geniuspace 5.27.8. Aucun remplacement automatique : '.$path);}
                elseif(!empty($proof['required_existing']))throw new \RuntimeException('Installer d’abord Geniuspace 5.27.8 complet.');
            }
            $this->boot();$db=\Geniuspace\ProductAccess::store()->db;$engines=$db->setQuery('SELECT TABLE_NAME,ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()')->loadAssocList('TABLE_NAME');
            foreach(['js_res_record','js_res_record_values','js_res_record_category','js_res_categories','gp_social_links','gp_social_knowledge_chunks']as$name)if(strtoupper($engines[$db->getPrefix().$name]['ENGINE']??'')!=='INNODB')throw new \RuntimeException('La publication transactionnelle nécessite InnoDB : '.$name.'. Aucun moteur n’a été modifié.');
            $map=\Geniuspace\ForumProvisioner::manifest();if(!$map)throw new \RuntimeException('Forum natif non installé.');
            return true;
        }catch(\Throwable$e){\Joomla\CMS\Factory::getApplication()->enqueueMessage($e->getMessage(),'error');return false;}
    }
    private function boot(): void
    {
        require_once JPATH_ROOT.'/components/com_joomcck/libraries/vendor/autoload.php';require_once JPATH_ROOT.'/components/com_joomcck/api.php';require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php';require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusPlatform.php';require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusForumApp.php';
    }
    public function install($parent): bool{return $this->apply();}
    public function update($parent): bool{return $this->apply();}
    private function apply(): bool
    {
        try{
            $this->boot();$base=dirname(JPATH_ROOT).'/.nexus-japan-backups';if(!is_dir($base)&&!mkdir($base,0700,true))throw new \RuntimeException('Sauvegarde privée indisponible.');$this->backup=$base.'/'.gmdate('Ymd-His').'-'.bin2hex(random_bytes(8));if(!mkdir($this->backup,0700))throw new \RuntimeException('Sauvegarde indisponible.');
            $before=[];foreach($this->manifest['files']as$path=>$proof){$target=JPATH_ROOT.'/'.$path;$before[$path]=is_file($target)?hash_file('sha256',$target):null;if(is_file($target)){$copy=$this->backup.'/'.$path;if(!is_dir(dirname($copy)))mkdir(dirname($copy),0700,true);if(!copy($target,$copy))throw new \RuntimeException('Sauvegarde incomplète.');chmod($copy,0600);}}
            $meta=$this->backup.'/BEFORE.json';if(file_put_contents($meta,json_encode($before,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))===false)throw new \RuntimeException('Sauvegarde non enregistrée.');chmod($meta,0600);
            foreach($this->manifest['files']as$path=>$proof){$target=JPATH_ROOT.'/'.$path;if(!is_dir(dirname($target))&&!mkdir(dirname($target),0755,true))throw new \RuntimeException('Dossier cible indisponible.');$tmp=$target.'.japan-'.bin2hex(random_bytes(6));if(!copy($this->source.'/payload/'.$path,$tmp))throw new \RuntimeException('Copie interrompue.');chmod($tmp,0644);if(!rename($tmp,$target)){@unlink($tmp);throw new \RuntimeException('Remplacement interrompu.');}$this->written[]=$path;if(function_exists('opcache_invalidate'))opcache_invalidate($target,true);}
            $store=\Geniuspace\ProductAccess::store();$db=$store->db;
            $receipt=$store->atomic(function()use($db){
                $map=\Geniuspace\ForumProvisioner::manifest();$ctx=\Geniuspace\UniverseBlueprint::context((int)$map['section']);$category=0;
                foreach($ctx['roots']as$root)if(\Geniuspace\UniverseBlueprint::rootKey($root,$ctx['flat'])==='artisanat'){$category=(int)$root->id;break;}
                if(!$category)throw new \RuntimeException('Catégorie Boutique Japon introuvable.');
                $row=$db->setQuery('SELECT * FROM #__js_res_categories WHERE id='.$category.' FOR UPDATE')->loadAssoc();$params=json_decode($row['params']??'{}',true)?:[];
                $backup=$this->backup.'/CATEGORY.json';if(file_put_contents($backup,\Geniuspace\Seo::json($row))===false)throw new \RuntimeException('Sauvegarde de catégorie indisponible.');chmod($backup,0600);
                $defaults=['blog_heading'=>'Artisanat japonais','blog_accent'=>'Guides, artisans et créateurs.','blog_intro'=>'Kimonos, céramique, coutellerie et ateliers : découvrez les guides et les récits des artisans, des créateurs et des passionnés du Japon.','blog_seo_title'=>'Artisanat japonais : guides et blogs de créateurs | Geniuspace','blog_seo_description'=>'Explorez l’artisanat japonais : kimonos, céramique, coutellerie et ateliers. Retrouvez les guides, les blogs de créateurs et les discussions sur Geniuspace.'];
                foreach($defaults as$key=>$value)if(trim((string)($params[$key]??''))==='')$params[$key]=$value;
                $oldTitle=trim(explode('|',(string)($params['seo_title']??''),2)[0]);if($oldTitle===''||mb_strtolower($oldTitle)===mb_strtolower($row['title']))$params['seo_title']='Artisanat japonais : boutiques, créateurs et forum | Geniuspace';
                $update=(object)['id'=>$category,'params'=>\Geniuspace\Seo::json($params)];$db->updateObject('#__js_res_categories',$update,'id');
                $articles=\Geniuspace\EditorialPack::collection2026('artisanat');$topics=\Geniuspace\EditorialPack::topics2026('artisanat');$gate=new \Geniuspace\NativeAccess();$publicArticles=0;$publicTopics=0;
                foreach($articles['articles']as$id)if(\Geniuspace\PublicMaterial::record((int)$id,false,$gate))$publicArticles++;
                foreach($topics['topics']as$id)if(\Geniuspace\PublicMaterial::record((int)$id,false,$gate))$publicTopics++;
                $receipt=['category'=>$category,'articles_created'=>$articles['created'],'articles_preserved'=>$articles['preserved'],'topics_created'=>$topics['created'],'topics_preserved'=>$topics['preserved'],'public_articles'=>$publicArticles,'public_topics'=>$publicTopics];
                $file=$this->backup.'/RECEIPT.json';$encoded=\Geniuspace\Seo::json($receipt);if(file_put_contents($file,$encoded)!==strlen($encoded))throw new \RuntimeException('Reçu de publication non enregistré.');chmod($file,0600);return $receipt;
            });
            try{foreach(['com_joomcck','page']as$group)\Joomla\CMS\Cache\Cache::getInstance('callback')->clean($group);}catch(\Throwable$cacheError){\Joomla\CMS\Factory::getApplication()->enqueueMessage('Les publications sont enregistrées. Videz le cache de pages Joomla si une ancienne version reste affichée.','warning');}
            \Joomla\CMS\Factory::getApplication()->enqueueMessage('Boutique Japon : '.$receipt['public_articles'].' articles et '.$receipt['public_topics'].' topics publics vérifiés. Magazine centré et titres SEO contextualisés. Les contenus et réglages personnalisés antérieurs sont conservés.');
            return true;
        }catch(\Throwable$e){
            foreach(array_reverse($this->written)as$path){$target=JPATH_ROOT.'/'.$path;$prior=$this->backup.'/'.$path;if(is_file($prior))copy($prior,$target);elseif(is_file($target))unlink($target);if(function_exists('opcache_invalidate'))opcache_invalidate($target,true);}
            \Joomla\CMS\Factory::getApplication()->enqueueMessage('Correctif Japon annulé : '.$e->getMessage(),'error');return false;
        }
    }
    public function postflight($type,$parent): void{}
    public function uninstall($parent): bool{return true;}
}
}
