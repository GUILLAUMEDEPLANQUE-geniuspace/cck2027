<?php
declare(strict_types=1);
namespace Geniuspace;
/** Native talent offers and fractional capacity, with local transactions and explicit acceptance. */
final class TalentMarket
{
    private static ?string $lockName=null;
    public static function lockForSave(array $record):void{if(empty($record['id']))return;$s=self::store();if($s->rows("SELECT id FROM #__js_res_fields WHERE type_id=".(int)$record['type_id']." AND field_type='gptalentmarket' AND published=1",1))self::lock((int)$record['id']);}
    private static function lock(int $id):void{if(self::$lockName!==null)return;$s=self::store();$name='gp_talent_'.substr(hash('sha256',$s->db->getPrefix().':'.$id),0,36);$s->db->setQuery('SELECT GET_LOCK('.$s->q($name).',5)');if((int)$s->db->loadResult()!==1)throw new \DomainException('Une modification est en cours. Réessayez.',409);self::$lockName=$name;register_shutdown_function(static fn()=>self::release());}
    public static function release():void{if(self::$lockName===null)return;$s=self::store();$name=self::$lockName;self::$lockName=null;$s->db->setQuery('SELECT RELEASE_LOCK('.$s->q($name).')');$s->db->loadResult();}
    private static function store():Store{return new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class));}
    public static function parse(string $raw,string $mode):array
    {
        if(strlen($raw)>16384)throw new \InvalidArgumentException('Configuration trop volumineuse.');$d=json_decode($raw,true,6,JSON_THROW_ON_ERROR);if(!is_array($d)||!preg_match('/^[A-Z]{3}$/D',$d['currency']??''))throw new \InvalidArgumentException('Devise ISO requise.');
        foreach($mode==='auction'?['minimum_salary']:['daily_rate','available_days']as$key)if((!is_int($d[$key]??null)&&!is_float($d[$key]??null))||!is_finite((float)$d[$key])||$d[$key]<=0||$d[$key]>10000000)throw new \InvalidArgumentException('Montant ou capacité invalide.');
        if($mode==='auction'){if(!is_string($d['ends_at']??null)||!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/D',$d['ends_at'])||!Text::date($d['ends_at']))throw new \InvalidArgumentException('Date de clôture UTC requise.');return array_intersect_key($d,array_flip(['currency','minimum_salary','ends_at']));}
        if($mode!=='fractional'||$d['available_days']>5||floor($d['available_days']*2)!=$d['available_days']*2)throw new \InvalidArgumentException('Capacité de 0,5 à 5 jours par demi-journée.');return array_intersect_key($d,array_flip(['currency','daily_rate','available_days']));
    }
    private static function definition(int $record,int $field):array
    {
        $r=(new NativeAccess())->record($record);$f=$r['fields'][$field]??null;if(!$r||($f['field_type']??'')!=='gptalentmarket')throw new \DomainException('Offre de talent inaccessible.',404);
        $mode=$f['params']['params']['mode']??'auction';return ['record'=>$r,'mode'=>$mode,'params'=>$f['params']['params']??[],'data'=>self::parse((string)($r['values'][$field]??''),$mode)];
    }
    private static function company(int $id,array $d,int $user):array
    {
        $r=(new NativeAccess())->record($id);$types=array_map('intval',(array)($d['params']['company_type_ids']??[]));
        if(!$r||(int)$r['raw']['user_id']!==$user||!in_array((int)$r['raw']['type_id'],$types,true))throw new \DomainException('Une fiche entreprise autorisée dont vous êtes propriétaire est requise.',403);return $r;
    }
    public static function action(array $data):void
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id||$user->block)throw new \DomainException('Connexion requise.',403);$id=Social::id($data,'record');$fid=Social::id($data,'field');$s=self::store();$actor=(int)$user->id;
        self::lock($id);try{$s->atomic(function()use($s,$id,$fid,$data,$actor){$s->rows('SELECT id FROM #__js_res_record WHERE id='.$id.' FOR UPDATE',1);$d=self::definition($id,$fid);$action=$data['action']??'';$where='record_id='.$id.' AND field_id='.$fid;
            if($action==='accept'){
                if($d['mode']!=='auction'||(int)$d['record']['raw']['user_id']!==$actor)throw new \DomainException('Acceptation réservée au propriétaire du talent.',403);
                if(strtotime($d['data']['ends_at'])>time())throw new \DomainException('Attendez la clôture pour accepter une offre.',409);
                $company=Social::id($data,'company');$top=$s->rows('SELECT company_id FROM #__gp_social_talent_bids WHERE '.$where.' ORDER BY salary DESC,bonus DESC,ctime ASC',3);
                if(!in_array($company,array_map('intval',array_column($top,'company_id')),true))throw new \DomainException('Seules les trois premières propositions peuvent être acceptées.',409);
                $s->run('UPDATE #__gp_social_talent_bids SET accepted=1 WHERE '.$where.' AND company_id='.$company);return;
            }
            $company=Social::id($data,'company');self::company($company,$d,$actor);if((int)$d['record']['raw']['user_id']===$actor)throw new \DomainException('Une entreprise ne peut réserver son propre talent.',403);
            if($d['mode']==='auction'&&$action==='bid'){
                if(strtotime($d['data']['ends_at'])<=time())throw new \DomainException('Cette session est clôturée.',409);$salary=self::number($data['salary']??'',1,10000000);$bonus=self::number($data['bonus']??'0',0,10000000);$remote=self::number($data['remote_days']??'0',0,5);
                if($salary<$d['data']['minimum_salary']||floor($remote*2)!=$remote*2)throw new \InvalidArgumentException('Salaire minimum ou jours de télétravail invalides.');
                $s->run('INSERT INTO #__gp_social_talent_bids (record_id,field_id,company_id,user_id,salary,bonus,remote_days,accepted,ctime) VALUES ('.$id.','.$fid.','.$company.','.$actor.','.$salary.','.$bonus.','.$remote.',0,'.$s->q(gmdate('Y-m-d H:i:s')).') ON DUPLICATE KEY UPDATE salary=VALUES(salary),bonus=VALUES(bonus),remote_days=VALUES(remote_days),ctime=VALUES(ctime)');
            }elseif($d['mode']==='fractional'&&in_array($action,['reserve','cancel'],true)){
                if($action==='cancel'){$s->run('DELETE FROM #__gp_social_fractional_contracts WHERE '.$where.' AND company_id='.$company.' AND user_id='.$actor);return;}
                $days=self::number($data['days']??'',.5,5);if(floor($days*2)!=$days*2)throw new \InvalidArgumentException('Réservez par demi-journée.');
                $rows=$s->rows('SELECT company_id,days FROM #__gp_social_fractional_contracts WHERE '.$where.' FOR UPDATE',1000);$used=0.;foreach($rows as$r)if((int)$r['company_id']!==$company)$used+=(float)$r['days'];if($used+$days>$d['data']['available_days'])throw new \DomainException('Capacité hebdomadaire insuffisante.',409);
                $s->run('INSERT INTO #__gp_social_fractional_contracts (record_id,field_id,company_id,user_id,days,ctime) VALUES ('.$id.','.$fid.','.$company.','.$actor.','.$days.','.$s->q(gmdate('Y-m-d H:i:s')).') ON DUPLICATE KEY UPDATE days=VALUES(days),ctime=VALUES(ctime)');
            }else throw new \InvalidArgumentException('Action non autorisée.');
        });}finally{self::release();}
    }
    private static function number($v,float $min,float $max):float
    {
        if(!is_scalar($v)||!preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D',(string)$v)||($n=(float)$v)<$min||$n>$max)throw new \InvalidArgumentException('Nombre invalide.');return $n;
    }
    public static function validateSave(object $field,$value,$record):void
    {
        $mode=$field->params->get('params.mode','auction');$d=self::parse((string)$value,$mode);$r=(array)$record;$id=(int)($r['id']??0);
        if($id){$s=self::store();$where='record_id='.$id.' AND field_id='.(int)$field->id;$used=$s->rows('SELECT record_id FROM #__gp_social_talent_bids WHERE '.$where,1)||$s->rows('SELECT record_id FROM #__gp_social_fractional_contracts WHERE '.$where,1);if($used){$old=json_decode($s->rows('SELECT fields FROM #__js_res_record WHERE id='.$id,1)[0]['fields'],true);if(self::parse((string)($old[$field->id]??''),$mode)!==$d)throw new \DomainException('Les conditions ne peuvent changer après une proposition ou réservation.',409);}}
        if($mode==='auction'){
            $type=self::store()->rows('SELECT params FROM #__js_res_types WHERE id='.(int)($r['type_id']??0),1)[0]??[];$tp=json_decode($type['params']??'{}',true);if(!str_starts_with((string)($tp['properties']['tmpl_article']??''),'nexus_talent'))throw new \InvalidArgumentException('Sélectionnez le template natif Nexus Talent sur ce type anonyme.');
            $section=self::store()->rows('SELECT params FROM #__js_res_sections WHERE id='.(int)($r['section_id']??0),1)[0]??[];$sp=json_decode($section['params']??'{}',true);$lists=(array)($sp['general']['tmpl_list']??[]);
            if(!empty($sp['personalize']['personalize'])||!$lists||array_filter($lists,static fn($v)=>explode('.',(string)$v)[0]!=='nexus_talents'))throw new \InvalidArgumentException('Une section dédiée avec liste Nexus Talents et personnalisation par auteur désactivée est requise.');
            if(!preg_match('/^TALENT-[A-Z0-9]{8}$/D',(string)($r['title']??'')))throw new \InvalidArgumentException('Une session anonyme doit porter un titre TALENT- suivi de 8 lettres ou chiffres.');
            if(!empty($r['alias'])&&!str_starts_with((string)$r['alias'],'talent-'))throw new \InvalidArgumentException('Alias anonyme talent- requis.');
        }elseif($id){$used=(float)(self::store()->rows('SELECT SUM(days) AS n FROM #__gp_social_fractional_contracts WHERE record_id='.$id.' AND field_id='.(int)$field->id,1)[0]['n']??0);if($d['available_days']<$used)throw new \DomainException('La capacité ne peut être réduite sous les réservations existantes.',409);}
    }
    public static function render(object $record,object $field):string
    {
        try{$d=self::definition((int)$record->id,(int)$field->id);}catch(\Throwable $e){return '';}$s=self::store();$id=(int)$record->id;$fid=(int)$field->id;$user=\Joomla\CMS\Factory::getApplication()->getIdentity();$where='record_id='.$id.' AND field_id='.$fid;$out='<section class="nx-talent-market"><h3>'.($d['mode']==='auction'?'Propositions des entreprises':'Travail fractionné').'</h3>';
        if($d['mode']==='auction')$out.='<p>Minimum annuel : '.Text::escape((string)$d['data']['minimum_salary'].' '.$d['data']['currency']).' · Clôture : '.Text::escape($d['data']['ends_at']).'</p>';
        else{$used=(float)($s->rows('SELECT SUM(days) AS n FROM #__gp_social_fractional_contracts WHERE '.$where,1)[0]['n']??0);$out.='<p>'.($d['data']['available_days']-$used).' jours disponibles par semaine · '.Text::escape((string)$d['data']['daily_rate'].' '.$d['data']['currency']).' / jour</p>';}
        $out.='<p>Les propositions et réservations restent sur le site. Aucun paiement, contrat de travail ou transfert automatique n’est exécuté.</p>';if(!$user->id)return $out.'<p>Connectez-vous pour participer.</p></section>';
        \Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);$owner=(int)$d['record']['raw']['user_id']===(int)$user->id;
        $hidden='<input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="task" value="geniuspace.talentmarket"><input type="hidden" name="record" value="'.$id.'"><input type="hidden" name="field" value="'.$fid.'">'.\Joomla\CMS\HTML\HTMLHelper::_('form.token');
        if($d['mode']==='auction')foreach($s->rows('SELECT * FROM #__gp_social_talent_bids WHERE '.$where.($owner?'':' AND user_id='.(int)$user->id).' ORDER BY salary DESC,bonus DESC,ctime ASC',1000)as$b){if(!$owner)try{self::company((int)$b['company_id'],$d,(int)$user->id);}catch(\DomainException $e){continue;}$company=(new NativeAccess())->title((int)$b['company_id']);$out.='<div><p>'.Text::escape($company['title']??'Entreprise').': '.Text::escape($b['salary'].' '.$d['data']['currency']).' + '.Text::escape($b['bonus']).' · Télétravail '.Text::escape($b['remote_days']).' jours</p>';
            if($owner&&strtotime($d['data']['ends_at'])<=time()&&!$b['accepted'])$out.='<form method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'">'.$hidden.'<input type="hidden" name="action" value="accept"><input type="hidden" name="company" value="'.(int)$b['company_id'].'"><button class="nx-connect-button">Accepter et partager mon contact</button></form>';
            if($b['accepted']){$out.='<p>Proposition acceptée.</p>';if(!$owner){$talent=$s->rows('SELECT name,email FROM #__users WHERE id='.(int)$d['record']['raw']['user_id'].' AND block=0',1)[0]??[];$out.='<p>Contact transmis avec acceptation : '.Text::escape($talent['name']??'').' · '.Text::escape($talent['email']??'').'</p>';}}$out.='</div>';}
        if(!$owner&&($d['mode']!=='auction'||strtotime($d['data']['ends_at'])>time())){$out.='<form method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'">'.$hidden.'<label>ID de ma fiche entreprise <input required type="number" min="1" name="company"></label>';
            if($d['mode']==='auction')$out.='<input type="hidden" name="action" value="bid"><label>Salaire annuel <input required type="number" min="'.$d['data']['minimum_salary'].'" step=".01" name="salary"></label><label>Prime <input type="number" min="0" name="bonus" value="0"></label><label>Télétravail (jours) <input type="number" min="0" max="5" step=".5" name="remote_days" value="0"></label>';
            else $out.='<input type="hidden" name="action" value="reserve"><label>Jours par semaine <input required type="number" min=".5" max="5" step=".5" name="days"></label>';
            $out.='<button class="nx-connect-button">'.($d['mode']==='auction'?'Proposer une offre':'Réserver des jours').'</button></form>';
            if($d['mode']==='fractional')foreach($s->rows('SELECT company_id,days FROM #__gp_social_fractional_contracts WHERE '.$where.' AND user_id='.(int)$user->id,100)as$r)$out.='<form method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'">'.$hidden.'<input type="hidden" name="action" value="cancel"><input type="hidden" name="company" value="'.(int)$r['company_id'].'"><button class="nx-connect-button">Annuler ma réservation de '.Text::escape($r['days']).' jours</button></form>';
        }return $out.'</section>';
    }
}
