<?php
declare(strict_types=1);
namespace Geniuspace;
/** Recruiter pipeline remains attached to native, private application records. */
final class Hiring
{
    private static function store(): Store{return new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class));}
    private static function application(int $id): array
    {
        $store=self::store();$record=$store->rows('SELECT * FROM #__js_res_record WHERE id='.$id,1)[0]??null;
        if(!$record||($record['parent']??'')!=='com_joomcck')throw new \DomainException('Candidature native introuvable.',404);
        foreach(ComponentRuntime::configuration()->companies as$c)foreach($c['application_gates']as$gate)if((int)$record['type_id']===$gate['type_id']&&(int)$record['section_id']===$gate['section_id']){
            $job=$store->rows('SELECT * FROM #__js_res_record WHERE id='.(int)$record['parent_id'],1)[0]??null;
            if($job&&in_array((int)$job['section_id'],$c['section_ids'],true))return ['record'=>$record,'job'=>$job,'company'=>$c,'gate'=>$gate];
        }throw new \DomainException('Candidature hors périmètre.',404);
    }
    public static function saved(int $id): void
    {
        try{$a=self::application($id);}catch(\DomainException $e){return;}
        if((int)$a['record']['user_id']===(int)ProductAccess::user()->id){Experience::metric($id,'application_complete');if(SchemaHealth::has('resume_items'))Experience::resume($id,0,'application');}
        $s=self::store();$s->run('INSERT IGNORE INTO #__gp_social_hiring_states (application_id,job_id,state,actor_id,mtime) VALUES ('.$id.','.(int)$a['job']['id'].",'applied',".(int)$a['record']['user_id'].','.$s->q(gmdate('Y-m-d H:i:s')).')');
    }
    public static function change(int $id,string $state): void
    {
        $identity=\Joomla\CMS\Factory::getApplication()->getIdentity();$s=self::store();
        $s->atomic(function()use($id,$state,$identity,$s){
            $s->rows('SELECT id FROM #__js_res_record WHERE id='.$id.' FOR UPDATE',1);$a=self::application($id);
            if(!$identity->id||$identity->block||!CompanyTeam::allows($a['job'],'recruit'))throw new \DomainException('Pipeline réservé au propriétaire de l’offre.',403);
            $prior=$s->rows('SELECT state FROM #__gp_social_hiring_states WHERE application_id='.$id.' FOR UPDATE',1)[0]['state']??'applied';
            $transitions=['applied'=>['review','rejected'],'review'=>['interview','rejected'],'interview'=>['hired','rejected'],'hired'=>[],'rejected'=>[]];
            if(!in_array($state,$transitions[$prior]??[],true))throw new \DomainException('Transition de candidature interdite.',409);
            if($state!=='rejected'){
                $q=new Quiz($s,ComponentRuntime::configuration(),new Repository($s->db,ComponentRuntime::configuration(),(new \Joomla\CMS\User\User())->getAuthorisedViewLevels()),$a['company'],(int)$a['record']['user_id'],(new \Joomla\CMS\User\User())->getAuthorisedViewLevels());
                QuizBridge::guardRecord($q,$a['gate'],$a['record']);
            }
            self::saved($id);$s->run('UPDATE #__gp_social_hiring_states SET state='.$s->q($state).',actor_id='.(int)$identity->id.',mtime='.$s->q(gmdate('Y-m-d H:i:s')).' WHERE application_id='.$id);
            $s->insert('hiring_events',['application_id'=>$id,'actor_id'=>(int)$identity->id,'old_state'=>$prior,'new_state'=>$state,'ctime'=>gmdate('Y-m-d H:i:s')]);
            if($state==='hired')CreatorRevenue::hired($a,$q);
        });
    }
    public static function render(object $job): string
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id||!CompanyTeam::allows((array)$job,'recruit'))return '';
        $s=self::store();$out='<section class="nx-connect-block nx-hiring"><h2 class="font-bold mb-4">Pipeline des candidatures</h2>';$states=['applied'=>'Reçue','review'=>'À l’étude','interview'=>'Entretien','hired'=>'Embauchée','rejected'=>'Refusée'];
        foreach($s->rows('SELECT r.id,r.title,r.type_id,r.section_id,h.state FROM #__js_res_record r LEFT JOIN #__gp_social_hiring_states h ON h.application_id=r.id WHERE r.parent='.$s->q('com_joomcck').' AND r.parent_id='.(int)$job->id.' ORDER BY r.id DESC',100)as$r){try{self::application((int)$r['id']);}catch(\DomainException $e){continue;}$state=$r['state']??'applied';$transitions=['applied'=>['review','rejected'],'review'=>['interview','rejected'],'interview'=>['hired','rejected']];$out.='<div class="nx-hiring-application"><h3>'.Text::escape($r['title']).'</h3><p>'.Text::escape($states[$state]??$state).'</p>';
            if($next=$transitions[$state]??[]) {$out.='<form method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'"><input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="task" value="geniuspace.hiring"><input type="hidden" name="application" value="'.(int)$r['id'].'"><input type="hidden" name="record" value="'.(int)$job->id.'"><select name="state" aria-label="Prochaine étape">';foreach($next as$n)$out.='<option value="'.$n.'">'.Text::escape($states[$n]).'</option>';$out.='</select><button class="nx-connect-button">Valider l’étape</button>'.\Joomla\CMS\HTML\HTMLHelper::_('form.token').'</form>';}$out.='</div>';
        }return $out.'</section>';
    }
}
