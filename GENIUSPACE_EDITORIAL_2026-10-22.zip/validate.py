from pathlib import Path
import json,re,hashlib
from PIL import Image
ROOT=Path(__file__).parent
catalog=json.loads((ROOT/'catalogue-420.json').read_text());articles=json.loads((ROOT/'articles-premier-lot-12.json').read_text());topics=json.loads((ROOT/'topics-180.json').read_text());checks=[]
def ck(ok,label):
 assert ok,label
 checks.append(label)
ck(len(catalog)==420 and len({x['slug']for x in catalog})==420,'420 distinct planned slugs')
for u in {x['universe']for x in catalog}:
 ck(sum(x['kind']=='article'and x['universe']==u for x in catalog)==20,'20 planned articles: '+u)
 ck(sum(x['kind']=='discussion'and x['universe']==u for x in catalog)==15,'15 drafted editorial discussions: '+u)
ck(len(articles)==12 and len(topics)==180,'Written drafts: 12 articles, 180 opening topics')
for a in articles:
 ck(a['word_count']>=500,'Minimum article substance: '+a['key'])
 ck(a['body_html'].count('<h2>')>=4,'Structured article headings: '+a['key'])
 ck(not re.search(r'<(?:script|iframe|form)\b|\son\w+\s*=|javascript:',a['body_html'],re.I),'No active embedded content: '+a['key'])
 p=ROOT/a['illustration']['path'];im=Image.open(p);ck(im.size==(1200,675)and p.stat().st_size<100000,'Optimized original diagram: '+a['key'])
ck(round(10000*1.04**5,2)==12166.53 and round(10000*1.03**5,2)==11592.74,'Compound scenario arithmetic')
ck(abs(1000/60-16.7)<.1 and abs(1000/120-8.3)<.1,'Frame-time arithmetic')
r={'planned_articles':240,'planned_topics':180,'written_articles':len(articles),'written_topics':len(topics),'article_words':sum(a['word_count']for a in articles),'remaining_unwritten_articles':228,'original_illustrations':12,'production_publications':0,'accounts_created':0,'checks_passed':len(checks),'checks':checks,'production_blocker':'Native authentication refused configured account; no credentials distributed.'}
(ROOT/'VALIDATION.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in r.items()if k!='checks'},ensure_ascii=False))
