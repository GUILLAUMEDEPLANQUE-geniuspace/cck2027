<?php
declare(strict_types=1);
namespace Geniuspace;

/** Native public CCK sitemap, stable ID shards, refreshed directly from publication/access state. */
final class NexusSitemap
{
    /** Root-query URLs also work when a host mishandles direct /index.php requests. */
    public static function url(): string
    {
        return \Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.sitemap';
    }
    private static function hub(): string
    {
        $map=ForumProvisioner::manifest();if(!$map)return '';$section=ForumRoutes::section((int)$map['section']);$levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();
        if(!$section||!in_array((int)$section['access'],$levels,true)||!$section['settings']->get('general.status',1)||$section['settings']->get('emerald.section_subscription')||$section['settings']->get('more.nexus_demo')||str_contains(strtolower((string)$section['settings']->get('more.robots','')),'noindex'))return '';
        return PublicDiscovery::absolute(ForumRoutes::categoryUrl((int)$map['section']));
    }
    public static function response(int $shard=-1): Response
    {
        if($shard< -1||$shard>4294967)throw new \DomainException('Fragment de sitemap invalide.',404);
        $db=\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);$s=new Store($db);
        $root=self::url();$hub=self::hub();
        $levels=array_map('intval',(new \Joomla\CMS\User\User())->getAuthorisedViewLevels());$allowed=implode(',',$levels?:[0]);
        $e=static fn($v)=>htmlspecialchars((string)$v,ENT_XML1|ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');$body='<?xml version="1.0" encoding="UTF-8"?>';
        if($shard===-1){$body.='<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
            $shards=array_map('intval',$db->setQuery("SELECT DISTINCT FLOOR(id/500) AS shard FROM #__js_res_record WHERE published=1 AND access IN (".$allowed.") AND hidden=0 AND archive=0 AND (meta_index IS NULL OR meta_index NOT LIKE '%noindex%') ORDER BY shard",0,50000)->loadColumn());
            if($hub&&!in_array(0,$shards,true))array_unshift($shards,0);
            foreach($shards as$part)$body.='<sitemap><loc>'.$e($root.'&shard='.$part).'</loc></sitemap>';
            $body.='</sitemapindex>';
        }else{$body.='<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">';$access=new NativeAccess();
            if($shard===0&&$hub)$body.='<url><loc>'.$e($hub).'</loc></url>';
            foreach($s->rows('SELECT id FROM #__js_res_record WHERE id>='.($shard*500).' AND id<'.(($shard+1)*500).' AND published=1 AND access IN ('.$allowed.') AND hidden=0 AND archive=0 ORDER BY id',500)as$r){$p=PublicMaterial::projection((int)$r['id'],true,$access);if(!$p||!empty($p['raw']['nofollow']))continue;
                $u=PublicDiscovery::absolute((string)$p['record']['url']);if(!Text::url($u))continue;$body.='<url><loc>'.$e($u).'</loc>';
                $modified=(string)($p['raw']['mtime']?:$p['raw']['ctime']);if(($date=Text::date($modified))&&strtotime($date)<=time())$body.='<lastmod>'.$e($date).'</lastmod>';
                // Only image:loc is used; deprecated caption/title tags are deliberately omitted.
                foreach(PublicDiscovery::images($p)as$image)$body.='<image:image><image:loc>'.$e($image['url']).'</image:loc></image:image>';
                $body.='</url>';
            }$body.='</urlset>';
        }
        // Access revocations must be reflected immediately; no shared stale ACL-sensitive cache.
        return new Response($body,'application/xml; charset=utf-8',200,['Cache-Control'=>'no-store','X-Content-Type-Options'=>'nosniff','X-Robots-Tag'=>'noindex']);
    }
}
