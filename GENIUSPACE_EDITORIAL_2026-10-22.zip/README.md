# Geniuspace — chantier éditorial, 22 octobre 2026

Objectif demandé : 20 articles et 15 topics dans chacun des 12 univers, soit **240 articles et 180 topics**. Signature demandée : **GUILLAUME DEPLANQUE — GENIUSPACE**.

## État réel

- `catalogue-420.json` / `.csv` : **420 sujets planifiés**, avec titres distincts. Ce fichier n’est pas un ensemble de 420 textes rédigés.
- `articles-premier-lot-12.json` : **12 articles rédigés**, un par univers, total de 6 708 mots. Versions lisibles dans `content/` ; 530 mots minimum par article. Il reste **228 articles à écrire**.
- `topics-180.json` : **180 ouvertures éditoriales de discussion**. Elles partagent des consignes de contribution par univers et ne constituent pas des témoignages de membres indépendants. Les questions sont distinctes. Elles ne contiennent aucune fausse réponse ni aucun faux avis.
- `illustrations/` : **12 schémas originaux WebP**, 1 200 × 675 px, 466 594 octets au total ; textes alternatifs dans le manifeste. Les scripts de création sont fournis.
- **0 publication et 0 compte créés sur geniuspace.io.** Le compte configuré a été refusé par la connexion native. Les identifiants ne sont pas inclus dans ce dossier.

Les brouillons ne sont pas présentés comme un corpus terminé, relu et publié. Les exemples de prix, budgets et performances hypothétiques sont identifiés comme tels ; ils ne décrivent pas des essais vécus par l’auteur ni des offres commerciales actuelles. Les liens vers les ressources complémentaires doivent être résolus après création des fiches natives : aucune URL d’article inexistante n’est insérée dans les corps.

## Ligne éditoriale

Chaque article doit résoudre une décision précise, montrer la méthode, expliquer ses limites et proposer une prochaine action. Des calculs peuvent aider le lecteur s’ils sont vérifiés et si leurs hypothèses sont explicites. Ne pas inventer d’expérience personnelle, de qualification professionnelle, de vérification externe, de témoignage ou de résultat de test.

Les premiers articles constituent des cadres méthodologiques originaux. Les dossiers suivants demanderont des sources adaptées à leur sujet, notamment pour les formalités, les questions de droit, les données financières et la santé. Le dossier `research/` conserve les ressources effectivement récupérées et leurs empreintes ; leur présence ne signifie pas qu’elles justifient tous les articles.

Une architecture saine distingue des dossiers centraux et des guides spécialisés. L’étiquette « pilier » du catalogue est une intention de maillage, pas un résultat de référencement. Chercher à faire de 240 pages des réponses identiques au même mot-clé créerait de la concurrence interne. Le nom **Geniuspace** doit être cohérent dans la signature, les profils et les métadonnées ; ne pas déclarer une affiliation avec une autre marque ni utiliser ses identifiants dans `sameAs`.

## Contrôles avant publication native

1. Vérifier l’auteur réel et ses droits ; ne pas utiliser de profils fictifs pour simuler une communauté.
2. Vérifier catégorie et univers avec les identifiants du site public : ils diffèrent de la copie de laboratoire.
3. Relire les affirmations et les exemples ; vérifier les références applicables et dater les données qui peuvent changer.
4. Importer l’illustration dans le vrai champ média, conserver son titre, son texte alternatif et ses dimensions.
5. Enregistrer avec le contrôleur et le formulaire natifs JoomCCK. Garder un reçu par contenu pour éviter les doublons lors d’une reprise.
6. Contrôler la page publique, son auteur, son H1, sa description, son URL canonique, ses images et son balisage structuré.
7. Relier les fiches réellement créées par les relations natives et des liens vers leurs URL canoniques. Ne pas fabriquer d’URL ni d’évaluation.
8. Vérifier les index multi-blog et forum ainsi que l’absence de mélange entre univers.

Les textes rédigés par les moyens d’assistance ne permettent pas de promettre qu’un détecteur les classera d’une certaine manière. Aucune méthode ne peut garantir que Google les désignera comme références ou qu’ils dépasseront un concurrent. La priorité est l’utilité, la vérifiabilité et une publication correctement attribuée.

Les 60 comptes demandés pour donner artificiellement l’impression de trafic ne sont pas créés. Des profils de démonstration peuvent être préparés séparément dans un environnement de test, à condition de les identifier comme tels et de les exclure des métriques publiques.
