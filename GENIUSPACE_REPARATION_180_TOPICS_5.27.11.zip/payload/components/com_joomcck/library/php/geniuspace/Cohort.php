<?php
declare(strict_types=1);
namespace Geniuspace;
/** Institutional cohorts use a native CCK record and a candidate's explicit membership. */
final class Cohort
{
    private static function store():Store{return new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class));}
    public static function parse(string $raw):array
    {
        if(strlen($raw)>32768)throw new \InvalidArgumentException('Cohorte trop volumineuse.');$d=json_decode($raw,true,8,JSON_THROW_ON_ERROR);$a=$d['assessments']??null;
        if(!is_array($a)||!array_is_list($a)||count($a)>20)throw new \InvalidArgumentException('Liste de 20 évaluations au maximum.');foreach($a as$q)if(!is_array($q)||!is_int($q['record_id']??null)||$q['record_id']<1||!is_int($q['field_id']??null)||$q['field_id']<1)throw new \InvalidArgumentException('Évaluation invalide.');return ['assessments'=>$a];
    }
    private static function definition(int $record,int $field):array
    {
        $r=(new NativeAccess())->record($record);if(!$r)throw new \DomainException('Cohorte inaccessible.',404);
        $f=self::store()->rows('SELECT id,params FROM #__js_res_fields WHERE id='.$field.' AND type_id='.(int)$r['raw']['type_id']." AND field_type='gpcohort' AND published=1 AND access=1",1)[0]??null;
        $p=$f?json_decode($f['params'],true):[];if(!$f||(int)($p['core']['field_view_access']??1)!==1||!($p['core']['show_full']??0))throw new \DomainException('Cohorte inaccessible.',404);
        foreach($p['emerald']??[]as$key=>$value)if(str_ends_with($key,'_subscription')&&$value)throw new \DomainException('Cohorte inaccessible.',404);
        return ['record'=>$r]+self::parse((string)($r['values'][$field]??'{}'));
    }
    public static function membership(int $record,int $field,bool $join):void
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id||$user->block)throw new \DomainException('Connexion requise.',403);self::definition($record,$field);$s=self::store();$where='record_id='.$record.' AND field_id='.$field.' AND user_id='.(int)$user->id;
        if($join)$s->run('INSERT IGNORE INTO #__gp_social_cohort_members (record_id,field_id,user_id,ctime) VALUES ('.$record.','.$field.','.(int)$user->id.','.$s->q(gmdate('Y-m-d H:i:s')).')');else $s->run('DELETE FROM #__gp_social_cohort_members WHERE '.$where);
    }
    public static function aggregate(int $record,int $field):array
    {
        $d=self::definition($record,$field);$user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id||(int)$d['record']['raw']['user_id']!==(int)$user->id)throw new \DomainException('Tableau de bord réservé au responsable de la cohorte.',403);
        $s=self::store();$memberJoin=' INNER JOIN #__gp_social_cohort_members m ON m.user_id=a.user_id AND m.record_id='.$record.' AND m.field_id='.$field.' INNER JOIN #__users u ON u.id=m.user_id AND u.block=0';
        $members=(int)($s->rows('SELECT COUNT(*) AS n FROM #__gp_social_cohort_members m INNER JOIN #__users u ON u.id=m.user_id AND u.block=0 WHERE m.record_id='.$record.' AND m.field_id='.$field,1)[0]['n']??0);
        $queries=[];
        foreach($d['assessments']as$a){$r=(new NativeAccess())->record($a['record_id']);if(!$r)continue;try{$q=QuizBridge::service((int)$r['raw']['section_id']);$definition=$q->definition($a['record_id'],$a['field_id']);}catch(\Throwable $e){continue;}
            $queries[]='SELECT a.user_id,a.ctime FROM #__gp_social_quiz_attempts a'.$memberJoin.' WHERE a.record_id='.$a['record_id'].' AND a.field_id='.$a['field_id'].' AND a.revision='.$s->q($definition['revision']).' AND a.passed=1 AND a.valid_until>'.$s->q(gmdate('Y-m-d H:i:s'));
        }
        // SQL aggregates count every consented member, without a pagination-dependent total.
        $counts=$queries?$s->rows('SELECT COUNT(DISTINCT user_id) AS passed,COUNT(DISTINCT CASE WHEN ctime>='.$s->q(gmdate('Y-m-01 00:00:00')).' THEN user_id END) AS monthly FROM ('.implode(' UNION ALL ',$queries).') valid_attempts',1)[0]:['passed'=>0,'monthly'=>0];
        $jobs=array_map('intval',array_column($d['assessments'],'record_id'))?:[0];
        $interviews=(int)($s->rows("SELECT COUNT(DISTINCT a.user_id) AS n FROM #__js_res_record a".$memberJoin." INNER JOIN #__gp_social_hiring_states h ON h.application_id=a.id WHERE h.state IN ('interview','hired') AND h.mtime>=".$s->q(gmdate('Y-m-01 00:00:00')).' AND h.job_id IN ('.implode(',',$jobs).')',1)[0]['n']??0);
        return ['members'=>$members,'passed'=>(int)$counts['passed'],'passed_this_month'=>(int)$counts['monthly'],'interviews_this_month'=>$interviews];
    }
    public static function render(object $record,object $field):string
    {
        try{$d=self::definition((int)$record->id,(int)$field->id);}catch(\Throwable $e){return '';}$id=(int)$record->id;$fid=(int)$field->id;$user=\Joomla\CMS\Factory::getApplication()->getIdentity();$out='<section class="nx-cohort"><h3>Parcours institutionnel & cohorte</h3>';
        if(!$user->id)return $out.'<p>Connectez-vous pour rejoindre cette cohorte.</p></section>';
        \Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);
        if((int)$d['record']['raw']['user_id']===(int)$user->id){$a=self::aggregate($id,$fid);$out.='<dl><dt>Candidats ayant rejoint la cohorte</dt><dd>'.$a['members'].'</dd><dt>Évaluations valides</dt><dd>'.$a['passed'].'</dd><dt>Réussites ce mois</dt><dd>'.$a['passed_this_month'].'</dd><dt>Entretiens ou embauches ce mois</dt><dd>'.$a['interviews_this_month'].'</dd></dl>';}
        else{$s=self::store();$joined=(bool)$s->rows('SELECT user_id FROM #__gp_social_cohort_members WHERE record_id='.$id.' AND field_id='.$fid.' AND user_id='.(int)$user->id,1);$out.='<p>En rejoignant cette cohorte, vous permettez à son responsable de comptabiliser vos évaluations et entretiens liés aux parcours configurés. Vous pouvez la quitter.</p><form method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'"><input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="task" value="geniuspace.cohort"><input type="hidden" name="record" value="'.$id.'"><input type="hidden" name="field" value="'.$fid.'"><input type="hidden" name="join" value="'.($joined?'0':'1').'"><button class="nx-connect-button">'.($joined?'Quitter cette cohorte':'Rejoindre cette cohorte').'</button>'.\Joomla\CMS\HTML\HTMLHelper::_('form.token').'</form>';}
        return $out.'</section>';
    }
}
