<?php
declare(strict_types=1);
namespace Geniuspace;
/** A transparent local scenario comparison. This is not a psychological diagnosis. */
final class Workstyle
{
    public static function parse(string $raw): array
    {
        if(strlen($raw)>65536)throw new \InvalidArgumentException('Scénarios trop volumineux.');$d=json_decode($raw,true,10,JSON_THROW_ON_ERROR);
        if(!is_array($d)||!is_array($d['scenarios']??null)||!array_is_list($d['scenarios'])||count($d['scenarios'])<1||count($d['scenarios'])>20)throw new \InvalidArgumentException('1 à 20 scénarios requis.');
        $target=self::vector($d['company_vector']??null);$ids=[];
        foreach($d['scenarios']as$s){if(!is_array($s)||!preg_match('/^[a-z0-9_-]{1,32}$/D',$s['id']??'')||isset($ids[$s['id']])||!is_string($s['prompt']??null)||mb_strlen($s['prompt'])>2000||!is_array($s['options']??null)||!array_is_list($s['options'])||count($s['options'])<2||count($s['options'])>6)throw new \InvalidArgumentException('Scénario invalide.');$ids[$s['id']]=true;$choices=[];
            foreach($s['options']as$o){if(!is_array($o)||!preg_match('/^[a-z0-9_-]{1,32}$/D',$o['id']??'')||isset($choices[$o['id']])||!is_string($o['text']??null)||mb_strlen($o['text'])>1000)throw new \InvalidArgumentException('Choix invalide.');$choices[$o['id']]=true;self::vector($o['traits']??null);}
        }return ['company_vector'=>$target,'scenarios'=>$d['scenarios']];
    }
    private static function vector($d): array
    {
        if(!is_array($d)||!$d||count($d)>12)throw new \InvalidArgumentException('Vecteur de 1 à 12 dimensions requis.');
        foreach($d as$k=>$v)if(!is_string($k)||!preg_match('/^[a-z0-9_-]{1,32}$/D',$k)||(!is_int($v)&&!is_float($v))||!is_finite((float)$v)||$v<0||$v>100)throw new \InvalidArgumentException('Dimension invalide.');return $d;
    }
    public static function compare(array $definition,array $answers): array
    {
        $vector=[];$known=array_column($definition['scenarios'],null,'id');if(count($answers)!==count($known)||array_diff(array_keys($answers),array_keys($known)))throw new \InvalidArgumentException('Répondez à tous les scénarios.');
        foreach($known as$id=>$s){$choice=$answers[$id]??null;$options=array_column($s['options'],null,'id');if(!is_string($choice)||!isset($options[$choice]))throw new \InvalidArgumentException('Choix non autorisé.');foreach($options[$choice]['traits']as$k=>$v)$vector[$k]=($vector[$k]??0)+$v;}
        $target=$definition['company_vector'];$keys=array_unique(array_merge(array_keys($vector),array_keys($target)));$dot=$a=$b=0.;foreach($keys as$k){$x=(float)($vector[$k]??0);$y=(float)($target[$k]??0);$dot+=$x*$y;$a+=$x*$x;$b+=$y*$y;}
        return ['vector'=>$vector,'similarity'=>$a>0&&$b>0?round(min(100,max(0,100*$dot/sqrt($a*$b))),1):null];
    }
    public static function submit(int $record,int $field,array $answers): void
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id||$user->block)throw new \DomainException('Connexion requise.',403);
        $r=(new NativeAccess())->record($record);if(($r['fields'][$field]['field_type']??'')!=='gpworkstyle')throw new \DomainException('Scénarios inaccessibles.',404);
        $raw=(string)($r['values'][$field]??'');$result=self::compare(self::parse($raw),$answers);$s=new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class));$revision=hash('sha256',$raw);
        $s->run('INSERT INTO #__gp_social_workstyle (record_id,field_id,user_id,revision,result,ctime) VALUES ('.$record.','.$field.','.(int)$user->id.','.$s->q($revision).','.$s->q(Seo::json($result)).','.$s->q(gmdate('Y-m-d H:i:s')).') ON DUPLICATE KEY UPDATE revision=VALUES(revision),result=VALUES(result),ctime=VALUES(ctime)');
    }
    public static function render(object $record,object $field): string
    {
        try{$d=self::parse((string)$field->value);}catch(\Throwable $e){return '';}$user=\Joomla\CMS\Factory::getApplication()->getIdentity();$id=(int)$record->id;$fid=(int)$field->id;$out='<section class="nx-workstyle"><h3 class="font-bold mb-3">Simulateur des façons de travailler</h3><p class="text-sm mb-4">Comparez vos choix à un profil déclaré par l’entreprise. Ce résultat décrit ces scénarios ; il ne constitue ni un diagnostic ni une condition de candidature.</p>';
        if(!$user->id)return $out.'<p>Connectez-vous pour enregistrer vos choix personnels.</p></section>';
        \Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);$s=new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class));$row=$s->rows('SELECT revision,result FROM #__gp_social_workstyle WHERE record_id='.$id.' AND field_id='.$fid.' AND user_id='.(int)$user->id,1)[0]??[];
        if(($row['revision']??'')===hash('sha256',(string)$field->value)){$result=json_decode($row['result'],true);$out.='<p class="nx-workstyle-result"><strong>Proximité sur ces scénarios : '.($result['similarity']!==null?Text::escape((string)$result['similarity']).' %':'indéterminée').'</strong></p>';}
        $out.='<form method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'"><input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="task" value="geniuspace.workstyle"><input type="hidden" name="record" value="'.$id.'"><input type="hidden" name="field" value="'.$fid.'">';
        foreach($d['scenarios']as$scenario){$out.='<fieldset class="nx-workstyle-scenario"><legend>'.Text::escape($scenario['prompt']).'</legend>';foreach($scenario['options']as$o)$out.='<label><input required type="radio" name="answers['.Text::escape($scenario['id']).']" value="'.Text::escape($o['id']).'"> '.Text::escape($o['text']).'</label>';$out.='</fieldset>';}
        return $out.'<button class="nx-connect-button">Comparer mes choix</button>'.\Joomla\CMS\HTML\HTMLHelper::_('form.token').'</form></section>';
    }
}
