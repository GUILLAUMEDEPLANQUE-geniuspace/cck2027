<?php
/** forum7.html: native CCK data, local assets and progressive enhancement. */
defined('_JEXEC') or die;
require_once __DIR__.'/NexusMultivers.php';
require_once __DIR__.'/NexusAbsolu.php';

final class NexusForumSeven
{
    public static function assets(): void
    {
        \Geniuspace\Ergonomics::assets();\Geniuspace\PathPresentation::assets();NexusMultivers::assets();static $done=false;if($done)return;$done=true;
        $d=\Joomla\CMS\Factory::getApplication()->getDocument();$d->setLanguage(NexusSuite::locale());$base=\Joomla\CMS\Uri\Uri::root(true).'/media/com_joomcck/nexus/';
        $d->addStyleSheet($base.'forum7.css',['version'=>'5.16.0']);
        require_once __DIR__.'/NexusAbsolu.php';NexusAbsolu::assets();
        $d->addScript($base.'forum7.js',['version'=>'5.27.7'],['type'=>'module']);\Geniuspace\AppDock::assets();
    }
    /** Native category ACLs include all ancestors, including unpublished parents. */
    public static function categories(int $section): array
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();$key='category-tree:'.$section.':'.$user->id.':'.implode(',',$user->getAuthorisedViewLevels());
        $roots=\Geniuspace\ReadMemo::get($key,static fn()=>self::readCategories($section));return self::cloneCategories($roots);
    }
    private static function cloneCategories(array $roots): array
    {
        $out=[];foreach($roots as$node){$copy=clone$node;$copy->params=new \Joomla\Registry\Registry($node->params->toArray());$copy->children=self::cloneCategories($node->children);$out[]=$copy;}return $out;
    }
    private static function readCategories(int $section): array
    {
        $s=\Geniuspace\ProductAccess::store();$levels=\Joomla\CMS\Factory::getApplication()->getIdentity()->getAuthorisedViewLevels();
        $raw=$s->db->setQuery('SELECT * FROM #__js_res_categories WHERE section_id='.$section.' ORDER BY lft,id')->loadAssocList();$by=[];
        foreach($raw as$r)$by[(int)$r['id']]=$r;
        $visible=function(array $r)use($by,$levels):bool{$seen=[];while(true){$id=(int)$r['id'];if(isset($seen[$id])||(int)$r['published']!==1||!in_array((int)$r['access'],$levels,true))return false;$seen[$id]=true;$parent=(int)$r['parent_id'];if($parent<=1)return true;if(!isset($by[$parent]))return false;$r=$by[$parent];}};
        $nodes=[];foreach($by as$id=>$r)if($visible($r)){$c=(object)$r;$c->params=new \Joomla\Registry\Registry($r['params']);$c->children=[];$c->link=\Geniuspace\ForumRoutes::categoryUrl($section,$id);$nodes[$id]=$c;}
        $roots=[];foreach($nodes as$id=>$c){$parent=(int)$c->parent_id;if(isset($nodes[$parent]))$nodes[$parent]->children[]=$c;else$roots[]=$c;}$catalog=array_keys(\Geniuspace\UniverseBlueprint::catalogue());usort($roots,static function($a,$b)use($catalog){$ak=$a->params->get('universe_v21')?array_search($a->params->get('universe_key'),$catalog,true):999;$bk=$b->params->get('universe_v21')?array_search($b->params->get('universe_key'),$catalog,true):999;return $ak<=>$bk?:((int)$a->lft<=>(int)$b->lft);});return $roots;
    }
    public static function flat(array $roots): array
    { $all=[];foreach($roots as$c){$all[(int)$c->id]=$c;$all+=self::flat($c->children);}return $all; }
    public static function image(object $c,int $width=64): string
    {
        return \Geniuspace\ForumCategories::image($c,$width);
    }
    public static function imageHtml(object $c,int $width=64,string $class='squircle',bool $eager=false): string
    {
        if(!$src=self::image($c,$width))return NexusConnect::icon((string)$c->params->get('icon','hashtag'));
        $alt=\Geniuspace\ForumCategories::alt($c);[$actualWidth,$height]=\Geniuspace\ForumCategories::dimensions($src,$width);
        $set=[];foreach([64,256,768]as$size)if($v=self::image($c,$size)){[$w]=\Geniuspace\ForumCategories::dimensions($v,$size);$set[$v]=NexusSuite::e($v).' '.$w.'w';}
        return '<img src="'.NexusSuite::e($src).'" srcset="'.implode(', ',$set).'" sizes="'.($width===768?'(max-width: 767px) 100vw, 720px':$width.'px').'" class="'.NexusSuite::e($class).'" alt="'.NexusSuite::e($alt).'" width="'.$actualWidth.'" height="'.$height.'" loading="'.($eager?'eager':'lazy').'" decoding="async"'.($eager?' fetchpriority="high"':'').'>';
    }
    public static function metadata(int $section,array $categories,?object $category,array $items): void
    {
        require_once __DIR__.'/NexusForumApp.php';
        $doc=\Joomla\CMS\Factory::getApplication()->getDocument();$sec=\ItemsStore::getSection($section);
        $url=NexusPlatform::sameSite(\Geniuspace\ForumRoutes::categoryUrl($section,(int)($category->id??0)));
        $title=$category?\Geniuspace\ForumCategories::title($category):$sec->title.' | Geniuspace';
        $desc=$category?\Geniuspace\ForumCategories::description($category):(string)$sec->params->get('more.metadesc');
        if(!$category){$brand=\Geniuspace\BrandGateway::identity();$title=$brand['title'];$desc=$brand['description'];}
        $doc->setTitle($title);$doc->setDescription($desc);NexusForumApp::social($url,'website',$category?self::image($category,768):'',$category?\Geniuspace\ForumCategories::alt($category):'');$doc->setMetaData('og:title',$title,'property');$doc->setMetaData('og:description',$desc,'property');$doc->setMetaData('og:url',$url,'property');
        $head=$doc->getHeadData();foreach($head['links']??[]as$key=>$link)if(($link['relation']??'')==='canonical')unset($head['links'][$key]);$doc->setHeadData($head);$doc->addHeadLink($url,'canonical');
        $input=\Joomla\CMS\Factory::getApplication()->input;
        if($input->getString('nx_query','')!==''&&!$input->getString('q','')&&\Joomla\CMS\Factory::getApplication()->get('sef')&&strtoupper($input->getMethod())==='GET'){
            $search=new \Joomla\CMS\Uri\Uri(\Geniuspace\ForumRoutes::searchUrl($section));$search->setVar('q',mb_substr($input->getString('nx_query'),0,200));\Joomla\CMS\Factory::getApplication()->redirect($search->toString(),301);
        }
        if($input->getInt('nx_all_universes')||$input->getString('nx_query','')!==''||$input->getString('q','')!==''||$input->getInt('nx_search')||$input->getInt('start',0)>0||$input->getInt('limitstart',0)>0||$input->get('filter',[],'array'))$doc->setMetaData('robots','noindex, follow');
        $guest=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();if(!in_array((int)$sec->access,$guest,true)||$sec->params->get('emerald.section_subscription')||($category&&!\Geniuspace\ForumCategories::public((array)$category))){$doc->setMetaData('robots','noindex, nofollow');return;}
        $node=['@context'=>'https://schema.org','@type'=>'CollectionPage','@id'=>$url.'#page','url'=>$url,'name'=>$title,'description'=>$desc,'inLanguage'=>NexusSuite::locale()];
        if($category&&$image=self::image($category,768)){[$width,$height]=\Geniuspace\ForumCategories::dimensions($image,768);$alt=\Geniuspace\ForumCategories::alt($category);$node['image']=['@type'=>'ImageObject','contentUrl'=>$image,'caption'=>$alt,'width'=>$width,'height'=>$height];$doc->setMetaData('og:image',$image,'property');$doc->setMetaData('og:image:alt',$alt,'property');$doc->setMetaData('og:image:width',(string)$width,'property');$doc->setMetaData('og:image:height',(string)$height,'property');}
        NexusPlatform::ld($node);NexusPlatform::itemList($items);
        $crumbs=[['@type'=>'ListItem','position'=>1,'name'=>$sec->title,'item'=>NexusPlatform::sameSite(\Geniuspace\ForumRoutes::categoryUrl($section))]];
        if($category){$flat=self::flat($categories);$chain=[];$c=$category;while($c&&count($chain)<20){array_unshift($chain,$c);$c=$flat[(int)$c->parent_id]??null;}foreach($chain as$c)$crumbs[]=['@type'=>'ListItem','position'=>count($crumbs)+1,'name'=>$c->title,'item'=>NexusPlatform::sameSite($c->link)];}
        NexusPlatform::ld(['@context'=>'https://schema.org','@type'=>'BreadcrumbList','itemListElement'=>$crumbs]);
    }
    public static function focused(): bool
    {return \Joomla\CMS\Factory::getApplication()->input->getInt('nx_focus',0)===1;}
    /** Presentation preference only: the native canonical and content identity stay unchanged. */
    public static function focusUrl(string $url,bool $enabled): string
    {
        $uri=new \Joomla\CMS\Uri\Uri($url);
        if($enabled)$uri->setVar('nx_focus',1);else$uri->delVar('nx_focus');
        return $uri->toString();
    }
    public static function modeUrl(string $url,string $mode): string
    {
        $uri=new \Joomla\CMS\Uri\Uri($url);$uri->delVar('nx_focus');$uri->setVar('nx_mode',$mode==='blog'?'blog':'forum');return$uri->toString();
    }
    public static function header($p,int $section,string $home,string $focus='',string $mode='forum'): string
    {
        $e=[NexusSuite::class,'e'];$u=\Geniuspace\ProductAccess::user();$ctx=\Geniuspace\UniverseBlueprint::context($section,\Geniuspace\UniverseBlueprint::selected($section));
        $label=$ctx['universe']['shortName']??'Tous les univers';
        $out='<header class="meta-header nx-v23-header"><a href="'.$e($home).'" class="meta-brand">'.NexusConnect::icon('bolt').' Geniuspace</a><span class="nx-v23-universe-pill">'.$e($label).'</span><button type="button" class="nx-v23-omnibar" data-dock-open="search" aria-label="Rechercher dans Geniuspace">'.NexusConnect::icon('magnifying-glass').'<span>Rechercher un guide, un emploi, @Entreprise, #Catégorie…</span><kbd>Ctrl+K</kbd></button>';
        $out.='<nav class="forum7-mode" aria-label="Explorer ou lire">';
        foreach(['forum'=>['Explorer l’Univers','table-columns',$home],'blog'=>['Multi-Blog','book-open',\Geniuspace\NexusBlogIndex::url($section)]]as$key=>[$label,$icon,$url])$out.='<a id="btn-mode-'.$key.'" href="'.$e($url).'" data-forum7-mode="'.$key.'" role="button" aria-pressed="'.($mode===$key?'true':'false').'" title="'.$e($label).'">'.NexusConnect::icon($icon).'<span>'.$e($label).'</span></a>';
        $out.='</nav>'.\Geniuspace\UniverseExperience::creatorButton().'<button type="button" class="nx-v23-publish" data-dock-open="publish" title="Publier dans cet univers">＋ <span>Publier</span></button><button type="button" class="nx-v23-account" data-dock-open="me" title="Mon espace">'.NexusMultivers::avatar($u->id?$u->name:'V',24).'<span>Mon Espace</span></button><span class="sr-only" role="status" data-forum7-mode-status></span><div data-shell-site-navigation></div><div hidden>'.\Geniuspace\PathPresentation::launcher().'</div></header>';
        return $out;
    }
    private static function inbox(): string
    {
        $u=\Geniuspace\ProductAccess::user();if(!$u->id)return '';$items=\Geniuspace\MultiverseMechanisms::inbox();$e=[NexusSuite::class,'e'];
        $out='<details class="nx-paid-inbox"><summary>✉ Sollicitations <small>'.count($items).'</small></summary><div class="nx-inbox-panel"><h3>Mes échanges professionnels</h3>';
        foreach($items as$i)$out.='<a href="'.$e($i['url']).'"><strong>'.$e($i['company']).'</strong><span>'.$e($i['subject']).'</span><small>Échange non financé</small></a>';
        return$out.(!$items?'<p>Aucune demande en attente. Vous choisissez librement d’accepter ces échanges.</p>':'').'</div></details>';
    }
    public static function rail(array $roots,$p,array $items,string $home,int $active=0): string
    {
        $out='<nav class="forum7-rail hide-scroll" aria-label="Univers de la communauté"><a class="sidebar-group active" href="'.NexusSuite::e($home).'" aria-label="Méta-Hub"><span class="squircle bg-primary text-white text-xl">'.NexusConnect::icon('globe').'</span></a><span class="sidebar-divider"></span>';
        $pinned=array_values(array_filter(array_map('intval',preg_split('/[,;\s]+/',NexusPlatform::config($p,'rail_categories'),-1,PREG_SPLIT_NO_EMPTY))));$rail=$roots;
        if($pinned){$all=self::flat($roots);$rail=[];foreach($pinned as$id)if(isset($all[$id]))$rail[]=$all[$id];}
        $shown=[];$rail=array_values(array_filter($rail,static function($c)use(&$shown,$roots){$key=\Geniuspace\UniverseBlueprint::rootKey($c,self::flat($roots));if(!$key||$key==='tech'||isset($shown[$key]))return false;$shown[$key]=true;return true;}));
        foreach($rail as$c)$out.='<a class="sidebar-group'.($active===(int)$c->id?' active':'').'" href="'.NexusSuite::e($c->link).'" aria-label="'.NexusSuite::e($c->title).'" title="'.NexusSuite::e($c->title).'"><span class="active-indicator"></span>'.'<span class="squircle forum8-universe-icon" style="--forum8-accent:'.NexusSuite::e(preg_match('/^#[a-f0-9]{6}$/iD',(string)$c->params->get('color'))?(string)$c->params->get('color'):'#4f46e5').'">'.NexusConnect::icon((string)$c->params->get('icon','hashtag')).'</span><span class="sr-only">'.self::imageHtml($c).'</span><span class="forum7-tooltip">'.NexusSuite::e($c->title).'</span></a>';
        $seen=[];foreach($items as$i)foreach(NexusConversation::targets($i,$p,'field_workspaces',12)as$target){if(isset($seen[$target->id]))continue;$seen[$target->id]=true;$cover=\Geniuspace\RelationCards::value($target,(string)(NexusMultivers::field($i,$p,'field_workspaces')?->params->get('params.card_cover_fields','')??''),true);$out.='<a class="sidebar-group" href="'.NexusSuite::e(NexusPlatform::sameSite(\Geniuspace\ExtendedFields::url($target))).'" aria-label="'.NexusSuite::e($target->title).'">'.($cover?'<img class="squircle" src="'.NexusSuite::e($cover).'" alt="'.NexusSuite::e($target->title).'" width="48" height="48" loading="lazy" decoding="async">':'<span class="squircle bg-slate-900 text-white">'.NexusSuite::e(mb_substr($target->title,0,1)).'</span>').'<span class="forum7-tooltip">'.NexusSuite::e($target->title).'</span></a>';}
        foreach($items as$i)if($html=NexusConnect::region($i,$p,'workspaces'))$out.='<div class="forum7-workspaces">'.$html.'</div>';
        return $out.'<span class="sidebar-divider"></span><a class="sidebar-group" href="#nx-journey-explorer" data-journey-open aria-label="Explorer les parcours"><span class="squircle bg-brand-50 border border-brand-200 text-slate-500">'.NexusConnect::icon('compass').'</span></a><a class="sidebar-group" href="#forum7-directory" aria-label="Explorer les catégories"><span class="squircle">'.NexusConnect::icon('list').'</span></a></nav>';
    }
    public static function directory(array $roots,int $active=0,string $id='forum7-directory'): string
    {
        $branch=function($nodes)use(&$branch,$active):string{$out='';foreach($nodes as$c){$link='<a href="'.NexusSuite::e($c->link).'"'.($active===(int)$c->id?' aria-current="page"':'').'>'.\Geniuspace\UniverseBlueprint::categoryIcon($c).'<span>'.NexusSuite::e(\Geniuspace\UniverseBlueprint::label($c)).'</span></a>';
            $expanded=$active===(int)$c->id||isset(self::flat($c->children)[$active]);
            if($c->children)$out.='<details'.($expanded?' open':'').'><summary>'.$link.NexusConnect::icon('chevron-down').'</summary><div class="forum7-subcategories">'.$branch($c->children).'</div></details>';else$out.=$link;
        }return $out;};
        $primary=[];$extra=[];$shown=[];$flat=self::flat($roots);foreach($roots as$c){$key=\Geniuspace\UniverseBlueprint::rootKey($c,$flat);if($key&&$key!=='tech'&&!isset($shown[$key])){$primary[]=$c;$shown[$key]=true;}else$extra[]=$c;}
        $tree=$branch($primary);if($extra)$tree.='<details class="nx-directory-extra"><summary>Autres communautés '.NexusConnect::icon('chevron-down').'</summary>'.$branch($extra).'</details>';
        return '<aside class="forum7-directory" id="'.NexusSuite::e($id).'"><h2>'.NexusConnect::icon('network-wired').' Annuaire 3 Niveaux</h2><label class="nx-directory-search">Filtrer l’annuaire<input type="search" data-universe-directory-filter placeholder="PS5, Japon, holding…"></label><nav aria-label="Catégories et sous-forums">'.$tree.'</nav></aside>';
    }
    public static function ticker(array $items,$p): string
    {
        $extra=$items;$section=(int)($items[0]->section_id??\Joomla\CMS\Factory::getApplication()->input->getInt('section_id',0));$key=NexusPlatform::config($p,'field_news');if($section&&$key){$store=\Geniuspace\ProductAccess::store();$f=$store->rows('SELECT id FROM #__js_res_fields WHERE `key`='.$store->q($key),1)[0]??null;if($f)foreach($store->rows('SELECT id,fields FROM #__js_res_record WHERE published=1 AND hidden=0 AND section_id='.$section.' ORDER BY mtime DESC,id DESC',150)as$r){$v=json_decode($r['fields'],true)?:[];$value=$v[(int)$f['id']]??'';if(is_array($value))$value=reset($value);if(in_array(mb_strtolower((string)$value),['1','oui','yes'],true)&&($public=\Geniuspace\ExtendedFields::publicRecord((int)$r['id'],false)))$extra[]=$public;}}$seen=[];$out='';foreach($extra as$i){if(isset($seen[(int)$i->id]))continue;$seen[(int)$i->id]=true;$news=NexusPlatform::raw($i,$p,'field_news');if(!in_array(mb_strtolower($news),['1','oui','yes','actualite','actualité'],true))continue;
            $out.='<a class="ticker-item" href="'.NexusSuite::e(NexusPlatform::recordUrl($i)).'">'.NexusConnect::icon('bolt').' '.NexusSuite::e($i->title).'</a>';}
        return $out?'<div class="ticker-wrap"><div class="ticker">'.$out.'</div><button type="button" class="ticker-toggle" data-meta-ticker-pause aria-label="Suspendre le bandeau" aria-pressed="false">Ⅱ</button></div>':NexusMultivers::ticker($items,$p);
    }
    public static function contentType(object $i,$p): string
    {return NexusForumApp::isArticle($i,$p)?'article':'discussion';}
    public static function sidebar(array $items,$p,int $section): string
    {
        $category=\Geniuspace\UniverseBlueprint::selected($section);$ctx=\Geniuspace\UniverseBlueprint::context($section,$category);
        $legacy=NexusMultivers::sidebar($items,$p);$legacy=preg_replace('~^<aside[^>]*><div[^>]*>~','',$legacy);$legacy=preg_replace('~</div></aside>$~','',$legacy);
        $out='<aside class="nx-reference-sidebar" aria-label="À la Une, assistant et parcours">';
        if($ctx['universe'])$out.=\Geniuspace\UniverseBlueprint::sidebar($section,$category,$p);
        else $out.=\Geniuspace\JourneyCatalogue::widget('');
        if($ctx['current'])$out.=\Geniuspace\SemanticLinks::block(\Geniuspace\SemanticLinks::suggestions($ctx['current']->title,array_map(static fn($i)=>(int)$i->id,$items),4),'Explorer les connexions');
        $activity=NexusForumIndex::activity($section);$links='';foreach(array_slice($activity['records'],0,5)as$r)$links.='<a class="forum7-recent" href="'.NexusSuite::e($r['url']).'">'.NexusSuite::e($r['title']).'<small>'.(int)($activity['replies'][$r['id']]??0).' réponses publiques</small></a>';
        // Every existing sidebar field, radar and network destination remains reachable.
        $out.='<details class="nx-reference-more"><summary>Salons, réseau & activité</summary>'.$legacy.NexusAbsolu::regions($items,$p,'radar').NexusAbsolu::radarPreview($section).'<section class="forum7-sidebar-block"><h2>'.NexusConnect::icon('fire-flame-curved').' Sujets récents</h2>'.($links?:'<p>Les prochains sujets apparaîtront ici.</p>').'</section></details>';
        return \Geniuspace\DesignInlineParts::markSidebar($out.'</aside>');
    }
    /** Local browser TTS is explicitly triggered; stored audio keeps its native field output. */
    public static function narration(): string
    {return '<div class="forum7-narration bg-slate-900 rounded-2xl p-4 flex items-center gap-4 shadow-xl font-sans"><button type="button" class="squircle bg-immo text-white" data-forum7-speak aria-label="Écouter cet article">'.NexusConnect::icon('play').'</button><div><strong class="text-immo text-xs">'.NexusConnect::icon('podcast').' Écouter l’article</strong><span data-forum7-speech-status class="text-xs text-white" role="status"></span></div></div>';}
}
