# Lire un grimoire ancien : distinguer document historique, récit et allégation

Un grimoire peut être étudié comme un document : qui l’a produit, dans quel contexte, sous quelle forme et à travers quelle transmission ? Cette démarche permet de s’intéresser aux récits et aux pratiques sans transformer chaque formule en fait historique établi ou en mécanisme démontré. La première tâche est de décrire la source avant de l’interpréter.

## Identifier l’objet que l’on est réellement en train de lire

Une photographie de page, une transcription, une traduction et une édition commentée ne sont pas des objets équivalents. Relevez le titre utilisé, l’auteur attribué, la date annoncée, l’édition, la provenance et la personne responsable d’une éventuelle traduction. Quand une information manque, conservez ce manque au lieu de le remplacer par une supposition.

L’ancienneté revendiquée dans un texte n’établit pas à elle seule la date du document consulté. De même, une copie numérique peut reproduire une édition récente qui reprend des éléments plus anciens. Il faut garder distinctes la date du récit, celle de son témoin matériel et celle de l’édition accessible.

## Séparer les niveaux de lecture

| Niveau | Question | Formulation prudente |
|---|---|---|
| Description | Que voit-on sur la page ou dans l’édition ? | « Le passage contient cette formulation » |
| Attribution | À qui et à quelle période le texte est-il rattaché ? | « L’édition attribue le texte à… » |
| Interprétation | Quel sens propose-t-on dans ce contexte ? | « Une lecture possible est… » |
| Allégation | Le texte prétend-il produire un effet dans le monde ? | « Le document affirme…, ce qui demande une preuve distincte » |

Cette séparation n’appauvrit pas le texte. Elle permet au contraire de discuter une hypothèse sans demander au lecteur d’accepter toutes les autres en bloc.

## Construire une fiche de passage révisable

Pour un passage choisi, notez son emplacement, sa transcription et les difficultés de lecture. Ajoutez ensuite les variantes d’une autre édition en indiquant exactement d’où elles proviennent. Une différence peut venir d’une traduction, d’une modernisation ou d’un choix éditorial ; l’observer ne suffit pas à en expliquer l’origine.

Dans un exemple de travail, une édition écrit « cueillir au matin » et une autre « cueillir avant le lever du soleil ». La divergence mérite d’être conservée et comparée à leurs sources. Elle ne permet pas, à elle seule, de reconstituer une pratique générale ou de démontrer un effet du moment de cueillette. Cet exemple est fictif et ne constitue pas une citation historique.

## Ne pas confondre étude culturelle et conseil de santé

Un texte peut mentionner une plante, une préparation ou une ingestion. Son intérêt historique n’autorise pas à reproduire la recette. L’identification, la toxicité, les interactions et la situation d’une personne demandent d’autres compétences et d’autres preuves. Une photographie ou un nom vernaculaire peuvent laisser subsister une ambiguïté importante.

Un dossier documentaire doit donc éviter de transformer une description ancienne en recommandation pratique. Il peut expliquer ce que la source dit et pourquoi cela mérite une vérification, tout en maintenant une limite claire sur l’usage.

## Partager une enquête plutôt qu’une certitude fabriquée

Conservez les références d’édition, les droits applicables aux images et l’attribution des transcriptions ou traductions. Si une interprétation change, ajoutez la correction et la nouvelle référence au dossier.

Une discussion collective devient productive lorsqu’elle porte sur un passage repérable et sur la nature exacte d’un désaccord. Il est alors possible d’enrichir le lexique, de comparer les versions et de documenter les zones d’incertitude sans transformer les traditions en un ensemble de réponses invérifiables.

## Décrire un grimoire comme un document, avant de l’interpréter

Une notice exploitable distingue l’objet consulté de l’œuvre qu’on lui attribue. Relevez le titre indiqué, l’auteur annoncé, l’éditeur, la date de cette édition, le traducteur éventuel, la pagination et l’endroit précis du passage. Une réédition récente d’un texte présenté comme ancien n’est pas un exemplaire ancien. Une couverture patinée ou une illustration évocatrice ne permet pas de dater un contenu.

Pour une image numérique, conservez l’institution ou le détenteur qui la diffuse, l’identifiant de la notice, les conditions de réutilisation et la date de consultation. Un recadrage peut faire disparaître une légende ou une marque de provenance utile. N’attribuez pas à l’archive des affirmations que seule une publication commerciale formule.

## Comparer deux traductions sans décréter une vérité unique

Choisissez un passage court autorisé à la citation. Situez-le dans chaque édition et décrivez la différence observée : mot, découpage, note, omission annoncée ou choix d’interprétation. Une différence ne suffit pas à établir une falsification ; elle peut venir d’un texte source distinct ou d’une politique éditoriale explicite. La question suivante est de retrouver cette explication.

Le carnet comporte une colonne « observation » et une colonne « interprétation ». « Cette édition emploie ce terme » est une observation vérifiable dans la référence indiquée. « Ce terme prouve l’existence d’un pouvoir » est une proposition d’une autre nature, qui ne découle pas de la première. Cette séparation permet aux amateurs d’histoire, de symbolisme et de traditions de participer sans brouiller les niveaux de preuve.

## Créer une discussion accueillante et sûre

Demandez une source et un contexte plutôt que de ridiculiser une croyance. On peut examiner une attribution, une gravure ou une filiation culturelle sans promettre de résultat surnaturel. Les références à des plantes, fumigations ou substances ne valent pas instruction d’usage : leur présence dans un texte historique ne démontre ni innocuité ni efficacité. Les illustrations originales de ce dossier sont des créations éditoriales et ne représentent pas un manuscrit identifié.
