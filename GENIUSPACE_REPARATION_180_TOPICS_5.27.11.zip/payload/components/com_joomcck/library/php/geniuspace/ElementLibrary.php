<?php
declare(strict_types=1);
namespace Geniuspace;

/** Every design element can bind several fields; stored data remains in native CCK records. */
final class ElementLibrary
{
    public static function assets(): void
    {
        static $done=false;if($done)return;$done=true;$d=\Joomla\CMS\Factory::getApplication()->getDocument();$base=\Joomla\CMS\Uri\Uri::root(true).'/media/com_joomcck/nexus/';
        $d->addStyleSheet($base.'experience-v580.css',['version'=>'5.8.0']);$d->addScript($base.'experience-v580.js',['version'=>'5.8.0'],['defer'=>true]);
    }
    public static function render(array $d,array $r,int $field,bool $full=true): string
    {
        self::assets();$private=in_array($d['element'],ElementData::PRIVATE,true);$u=ProductAccess::user();if($private&&(!$u->id||$u->block))return '<p class="gp-element-signin">Connectez-vous pour retrouver votre espace personnel.</p>';
        if($private)\Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);
        $title=NativeBindings::text($r,$d,'heading',$d['title']);$intro=NativeBindings::text($r,$d,'intro',$d['intro']);$id='gp-element-'.(int)$r['id'].'-'.$field;
        $out='<section class="gp-element gp-element-'.$d['element'].' gp-element-'.$d['variant'].'" id="'.$id.'" data-gp-element="'.$d['element'].'" data-record="'.(int)$r['id'].'" style="--gp-element-accent:'.Text::escape($d['color']).'">';
        if($title)$out.='<header class="gp-element-heading"><i class="fa-solid fa-'.Text::escape($d['icon']).'" aria-hidden="true"></i><h2>'.Text::escape($title).'</h2></header>';
        if($intro)$out.='<p class="gp-element-intro">'.Text::escape($intro).'</p>';
        $out.=match($d['element']){
            'workspace'=>self::workspace(),'preferences'=>self::preferences(),'goal'=>self::goal(),'watch'=>self::watch($r),
            'comparison'=>self::comparison($d),'release'=>self::release($r),'commitments'=>self::commitments($d,$r,$field),
            'project'=>self::project($d,$r,$field),'study'=>self::study($d),'format'=>self::format($d),'reputation'=>self::reputation($d),
            'author'=>self::author(),'ai'=>self::ai(),'search'=>self::search(),'taxonomy'=>self::taxonomy($d),
            'sitemap'=>self::sitemap(),'journey'=>self::journey($d,$r),
            'actions'=>self::actions($d,$r),'questions'=>self::questions($d,$r),
            'campaign'=>self::campaign($d,$r),default=>self::parts($d,$r)};
        return $out.'</section>';
    }
    private static function parts(array $d,array $r): string
    {
        $out='<div class="gp-element-parts">';$scope=substr(hash('sha256',Seo::json($d)),0,12);foreach($d['parts']as$n=>$part){$out.='<article id="gp-part-'.(int)$r['id'].'-'.$scope.'-'.$n.'"><h3><i class="fa-solid fa-'.Text::escape($part['icon']).'" aria-hidden="true"></i> '.Text::escape($part['title']).'</h3><p>'.Text::escape($part['text']).'</p>';
            foreach(NativeBindings::values($r,$part['field_ids'])as$f)$out.='<div class="gp-element-bound" data-native-field="'.$f['field'].'">'.$f['html'].'</div>';
            if($part['date'])$out.='<time datetime="'.Text::escape($part['date']).'">'.Text::escape($part['date']).'</time>';
            if($part['source_record'])$out.=self::links([$part['source_record']],'Source');$out.='</article>';}
        foreach($d['bindings']as$role=>$ids)if(!in_array($role,['heading','intro','destination'],true))foreach(NativeBindings::values($r,$ids)as$f)$out.='<article class="gp-element-bound" data-native-field="'.$f['field'].'"><h3>'.Text::escape($f['label']).'</h3>'.$f['html'].'</article>';
        $out.='</div>';if($d['criteria']){$out.='<div class="gp-element-criteria"><h3>Critères et réalisation attendue</h3><ul>';foreach($d['criteria']as$criterion)$out.='<li>'.Text::escape($criterion).'</li>';$out.='</ul></div>';}if($d['element']==='sources'){foreach(NativeBindings::values($r,$d['bindings']['development']??[])as$f)$out.='<div class="gp-record-citation"><button type="button" data-gp-cite="gp-passage-'.(int)$r['id'].'-'.$f['field'].'" data-title="'.Text::escape($r['title']).'">Citer ce passage avec sa source</button><output role="status"></output></div>';}if($d['method'])$out.='<details><summary>Sources et méthode</summary><p>'.Text::escape($d['method']).'</p></details>';return $out.self::links($d['record_ids']);
    }
    public static function links(array $ids,string $label='Découvrir'): string
    {
        $out='<div class="gp-element-links">';foreach($ids as$id){try{$r=ProductAccess::visible((int)$id);}catch(\DomainException){continue;}$url=ExtendedFields::url((object)$r);$out.='<a href="'.Text::escape($url).'">'.Text::escape($r['title']).'<small>'.Text::escape($label).' →</small></a>';}return $out.'</div>';
    }
    private static function form(string $action,int $record,array $extra=[]): string
    { return ProductAccess::form('experience.'.$action,$record,$extra); }
    private static function workspace(): string
    {
        $w=Experience::workspace();$launcher=PersonalPaths::ready()?PathPresentation::launcher():'';$out=$w['goal']['goal']?'<p>Mon objectif : '.Text::escape($w['goal']['goal']).'</p>':'';$out=$launcher.$out;
        foreach($w['items']as$i)$out.='<article class="gp-resume-item"><a href="'.Text::escape($i['url']).'">'.Text::escape($i['title']).'</a><span>'.(int)$i['position'].' % · '.Text::escape($i['kind']).'</span>'.($i['changed']?'<strong>Ce contenu a évolué depuis votre dernière étape.</strong>':'').'</article>';
        if(!$w['items'])$out.='<p>Sauvegardez une lecture ou un parcours pour le retrouver ici.</p>';
        $groups=[];foreach($w['notifications']as$n){$period=match($w['preferences']['frequency']){'weekly'=>date('o-\WW',strtotime($n['ctime'])),'daily'=>substr($n['ctime'],0,10),default=>'Nouveautés'};$groups[$period][]=$n;}
        foreach($groups as$period=>$rows){$out.='<details><summary>'.Text::escape($period).' · '.count($rows).' contenus actualisés</summary>';foreach($rows as$n)$out.='<p><a href="'.Text::escape($n['url']).'">'.Text::escape($n['title']).'</a></p>'.self::form('seen',(int)$n['record_id'],['notification'=>$n['id']]).'<button>Marquer comme lu</button></form>';$out.='</details>';}foreach(AuthorWorkspace::matching()as$hit)$out.='<p><a href="'.Text::escape($hit['url']).'">'.Text::escape($hit['title']).'</a> · '.Text::escape($hit['reason']).'</p>';return $out;
    }
    private static function preferences(): string
    {
        $p=Experience::preferences();$out=self::form('preferences',0).'<label><input type="checkbox" name="metrics" value="1"'.((int)$p['metrics']?' checked':'').'> Autoriser la mesure locale de mes usages pour améliorer les parcours</label><p>Pas d’empreinte du navigateur ni d’envoi à un service externe. Désactiver supprime mes événements de mesure.</p><label>Regrouper les nouveautés <select name="frequency">';
        foreach(['immediate'=>'Une par contenu','daily'=>'Par jour','weekly'=>'Par semaine','off'=>'Ne pas afficher de notifications']as$v=>$label)$out.='<option value="'.$v.'"'.($p['frequency']===$v?' selected':'').'>'.$label.'</option>';
        return $out.'</select></label><button>Enregistrer mes préférences</button></form>';
    }
    private static function goal(): string
    {
        $w=Experience::workspace();return self::form('goal',0).'<label>Ce que je souhaite accomplir <textarea name="goal" maxlength="500">'.Text::escape($w['goal']['goal']).'</textarea></label><label>Compétences visées, séparées par des virgules <input name="skill_codes" maxlength="2000"></label><button>Conserver mon objectif</button></form>';
    }
    private static function watch(array $r): string
    {
        if(!ProductAccess::user()->id)return '<a href="'.Text::escape(\Joomla\CMS\Router\Route::_('index.php?option=com_users&view=login',false)).'">Se connecter pour suivre les évolutions</a>';
        $s=ProductAccess::store();$on=(bool)$s->rows('SELECT record_id FROM #__gp_social_record_watches WHERE user_id='.(int)ProductAccess::user()->id.' AND record_id='.(int)$r['id'].' AND active=1',1);
        return self::form('watch',(int)$r['id'],['active'=>$on?0:1]).'<button>'.($on?'Ne plus suivre':'Suivre les nouveautés de ce contenu').'</button></form>'.self::form('resume',(int)$r['id'],['kind'=>'saved','position'=>0]).'<button>Garder pour plus tard</button></form>';
    }
    private static function comparison(array $d): string
    {
        $data=PresentationMap::compare(array_slice($d['record_ids'],0,3));$out='<div class="gp-comparison" data-gp-comparison>';if(!$data['items'])return $out.'<p>Choisissez jusqu’à trois offres avec le bouton Comparer.</p></div>';
        $out.='<table><caption>Fields publics des offres · informations manquantes indiquées</caption><thead><tr><th scope="col">Critère</th>';foreach($data['items']as$i)$out.='<th scope="col"><a href="'.Text::escape($i['url']).'">'.Text::escape($i['title']).'</a></th>';$out.='</tr></thead><tbody>';
        foreach(array_keys($data['items'][0]['values'])as$key){$out.='<tr><th scope="row">'.Text::escape($key).'</th>';foreach($data['items']as$i)$out.='<td>'.Text::escape($i['values'][$key]).'</td>';$out.='</tr>';}return $out.'</tbody></table><p>'.Text::escape($data['policy']).'</p></div>';
    }
    private static function release(array $r): string
    {
        $history=RecordVersions::history((int)$r['id']);$changes=RecordVersions::changes((int)$r['id']);$out='<p>Les versions permettent de retrouver les contenus actualisés ; les droits actuels restent appliqués.</p><ul>';foreach($changes as$c)$out.='<li>'.Text::escape($c['label']).' · '.Text::escape($c['date']).'</li>';$out.='</ul>';
        foreach(array_slice($history,0,8)as$v)$out.='<p>Version '.$v['id'].' · <time>'.Text::escape($v['date']).'</time></p>';if(!$history)$out.='<p>Le premier checkpoint sera enregistré à la prochaine sauvegarde native.</p>';return $out;
    }
    private static function commitments(array $d,array $r,int $field): string
    {
        $out='<div class="gp-element-parts">';$scope=substr(hash('sha256',Seo::json($d)),0,12);foreach($d['parts']as$part){$source=$part['source_record']?(new NativeAccess())->title($part['source_record']):null;
            $state=$part['state']==='outdated'?'À actualiser':($part['state']==='documented'&&$source?'Documenté':'Déclaré');$out.='<article><span class="gp-element-status">'.$state.'</span><h3>'.Text::escape($part['title']).'</h3><p>'.Text::escape($part['text']).'</p>'.($source?self::links([$part['source_record']],'Consulter le document'):'').'<time>'.Text::escape($part['date']).'</time></article>';}
        $out.='</div><p>Un document ne constitue pas à lui seul une vérification indépendante.</p>';foreach(RecordVersions::reviews((int)$r['id'],$field)as$review)$out.='<blockquote><strong>'.Text::escape($review['status']).' · '.Text::escape($review['date']).'</strong><p>'.Text::escape($review['note']).'</p></blockquote>';
        return $out.self::reviewForm($r,$field);
    }
    private static function reviewForm(array $r,int $field): string
    {
        $u=ProductAccess::user();if(!$u->id||(int)$r['user_id']===(int)$u->id||(!$u->authorise('core.admin')&&!CompanyTeam::allows($r,'review')))return '';
        return '<details><summary>Relire ce contenu</summary><p>La portée et la date de cette relecture seront visibles avec le contenu. Aucun label de certification n’est attribué automatiquement.</p>'.self::form('review',(int)$r['id'],['field'=>$field]).'<label>Relecture argumentée <textarea name="note" maxlength="4000" required></textarea></label><select name="status"><option value="reviewed">Relu</option><option value="needs_update">À actualiser</option></select><button>Publier cette relecture</button></form></details>';
    }
    private static function project(array $d,array $r,int $field): string
    {
        $out='<p>'.Text::escape($d['objective']).'</p><ul>';foreach($d['criteria']as$c)$out.='<li>'.Text::escape($c).'</li>';$out.='</ul>'.self::parts($d,$r);
        if(!ProductAccess::user()->id)return $out.'<p>Connectez-vous pour proposer une contribution volontaire.</p>';
        $out.=self::form('project.submit',(int)$r['id'],['field'=>$field]).'<label>Ma contribution <textarea name="response" required maxlength="12000"></textarea></label><label>Fiche de réalisation dont je suis l’auteur <input type="number" name="proof_record" min="0" value="0"></label><label><input type="checkbox" name="consent" value="1" required> Je participe volontairement selon le périmètre présenté.</label><button>Proposer ma contribution</button></form>';
        foreach(OpenProjects::submissions((int)$r['id'],$field)as$s){$out.='<article><strong>Contribution '.$s['id'].' · '.Text::escape($s['status']).'</strong><p>'.Text::escape($s['response']).'</p><p>'.Text::escape($s['feedback']).'</p>';
            if((int)$s['user_id']!==(int)ProductAccess::user()->id&&((int)$r['user_id']===(int)ProductAccess::user()->id||CompanyTeam::allows($r,'review')))$out.=self::form('project.feedback',(int)$r['id'],['submission'=>$s['id']]).'<label>Retour humain <textarea name="feedback" maxlength="4000" required></textarea></label><select name="status"><option value="reviewed">Relu</option><option value="revise">À reprendre</option></select><button>Enregistrer le retour</button></form>';
            $out.='</article>';}return $out;
    }
    private static function study(array $d): string
    {
        if($d['metric']==='public_offers'){$rows=ProductAccess::store()->rows('SELECT id FROM #__js_res_record ORDER BY id DESC',1000);$n=0;foreach($rows as$r)if($m=PublicMaterial::record((int)$r['id'])){$p=$m['projection']['type_params'];if(str_contains((string)($p['properties']['tmpl_article']??''),'job'))$n++;}return '<p>'.$n.' offres publiques indexables dans la fenêtre analysée de mille records les plus récents.</p><p>'.Text::escape($d['method']?:'Démonstrations, fiches privées et non indexables exclues.').'</p>';}
        $m=Experience::aggregate($d['metric'],$d['days'],$d['min_sample'],$d['record_ids']);if(!$m['available'])return '<p>'.Text::escape($m['reason']).'</p>';
        return '<p class="gp-study-value">'.Text::escape((string)$m['value']).' '.Text::escape($m['unit']).'</p><p>Échantillon : '.$m['sample'].' · '.Text::escape($m['from'].' → '.$m['to']).'</p><details><summary>Méthode et limites</summary><p>'.Text::escape($m['method'].' '.$d['method']).'</p></details>';
    }
    private static function format(array $d): string
    { return '<p class="gp-element-status">'.Text::escape($d['objective']?:'Question').'</p><p>'.Text::escape($d['method']).'</p>'; }
    private static function reputation(array $d): string
    {
        $out='';foreach(Expertise::contributions($d['record_ids'])as$c){$out.='<article><a href="'.Text::escape($c['url']).'">'.Text::escape($c['title']).'</a><p>'.Text::escape($c['author']).' · <time>'.Text::escape($c['date']).'</time></p><p>Domaines déclarés : '.Text::escape(implode(', ',$c['domains'])?:'à préciser').'</p><span>'.$c['replies'].' réponses publiques · '.Text::escape($c['state']).'</span><p>Consultez les contributions, la réponse retenue et ses sources. Les domaines déclarés ne constituent pas une certification ni un classement personnel.</p></article>';}return $out?:'<p>Reliez des contributions publiques pour rendre leurs domaines et preuves consultables.</p>';
    }
    private static function author(): string
    {
        $out='';foreach(AuthorWorkspace::items()as$r){$out.='<article><a href="'.Text::escape($r['url']).'">'.Text::escape($r['title']).'</a><p><time>'.Text::escape($r['modified']).'</time> · '.$r['external_comments'].' contributions publiques d’autres auteurs à relire'.($r['stale']?' · À réexaminer (90 jours)':'').'</p><a href="'.Text::escape($r['edit']).'">Actualiser dans le formulaire natif</a></article>';}return $out?:'<p>Aucun contenu auteur à actualiser.</p>';
    }
    private static function ai(): string
    {
        if(!ProductAccess::user()->authorise('core.manage','com_joomcck'))return '<p>Le suivi des tâches IA est réservé aux responsables autorisés.</p>';
        $s=ProductAccess::store();$count=(int)($s->rows('SELECT COUNT(*) AS n FROM #__gp_social_knowledge_chunks',1)[0]['n']??0);$status=OmegaCockpit::status();$out='<p>'.$count.' passages dans l’index local. Chaque résultat est recontrôlé avec les droits et la révision actuels.</p><details><summary>Missions et modèles disponibles</summary><pre>'.Text::escape(Seo::json(['missions'=>$status['missions'],'models'=>$status['models'],'limits'=>$status['limits']])).'</pre></details>';return $out;
    }
    private static function search(): string
    {return '<form class="gp-source-search" method="get" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'" data-gp-search><label>Interroger les sources publiques <input name="query" maxlength="2000" type="search"></label><button>Rechercher des passages cités</button><div data-gp-results role="status"></div></form>';}
    private static function taxonomy(array $d): string
    {
        $s=ProductAccess::store();$levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();$out='<nav aria-label="Domaines et catégories">';$where='published=1 AND access IN ('.implode(',',$levels?:[0]).')';if($d['section_ids'])$where.=' AND id IN ('.implode(',',$d['section_ids']).')';
        foreach($s->rows('SELECT id,name FROM #__js_res_sections WHERE '.$where,100)as$r)$out.='<a href="'.Text::escape(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=records&section_id='.$r['id'],false)).'">'.Text::escape($r['name']).'</a>';return $out.'</nav>';
    }
    private static function sitemap(): string
    {
        $url=\Joomla\CMS\Uri\Uri::root().'?option=com_jmap&view=sitemap';$out='<nav aria-label="Formats de découverte">';foreach(['html'=>'Plan du site','xml'=>'XML','images'=>'Images','videos'=>'Vidéos','rss'=>'RSS','hreflang'=>'Langues','aifeed'=>'Flux IA','llms'=>'Guide LLM','mindmap'=>'Carte des connaissances']as$format=>$label)$out.='<a href="'.Text::escape($url.'&format='.$format).'">'.Text::escape($label).'</a>';return $out.'</nav>';
    }
    private static function journey(array $d,array $r): string
    {
        $out='<p>Objectif : '.Text::escape($d['objective']).'</p>'.self::parts($d,$r);if(ProductAccess::user()->id)$out.=self::form('resume',(int)$r['id'],['kind'=>'learning','position'=>0]).'<button>Ajouter à mon parcours</button></form>';return $out;
    }
    private static function actions(array $d,array $r): string
    {
        $out=self::links($d['record_ids'],match($d['action']){'learn'=>'Commencer ce parcours','question'=>'Poser une question',default=>'Découvrir'});
        $html=NativeBindings::html($r,$d,'destination');$url=NativeBindings::text($r,$d,'destination');if(preg_match('~href=["\']([^"\']+)["\']~',$html,$match))$url=html_entity_decode($match[1],ENT_QUOTES);try{$url=ProductData::url($url,true);}catch(\InvalidArgumentException){$url='';}if($url)$out.='<a class="gp-element-primary" href="'.Text::escape($url).'">'.Text::escape($d['objective']?:'Continuer').'</a>';return $out;
    }
    private static function questions(array $d,array $r): string
    {
        $out='';foreach($d['record_ids']as$id)if($m=PublicMaterial::record($id,false)){foreach(array_slice($m['comments'],0,3)as$c)$out.='<blockquote><p>'.Text::escape(mb_substr($c['text'],0,350)).'</p><a href="'.Text::escape($c['url']).'">'.Text::escape($c['author']).' · Lire et répondre</a></blockquote>';}$out.=self::links($d['record_ids'],'Poser une question');return $out?:'<p>Reliez les discussions auxquelles cette partie répond.</p>';
    }
    private static function campaign(array $d,array $r): string
    {
        $out='<p>'.Text::escape($d['objective']).'</p>'.self::parts($d,$r);$out.=self::actions($d,$r);if($d['campaign'])$out.='<small>Campagne : '.Text::escape($d['campaign']).' · mesure locale uniquement pour les comptes ayant consenti.</small>';return $out;
    }
}
