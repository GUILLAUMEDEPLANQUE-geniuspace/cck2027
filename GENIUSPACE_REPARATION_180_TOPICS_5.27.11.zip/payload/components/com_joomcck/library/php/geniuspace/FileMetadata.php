<?php
declare(strict_types=1);
namespace Geniuspace;

/** Metadata supplement for native uploads. Existing binaries and CCK field values remain untouched. */
final class FileMetadata
{
    public static function parse(array $d): array
    {
        $out=[];foreach(['summary'=>2000,'language'=>20,'version'=>80,'source_url'=>2000,'license_url'=>2000,'expires_at'=>40,'transcript'=>30000]as$key=>$max){
            $value=$d[$key]??'';if(!is_string($value)||mb_strlen($value)>$max)throw new \InvalidArgumentException('Métadonnée documentaire trop longue : '.$key);
            $out[$key]=$key==='transcript'?trim($value):Text::plain($value);
        }
        foreach(['source_url','license_url']as$key)if($out[$key]!==''&&!Text::url($out[$key]))throw new \InvalidArgumentException('URL documentaire invalide.');
        if($out['expires_at']!==''&&!Text::date($out['expires_at']))throw new \InvalidArgumentException('Date de validité documentaire invalide.');
        if($out['language']!==''&&!preg_match('/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/D',$out['language']))throw new \InvalidArgumentException('Langue documentaire invalide.');
        if(!is_bool($d['transcript_approved']??false))throw new \InvalidArgumentException('Validation de l’extrait requise.');
        $out['transcript_approved']=$d['transcript_approved']??false;return $out;
    }
    private static function store(): Store { return new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class)); }
    public static function read(int $record,int $field,int $file): array
    {
        $row=self::store()->rows('SELECT revision,data FROM #__gp_social_file_metadata WHERE record_id='.$record.' AND field_id='.$field.' AND file_id='.$file,1)[0]??[];
        return ['revision'=>(int)($row['revision']??0),'data'=>self::parse(json_decode($row['data']??'{}',true)?:[])];
    }
    public static function save(int $record,int $field,int $file,array $data,int $expected): array
    {
        $clean=self::parse($data);$store=self::store();return $store->atomic(function()use($store,$record,$field,$file,$clean,$expected){
            $store->db->setQuery('SELECT id FROM #__js_res_files WHERE record_id='.$record.' AND field_id='.$field.' AND id='.$file.' AND saved=1 FOR UPDATE');if(!$store->db->loadResult())throw new \DomainException('Fichier inaccessible.',404);
            $prior=self::read($record,$field,$file);if($expected!==$prior['revision'])throw new \DomainException('Métadonnées modifiées : rechargez leur version.',409);
            $where='record_id='.$record.' AND field_id='.$field.' AND file_id='.$file;
            if($prior['revision'])$store->run('UPDATE #__gp_social_file_metadata SET data='.$store->q(Seo::json($clean)).',revision='.($expected+1).',mtime='.$store->q(gmdate('Y-m-d H:i:s')).' WHERE '.$where);
            else$store->insert('file_metadata',['record_id'=>$record,'field_id'=>$field,'file_id'=>$file,'revision'=>1,'data'=>Seo::json($clean),'mtime'=>gmdate('Y-m-d H:i:s')]);
            return ['revision'=>$expected+1,'data'=>$clean];
        });
    }
    private static function files(int $record,int $field): array
    { return self::store()->rows('SELECT id,realname FROM #__js_res_files WHERE record_id='.$record.' AND field_id='.$field.' AND saved=1 ORDER BY id',40); }
    public static function render(object $record,int $field,array $p): string
    {
        $out='';$levels=\Joomla\CMS\Factory::getApplication()->getIdentity()->getAuthorisedViewLevels();$canText=in_array((int)($p['allow_download']??1),$levels,true)&&empty($p['subscription']);
        foreach(self::files((int)$record->id,$field)as$file){$row=self::read((int)$record->id,$field,(int)$file['id']);if(!$row['revision'])continue;$m=$row['data'];$expired=$m['expires_at']!==''&&strtotime($m['expires_at'])<=time();$e=fn($v)=>Text::escape((string)$v);
            $out.='<section class="gp-file-metadata" id="document-'.$field.'-'.(int)$file['id'].'"><h4>'.$e($file['realname']).'</h4>';
            if($m['summary'])$out.='<p>'.$e($m['summary']).'</p>';if($m['version'])$out.='<p>Version documentaire : '.$e($m['version']).'</p>';if($m['language'])$out.='<p>Langue : '.$e($m['language']).'</p>';
            if($m['source_url'])$out.='<p><a href="'.$e($m['source_url']).'" rel="noopener">Source du document</a></p>';if($m['license_url'])$out.='<p><a href="'.$e($m['license_url']).'" rel="license">Licence</a></p>';
            if($m['expires_at'])$out.='<p><time>'.$e($m['expires_at']).'</time>'.($expired?' · Validité expirée':'').'</p>';
            if(!$expired&&$canText&&$m['transcript_approved']&&$m['transcript'])$out.='<details><summary>Extrait vérifié par l’auteur</summary><p>'.nl2br($e($m['transcript'])).'</p></details>';
            $out.='</section>';
        }return $out;
    }
    public static function schemas(int $record,int $field,array $p,string $url): array
    {
        $public=(new NativeAccess())->record($record);if(!$public||!isset($public['fields'][$field]))return [];
        $levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();$canText=in_array((int)($p['allow_download']??1),$levels,true)&&empty($p['subscription']);$nodes=[];
        foreach(self::files($record,$field)as$file){$row=self::read($record,$field,(int)$file['id']);if(!$row['revision'])continue;$m=$row['data'];$node=['@type'=>'CreativeWork','@id'=>$url.'#document-'.$field.'-'.$file['id'],'url'=>$url.'#document-'.$field.'-'.$file['id'],'name'=>Text::plain($file['realname'])];
            foreach(['description'=>'summary','citation'=>'source_url','license'=>'license_url','inLanguage'=>'language','version'=>'version']as$key=>$source)if($m[$source])$node[$key]=$m[$source];
            if($m['expires_at'])$node['expires']=Text::date($m['expires_at']);if($canText&&$m['transcript_approved']&&$m['transcript']&&(!$m['expires_at']||strtotime($m['expires_at'])>time()))$node['text']=$m['transcript'];$nodes[]=$node;
        }return $nodes;
    }
    public static function tools(object $record,int $field): string
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();
        if(!$user->id||(!$user->authorise('core.admin')&&(int)$record->user_id!==(int)$user->id))return '';
        $doc=\Joomla\CMS\Factory::getDocument();$base=\Joomla\CMS\Uri\Uri::root(true).'/components/com_joomcck/library/php/geniuspace/media/';
        $doc->addScript($base.'content-insights.js',[],['defer'=>true]);$doc->addStyleSheet($base.'author-tools.css');
        return self::editor($record,$field);
    }
    private static function editor(object $record,int $field): string
    {
        $out='';foreach(self::files((int)$record->id,$field)as$file){$row=self::read((int)$record->id,$field,(int)$file['id']);$m=$row['data'];$e=fn($v)=>Text::escape((string)$v);
            $out.='<details class="gp-file-meta-editor" data-record="'.(int)$record->id.'" data-field="'.$field.'" data-file="'.(int)$file['id'].'" data-revision="'.$row['revision'].'" data-api="'.$e(\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.assist').'" data-csrf="'.$e(\Joomla\CMS\Session\Session::getFormToken()).'"><summary>Métadonnées : '.$e($file['realname']).'</summary>';
            foreach(['summary'=>'Résumé','language'=>'Langue (fr-FR, en-US, zh-CN)','version'=>'Version du document','source_url'=>'URL source','license_url'=>'URL de licence','expires_at'=>'Fin de validité','transcript'=>'Extrait corrigé']as$key=>$label){$tag=in_array($key,['summary','transcript'],true)?'textarea':'input';$out.='<label>'.$label.'<'.$tag.' data-meta="'.$key.'"'.($tag==='input'?' type="'.(str_ends_with($key,'url')?'url':($key==='expires_at'?'date':'text')).'" value="'.$e($m[$key]).'"':' rows="4"').'>'.($tag==='textarea'?$e($m[$key]).'</textarea>':'').'</label>';}
            $out.='<label><input type="checkbox" data-meta="transcript_approved"'.($m['transcript_approved']?' checked':'').'>J’ai vérifié l’extrait et j’autorise son affichage avec les droits du champ.</label><button type="button" data-meta-save>Enregistrer ces métadonnées</button><output aria-live="polite"></output></details>';
        }return $out;
    }
}
