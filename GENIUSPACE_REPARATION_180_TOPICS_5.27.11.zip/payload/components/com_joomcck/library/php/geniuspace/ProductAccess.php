<?php
declare(strict_types=1);
namespace Geniuspace;

/** Common access boundary for additive native-field operations. */
final class ProductAccess
{
    public static function store(): Store
    { return new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class)); }
    public static function user(): object
    { return \Joomla\CMS\Factory::getApplication()->getIdentity(); }
    public static function authenticated(): int
    {
        $u=self::user();
        if(!$u->id||$u->block)throw new \DomainException('Connectez-vous avec un compte actif.',403);
        return (int)$u->id;
    }
    public static function raw(int $id): array
    {
        $r=ReadMemo::get('native-raw-record:'.max(0,$id),static fn()=>self::store()->rows('SELECT * FROM #__js_res_record WHERE id='.max(0,$id),1)[0]??null);
        if(!$r)throw new \DomainException('Fiche introuvable.',404);
        return $r;
    }
    public static function editable(int $id): array
    {
        self::authenticated();$r=self::raw($id);
        $table=\Joomla\CMS\Table\Table::getInstance('Record','JoomcckTable');$table->load($id);
        if(!\MECAccess::allowEdit($table,\ItemsStore::getType((int)$r['type_id']),\ItemsStore::getSection((int)$r['section_id'])))
            throw new \DomainException('Vous ne pouvez pas modifier cette fiche.',403);
        return $r;
    }
    public static function visible(int $id): array
    {
        if($r=ExtendedFields::publicRecord($id,false))return get_object_vars($r);
        $r=self::raw($id);$u=self::user();
        if($u->id&&!$u->block&&(int)$r['user_id']===(int)$u->id)return $r;
        if(!$u->id||$u->block||ExtendedGate::restricted($r))throw new \DomainException('Fiche inaccessible.',404);
        // Reuse the native repository gates for schedules, categories, types and sections.
        $config=ComponentRuntime::configuration();$repo=new Repository(self::store()->db,$config,$u->getAuthorisedViewLevels());
        foreach($config->companies as$c)if(in_array((int)$r['section_id'],$c['section_ids'],true)&&$repo->record($c,$id))return $r;
        throw new \DomainException('Fiche inaccessible.',404);
    }
    public static function field(int $record,int $field,string|array $kind,bool $write=false): array
    {
        $r=$write?self::editable($record):self::visible($record);$s=self::store();
        $f=$s->rows('SELECT * FROM #__js_res_fields WHERE id='.max(0,$field).' AND type_id='.(int)$r['type_id'].' AND published=1',1)[0]??null;
        $p=json_decode($f['params']??'{}',true)?:[];$u=self::user();$levels=$u->getAuthorisedViewLevels();
        if(!$f||!in_array($f['field_type'],(array)$kind,true)||!in_array((int)$f['access'],$levels,true)
            ||!in_array((int)($p['core']['field_view_access']??1),$levels,true)
            ||($write&&!in_array((int)($p['core']['field_edit_access']??$p['core']['field_submit_access']??1),$levels,true)))
            throw new \DomainException('Field inaccessible.',404);
        foreach($p['emerald']??[]as$key=>$value)if(str_ends_with($key,'_subscription')&&$value)throw new \DomainException('Field réservé.',403);
        $values=json_decode((string)($r['fields']??'{}'),true)?:[];
        return ['record'=>$r,'field'=>$f,'params'=>$p,'value'=>$values[$field]??''];
    }
    public static function valueHash(mixed $value): string
    { return hash('sha256',Seo::json(['value'=>$value])); }
    public static function revision(array $r): string
    { return hash('sha256',(string)$r['title']."\n".(string)($r['fields']??'{}')); }
    public static function event(int $record,string $kind,array $payload): void
    {
        self::store()->insert('record_events',['record_id'=>$record,'actor_id'=>(int)self::user()->id,'kind'=>$kind,
            'payload'=>Seo::json($payload),'ctime'=>gmdate('Y-m-d H:i:s')]);
    }
    public static function form(string $action,int $record,array $extra=[]): string
    {
        $html='<form class="gp-product-form meta-reaction-form" method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'">';
        foreach(['option'=>'com_joomcck','task'=>'geniuspace.product','action'=>$action,'record'=>$record]+$extra as$key=>$value)
            $html.='<input type="hidden" name="'.Text::escape((string)$key).'" value="'.Text::escape((string)$value).'">';
        return $html.\Joomla\CMS\HTML\HTMLHelper::_('form.token');
    }
}
