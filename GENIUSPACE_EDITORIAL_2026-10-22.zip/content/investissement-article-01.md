# Construire une décision d’investissement à partir de l’horizon et du risque supportable

Avant de comparer des placements, il faut comprendre la décision à financer : à quel horizon l’argent pourrait-il être nécessaire, quelle perte serait supportable et quelles contraintes peuvent obliger à sortir plus tôt ? Un rendement affiché ne répond pas à ces questions. Ce dossier propose une méthode d’analyse ; il ne sélectionne pas de produit pour une situation personnelle.

## Définir l’usage de l’argent et les dates possibles

« Long terme » reste vague si une partie de la somme peut servir à un achat ou à une dépense imprévue. Séparez les projets et leurs contraintes. L’horizon annoncé doit être cohérent avec les moments où une sortie pourrait devenir nécessaire, pas seulement avec la durée souhaitée pour obtenir un gain.

Pour chaque scénario, notez ce qui arriverait si la valeur du placement baissait au mauvais moment. La capacité à attendre et la volonté d’attendre sont deux sujets différents : une personne peut accepter intellectuellement une baisse sans disposer de la marge financière nécessaire.

## Rendre le risque observable

| Dimension | Question utile | Ce qu’un chiffre isolé ne montre pas |
|---|---|---|
| Valeur | Quelle baisse peut survenir et comment serait-elle vécue ? | Le rendement moyen ne décrit pas toutes les trajectoires |
| Liquidité | À quelles conditions peut-on sortir ? | Une valeur affichée n’est pas toujours un montant immédiatement disponible |
| Contrepartie | Qui détient, administre ou doit rembourser ? | Un nom commercial ne décrit pas toute la chaîne |
| Coûts | Quels frais s’appliquent à l’achat, à la détention et à la sortie ? | Un seul pourcentage peut laisser de côté plusieurs postes |
| Concentration | Quelles expositions dépendent du même facteur ? | Un nombre élevé de lignes ne suffit pas à démontrer une diversification |

## Calculer un scénario sans le transformer en prévision

Dans un exemple purement mathématique, une somme de 10 000 euros qui progresserait de 4 % par an pendant cinq ans atteindrait environ 12 166,53 euros avant les coûts et prélèvements non inclus. La formule est 10 000 multiplié par 1,04 à la puissance 5. Le taux de 4 % est une hypothèse, pas un rendement attendu.

Si l’hypothèse nette retenue devient 3 % par an, le même calcul donne environ 11 592,74 euros. L’écart illustre la sensibilité du scénario au taux choisi ; il ne prouve pas qu’un produit reproduira l’une de ces trajectoires. Un calcul présenté sans ses hypothèses crée facilement une précision trompeuse.

## Chercher ce qui pourrait invalider le choix

Lisez les documents du produit, identifiez les frais et les conditions de sortie, puis notez les questions que vous ne savez pas encore résoudre. Vérifiez les acteurs et les documents auprès des sources officielles compétentes. Une expérience de membre ou une communication commerciale ne remplace pas ce contrôle.

Écrivez aussi une règle de réexamen. Elle peut être liée à un changement de projet, de situation, de document ou de risque identifié. Décider uniquement après une hausse ou une baisse revient à laisser le dernier résultat réécrire les raisons du choix.

## Discuter sans exposer son patrimoine

Pour poser une question à une communauté, il est souvent suffisant de décrire le mécanisme, l’horizon et le point incertain. Il n’est pas nécessaire de publier ses comptes, ses identifiants ou l’intégralité de ses avoirs.

Une bonne réponse devrait expliquer ses limites et distinguer information générale et recommandation personnelle. La qualité de la décision dépend du dossier et de sa cohérence, pas de la popularité d’un avis ou de la promesse d’un classement de performance.
