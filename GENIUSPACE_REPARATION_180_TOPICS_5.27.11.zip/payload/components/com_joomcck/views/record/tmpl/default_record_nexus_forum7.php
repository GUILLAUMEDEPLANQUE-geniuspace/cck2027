<?php
defined('_JEXEC') or die;
require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusForumApp.php';
require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusForumEight.php';NexusForumSeven::assets();$i=$this->item;$p=NexusAbsolu::paramsFor($i,$this->tmpl_params['record']);$e=[NexusSuite::class,'e'];$section=(int)$i->section_id;
$kind=$this->nexusForumSevenArticle?'article':NexusForumSeven::contentType($i,$p);$body=NexusPlatform::html($i,$p,'field_body');$comments=NexusConversation::comments((int)$i->id,6);
$visibleComments=(array)($this->comments??[]);
NexusPlatform::metadata($i,$p,$kind==='article'?'Article':'DiscussionForumPosting',$body,$visibleComments);
$this->nexusCommentsInline=true;$this->nexusExtrasInline=true;$hub=$this->nexusForumSevenHub?:$section;$home=NexusPlatform::sameSite(\Geniuspace\ForumRoutes::categoryUrl($hub));$url=NexusPlatform::recordUrl($i);
NexusForumApp::social($url,$kind==='article'?'article':'website',NexusAurora::cover($i,$p,'field_cover'),NexusPlatform::value($i,$p,'field_cover_alt')?:$i->title);
$roots=NexusForumSeven::categories($section);$flat=NexusForumSeven::flat($roots);$nativeCategories=is_array($i->categories)?$i->categories:(json_decode((string)$i->categories,true)?:[]);$category=null;foreach(array_keys($nativeCategories)as$cid)if(isset($flat[(int)$cid])){$category=$flat[(int)$cid];break;}
$format=NexusForumEight::format($i,$p);$formatLabel=NexusAbsolu::profileLabel($i);$author=NexusForumEight::author($i,$p);$read=max(1,(int)ceil(preg_match_all('/[\p{L}\p{N}]+/u',NexusSuite::plain($body))/220));
$enabled=NexusDisplay::enabled($p,'comments')&&(bool)$this->type->params->get('comments.comments');
if($kind==='article'&&$enabled&&NexusPlatform::indexableRecord($i))NexusPlatform::ld(['@context'=>'https://schema.org','@type'=>'DiscussionForumPosting','@id'=>$url.'#discussion','url'=>$url.'#comments','headline'=>'Discussion : '.$i->title,'author'=>['@type'=>'Person','name'=>$author],'isPartOf'=>['@id'=>$url.'#content'],'commentCount'=>$comments['total'],'comment'=>NexusSuite::commentGraph($visibleComments,$url)]);
$inline=NexusAbsolu::article($body,$i,$p);$body=$inline['html'];$inlineFields=$inline['fields'];
ob_start();
?>
<div class="forum7-thread-layout<?= $kind==='discussion'?' forum7-classic-thread':'' ?>">
<main class="forum7-article-pane"><div class="forum7-reading-content">
<nav class="forum7-breadcrumb" aria-label="Fil d’Ariane"><a href="<?= $e($home) ?>">Méta-Hub</a><?php if($category): ?> / <a href="<?= $e($category->link) ?>"><?= $e($category->title) ?></a><?php endif; ?></nav>
<div class="flex flex-wrap gap-2 mb-4 items-center"><span class="forum7-type-badge"><?= NexusConnect::icon($format==='review'?'star':($kind==='article'?'newspaper':'comments')) ?> <?= $formatLabel!==''?$e($formatLabel):($format==='review'?'Avis &amp; notes':($format==='reportage'?'Reportage':($kind==='article'?'Article de fond':'Discussion'))) ?></span><?php if($kind==='article'): ?><span class="forum7-reading-time"><?= NexusConnect::icon('clock') ?> Lecture : <?= $read ?> min</span><?php endif; ?><?php if($category): ?><a class="forum7-category-badge" href="<?= $e($category->link) ?>"><?= NexusConnect::icon((string)$category->params->get('icon','hashtag')) ?> <?= $e($category->title) ?></a><?php endif; ?></div>
<h1><?= $e($i->title) ?></h1>
<?= \Geniuspace\ModerationBot::notices((int)$i->id) ?>
<div class="forum7-author flex items-center gap-4 border-b border-brand-100 pb-6"><?php $identity=\Geniuspace\AccountIdentity::render((int)$i->user_id); echo $identity ?: NexusMultivers::avatar($author).'<strong>'.$e($author).'</strong>'; ?><div><?php if($identity&&$author!==(string)($i->user_name??'')): ?><strong class="forum7-editorial-byline"><?= $e($author) ?></strong><?php endif; ?><span class="forum7-author-badges"><?= NexusPlatform::widget($i,$p,'field_author_badges') ?></span><time datetime="<?= $e(NexusSuite::iso($i->mtime?:$i->ctime)) ?>"><?= $e(substr(NexusSuite::iso($i->mtime?:$i->ctime),0,10)) ?></time><?= NexusPlatform::widget($i,$p,'field_author_bio') ?></div></div>
<?= NexusConnect::region($i,$p,'header').NexusDisplay::extras($i,$p,'header') ?>
<?php if($intro=NexusPlatform::value($i,$p,'field_excerpt')): ?><p class="forum7-lead"><?= $e($intro) ?></p><?php endif; ?>
<?php if($cover=NexusAurora::cover($i,$p,'field_cover')): $coverMeta=\Geniuspace\EditorialImages::metadata($cover); ?><figure class="forum7-cover"><img src="<?= $e($cover) ?>" alt="<?= $e(\Geniuspace\EditorialImages::alternative($cover,NexusPlatform::value($i,$p,'field_cover_alt'))) ?>" <?= \Geniuspace\EditorialImages::attributes($cover,'(max-width: 700px) 100vw, 900px',900,500) ?> decoding="async" fetchpriority="high"><?php if(!empty($coverMeta['credit'])): ?><figcaption class="text-xs text-slate-500 mt-2"><?= $e($coverMeta['credit']) ?></figcaption><?php endif; ?></figure><?php endif; ?>
<?= \Geniuspace\MultiverseMechanisms::crystallized((int)$i->id) ?>
<div class="blog-content nx-rich-body" data-forum7-body data-source-url="<?= $e($url) ?>"><?= $body ?></div>
<?php if($kind==='article'): ?><button type="button" class="forum7-reading-tools" data-forum7-distraction aria-pressed="false">Lire sans distractions</button><?php endif; ?>
<?php if($kind==='article'&&NexusPlatform::config($p,'show_narration','1')==='1')echo NexusForumSeven::narration(); ?>
<?php if($kind==='article'&&$enabled): ?><button type="button" class="forum7-highlight-button" data-forum7-quote hidden><?= NexusConnect::icon('quote-left') ?> Discuter le passage sélectionné</button><span role="status" data-forum7-quote-status></span><?php endif; ?>
<?= NexusForumEight::extra($i,$p,$inlineFields).NexusForumEight::metrics($i) ?>
<?php if($kind==='discussion'): ?><details class="forum7-topic-tools"><summary><?= NexusConnect::icon('toolbox') ?> Outils, médias et ressources de ce sujet</summary><?php endif; ?>
<?= NexusAbsolu::widget($i,$p,'field_widgets',$inlineFields).NexusAbsolu::widget($i,$p,'field_audio',$inlineFields).NexusAbsolu::widget($i,$p,'field_code',$inlineFields).NexusAbsolu::widget($i,$p,'field_media',$inlineFields).NexusAbsolu::widget($i,$p,'field_video',$inlineFields).NexusAbsolu::widget($i,$p,'field_images',$inlineFields).NexusAbsolu::widget($i,$p,'field_files',$inlineFields).NexusAbsolu::widget($i,$p,'field_source',$inlineFields) ?>
<?= NexusConnect::region($i,$p,'coalitions').NexusAbsolu::widget($i,$p,'field_coalition',$inlineFields).NexusConnect::region($i,$p,'opportunities').NexusAbsolu::widget($i,$p,'field_opportunity',$inlineFields).NexusConnect::region($i,$p,'expert').NexusAbsolu::widget($i,$p,'field_consultation',$inlineFields).NexusAbsolu::widget($i,$p,'field_factcheck',$inlineFields).NexusAbsolu::widget($i,$p,'field_sponsorship',$inlineFields) ?>
<?= NexusConnect::region($i,$p,'body').NexusConnect::region($i,$p,'context').NexusConnect::region($i,$p,'widgets').NexusConnect::region($i,$p,'sandbox').NexusDisplay::extras($i,$p,'body') ?>
<?= NexusMultivers::links($i,$p,'field_company','Entreprise').NexusMultivers::links($i,$p,'field_job','Offre liée').NexusMultivers::links($i,$p,'field_related','Ressource parente').NexusMultivers::links($i,$p,'field_courses','Apprendre').NexusMultivers::links($i,$p,'field_children','Discussions associées') ?>
<?= NexusAbsolu::additional($i,$p).NexusMultivers::controls($i,$p) ?>
<?= \Geniuspace\MultiverseMechanisms::render((int)$i->id) ?>
<?= \Joomcck\Layout\Helpers\Layout::render('core.single.recordParts.buttonsManage',['current'=>$this,'item'=>$i,'params'=>$p]) ?>
<?= NexusConnect::region($i,$p,'footer').NexusDisplay::extras($i,$p,'footer').NexusDisplay::extras($i,$p,'left').NexusDisplay::extras($i,$p,'connections') ?>
<?php require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusAcademy.php';if($filters=NexusAcademy::filters($this,$p)): ?><details class="meta-native-filters"><summary>Affiner votre recherche</summary><?= $filters ?></details><?php endif; ?>
<?= \Geniuspace\JourneyCatalogue::widget((string)$i->title,true) ?>
<?= \Geniuspace\SemanticLinks::render((int)$i->id,(int)NexusPlatform::config($p,'internal_links_limit','6')) ?>
<?php if($kind==='discussion'): ?></details><?php endif; ?>
<a class="forum7-back-top" href="#forum7-top">Retour en haut de ce sujet ↑</a>
</div></main>
<?php if($enabled): ?>
<button type="button" class="absolu-discussion-toggle" data-absolu-chat-open aria-expanded="false" aria-controls="forum7-debates-<?= (int)$i->id ?>"><?= NexusConnect::icon('comments') ?> <?= $comments['total'] ?> réponses · Participer</button>
<aside class="forum7-discussion-pane" id="forum7-debates-<?= (int)$i->id ?>" aria-label="Discussion de ce contenu"><header class="forum7-discussion-heading"><div><h2><?= NexusConnect::icon('comments') ?> <?= $kind==='article'?'Débats &amp; Conciergerie Live':'Réponses de la communauté' ?></h2><small><?= $comments['total'] > 0 ? (int)$comments['total'].' réponse'.($comments['total'] > 1 ? 's' : '').' publique'.($comments['total'] > 1 ? 's' : '') : 'Ouvrez la conversation' ?></small></div><a class="btn-shiny bg-primary text-white" data-forum7-mode="forum" href="<?= $e(NexusForumSeven::modeUrl($home,'forum')) ?>"><?= NexusConnect::icon('expand') ?> Ouvrir Méta-Hub</a><button type="button" class="absolu-discussion-toggle" data-absolu-chat-close aria-label="Revenir à l’article">← Article</button></header><?= \Geniuspace\ForumPresence::controls((int)$i->id).\Geniuspace\ForumPresence::readerControls((int)$i->id) ?><section id="comments" data-forum7-comments><?= $this->loadTemplate('comments') ?></section><div class="forum7-live-watch" data-forum7-watch data-endpoint="<?= $e(\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.productRead&kind=forum_activity&record='.(int)$i->id) ?>"><button type="button" data-absolu-compose>Écrire une réponse</button><button type="button" data-forum7-watch-toggle aria-pressed="false">Suivre les nouvelles réponses</button><p role="status"></p><a href="<?= $e($url) ?>#comments" hidden>Afficher la discussion mise à jour</a></div><?= NexusConnect::region($i,$p,'sidebar').NexusDisplay::extras($i,$p,'right') ?></aside><?php endif; ?>
</div>
<?php
$fragment=(string)ob_get_clean();
if($kind==='article'){require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusOutline.php';$partner=NexusAbsolu::regions([$i],$p,'partner','field_partner');$fragment=NexusForumEight::reading($fragment,(int)$i->id,$partner);$fragment=NexusOutline::decorate($fragment,(int)$i->id,$p);}
// Compose the record inside its existing Super-App shell, never around a second viewport.
if($design=\Geniuspace\DesignLayouts::published('record',(int)$i->section_id,(int)$i->id)){
    $fragment=\Geniuspace\DesignRenderer::render($design,['scope'=>'record','section'=>(int)$i->section_id,'target'=>(int)$i->id,'record'=>(int)$i->id,'item'=>$i],['record'=>$fragment]);
}
\Geniuspace\DesignRenderer::assets();
$fragment=\Geniuspace\DesignLayouts::link('record',(int)$i->section_id,(int)$i->id).$fragment;
$fragment=\Geniuspace\DesignInline::host($fragment,'record',(int)$i->section_id,(int)$i->id);
$this->nexusDesignApplied=true;
if($this->nexusForumSevenEmbedded)echo $fragment;else echo NexusForumApp::render($this,$fragment,$kind);
