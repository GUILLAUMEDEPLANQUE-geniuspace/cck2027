<?php
declare(strict_types=1);
namespace Geniuspace;

/** Opt-in native Joomla menu routing. Other JoomCCK sections keep their router. */
final class ForumRoutes
{
    public static function section(int $id): ?array
    {
        static $cache=[];
        if(!array_key_exists($id,$cache)){
            $r=ProductAccess::store()->rows('SELECT id,published,access,params FROM #__js_res_sections WHERE id='.$id,1)[0]??null;
            $p=new \Joomla\Registry\Registry($r['params']??'{}');
            $cache[$id]=$r&&(int)$r['published']===1&&(int)$p->get('general.nexus_forum7')===1?$r+['settings'=>$p]:null;
        }
        return $cache[$id];
    }
    public static function menu(int $section,string $role,int $category=0): int
    {
        static $indexes=[];$key=$section.':'.$role.':'.$category;
        $levels=\Joomla\CMS\Factory::getApplication()->getIdentity()->getAuthorisedViewLevels();
        $viewer=implode(',',$levels?:[0]);if(isset($indexes[$viewer]))return $indexes[$viewer][$key]??0;$indexes[$viewer]=[];
        foreach(ProductAccess::store()->db->setQuery("SELECT id,params,link FROM #__menu WHERE published=1 AND client_id=0 AND type='component' AND access IN (".implode(',',$levels?:[0]).') ORDER BY id')->loadAssocList()as$m){
            $p=new \Joomla\Registry\Registry($m['params']);
            if($p->get('nexus_forum7_section')&&in_array($p->get('nexus_forum7_role'),['hub','category','thread'],true)){
                $q=[];parse_str(parse_url($m['link'],PHP_URL_QUERY)?:'',$q);
                if(($q['option']??'')==='com_joomcck'&&(int)($q['section_id']??0)===(int)$p->get('nexus_forum7_section'))$indexes[$viewer][(int)$p->get('nexus_forum7_section').':'.$p->get('nexus_forum7_role').':'.(int)$p->get('nexus_forum7_category',0)]=(int)$m['id'];
            }
        }
        return $indexes[$viewer][$key]??0;
    }
    private static function categoryChain(int $section,int $category): array
    {
        $out=[];$seen=[];$s=ProductAccess::store();$index=null;
        if(ReadMemo::enabled())$index=ReadMemo::get('route-category-index:'.$section,static function()use($s,$section){$rows=$s->rows('SELECT id,parent_id,alias,section_id FROM #__js_res_categories WHERE section_id='.$section,10001);return count($rows)>10000?null:array_column($rows,null,'id');});
        while($category>1&&count($seen)<20){if(isset($seen[$category]))return [];$seen[$category]=true;$c=$index!==null?($index[$category]??null):$s->rows('SELECT id,parent_id,alias,section_id FROM #__js_res_categories WHERE id='.$category.' AND section_id='.$section,1)[0]??null;if(!$c)return [];array_unshift($out,$c);$category=(int)$c['parent_id'];}return $category<=1?$out:[];
    }
    private static function categoryMenu(int $section,int $category): int
    {
        // Most native categories already have a Joomla menu. Avoid traversing the
        // tree again for every directory icon, field, sidebar and dock rendering.
        if($menu=self::menu($section,'category',$category))return $menu;
        foreach(array_reverse(self::categoryChain($section,$category))as$c)if($menu=self::menu($section,'category',(int)$c['id']))return $menu;
        return self::menu($section,'hub');
    }
    public static function preprocess(array &$q): bool
    {
        $view=$q['view']??'';if(!in_array($view,['records','record'],true)||!empty($q['task'])||!empty($q['view_what']))return false;
        $section=(int)($q['section_id']??0);
        if($view==='record'){$r=self::routeRecord((int)($q['id']??0));$section=(int)($r['section_id']??0);}
        if(!self::section($section))return false;
        $cat=(int)($q['cat_id']??0);$role=$view==='record'?'thread':($cat?'category':'hub');$item=self::menu($section,$role,$view==='records'?$cat:0);
        if(!$item&&$view==='records')$item=$cat?self::categoryMenu($section,$cat):self::menu($section,'hub');
        if(!$item)return false;$q['Itemid']=$item;return true;
    }
    public static function build(array &$q): ?array
    {
        $menu=\Joomla\CMS\Factory::getApplication()->getMenu()->getItem((int)($q['Itemid']??0));if(!$menu)return null;
        $section=(int)$menu->getParams()->get('nexus_forum7_section');$role=$menu->getParams()->get('nexus_forum7_role');
        if(!self::section($section)||!in_array($role,['hub','category','thread'],true))return null;
        if(($q['view']??'')==='record'&&$role==='thread'){
            $r=self::routeRecord((int)($q['id']??0));
            if(!$r||(int)$r['section_id']!==$section)return null;
            $slug=self::slug($r);foreach(['view','section_id','cat_id','id']as$k)unset($q[$k]);return [$slug];
        }
        if(($q['view']??'')!=='records'||(int)($q['section_id']??0)!==$section||!empty($q['view_what']))return null;
        $cat=(int)($q['cat_id']??0);$menuCat=(int)$menu->getParams()->get('nexus_forum7_category');
        if($role==='hub'&&!empty($q['nx_search'])){foreach(['view','section_id','cat_id','nx_search','nx_mode']as$k)unset($q[$k]);return ['recherche'];}
        if($cat===$menuCat){foreach(['view','section_id','cat_id']as$k)unset($q[$k]);return [];}
        if(in_array($role,['hub','category'],true)&&$cat){$chain=self::categoryChain($section,$cat);$segments=[];$found=$role==='hub';foreach($chain as$c){if(!$found){if((int)$c['id']===$menuCat)$found=true;continue;}$segments[]=self::categorySlug($c);}if($found&&$segments){foreach(['view','section_id','cat_id']as$k)unset($q[$k]);return $segments;}}
        return null;
    }
    public static function parse(array $segments): ?array
    {
        if($job=EmploymentRoutes::parse($segments))return $job;
        // Native submissions/edits retain their own router and server ACLs under hub menus.
        $action=urldecode((string)($segments[0]??''));if(in_array($action,[\Joomla\CMS\Language\Text::_('SEF_FORM_ADD'),\Joomla\CMS\Language\Text::_('SEF_FORM_EDIT'),'submit','edit'],true))return null;
        $menu=\Joomla\CMS\Factory::getApplication()->getMenu()->getActive();if(!$menu)return null;
        $p=$menu->getParams();$section=(int)$p->get('nexus_forum7_section');$role=$p->get('nexus_forum7_role');if(!self::section($section))return null;
        if(!$segments)return null;
        if(count($segments)>20||($role==='thread'&&count($segments)!==1))throw new \RuntimeException('Page introuvable.',404);foreach($segments as$segment)if(!preg_match('/^[\p{L}\p{N}][\p{L}\p{N}-]{0,199}$/uD',(string)$segment))throw new \RuntimeException('Page introuvable.',404);
        $s=ProductAccess::store();$slug=(string)$segments[0];
        if($role==='hub'&&count($segments)===1&&$slug==='recherche')return ['view'=>'records','section_id'=>$section,'nx_search'=>1,'nx_mode'=>'forum'];
        if($role==='thread'){
            $rows=$s->rows('SELECT id,alias,section_id FROM #__js_res_record WHERE section_id='.$section.' AND alias='.$s->q($slug),2);
            if(count($rows)!==1&&preg_match('/-([0-9]+)$/D',$slug,$m)){$r=$s->rows('SELECT id,alias,section_id FROM #__js_res_record WHERE section_id='.$section.' AND id='.(int)$m[1],1)[0]??null;$rows=$r&&self::slug($r)===$slug?[$r]:[];}
            if(count($rows)!==1)throw new \RuntimeException('Sujet introuvable.',404);
            return ['view'=>'record','id'=>(int)$rows[0]['id'],'section_id'=>$section];
        }
        if(in_array($role,['hub','category'],true)){
            $parent=$role==='category'?(int)$p->get('nexus_forum7_category'):1;$valid=true;$last=0;
            foreach($segments as$part){$rows=$s->rows('SELECT id,alias,section_id FROM #__js_res_categories WHERE section_id='.$section.' AND parent_id='.$parent.' AND alias='.$s->q((string)$part).' AND published=1',2);
                if(count($rows)!==1&&preg_match('/-([0-9]+)$/D',(string)$part,$match)){$row=$s->rows('SELECT id,alias,section_id FROM #__js_res_categories WHERE section_id='.$section.' AND parent_id='.$parent.' AND id='.(int)$match[1].' AND published=1',1)[0]??null;$rows=$row&&self::categorySlug($row)===$part?[$row]:[];}
                if(count($rows)!==1){$valid=false;break;}$parent=$last=(int)$rows[0]['id'];
            }
            if($valid&&$last)return ['view'=>'records','section_id'=>$section,'cat_id'=>$last];
        }
        if($role==='hub'&&count($segments)===1){$rows=$s->rows('SELECT id,alias,section_id FROM #__js_res_categories WHERE section_id='.$section.' AND alias='.$s->q($slug).' AND published=1',2);if(count($rows)!==1&&preg_match('/-([0-9]+)$/D',$slug,$m)){$r=$s->rows('SELECT id,alias,section_id FROM #__js_res_categories WHERE section_id='.$section.' AND id='.(int)$m[1].' AND published=1',1)[0]??null;$rows=$r&&self::categorySlug($r)===$slug?[$r]:[];}if(count($rows)===1)return ['view'=>'records','section_id'=>$section,'cat_id'=>(int)$rows[0]['id']];}
        throw new \RuntimeException('Catégorie introuvable.',404);
    }
    public static function slug(array $r): string
    {
        $slug=(string)$r['alias'];if(!preg_match('/^[\p{L}\p{N}][\p{L}\p{N}-]{0,179}$/uD',$slug))return 'sujet-'.(int)$r['id'];
        $s=ProductAccess::store();$rows=ReadMemo::get('record-alias-count:'.(int)$r['section_id'].':'.$slug,static fn()=>$s->rows('SELECT id FROM #__js_res_record WHERE section_id='.(int)$r['section_id'].' AND alias='.$s->q($slug),2));
        return count($rows)>1?$slug.'-'.(int)$r['id']:$slug;
    }
    private static function categorySlug(array $c): string
    {
        $alias=(string)$c['alias'];$s=ProductAccess::store();$rows=$s->rows('SELECT id FROM #__js_res_categories WHERE section_id='.(int)$c['section_id'].' AND alias='.$s->q($alias),2);
        return count($rows)>1||$alias==='recherche'?$alias.'-'.(int)$c['id']:$alias;
    }
    private static function routeRecord(int $id): ?array
    {return ReadMemo::get('native-raw-record:'.$id,static fn()=>ProductAccess::store()->rows('SELECT * FROM #__js_res_record WHERE id='.$id,1)[0]??null);}
    public static function recordUrl(array|object $record): ?string
    {
        $r=(array)$record;$section=(int)($r['section_id']??0);if(!self::section($section)||!($menu=self::menu($section,'thread')))return null;
        return \Joomla\CMS\Router\Route::link('site','index.php?option=com_joomcck&view=record&id='.(int)$r['id'].'&section_id='.$section.'&Itemid='.$menu,false);
    }
    public static function categoryUrl(int $section,int $category=0): string
    {
        if(!$category&&($nativeHome=NativeHome::url($section)))return $nativeHome;
        $menu=$category?self::categoryMenu($section,$category):self::menu($section,'hub');
        return \Joomla\CMS\Router\Route::link('site','index.php?option=com_joomcck&view=records&section_id='.$section.($category?'&cat_id='.$category:'').($menu?'&Itemid='.$menu:''),false);
    }
    public static function searchUrl(int $section): string
    {
        return \Joomla\CMS\Router\Route::link('site','index.php?option=com_joomcck&view=records&section_id='.$section.'&nx_search=1&Itemid='.self::menu($section,'hub'),false);
    }
}
