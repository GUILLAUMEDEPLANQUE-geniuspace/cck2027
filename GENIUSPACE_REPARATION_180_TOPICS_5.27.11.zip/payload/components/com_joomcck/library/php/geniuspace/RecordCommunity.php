<?php
declare(strict_types=1);
namespace Geniuspace;
/** Interactions point to the native profile record, never to a duplicate social account. */
final class RecordCommunity
{
    private static function store(): Store { return new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class)); }
    public static function catalogue(string $raw): array
    {
        if(strlen($raw)>16384)throw new \InvalidArgumentException('Catalogue trop volumineux.');
        $d=json_decode($raw?:'{}',true,8,JSON_THROW_ON_ERROR);if(!is_array($d))throw new \InvalidArgumentException('Objet JSON requis.');
        $g=$d['gifts']??[];if(!is_array($g)||!array_is_list($g)||count($g)>40)throw new \InvalidArgumentException('40 marques de reconnaissance au maximum.');$out=[];
        foreach($g as$i){if(!is_array($i)||!preg_match('/^[a-z0-9-]{1,32}$/D',$i['id']??'')||!is_string($i['label']??null)||mb_strlen($i['label'])>100||!in_array($i['icon']??'star',['star','heart','gift','award','lightbulb','rocket','handshake'],true)||isset($out[$i['id']]))throw new \InvalidArgumentException('Reconnaissance invalide.');$out[$i['id']]=['id'=>$i['id'],'label'=>$i['label'],'icon'=>$i['icon']??'star'];}
        return ['gifts'=>array_values($out)];
    }
    private static function definition(int $record,int $field): array
    {
        $r=(new NativeAccess())->record($record);$f=$r['fields'][$field]??null;
        if(!$r||!$f||$f['field_type']!=='gpcommunity')throw new \DomainException('Profil ou field inaccessible.',404);
        return self::catalogue((string)($r['values'][$field]??'{}'));
    }
    public static function action(array $data): void
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id||$user->block)throw new \DomainException('Connexion requise.',403);
        $record=Social::id($data,'record');$field=Social::id($data,'field');$d=self::definition($record,$field);$store=self::store();$actor=(int)$user->id;$action=$data['action']??'';
        $store->atomic(function()use($store,$record,$field,$d,$actor,$action,$data){
            $where='record_id='.$record.' AND field_id='.$field.' AND user_id='.$actor;
            if($action==='follow'){$store->run('INSERT IGNORE INTO #__gp_social_record_followers (record_id,field_id,user_id,ctime) VALUES ('.$record.','.$field.','.$actor.','.$store->q(gmdate('Y-m-d H:i:s')).')');}
            elseif($action==='unfollow')$store->run('DELETE FROM #__gp_social_record_followers WHERE '.$where);
            elseif($action==='gift'){
                $gift=$data['gift']??'';if(!is_string($gift)||!in_array($gift,array_column($d['gifts'],'id'),true))throw new \InvalidArgumentException('Reconnaissance inconnue.');
                // A recognition is free and unique per user/catalogue item. No monetary or credit transfer.
                $store->run('INSERT IGNORE INTO #__gp_social_record_gifts (record_id,field_id,user_id,gift,ctime) VALUES ('.$record.','.$field.','.$actor.','.$store->q($gift).','.$store->q(gmdate('Y-m-d H:i:s')).')');
            }else throw new \InvalidArgumentException('Action inconnue.');
        });
    }
    public static function render(object $record,object $field,bool $full): string
    {
        try{$d=self::definition((int)$record->id,(int)$field->id);}catch(\Throwable $e){return '';}
        $store=self::store();$id=(int)$record->id;$fid=(int)$field->id;$user=\Joomla\CMS\Factory::getApplication()->getIdentity();$where='record_id='.$id.' AND field_id='.$fid;
        $total=(int)($store->rows('SELECT COUNT(*) AS n FROM #__gp_social_record_followers WHERE '.$where,1)[0]['n']??0);
        $gifts=$store->rows('SELECT gift,COUNT(*) AS n FROM #__gp_social_record_gifts WHERE '.$where.' GROUP BY gift',40);$counts=array_column($gifts,'n','gift');
        $out='<section class="nx-native-community" data-community-record="'.$id.'"><p><strong>'.$total.'</strong> abonnements à ce profil</p>';
        if($full){
            \Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);
            if($user->id){$following=(bool)$store->rows('SELECT user_id FROM #__gp_social_record_followers WHERE '.$where.' AND user_id='.(int)$user->id,1);
                $form=static fn($action,$label,$extra='')=>'<form method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'">'.'<input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="task" value="geniuspace.community"><input type="hidden" name="record" value="'.$id.'"><input type="hidden" name="field" value="'.$fid.'"><input type="hidden" name="action" value="'.$action.'">'.$extra.\Joomla\CMS\HTML\HTMLHelper::_('form.token').'<button type="submit" class="nx-connect-button">'.$label.'</button></form>';
                $out.=$form($following?'unfollow':'follow',$following?'Ne plus suivre':'Suivre ce profil');
                foreach($d['gifts']as$g)$out.=$form('gift','<i class="fa-solid fa-'.$g['icon'].'" aria-hidden="true"></i> '.Text::escape($g['label']).' · '.(int)($counts[$g['id']]??0),'<input type="hidden" name="gift" value="'.Text::escape($g['id']).'">');
            }else{$url=\Joomla\CMS\Uri\Uri::root().'?option=com_users&view=login&return='.base64_encode(\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&view=record&id='.$id);$out.='<a href="'.Text::escape($url).'">Se connecter pour suivre ou remercier</a>';}
        }return $out.'</section>';
    }
}
