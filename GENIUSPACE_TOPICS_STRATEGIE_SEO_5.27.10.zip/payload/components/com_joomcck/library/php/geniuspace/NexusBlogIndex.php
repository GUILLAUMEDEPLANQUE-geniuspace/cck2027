<?php
declare(strict_types=1);
namespace Geniuspace;

/** A public editorial directory. Entries keep their native record, fields and canonical URL. */
final class NexusBlogIndex
{
    private static array $states=[];
    public static function state(int $hub): array{return self::$states[$hub];}
    public const FORMATS=['article'=>'Articles','reportage'=>'Reportages','video'=>'Vidéos','audio'=>'Podcasts','review'=>'Avis & essais'];

    public static function url(int $hub,array $query=[]): string
    {
        $category=self::category($hub);$ctx=UniverseBlueprint::context($hub,$category);if(!$ctx['current']||array_key_exists('nx_blog_category',$query)&&$query['nx_blog_category']===0)$category=0;
        $uri=new \Joomla\CMS\Uri\Uri(\NexusPlatform::sameSite(ForumRoutes::categoryUrl($hub,$category)));
        $uri->setVar('nx_mode','blog');if($category)$uri->setVar('nx_blog_category',$category);
        foreach($query as$key=>$value)if(in_array($key,['nx_blog_format','nx_blog_author','nx_blog_before','nx_blog_category','q'],true)&&$value!=='')$uri->setVar($key,$value);
        return $uri->toString();
    }

    private static function category(int $hub): int
    {
        $input=\Joomla\CMS\Factory::getApplication()->input;
        // Explicit blog facets remain exact. Entering the magazine from a native
        // company/job subcategory opens its universe, not an empty leaf filter.
        if($input->get('nx_blog_category',null,'raw')!==null)return max(0,$input->getInt('nx_blog_category'));
        $category=max(0,$input->getInt('cat_id',0));
        $ctx=UniverseBlueprint::context($hub,$category);
        return $ctx['universe']?(int)($ctx['chain'][0]->id??$category):$category;
    }

    public static function canonical(int $hub): string
    {
        $category=self::category($hub);$ctx=UniverseBlueprint::context($hub,$category);if(!$ctx['current'])$category=0;
        $uri=new \Joomla\CMS\Uri\Uri(\NexusPlatform::sameSite(ForumRoutes::categoryUrl($hub,$category)));$uri->setVar('nx_mode','blog');return $uri->toString();
    }

    /** Native category settings remain editable; future categories get their own identity. */
    public static function identity(int $hub,?object $params=null): array
    {
        $params??=\NexusForumApp::listParams($hub);$ctx=UniverseBlueprint::context($hub,self::category($hub));
        $identity=['heading'=>\NexusPlatform::config($params,'blog_index_heading','Des idées à découvrir.'),'accent'=>\NexusPlatform::config($params,'blog_index_accent','Des personnes à rencontrer.'),'intro'=>\NexusPlatform::config($params,'blog_index_intro','Les blogs des membres, des entreprises et des communautés, réunis ici. Trouvez un récit, un format, une nouvelle perspective.'),'title'=>'Multi-Blog : articles, reportages et créateurs | Geniuspace','description'=>'Découvrez les articles, reportages, vidéos et podcasts des membres et entreprises de Geniuspace. Des publications reliées à leurs auteurs et à leurs discussions.'];
        if(!$ctx['current'])return $identity;
        $category=$ctx['current'];$p=ForumCategories::params($category);$label=Text::plain($category->title);
        $themes=['jeux_video'=>'Jeux vidéo','emploi'=>'Emploi et carrières','pays_expat'=>'Voyage et expatriation','artisanat'=>'Artisanat japonais','business'=>'Entrepreneuriat','investissement'=>'Investissement et patrimoine','traditions'=>'Herbier et traditions','paranormal'=>'Enquêtes et phénomènes inexpliqués','manga'=>'Manga et pop culture','gastronomie'=>'Gastronomie et savoir-faire','sports'=>'Sport et arts martiaux','tech'=>'IA, technologies et sciences'];
        $root=count($ctx['chain'])===1;$subject=$root?($themes[$ctx['key']]??$label):$label;
        $identity['heading']=$subject;$identity['accent']='Guides, récits et regards de la communauté.';
        $identity['title']=$subject.' : articles, guides et blogs | Geniuspace';
        $identity['intro']='Les articles, reportages et vidéos des membres, des créateurs et des entreprises autour de « '.$subject.' ». Découvrez leurs expériences et rejoignez les discussions.';
        $identity['description']='Explorez « '.$subject.' » sur Geniuspace : articles, guides, reportages et vidéos de membres et de créateurs, avec leurs sources et leurs discussions.';
        if($ctx['key']==='artisanat'&&$root){$identity['accent']='Guides, artisans et créateurs.';$identity['title']='Artisanat japonais : guides et blogs de créateurs | Geniuspace';$identity['intro']='Kimonos, céramique, coutellerie et ateliers : découvrez les guides et les récits des artisans, des créateurs et des passionnés du Japon.';$identity['description']='Explorez l’artisanat japonais : kimonos, céramique, coutellerie et ateliers. Retrouvez les guides, les blogs de créateurs et les discussions sur Geniuspace.';}
        // Preserve an explicitly authored native SEO title; never append text after its brand.
        $legacy=trim(Text::plain((string)$p->get('seo_title','')));$stock=$label.' | '.\Joomla\CMS\Factory::getApplication()->get('sitename');
        $legacySubject=trim(explode('|',$legacy,2)[0]);
        if($legacy!==''&&$legacy!==$stock&&mb_strtolower($legacySubject)!==mb_strtolower($label))$identity['title']=$legacy;
        if(trim((string)($category->metadesc??''))!=='')$identity['description']=Text::plain($category->metadesc);
        foreach(['heading'=>'blog_heading','accent'=>'blog_accent','intro'=>'blog_intro','title'=>'blog_seo_title','description'=>'blog_seo_description']as$key=>$field){$v=Text::plain((string)$p->get($field,''));if($v!=='')$identity[$key]=$v;}
        return $identity;
    }

    /** Bounded keyset scanning also progresses past records excluded by native public ACLs. */
    public static function data(int $hub,object $params,?array $nativeIds=null): array
    {
        require_once __DIR__.'/NexusForumApp.php';
        $app=\Joomla\CMS\Factory::getApplication();$s=ProductAccess::store();
        $sources=array_values(array_unique(array_filter(array_merge([$hub,(int)\NexusPlatform::config($params,'blog_section_id')],ShellBindings::sections($hub,'blog')))));
        $format=$app->input->getCmd('nx_blog_format','');if(!isset(self::FORMATS[$format]))$format='';
        $author=max(0,$app->input->getInt('nx_blog_author'));$before=max(0,$app->input->getInt('nx_blog_before'));
        $query=mb_substr(trim($app->input->getString('q',$app->input->getString('nx_query',''))),0,200);
        $where='published=1 AND hidden=0 AND section_id IN ('.implode(',',$sources?:[0]).')';
        $category=self::category($hub);if($category){$ctx=UniverseBlueprint::context($hub,$category);if(!$ctx['current'])$where.=' AND 1=0';else{$ids=[$category];foreach(\NexusForumSeven::flat($ctx['current']->children)as$c)$ids[]=(int)$c->id;$where.=' AND id IN (SELECT record_id FROM #__js_res_record_category WHERE catid IN ('.implode(',',$ids).'))';}}
        if($before)$where.=' AND id<'.$before;
        if($author)$where.=' AND user_id='.$author;
        if($nativeIds!==null)$where.=' AND id IN ('.implode(',',array_map('intval',$nativeIds?:[0])).')';
        $items=[];$last=0;$more=false;$access=new NativeAccess();$scanBefore=0;
        // New discussions must not hide older editorial cards at the first SQL window.
        for($window=0;$window<10;$window++){
        $scan=$where.($scanBefore?' AND id<'.$scanBefore:'');
        $rows=$s->rows('SELECT id,section_id,type_id,fields,params FROM #__js_res_record WHERE '.$scan.' ORDER BY id DESC',200);
        foreach($rows as$raw){
            $last=(int)$raw['id'];$record=(object)$raw;
            if(!\NexusForumApp::allowed($record,$hub,$access)||!($p=$access->record($last)))continue;
            $kind=self::format($p);
            if($format&&$format!==$kind)continue;
            // Only selected public fields enter excerpts and search; never raw private values.
            $parts=[];foreach($p['fields']as$id=>$f)if(in_array($f['field_type'],['html','textarea','text','gpmedia','gpaudio','gpparcours'],true))$parts[]=PublicMaterial::fieldText($f['field_type'],$p['values'][$id]??'');
            $excerpt=trim((string)($p['record']['description']??''))?:implode(' ',$parts);
            if($query){$words=NexusKnowledge::words($query);$hay=NexusKnowledge::words($p['record']['title'].' '.$excerpt);if(!array_intersect($words,$hay))continue;}
            if(count($items)>=18){$more=true;$last=(int)$items[array_key_last($items)]['id'];break;}
            $public=PublicMaterial::record($last,false,$access);if(!$public)continue;
            $images=$public['images'];$cover=(string)($images[0]['url']??'');$alt=(string)($images[0]['title']??'');
            $cover=EditorialImages::resolve($cover);
            if($visual=EditorialImages::metadata($cover)){
                $altKey=\NexusPlatform::config($params,'field_cover_alt');
                foreach($p['fields']as$id=>$definition)if((($altKey!=='')&&($definition['key']??'')===$altKey)||in_array($definition['alias']??'',['cover-alt','cover_alt'],true)){
                    if(in_array($definition['field_type'],['text','textarea','html'],true)&&is_scalar($p['values'][$id]??null)&&Text::plain((string)$p['values'][$id])!=='')$alt=Text::plain((string)$p['values'][$id]);break;
                }
                $alt=EditorialImages::alternative($cover,$alt);
            }
            $safe=SpoilerShield::hit(['record_id'=>$last,'title'=>$p['record']['title'],'excerpt'=>mb_substr(Text::plain($excerpt),0,230)]);
            if(!empty($safe['spoiler_protected'])){$cover='';$alt='';}
            $user=$s->rows('SELECT name FROM #__users WHERE id='.(int)$p['raw']['user_id'].' AND block=0',1)[0]??[];
            $byline=$user['name']??'Auteur';$authorKey=\NexusPlatform::config($params,'field_author');
            foreach($p['fields']as$id=>$field)if((($field['key']??'')===$authorKey||($field['alias']??'')==='author')&&in_array($field['field_type'],['text','textarea','html'],true)&&is_scalar($p['values'][$id]??null)){
                $name=Text::plain((string)$p['values'][$id]);if($name!=='')$byline=mb_substr($name,0,220);break;
            }
            $items[]=['id'=>$last,'title'=>$safe['title'],'excerpt'=>$safe['excerpt'],'url'=>$public['url'],'author_id'=>(int)$p['raw']['user_id'],'author'=>$byline,'company'=>self::company($p),
                'cover'=>$cover,'alt'=>$alt,'format'=>$kind,'date'=>$public['created'],'comments'=>(int)$public['comment_count'],'views'=>(int)$p['raw']['hits'],'indexable'=>PublicMaterial::projection($last,true,$access)!==null,'spoiler'=>!empty($safe['spoiler_protected'])];
        }
        if($more||count($rows)<200)break;
        $scanBefore=$last;if($window===9)$more=true;
        }
        return ['items'=>$items,'format'=>$format,'author'=>$author,'query'=>$query,'next'=>$more?$last:0,'before'=>$before];
    }

    private static function company(array $projection): ?array
    {
        foreach($projection['fields']as$id=>$definition){
            if(!in_array($definition['field_type'],['parent','child'],true))continue;
            $field=(object)$definition;$field->params=new \Joomla\Registry\Registry($definition['params']);$field->value=$projection['values'][$id]??'';
            // Inspect the declared target type before traversing potentially large relation sets.
            $targetType=(int)$field->params->get('params.parent_type');
            if($field->field_type==='parent')$targetType=(int)(ProductAccess::store()->rows('SELECT type_id FROM #__js_res_fields WHERE id='.(int)$field->params->get('params.child_field'),1)[0]['type_id']??0);
            $target=ReadMemo::get('native-type-metadata:'.$targetType,static fn()=>ProductAccess::store()->rows('SELECT params FROM #__js_res_types WHERE id='.$targetType,1)[0]??[]);$tp=json_decode($target['params']??'{}',true)?:[];
            if(!preg_match('/^nexus_(?:aurora_)?company(?:\.|$)/D',(string)($tp['properties']['tmpl_article']??'')))continue;
            foreach(array_slice(ExtendedFields::targets($field,(object)$projection['raw'],false),0,5)as$target){
                if(!(new NativeAccess())->record((int)$target->id))continue;
                $type=ProductAccess::store()->rows('SELECT params FROM #__js_res_types WHERE id='.(int)$target->type_id,1)[0]??[];$p=json_decode($type['params']??'{}',true)?:[];
                if(!preg_match('/^nexus_(?:aurora_)?company(?:\.|$)/D',(string)($p['properties']['tmpl_article']??'')))continue;
                return ['name'=>$target->title,'url'=>ExtendedFields::url($target),'logo'=>RelationCards::value($target,(string)$field->params->get('params.card_cover_fields',''),true)];
            }
        }
        return null;
    }

    private static function format(array $p): string
    {
        $params=new \Joomla\Registry\Registry($p['raw']['params']??'{}');$slug=(string)$params->get('nexus_publication_form','');
        if(str_contains($slug,'video'))return 'video';
        if(str_contains($slug,'audio'))return 'audio';
        if(str_contains($slug,'review'))return 'review';
        if(str_contains($slug,'reportage'))return 'reportage';
        foreach($p['fields']as$id=>$field)if(in_array($field['alias'],['content-type','content_type'],true)){
            $v=$p['values'][$id]??'';if(is_array($v))$v=reset($v);
            if(is_string($v)&&isset(self::FORMATS[$v]))return $v;
        }
        return 'article';
    }

    /** Recent discussions across the connected blogs, independently of the current card page. */
    public static function recent(int $hub,object $params): array
    {
        $s=ProductAccess::store();$levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();
        $sections=array_values(array_unique(array_filter(array_merge([$hub,(int)\NexusPlatform::config($params,'blog_section_id')],ShellBindings::sections($hub,'blog')))));
        $scope='';$category=self::category($hub);
        if($category){$ctx=UniverseBlueprint::context($hub,$category);if(!$ctx['current'])return [];$ids=[$category];foreach(\NexusForumSeven::flat($ctx['current']->children)as$c)$ids[]=(int)$c->id;$scope=' AND r.id IN (SELECT record_id FROM #__js_res_record_category WHERE catid IN ('.implode(',',$ids).'))';}
        $rows=$s->rows('SELECT r.id,r.title,r.section_id,r.type_id,r.fields,c.id AS comment_id,c.name,c.comment,c.ctime,c.langs FROM #__js_res_comments c INNER JOIN #__js_res_record r ON r.id=c.record_id WHERE c.id>1 AND c.published=1 AND c.hide=0 AND c.private=0 AND c.access IN ('.implode(',',$levels?:[0]).') AND r.published=1 AND r.hidden=0 AND r.section_id IN ('.implode(',',$sections?:[0]).')'.$scope.' ORDER BY c.ctime DESC,c.id DESC',100);
        $out=[];$eligibility=[];foreach($rows as$row){
            $record=(int)$row['id'];if(!array_key_exists($record,$eligibility))$eligibility[$record]=\NexusForumApp::allowed((object)$row,$hub)&&!SpoilerShield::pending($record);
            if(!$eligibility[$record])continue;
            $type=$s->rows('SELECT params FROM #__js_res_types WHERE id='.(int)$row['type_id'],1)[0]??[];$tp=new \Joomla\Registry\Registry($type['params']??'{}');
            if($tp->get('comments.comments')!=='core'||($tp->get('comments.comments_lang_mode')&&$row['langs']!==\Joomla\CMS\Factory::getApplication()->getLanguage()->getTag()))continue;
            $out[]=['item'=>['id'=>(int)$row['id'],'title'=>$row['title'],'url'=>NativeUrls::url((object)$row)],'comment'=>(object)['id'=>(int)$row['comment_id'],'name'=>Text::plain($row['name']),'comment'=>Text::plain($row['comment']),'ctime'=>$row['ctime']]];
            if(count($out)>=5)break;
        }
        return $out;
    }

    public static function metadata(int $hub,array $state): void
    {
        $doc=\Joomla\CMS\Factory::getApplication()->getDocument();$url=self::canonical($hub);$identity=self::identity($hub);
        $doc->setTitle($identity['title']);$doc->setDescription($identity['description']);
        $head=$doc->getHeadData();foreach($head['links']??[]as$key=>$link)if(($link['relation']??'')==='canonical')unset($head['links'][$key]);$doc->setHeadData($head);$doc->addHeadLink($url,'canonical');
        \NexusForumApp::social($url,'website',$state['items'][0]['cover']??'',$state['items'][0]['alt']??'');
        // Facets/search/keyset pages are useful navigation, not competing landing pages.
        if($state['format']||$state['author']||$state['query']||$state['before']||!empty(\Joomla\CMS\Factory::getApplication()->input->get('filter',[],'array')))$doc->setMetaData('robots','noindex, follow');
    }

    private static function card(array $item,int $hub,bool $feature=false,int $number=0): string
    {
        $e=[Text::class,'escape'];$format=self::FORMATS[$item['format']];
        $img=$item['cover']?'<img src="'.$e($item['cover']).'" alt="'.$e($item['alt']).'" '.EditorialImages::attributes($item['cover'],$feature?'(max-width: 700px) 100vw, 900px':'(max-width: 700px) 100vw, 400px').' loading="'.($feature&&$number===0?'eager':'lazy').'" decoding="async"'.($feature&&$number===0?' fetchpriority="high"':'').'>':'<span class="nx-blog-art" aria-hidden="true">'.\NexusConnect::icon(['video'=>'video','audio'=>'microphone','review'=>'star','reportage'=>'camera'][''.$item['format']]??'book-open').'</span>';
        $company=$item['company'];$linked=$company?'<a class="nx-blog-company" href="'.$e($company['url']).'">'.($company['logo']?'<img src="'.$e($company['logo']).'" alt="" width="24" height="24" loading="lazy">':'').'<span>En lien avec '.$e($company['name']).'</span></a>':'';
        $activity=[];if($item['comments']>0)$activity[]=$item['comments'].' réponse'.($item['comments']>1?'s':'');if($item['views']>0)$activity[]=$item['views'].' vue'.($item['views']>1?'s':'');
        return '<article class="nx-blog-card'.($feature?' nx-blog-feature':'').'" data-blog-format="'.$item['format'].'" data-blog-record="'.$item['id'].'"'.($feature?' data-blog-slide':'').'><a class="nx-blog-cover" href="'.$e($item['url']).'">'.$img.'<span class="nx-blog-format">'.$e($format).'</span></a><div class="nx-blog-card-copy"><p class="nx-blog-byline"><a href="'.$e(self::url($hub,['nx_blog_author'=>$item['author_id']])).'">'.$e($item['author']).'</a><time datetime="'.$e($item['date']).'">'.$e(substr($item['date'],0,10)).'</time></p>'.$linked.'<h2><a href="'.$e($item['url']).'">'.$e($item['title']).'</a></h2><p>'.$e($item['excerpt']).'</p><footer><span>'.($activity?implode(' · ',$activity):'Ouvrez la conversation').'</span><a href="'.$e($item['url']).'">Lire & échanger →</a></footer></div></article>';
    }

    public static function render(object $view,int $hub,object $params): string
    {
        $native=null;if(\Joomla\CMS\Factory::getApplication()->input->get('filter',[],'array'))$native=array_map(static fn($r)=>(int)$r->id,(array)($view->items??[]));
        $state=self::$states[$hub]=self::data($hub,$params,$native);self::metadata($hub,$state);$e=[Text::class,'escape'];$base=self::url($hub);$all=self::url($hub,['nx_blog_category'=>0]);$identity=self::identity($hub,$params);
        $out='<main class="nx-blog-index" data-blog-index tabindex="-1"><header class="nx-blog-intro"><div><p class="nx-blog-eyebrow">GENIUSPACE · LES VOIX DU MULTIVERS</p><h1 data-forum7-primary-heading>'.$e($identity['heading']).'<br><span>'.$e($identity['accent']).'</span></h1><p>'.$e($identity['intro']).'</p></div><a href="#nx-dock-publish" data-dock-open="publish" class="nx-blog-write">＋ Partager une publication</a></header>';
        if(\Joomla\CMS\Factory::getApplication()->input->getInt('nx_article')&&($resume=\NexusForumApp::article($hub,$params)))$out.='<a class="nx-blog-resume nx-blog-write" href="'.$e(\NexusForumApp::articleUrl($resume,$hub)).'">Reprendre ma lecture : '.$e($resume->title).' →</a>';
        if($state['items']&&!$state['before']&&\NexusPlatform::config($params,'blog_index_slider','1')!=='0'){$out.='<section class="nx-blog-featured" aria-label="Publications récentes à découvrir"><header><h2>À la une du Multi-Blog</h2><div><button type="button" data-blog-direction="-1" aria-label="Publication précédente">←</button><button type="button" data-blog-pause aria-pressed="false">Pause</button><button type="button" data-blog-direction="1" aria-label="Publication suivante">→</button></div></header><div class="nx-blog-slider" tabindex="0" aria-label="Sélection des dernières publications">';foreach(array_slice($state['items'],0,4)as$i=>$item)$out.=self::card($item,$hub,true,$i);$out.='</div><p class="nx-blog-slide-status" aria-live="off">Les dernières publications accessibles · faites défiler pour découvrir</p></section>';}
        $out.='<form method="get" action="'.$e($base).'" class="nx-blog-search"><input type="hidden" name="nx_mode" value="blog"><label for="nx-blog-query">Quel sujet vous intéresse ?</label><div><input type="search" id="nx-blog-query" name="q" maxlength="200" value="'.$e($state['query']).'" placeholder="Une idée, une expérience, une entreprise…"><button>Rechercher</button></div></form><nav class="nx-blog-facets" aria-label="Formats de publication"><a href="'.$e($base).'"'.(!$state['format']?' aria-current="page"':'').'>Tous les formats</a>';
        foreach(self::FORMATS as$key=>$label)$out.='<a href="'.$e(self::url($hub,['nx_blog_format'=>$key])).'"'.($state['format']===$key?' aria-current="page"':'').'>'.\NexusConnect::icon(['video'=>'video','audio'=>'microphone','review'=>'star','reportage'=>'camera'][$key]??'book-open').' '.$label.'</a>';
        $out.='</nav>';
        if(isset($view->tmpl_params['markup'])){$filters=\Joomcck\Layout\Helpers\Layout::render('nexus.platform.filters',['current'=>$view]);if(trim($filters))$out.='<details class="nx-blog-native-filters"><summary>Affiner selon les caractéristiques des publications</summary>'.$filters.'</details>';}
        $out.='<div class="nx-blog-layout"><section aria-label="Publications du Multi-Blog"><header class="nx-blog-section-heading"><h2>'.($state['author']?'Les publications de cet auteur':'Toutes les voix, tous les formats').'</h2><span>'.count($state['items']).' publication(s) sur cette page</span></header><div class="nx-blog-grid">';
        foreach($state['items']as$item)$out.=self::card($item,$hub);
        if(!$state['items'])$out.='<div class="nx-blog-empty"><h2>Aucune publication ne correspond encore.</h2><p>Essayez un autre sujet ou ouvrez tous les formats. Les publications privées et les brouillons restent dans leur espace.</p><a href="'.$e($all).'">Voir tous les blogs</a></div>';
        $out.='</div><nav class="nx-blog-pagination" aria-label="Autres publications">';
        if($state['before']||$state['author']||$state['query'])$out.='<a href="'.$e($base).'">Retour à toutes les publications</a>';
        if($state['next'])$out.='<a rel="next" href="'.$e(self::url($hub,['nx_blog_before'=>$state['next'],'nx_blog_format'=>$state['format'],'nx_blog_author'=>$state['author']?:'','q'=>$state['query']])).'">Découvrir les publications précédentes →</a>';
        $out.='</nav></section><aside class="nx-blog-aside"><section><h2>Les voix à découvrir</h2><p>Des idées portées par celles et ceux qui les vivent. Explorez un auteur, découvrez ses publications et rejoignez la conversation.</p>';
        $authors=[];foreach($state['items']as$item)if(!isset($authors[$item['author_id']])){$authors[$item['author_id']]=true;$out.='<a class="nx-blog-channel" href="'.$e(self::url($hub,['nx_blog_author'=>$item['author_id']])).'"><span aria-hidden="true">'.$e(mb_substr($item['author'],0,1)).'</span><strong>'.$e($item['author']).'</strong><small>Explorer ses publications →</small></a>';if(count($authors)>=6)break;}
        $out.='</section><section><h2>La conversation continue</h2>';
        $comments=self::recent($hub,$params);
        foreach(array_slice($comments,0,5)as$c){$item=$c['item'];$comment=$c['comment'];$out.='<a class="nx-blog-recent-comment" href="'.$e(CommentLocator::link($item['url'],(int)$comment->id)).'"><strong>'.$e(Text::plain($comment->name)).'</strong><p>'.$e(mb_substr(Text::plain($comment->comment),0,150)).'</p><small>Sur : '.$e($item['title']).'</small></a>';}
        if(!$comments)$out.='<p>Les premières réponses publiques apparaîtront ici.</p>';
        $out.='</section></aside></div><a class="nx-blog-top" href="#nx-blog-query" data-blog-top>↑ Revenir à la découverte</a>';
        $elements=[];foreach($state['items']as$item)if($item['indexable']){
            $post=['@type'=>'BlogPosting','@id'=>$item['url'].'#publication','url'=>$item['url'],'headline'=>$item['title'],'description'=>$item['excerpt'],'author'=>['@type'=>'Person','name'=>$item['author'],'url'=>self::url($hub,['nx_blog_author'=>$item['author_id']])],'publisher'=>['@type'=>'Organization','name'=>'Geniuspace','url'=>\Joomla\CMS\Uri\Uri::root()]];
            if($item['date']&&($date=strtotime($item['date']))!==false)$post['datePublished']=gmdate('c',$date);
            if($item['cover']){
                $image=['@type'=>'ImageObject','contentUrl'=>PublicDiscovery::absolute($item['cover']),'url'=>PublicDiscovery::absolute($item['cover']),'caption'=>$item['alt']];
                if($meta=EditorialImages::metadata($item['cover'])){$image['width']=(int)$meta['width'];$image['height']=(int)$meta['height'];if(!empty($meta['credit']))$image['creditText']=$meta['credit'];if(!empty($meta['caption']))$image['description']=$meta['caption'];}
                $post['image']=$image;
            }
            $elements[]=['@type'=>'ListItem','position'=>count($elements)+1,'url'=>$item['url'],'name'=>$item['title'],'item'=>$post];
        }
        $canonical=self::canonical($hub);$schema=['@context'=>'https://schema.org','@type'=>'CollectionPage','@id'=>$canonical.'#multiblog','url'=>$canonical,'name'=>$identity['heading'].' · Multi-Blog Geniuspace','description'=>$identity['description'],'mainEntity'=>['@type'=>'ItemList','itemListElement'=>$elements]];
        return $out.'<script type="application/ld+json" data-blog-schema>'.Seo::json($schema).'</script></main>';
    }
}
