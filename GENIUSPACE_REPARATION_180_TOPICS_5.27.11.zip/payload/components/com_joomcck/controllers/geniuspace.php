<?php
defined('_JEXEC') or die;
require_once JPATH_ROOT . '/components/com_joomcck/library/php/geniuspace/bootstrap.php';

/** Native component dispatch: disabling system plugins does not remove field endpoints. */
class JoomcckControllerGeniuspace extends MControllerBase
{
    public function subscriptions(){ echo \Geniuspace\SubscriptionRuntime::page(); }
    public function subscriptionWebhook(){ \Geniuspace\SubscriptionRuntime::webhook(); }
    private function nativePost(): void
    {
        if(($_SERVER['REQUEST_METHOD']??'')!=='POST'||!\Geniuspace\Tokens::valid())throw new \DomainException('Jeton ou méthode invalide.',403);
        $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');
        if($origin!==''&&!hash_equals($authority,$origin))throw new \DomainException('Origine invalide.',403);
    }
    /** Read-only, fresh public gate; the native view still renders and validates its own fields. */
    public function jobPreview()
    {
        $app=\Joomla\CMS\Factory::getApplication();$status=200;
        try{
            if($app->input->getMethod()!=='GET')throw new \DomainException('Méthode interdite.',405);
            $id=$app->input->getInt('id');$p=(new \Geniuspace\NativeAccess())->record($id);
            if(!$p||!\Geniuspace\EmploymentRoutes::eligible($p['raw'])||!\Geniuspace\EmploymentExperience::summary($p)['active'])throw new \DomainException('Offre introuvable.',404);
            require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusForumApp.php';
            $html=\Geniuspace\EmploymentExperience::preview($p);$head=$app->getDocument()->getHeadData();$assets=[];
            foreach(['styleSheets'=>'style','scripts'=>'script']as$key=>$kind)foreach($head[$key]??[]as$url=>$attributes)$assets[]=['url'=>$url,'kind'=>$kind,'module'=>($attributes['attributes']['type']??$attributes['type']??'')==='module'];
            $body=['id'=>$id,'title'=>$p['record']['title'],'url'=>\Geniuspace\EmploymentRoutes::recordUrl($p['raw']),'html'=>$html,'assets'=>$assets];
        }catch(\DomainException $e){$status=in_array($e->getCode(),[403,404,405],true)?$e->getCode():400;$body=['error'=>$e->getMessage()];}
        catch(\Throwable $e){$status=500;$body=['error'=>'L’aperçu est temporairement indisponible.'];\Joomla\CMS\Log\Log::add('Job preview: '.get_class($e),\Joomla\CMS\Log\Log::WARNING,'joomcck');}
        $app->setHeader('status',(string)$status,true);http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->setHeader('X-Robots-Tag','noindex, nofollow',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function product()
    {
        $app=\Joomla\CMS\Factory::getApplication();$json=str_contains((string)($_SERVER['CONTENT_TYPE']??''),'application/json')||str_contains((string)($_SERVER['HTTP_ACCEPT']??''),'application/json');
        try{
            if(($_SERVER['REQUEST_METHOD']??'')!=='POST')throw new \DomainException('Méthode interdite.',405);
            $token=\Joomla\CMS\Session\Session::getFormToken();$header=(string)($_SERVER['HTTP_X_GENIUSPACE_CSRF']??'');
            if(!(\Geniuspace\Tokens::valid()||($header!==''&&hash_equals($token,$header))))throw new \DomainException('Jeton invalide.',403);
            $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$origin=(string)($_SERVER['HTTP_ORIGIN']??'');$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');
            if($origin!==''&&!hash_equals($origin,$authority))throw new \DomainException('Origine invalide.',403);
            if(str_contains((string)($_SERVER['CONTENT_TYPE']??''),'application/json')){$raw=(string)file_get_contents('php://input',false,null,0,131073);if(strlen($raw)>131072)throw new \DomainException('Requête trop grande.',413);$data=json_decode($raw,true,24,JSON_THROW_ON_ERROR);}
            else $data=$_POST;
            if(!is_array($data)||array_is_list($data))throw new \InvalidArgumentException('Objet requis.');$data=\Geniuspace\ProductActions::normalize($data);
            if(($data['action']??'')==='audio.upload'){$upload=$app->input->files->get('audio',null,'raw');if(!is_array($upload)||($upload['error']??1)!==UPLOAD_ERR_OK||!is_uploaded_file($upload['tmp_name'])||filesize($upload['tmp_name'])>10*1024*1024)throw new \InvalidArgumentException('Audio téléversé invalide.');$body=\Geniuspace\AudioWorkshop::upload($data['record']??0,$data['field']??0,(string)file_get_contents($upload['tmp_name']),(int)($data['section']??0));}
            else $body=\Geniuspace\ProductActions::handle($data);$status=200;
        }catch(\DomainException $e){$status=in_array($e->getCode(),[403,404,405,409,413,422,429,503],true)?$e->getCode():400;$body=['error'=>$e->getMessage()];}
        catch(\InvalidArgumentException|\JsonException $e){$status=400;$body=['error'=>$e->getMessage()];}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Product operation: '.get_class($e),\Joomla\CMS\Log\Log::ERROR,'joomcck');$status=503;$body=['error'=>'Action indisponible. Consultez le journal Joomla.'];}
        if($json){http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();}
        $app->enqueueMessage($body['message']??$body['error']??'Modification enregistrée.',$status===200?'message':'warning');
        $action=(string)($data['action']??'');$target=str_starts_with($action,'account.')?'index.php?option=com_users&view=profile':(str_starts_with($action,'moderation.')?'index.php?option=com_joomcck&view=tools&layout=nexusmoderation':'index.php?option=com_joomcck&view=record&id='.$app->input->post->getInt('record'));
        if($status===200&&$action==='multiverse.spawn'&&!empty($body['url'])) {
            $destination=new \Joomla\CMS\Uri\Uri((string)$body['url']);$site=new \Joomla\CMS\Uri\Uri(\Joomla\CMS\Uri\Uri::root());
            if($destination->getScheme()===$site->getScheme()&&$destination->getHost()===$site->getHost()&&$destination->getPort()===$site->getPort()&&!$destination->getUser()&&!$destination->getPass())$target=(string)$body['url'];
        }
        $this->setRedirect(\Joomla\CMS\Router\Route::_($target,false));
    }
    public function designStudio() { \Geniuspace\DesignStudio::page(); }
    public function designApi() { \Geniuspace\DesignApi::dispatch(); }
    public function productRead()
    {
        $app=\Joomla\CMS\Factory::getApplication();try{
            if(!in_array(strtoupper($_SERVER['REQUEST_METHOD']??'GET'),['GET','HEAD'],true))throw new \DomainException('Lecture seule.',405);
            $body=\Geniuspace\ProductRead::handle($app->input->getCmd('kind','search'),$app->input->getString('query',''),$app->input->getInt('record',0));$status=200;
        }catch(\DomainException|\InvalidArgumentException $e){$body=['error'=>$e->getMessage()];$status=$e instanceof \DomainException?$e->getCode():400;}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Product read: '.get_class($e),\Joomla\CMS\Log\Log::ERROR,'joomcck');$body=['error'=>'Lecture indisponible.'];$status=503;}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->sendHeaders();if(strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='HEAD')echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function nativeMedia()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try { \Geniuspace\NativeMedia::stream($app->input->getInt('file')); }
        catch (\DomainException $e) { http_response_code(in_array($e->getCode(),[403,404,405,416],true)?$e->getCode():404);$app->setHeader('Content-Type','text/plain; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->sendHeaders();if(($_SERVER['REQUEST_METHOD']??'GET')!=='HEAD')echo 'Média inaccessible.';$app->close(); }
        catch (\Throwable $e) { \Joomla\CMS\Log\Log::add('Native media: '.get_class($e),\Joomla\CMS\Log\Log::WARNING,'joomcck');http_response_code(503);$app->setHeader('Cache-Control','private, no-store',true);$app->sendHeaders();$app->close(); }
    }
    /** Same-origin native field upload; no public media copies. */
    public function participationUpload()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try { $this->nativePost();require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusParticipation.php';NexusParticipation::upload();throw new \LogicException('Upload response was not closed.'); }
        catch(\DomainException|\InvalidArgumentException $e){$status=in_array($e->getCode(),[403,404,409,413,422,429],true)?$e->getCode():400;$body=['error'=>$e->getMessage()];}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Participation upload: '.get_class($e),\Joomla\CMS\Log\Log::ERROR,'joomcck');$status=503;$body=['error'=>'Image indisponible. Votre message est conservé.'];}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function productMedia()
    {
        $app=\Joomla\CMS\Factory::getApplication();$method=strtoupper($_SERVER['REQUEST_METHOD']??'GET');
        try{if(!in_array($method,['GET','HEAD'],true))throw new \DomainException('Lecture seule.',405);$r=\Geniuspace\AudioWorkshop::download($app->input->getInt('asset',0));}
        catch(\DomainException $e){$r=new \Geniuspace\Response($e->getMessage(),'text/plain; charset=utf-8',$e->getCode(),['Cache-Control'=>'private, no-store','X-Robots-Tag'=>'noindex']);}
        http_response_code($r->status);foreach($r->headers as$key=>$v)$app->setHeader($key,$v,true);$app->sendHeaders();if($method!=='HEAD')echo $r->body;$app->close();
    }
    public function repairNexus()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            $this->nativePost();
            if(!$app->getIdentity()->id||!$app->getIdentity()->authorise('core.admin'))throw new \DomainException('Réparation réservée aux administrateurs Joomla.',403);
            \Geniuspace\SchemaMigration::apply(\Geniuspace\ProductAccess::store()->db);
            \Geniuspace\NativeTemplates::defaults();\Geniuspace\SchemaMigration::clearMenus();
            if(\Geniuspace\SchemaHealth::missing())throw new \RuntimeException('Migration incomplète après réparation.');
            $app->enqueueMessage('Tables Nexus et configurations par défaut vérifiées. Les fiches, relations, menus et configurations personnalisées sont conservés.');
        }catch(\DomainException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Nexus repair: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');$app->enqueueMessage('Réparation interrompue. Consultez le journal PHP/Joomla pour la cause.','error');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=tools&layout=nexushealth',false));
    }
    public function demo()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{$this->nativePost();$result=\Geniuspace\DemoInstaller::install($app->input->post->getCmd('prefix','nexusdemo'),$app->input->post->getCmd('edition','classic'));$app->enqueueMessage(!empty($result['already_installed'])?'Cette démonstration existe déjà. Aucun doublon créé.':'Démonstration native installée : sections, types, fields, relations et menus Joomla.');}
        catch(\DomainException|\InvalidArgumentException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Demo install: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');$app->enqueueMessage('Installation annulée. Consultez le journal JoomCCK.','error');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=tools&layout=nexusdemo',false));
    }
    public function forumSetup()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            $this->nativePost();$opts=['title'=>$app->input->post->getString('title','Méta-Hub Geniuspace'),'hub_slug'=>$app->input->post->getCmd('hub_slug','hub'),'thread_slug'=>$app->input->post->getCmd('thread_slug','thread')];
            foreach(['company','job','courses']as$role)foreach(['type','section']as$key)$opts[$role.'_'.$key]=$app->input->post->getInt($role.'_'.$key,0);
            $result=\Geniuspace\ForumProvisioner::install($opts);$added=count($result['media_fields_added']??[]);$app->enqueueMessage(!empty($result['already_installed'])?($added?$added.' fields médias natifs ajoutés. Vos contenus et réglages ont été conservés.':'Fields médias vérifiés. Vos contenus et réglages ont été conservés.'):'Forum créé : catégories, images locales, fields natifs, templates et menus Joomla. Aucun sujet fictif créé.');
        }catch(\DomainException|\InvalidArgumentException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Forum provision: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');$app->enqueueMessage('Installation du forum interrompue. Consultez le journal JoomCCK.','error');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=tools&layout=nexusforum',false));
    }
    public function editorialPack()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{$this->nativePost();$result=\Geniuspace\EditorialPack::install();$app->enqueueMessage(!empty($result['already_installed'])?'Les dossiers existent déjà. Vos modifications et leurs commentaires sont conservés.':'Cinq dossiers illustrés, deux vidéos pédagogiques et cinq discussions associées sont publiés sous votre signature.');}
        catch(\DomainException|\InvalidArgumentException$e){$app->enqueueMessage($e->getMessage(),'warning');}
        catch(\Throwable$e){\Joomla\CMS\Log\Log::add('Editorial pack: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');$app->enqueueMessage('Publication des dossiers interrompue. Consultez le journal Joomla.','error');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=tools&layout=nexusforum',false));
    }
    public function editorialCollection2026()
    {
        $app=\Joomla\CMS\Factory::getApplication();$status=200;
        try{$this->nativePost();$body=\Geniuspace\EditorialPack::collection2026($app->input->post->getCmd('universe',''));}
        catch(\DomainException$e){$status=in_array($e->getCode(),[403,404,409],true)?$e->getCode():400;$body=['error'=>$e->getMessage()];}
        catch(\Throwable$e){$status=503;$body=['error'=>'Ce lot n’a pas été terminé. Relancez-le pour vérifier les articles déjà enregistrés et compléter les dossiers manquants.'];\Joomla\CMS\Log\Log::add('Editorial collection: '.get_class($e),\Joomla\CMS\Log\Log::ERROR,'joomcck');}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function forumRadar()
    {
        $app=\Joomla\CMS\Factory::getApplication();$status=200;
        try{
            if(!in_array($app->input->getMethod(),['GET','HEAD'],true))throw new \DomainException('Lecture seule.',405);
            $id=$app->input->getInt('section');$section=\Geniuspace\ForumRoutes::section($id);$levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();
            if(!$section||!in_array((int)$section['access'],$levels,true)||!$section['settings']->get('general.status',1)||$section['settings']->get('emerald.section_subscription'))throw new \DomainException('Communauté introuvable.',404);
            require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusForumSeven.php';$body=\NexusAbsolu::radar($id);
        }catch(\DomainException$e){$status=$e->getCode()?:400;$body='<p>Radar indisponible pour cette communauté.</p>';}
        catch(\Throwable$e){$status=503;$body='<p>Les tendances sont momentanément indisponibles.</p>';}
        http_response_code($status);$app->setHeader('Content-Type','text/html; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex, nofollow',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();if($app->input->getMethod()!=='HEAD')echo $body;$app->close();
    }
    public function editorialTopics2026()
    {
        $app=\Joomla\CMS\Factory::getApplication();$status=200;
        try{$this->nativePost();$body=\Geniuspace\EditorialPack::topics2026($app->input->post->getCmd('universe',''));}
        catch(\DomainException$e){$status=in_array($e->getCode(),[403,404,409],true)?$e->getCode():400;$body=['error'=>$e->getMessage()];}
        catch(\Throwable$e){$status=503;$body=['error'=>'Lot interrompu. Reprenez pour conserver les fils déjà enregistrés.'];\Joomla\CMS\Log\Log::add('Editorial topics: '.get_class($e),\Joomla\CMS\Log\Log::ERROR,'joomcck');}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function memberImport()
    {
        $app=\Joomla\CMS\Factory::getApplication();$status=200;
        try{
            $this->nativePost();$u=$app->getIdentity();if(!$u->id||$u->block||!$u->authorise('core.admin'))throw new \DomainException('Accès administrateur requis.',403);
            if($app->input->post->getCmd('stage')==='start'){
                $file=$app->input->files->get('members',null,'array');if(!$file||($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name']??'')||(int)$file['size']>10485760)throw new \InvalidArgumentException('Choisissez un CSV de membres, inférieur à 10 Mo.');
                $body=\Geniuspace\LegacyMembers::prepare($file['tmp_name'],$app->input->post->getInt('real_accounts')===1);
            }else $body=\Geniuspace\LegacyMembers::batch($app->input->post->getCmd('job',''));
        }catch(\DomainException|\InvalidArgumentException$e){$status=in_array($e->getCode(),[403,404,409],true)?$e->getCode():400;$body=['error'=>$e->getMessage()];}
        catch(\Throwable$e){$status=503;$body=['error'=>'Migration interrompue. Reprenez le lot ; les comptes antérieurs sont conservés.'];\Joomla\CMS\Log\Log::add('Member migration: '.get_class($e),\Joomla\CMS\Log\Log::ERROR,'joomcck');}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function repairPublications()
    {
        $app=\Joomla\CMS\Factory::getApplication();$status=200;$input=$app->getInput();
        try{
            $this->nativePost();$u=$app->getIdentity();if(!$u->id||$u->block||!$u->authorise('core.admin'))throw new \DomainException('Accès administrateur requis.',403);
            $stage=$input->post->getCmd('stage','diagnose');
            if($stage==='diagnose')$body=\Geniuspace\PublicationRecovery::diagnose();
            elseif($stage==='job-start')$body=\Geniuspace\PublicationRepair::start(true);
            elseif($stage==='job-status')$body=\Geniuspace\PublicationRepair::status()??['status'=>'not_started'];
            elseif($stage==='job-step')$body=\Geniuspace\PublicationRepair::step($input->post->getCmd('job',''));
            elseif($stage==='universe')$body=\Geniuspace\PublicationRecovery::universe($input->post->getCmd('universe',''));
            elseif($stage==='remove-import')$body=\Geniuspace\LegacyMemberRemoval::remove($input->post->getInt('expected',0));
            elseif(in_array($stage,['sql-diagnose','sql-topics','sql-remove'],true)){
                $file=$input->files->get('legacy_sql',null,'array');if(!$file||($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name']??'')||(int)$file['size']>2097152)throw new \InvalidArgumentException('Choisissez le fichier SQL original des 450 membres (2 Mo maximum).');
                if($stage==='sql-diagnose')$body=\Geniuspace\SqlImportRecovery::preview($file['tmp_name']);
                elseif($stage==='sql-topics')$body=\Geniuspace\SqlImportRecovery::repairTopics($file['tmp_name']);
                else $body=\Geniuspace\LegacyMemberRemoval::removeSql($file['tmp_name'],$input->post->getInt('expected',0));
            }
            else throw new \InvalidArgumentException('Action inconnue.');
        }catch(\DomainException|\InvalidArgumentException$e){$status=in_array((int)$e->getCode(),[403,404,409],true)?(int)$e->getCode():400;$body=['error'=>$e->getMessage()];if($e->getMessage()==='Une étape est déjà en cours. Réessayez dans un instant.')$body['retry_after']=2;}
        catch(\Throwable$e){$status=503;$body=['error'=>'Opération interrompue. Aucun autre compte ou contenu n’est supprimé. Consultez le journal Joomla.'];\Joomla\CMS\Log\Log::add('Publication recovery: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex, nofollow',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function editorialLibrary2026()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{$this->nativePost();$result=\Geniuspace\EditorialPack::library2026();$app->enqueueMessage(!empty($result['already_installed'])?'Les douze dossiers existent déjà. Vos modifications et commentaires sont conservés.':'Douze dossiers illustrés et leurs carnets sont publiés dans leurs univers, avec des liens entre les dossiers.');}
        catch(\DomainException|\InvalidArgumentException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Editorial library: '.get_class($e),\Joomla\CMS\Log\Log::ERROR,'joomcck');$app->enqueueMessage('Import interrompu. Consultez le journal Joomla.','error');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=tools&layout=nexusforum',false));
    }
    public function shellBindings()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{$this->nativePost();\Geniuspace\ShellBindings::save($app->input->post->get('bindings',[],'array'));$app->enqueueMessage('Espaces raccordés. Les fiches, menus et URL existants sont conservés.');}
        catch(\DomainException|\InvalidArgumentException$e){$app->enqueueMessage($e->getMessage(),'warning');}
        catch(\Throwable$e){\Joomla\CMS\Log\Log::add('Shell bindings: '.get_class($e),\Joomla\CMS\Log\Log::ERROR,'joomcck');$app->enqueueMessage('Raccordement indisponible. Consultez le journal Joomla.','error');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=tools&layout=nexusforum',false));
    }
    public function vault()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            $this->nativePost();$action=$app->input->post->getCmd('action');
            if($action==='upload'){$file=$app->input->files->get('proof',null,'raw');if(!is_array($file)||($file['error']??1)!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name'])||filesize($file['tmp_name'])>2*1024*1024)throw new \InvalidArgumentException('PDF reçu invalide ou trop volumineux.');\Geniuspace\OfferVault::upload($app->input->post->getInt('record'),$app->input->post->getInt('field'),$_POST,(string)$file['name'],(string)file_get_contents($file['tmp_name']));}
            elseif($action==='revoke')\Geniuspace\OfferVault::revoke($app->input->post->getInt('offer'));
            else \Geniuspace\OfferVault::review($app->input->post->getInt('offer'),$action);
            $app->enqueueMessage('Document actualisé.');
        }catch(\DomainException|\InvalidArgumentException|\JsonException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=record&id='.$app->input->post->getInt('record'),false));
    }
    public function vaultDownload()
    {
        $app=\Joomla\CMS\Factory::getApplication();$method=$_SERVER['REQUEST_METHOD']??'GET';
        try{if(!in_array($method,['GET','HEAD'],true))throw new \DomainException('Méthode interdite.',405);$response=\Geniuspace\OfferVault::download($app->input->getInt('id'),$app->input->getInt('original')===1);}
        catch(\DomainException $e){$response=new \Geniuspace\Response($e->getMessage(),'text/plain; charset=utf-8',in_array($e->getCode(),[403,404,405],true)?$e->getCode():400,['Cache-Control'=>'private, no-store','X-Robots-Tag'=>'noindex']);}
        http_response_code($response->status);foreach($response->headers as$name=>$value)$app->setHeader($name,$value,true);$app->sendHeaders();if($method!=='HEAD')echo $response->body;$app->close();
    }
    public function creatorRevenue()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{$this->nativePost();\Geniuspace\CreatorRevenue::settle($app->input->post->getInt('application'),$app->input->post->getInt('creator'),$app->input->post->getString('reference'));$app->enqueueMessage('Référence du règlement consignée.');}
        catch(\DomainException|\InvalidArgumentException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=record&id='.$app->input->post->getInt('record'),false));
    }
    public function workstyle()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            if(($_SERVER['REQUEST_METHOD']??'')!=='POST'||!\Geniuspace\Tokens::valid())throw new \DomainException('Jeton ou méthode invalide.',403);
            $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');if($origin!==''&&!hash_equals($authority,$origin))throw new \DomainException('Origine invalide.',403);
            \Geniuspace\Workstyle::submit($app->input->post->getInt('record'),$app->input->post->getInt('field'),$app->input->post->get('answers',[],'array'));$app->enqueueMessage('Comparaison enregistrée.');
        }catch(\DomainException|\InvalidArgumentException|\JsonException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=record&id='.$app->input->post->getInt('record'),false));
    }
    public function cohort()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            if(($_SERVER['REQUEST_METHOD']??'')!=='POST'||!\Geniuspace\Tokens::valid())throw new \DomainException('Jeton ou méthode invalide.',403);
            $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');if($origin!==''&&!hash_equals($authority,$origin))throw new \DomainException('Origine invalide.',403);
            \Geniuspace\Cohort::membership($app->input->post->getInt('record'),$app->input->post->getInt('field'),$app->input->post->getInt('join')===1);$app->enqueueMessage('Cohorte actualisée.');
        }catch(\DomainException|\InvalidArgumentException|\JsonException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=record&id='.$app->input->post->getInt('record'),false));
    }
    public function hiring()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            if(($_SERVER['REQUEST_METHOD']??'')!=='POST'||!\Geniuspace\Tokens::valid())throw new \DomainException('Jeton ou méthode invalide.',403);
            $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');if($origin!==''&&!hash_equals($authority,$origin))throw new \DomainException('Origine invalide.',403);
            \Geniuspace\Hiring::change($app->input->post->getInt('application'),$app->input->post->getCmd('state'));$app->enqueueMessage('Étape enregistrée.');
        }catch(\DomainException|\InvalidArgumentException|\JsonException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        $this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=record&id='.$app->input->post->getInt('record'),false));
    }
    public function talentmarket()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            if(($_SERVER['REQUEST_METHOD']??'')!=='POST'||!\Geniuspace\Tokens::valid())throw new \DomainException('Jeton ou méthode invalide.',403);
            $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');
            if($origin!==''&&!hash_equals($authority,$origin))throw new \DomainException('Origine invalide.',403);
            \Geniuspace\TalentMarket::action($_POST);$app->enqueueMessage('Proposition actualisée.');
        }catch(\DomainException|\InvalidArgumentException|\JsonException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        $id=$app->input->post->getInt('record');$this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=record&id='.$id,false));
    }
    public function community()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            if(($_SERVER['REQUEST_METHOD']??'')!=='POST'||!\Geniuspace\Tokens::valid())throw new \DomainException('Jeton ou méthode invalide.',403);
            $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');
            if($origin!==''&&!hash_equals($authority,$origin))throw new \DomainException('Origine invalide.',403);
            \Geniuspace\RecordCommunity::action($_POST);$app->enqueueMessage('Profil actualisé.');
        }catch(\DomainException|\InvalidArgumentException|\JsonException $e){$app->enqueueMessage($e->getMessage(),'warning');}
        $id=$app->input->post->getInt('record');$this->setRedirect(\Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=record&id='.$id,false));
    }
    public function omega()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            if(strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='POST')throw new \DomainException('Méthode interdite.',405);
            $csrf=\Joomla\CMS\Session\Session::getFormToken();$header=(string)($_SERVER['HTTP_X_GENIUSPACE_CSRF']??'');
            $uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');
            if(!$app->getIdentity()->id||!hash_equals($csrf,$header)||($origin!==''&&!hash_equals($authority,$origin)))throw new \DomainException('Accès ou jeton invalide.',403);
            $raw=(string)file_get_contents('php://input',false,null,0,1048577);if(strlen($raw)>1048576)throw new \DomainException('Requête trop volumineuse.',413);
            $data=json_decode($raw,true,20,JSON_THROW_ON_ERROR);if(!is_array($data))throw new \InvalidArgumentException('Objet JSON requis.');
            $body=\Geniuspace\OmegaCockpit::handle($data);$status=200;
        }catch(\DomainException $e){$body=['error'=>$e->getMessage()];$status=in_array($e->getCode(),[403,404,405,409,413,422,503],true)?$e->getCode():400;}
        catch(\InvalidArgumentException|\JsonException $e){$body=['error'=>$e->getMessage()];$status=400;}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Omega cockpit: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');$body=['error'=>'Cockpit indisponible. Consultez le journal Joomla.'];$status=503;}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function sitemap()
    {
        $app=\Joomla\CMS\Factory::getApplication();$method=strtoupper($_SERVER['REQUEST_METHOD']??'GET');
        try{if(!in_array($method,['GET','HEAD'],true))throw new \DomainException('Lecture seule.',405);$response=\Geniuspace\NexusSitemap::response($app->input->getInt('shard',-1));}
        catch(\DomainException $e){$response=new \Geniuspace\Response($e->getMessage(),'text/plain; charset=utf-8',$e->getCode(),['Cache-Control'=>'no-store']);}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('CCK sitemap: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');$response=new \Geniuspace\Response('Sitemap indisponible.','text/plain; charset=utf-8',503,['Cache-Control'=>'no-store']);}
        http_response_code($response->status);foreach($response->headers as$k=>$v)$app->setHeader($k,$v,true);$app->sendHeaders();if($method!=='HEAD')echo $response->body;$app->close();
    }
    public function discovery() { $this->nexusRead(false); }
    public function openapi() { $this->nexusRead(true); }
    private function nexusRead(bool $schema): void
    {
        $app=\Joomla\CMS\Factory::getApplication();$method=strtoupper($_SERVER['REQUEST_METHOD']??'GET');
        try {
            if(!in_array($method,['GET','HEAD'],true))throw new \DomainException('Méthode interdite.',405);
            $body=$schema?\Geniuspace\NexusDiscovery::openapi():\Geniuspace\NexusDiscovery::catalogue($app->input->getInt('section_id',0),$app->input->getInt('after',0),$app->input->getInt('limit',20));$status=200;
        }catch(\DomainException $e){$body=['error'=>$e->getMessage()];$status=$e->getCode();}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Nexus discovery: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');$body=['error'=>'Catalogue indisponible.'];$status=503;}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','no-store',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->sendHeaders();if($method!=='HEAD')echo \Geniuspace\Seo::json($body);$app->close();
    }
    /** Public machine-readable graph: metadata only, never raw record fields or quiz results. */
    public function semantic()
    {
        $app=\Joomla\CMS\Factory::getApplication();$method=strtoupper($_SERVER['REQUEST_METHOD']??'GET');
        try{
            if(!in_array($method,['GET','HEAD'],true))throw new \DomainException('Méthode interdite.',405);
            $result=\Geniuspace\NativeSemantic::project($app->input->getInt('id'));if(!$result['graph'])throw new \DomainException('Métadonnées publiques indisponibles.',404);
            $body=\Geniuspace\Seo::json($result['graph']);$status=200;
        }catch(\DomainException $e){$body=\Geniuspace\Seo::json(['error'=>$e->getMessage()]);$status=$e->getCode();}
        catch(\Throwable $e){$body=\Geniuspace\Seo::json(['error'=>'Métadonnées indisponibles.']);$status=503;}
        http_response_code($status);$app->setHeader('Content-Type','application/ld+json; charset=utf-8',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->setHeader('Cache-Control','no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->sendHeaders();if($method!=='HEAD')echo $body;$app->close();
    }
    public function extendedPay()
    {
        $app=\Joomla\CMS\Factory::getApplication();$app->setHeader('Cache-Control','no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);
        try{if(strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='POST')throw new \DomainException('Méthode interdite.',405);
            $signature=(string)($_SERVER['HTTP_STRIPE_SIGNATURE']??'');
            if($signature!==''){$body=(string)file_get_contents('php://input',false,null,0,1048577);\Geniuspace\ExtendedCommerce::event($body,$signature);$status=200;$out=['received'=>true];}
            else{$url=\Geniuspace\ExtendedCommerce::checkout($app->input->post->getInt('record_id'),$app->input->post->getInt('field_id'),$app->input->post->getString('nonce'));$app->redirect($url,303);return;}
        }catch(\DomainException $e){$status=in_array($e->getCode(),[400,403,404,405,409,422,503],true)?$e->getCode():400;$out=['error'=>$e->getMessage()];}
        catch(\Throwable $e){$status=503;$out=['error'=>'Paiement temporairement indisponible.'];}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->sendHeaders();echo json_encode($out);$app->close();
    }
    public function assist()
    {
        $app=\Joomla\CMS\Factory::getApplication();
        try{
            if(strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='POST')throw new \DomainException('Méthode interdite.',405);
            $csrf=\Joomla\CMS\Session\Session::getFormToken();$header=(string)($_SERVER['HTTP_X_GENIUSPACE_CSRF']??'');$uri=\Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());$authority=$uri->getScheme().'://'.$uri->getHost().($uri->getPort()?':'.$uri->getPort():'');$origin=(string)($_SERVER['HTTP_ORIGIN']??'');
            if(!$app->getIdentity()->id||!hash_equals($csrf,$header)||($origin!==''&&!hash_equals($authority,$origin)))throw new \DomainException('Accès ou jeton invalide.',403);
            $raw=(string)file_get_contents('php://input',false,null,0,1048577);if(strlen($raw)>1048576)throw new \DomainException('Requête trop volumineuse.',413);$data=json_decode($raw,true,20,JSON_THROW_ON_ERROR);if(!is_array($data))throw new \InvalidArgumentException('Objet JSON requis.');
            $body=\Geniuspace\AuthorAssist::handle($data);$status=200;
        }catch(\DomainException $e){$body=['error'=>$e->getMessage()];$status=in_array($e->getCode(),[403,404,405,409,413,422,503],true)?$e->getCode():400;}
        catch(\InvalidArgumentException|\JsonException $e){$body=['error'=>$e->getMessage()];$status=400;}
        catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Local author: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::ERROR,'joomcck');$body=['error'=>'Le catalogue local est temporairement indisponible. Les contrôles dans l’éditeur restent disponibles. Consultez le journal JoomCCK.'];$status=503;}
        http_response_code($status);$app->setHeader('Content-Type','application/json; charset=utf-8',true);$app->setHeader('Cache-Control','private, no-store',true);$app->setHeader('X-Robots-Tag','noindex',true);$app->setHeader('X-Content-Type-Options','nosniff',true);$app->sendHeaders();echo \Geniuspace\Seo::json($body);$app->close();
    }
    public function dispatch()
    {
        $app = \Joomla\CMS\Factory::getApplication();
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        try {
            $path = $app->input->getString('gp_path', '');
            if (strlen($path) > 600 || !preg_match('~^/(?:evaluation|communaute|geniuspace-api/studio|geniuspace-studio|geniuspace-watermark)/[a-zA-Z0-9_./-]+$~D', $path)) throw new \DomainException('Point d’entrée introuvable.', 404);
            $config = \Geniuspace\ComponentRuntime::configuration();
            $db = \Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
            $identity = $app->getIdentity(); $csrf = \Joomla\CMS\Session\Session::getFormToken();
            $expected = \Joomla\CMS\Uri\Uri::getInstance(\Joomla\CMS\Uri\Uri::root());
            $authority = $expected->getScheme() . '://' . $expected->getHost() . ($expected->getPort() ? ':' . $expected->getPort() : '');
            $origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
            $header = (string) ($_SERVER['HTTP_X_GENIUSPACE_CSRF'] ?? '');
            $valid = ($origin === '' || hash_equals($authority, $origin)) &&
                (($header !== '' && hash_equals($csrf, $header)) || \Geniuspace\Tokens::valid());
            $data = $_POST;
            if (str_contains((string) ($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) {
                $body = (string) file_get_contents('php://input', false, null, 0, 131073);
                if (strlen($body) > 131072) throw new \InvalidArgumentException('Requête trop volumineuse.');
                $data = json_decode($body ?: '{}', true, 20, JSON_THROW_ON_ERROR);
                if (!is_array($data)) throw new \InvalidArgumentException('Objet JSON requis.');
            }
            if (preg_match('~^/geniuspace-watermark/([1-9][0-9]{0,9})/([1-9][0-9]{0,9})/([0-9]{1,2})\.png$~D', $path, $m)) {
                $repository = new \Geniuspace\Repository($db, $config, $identity->getAuthorisedViewLevels());
                $response = \Geniuspace\Watermark::response($repository, $config, (int) $m[1], (int) $m[2], (int) $m[3], JPATH_ROOT);
            } else {
                if (!preg_match('~^/(?:evaluation|communaute|geniuspace-api/studio|geniuspace-studio)/([a-z0-9-]+)(?:/|$)~D', $path, $m)) throw new \DomainException('Point d’entrée introuvable.', 404);
                $company = $config->companies[$m[1]] ?? null;
                if (!$company) throw new \DomainException('Section introuvable.', 404);
                $section = $company['section_ids'][0];
                if (str_starts_with($path, '/geniuspace-api/studio/') || str_starts_with($path, '/geniuspace-studio/'))
                    $response = (new \Geniuspace\StudioRouter(\Geniuspace\StudioBridge::service($section), $csrf, $valid))->handle($path, $method, $data, $_GET);
                elseif (str_starts_with($path, '/evaluation/')) {
                    $quiz = \Geniuspace\QuizBridge::service($section);
                    if (str_contains($path, '/sondage/')) $response = (new \Geniuspace\PollRouter(\Geniuspace\StudioBridge::service($section), $csrf, $valid))->handle($path, $method, $data);
                    elseif (str_contains($path, '/parcours/')) $response = (new \Geniuspace\PathRouter(new \Geniuspace\LearningPath($quiz), $csrf, $valid))->handle($path, $method, $data);
                    else $response = (new \Geniuspace\QuizRouter($quiz, $csrf, $valid))->handle($path, $_GET, $method, $data);
                } else {
                    $social = \Geniuspace\Bridge::context($section);
                    if (!$social) throw new \DomainException('Communauté à configurer dans les options JoomCCK.', 404);
                    $response = (new \Geniuspace\SocialRouter($social, $csrf, $valid))->handle($path, $_GET, $method, $data, $_FILES);
                }
            }
        } catch (\DomainException $e) {
            $response = new \Geniuspace\Response($e->getMessage(), 'text/plain; charset=utf-8', in_array($e->getCode(), [403,404,409,503], true) ? $e->getCode() : 400);
        } catch (\InvalidArgumentException|\JsonException $e) {
            $response = new \Geniuspace\Response('Configuration ou requête invalide.', 'text/plain; charset=utf-8', 400);
        } catch (\Throwable $e) {
            \Joomla\CMS\Log\Log::add('JoomCCK fields: ' . get_class($e) . ': ' . $e->getMessage(), \Joomla\CMS\Log\Log::ERROR, 'joomcck');
            $response = new \Geniuspace\Response('Service de champ temporairement indisponible.', 'text/plain; charset=utf-8', 503);
        }
        if ($response->status >= 300 && $response->status < 400 && isset($response->headers['Location'])) {
            $location = html_entity_decode(\Geniuspace\ComponentRuntime::rewrite($response->headers['Location']), ENT_QUOTES, 'UTF-8');
            $app->redirect($location, $response->status);
            return;
        }
        http_response_code($response->status);
        foreach ($response->headers as $key => $value) $app->setHeader($key, $key === 'Location' ? html_entity_decode(\Geniuspace\ComponentRuntime::rewrite($value), ENT_QUOTES, 'UTF-8') : $value, true);
        if (str_starts_with($response->headers['Content-Type'] ?? '', 'text/html')) {
            // Field forms stay inside the current Joomla template, using component assets only.
            $html = \Geniuspace\ComponentRuntime::rewrite($response->body);
            $app->getDocument()->addStyleSheet(\Joomla\CMS\Uri\Uri::root(true) . '/components/com_joomcck/library/php/geniuspace/media/fields.css');
            $app->getDocument()->addStyleSheet(\Joomla\CMS\Uri\Uri::root(true) . '/components/com_joomcck/library/php/geniuspace/media/quiz.css');
            echo $method === 'HEAD' ? '' : $html;
            return;
        }
        $app->sendHeaders();
        if ($method !== 'HEAD') echo $response->body;
        $app->close();
    }
}
