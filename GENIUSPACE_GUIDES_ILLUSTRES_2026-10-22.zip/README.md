# Geniuspace — collection éditoriale illustrée, 22 octobre 2026

Ouvrir **index.html** après extraction pour parcourir les douze guides avec leurs nouvelles couvertures. Les liens entre dossiers, les sommaires et les carnets CSV fonctionnent sans connexion au site.

## Contenu réellement terminé

- 12 articles méthodologiques originaux, un par univers : **10 975 mots**, de 848 à 1 178 mots par article.
- 12 couvertures originales créées avec une assistance IA, avec 48 variantes WebP (480, 800, 1 200 et 1 600 px) et 12 JPEG pour le partage.
- 12 carnets CSV à remplir localement, sans collecte de réponses.
- 24 liens proposés vers des dossiers effectivement rédigés ; aucun lien vers les articles encore à écrire.
- Auteur demandé : **GUILLAUME DEPLANQUE — GENIUSPACE**.

Les images sont des illustrations, pas des photographies de tests, de voyages ou d’équipes réelles. Chaque article le précise. Les exemples chiffrés sont explicitement hypothétiques. Les sources techniques consultées sont indiquées avec le périmètre des passages utilisés ; les autres grilles sont des propositions éditoriales, pas des études de terrain.

## Intégration au site

Le ZIP installable NEXUS **5.27.2** contient les textes, images et carnets. Dans le compte administrateur : **JoomCCK → Outils → Forum Geniuspace → « Publier les 12 nouveaux dossiers illustrés »**.

Accès direct après connexion : `/index.php?option=com_joomcck&view=tools&layout=nexusforum`.

Cette action crée douze publications natives dans les bons univers et leurs relations parent/enfant. Leurs titres, corps, auteur, résumés et couvertures restent modifiables dans les champs natifs. L’import conserve les anciens articles, vidéos, commentaires et réglages. Une seconde exécution conserve les modifications faites après import. Installer le ZIP seul ne publie aucun article.

Le rendu natif utilise des URL canoniques SEF, un H1, des métadonnées spécifiques, des données structurées Article et ImageObject et des liens internes résolus après création des cibles. Les couvertures utilisent réellement `srcset` et `sizes`, les JPEG sont utilisés pour Open Graph, et les dimensions sont déclarées. Les aperçus hors ligne portent `noindex` et n’inventent pas d’URL canonique ou de date de publication.

## État du projet éditorial global

Le catalogue conserve l’objectif de **240 articles et 180 topics**. Les 180 ouvertures éditoriales préparées restent dans `topics-180.json` ; elles ne sont pas présentées comme des échanges de membres. **228 articles restent à rédiger.** Aucun compte fictif n’a été créé.

Aucune publication n’a été effectuée sur geniuspace.io : l’accès configuré a été refusé lors de la tentative de connexion native. Les douze imports ont été testés sur la copie isolée, puis les données de test retirées. Il n’y a aucune garantie de classement ou d’indexation par un moteur : le package prépare des contenus et des signaux techniques vérifiables.

## Contrôles

`QUALITY-VALIDATION.json` consigne 257 contrôles structurels des textes, images, carnets et liens locaux. Les tests de rendu JoomCCK, d’installation, de contrôle d’accès et de reprise après erreur sont fournis dans le rapport de livraison 5.27.2. Ces contrôles ne remplacent pas une expertise professionnelle personnalisée ni une vérification documentaire de chaque sujet spécialisé.
