# Cinq couvertures originales Geniuspace

Une illustration par thème : IA locale, offre d’emploi, vérification vidéo, playtest et achat groupé. Ouvrez `index.html` pour les consulter.

Les 20 WebP existent en 480, 800, 1 200 et 1 600 pixels. Les cinq JPEG sociaux mesurent 1 200 × 675 pixels. Les textes alternatifs et empreintes figurent dans `COVERS-MANIFEST.json`.

Les scènes sont des illustrations créées avec une assistance IA, sans reportage, témoignage ou test réel représenté.

Pour leur intégration automatique aux cinq articles existants, installez le paquet complet NEXUS 5.27.4. Il reconnaît les anciennes couvertures du premier lot et utilise les nouvelles images dans les cartes, le slider, les articles, le partage social et les schémas. Aucun article n’a besoin d’être réimporté. Les couvertures personnalisées restent prioritaires et les anciens fichiers pédagogiques restent présents.

Le correctif est testé dans la copie isolée ; il n’est pas annoncé comme déjà déployé sur geniuspace.io.
