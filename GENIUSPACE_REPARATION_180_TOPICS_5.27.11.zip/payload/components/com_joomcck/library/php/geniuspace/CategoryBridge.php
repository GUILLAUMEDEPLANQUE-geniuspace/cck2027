<?php
declare(strict_types=1);
namespace Geniuspace;

/** Preserve old native categories while reconnecting their public records to the primary universe. */
final class CategoryBridge
{
    public static function primary(array $source): ?array
    {
        $p=ForumCategories::params($source);$id=(int)$p->get('nexus_primary_category',0);if(!$id||(int)$source['parent_id']>1||$p->get('universe_v21'))return null;
        $target=ProductAccess::store()->rows('SELECT * FROM #__js_res_categories WHERE id='.$id.' AND section_id='.(int)$source['section_id'],1)[0]??null;if(!$target||(int)$target['parent_id']>1||!ForumCategories::public($source)||!ForumCategories::public($target))return null;
        $t=ForumCategories::params($target);$key=(string)$t->get('universe_key','');$catalogue=UniverseBlueprint::catalogue();if(!$t->get('universe_v21')||!isset($catalogue[$key])||!in_array($source['alias'],$catalogue[$key]['legacy_aliases'],true))return null;
        if(DesignLayouts::published('universe',(int)$source['section_id'],(int)$source['id']))return null;return $target;
    }
    public static function redirect(): ?string
    {
        $app=\Joomla\CMS\Factory::getApplication();$i=$app->getInput();if(!$app->isClient('site')||!in_array(strtoupper($_SERVER['REQUEST_METHOD']??''),['GET','HEAD'],true)||$i->getCmd('option')!=='com_joomcck'||$i->getCmd('view')!=='records'||$i->getCmd('task')||$i->getCmd('format','html')!=='html'||!$i->getInt('cat_id'))return null;
        $c=ProductAccess::store()->rows('SELECT * FROM #__js_res_categories WHERE id='.$i->getInt('cat_id'),1)[0]??null;if(!$c||!ForumCategories::params($c)->get('nexus_primary_category'))return null;
        if(!$app->getDocument())$app->loadDocument();if(!JmapBridge::boot())return null;$target=self::primary($c);if(!$target)return null;
        $uri=new \Joomla\CMS\Uri\Uri(PublicDiscovery::absolute(ForumRoutes::categoryUrl((int)$c['section_id'],(int)$target['id'])));
        $q=\Joomla\CMS\Uri\Uri::getInstance()->getQuery(true);foreach(['option','view','section_id','cat_id','Itemid']as$key)unset($q[$key]);if(isset($q['nx_blog_category'])&&(int)$q['nx_blog_category']===(int)$c['id'])$q['nx_blog_category']=(int)$target['id'];$uri->setQuery($q);return $uri->toString();
    }
    public static function repair(int $hub,callable $backup): array
    {
        $ctx=UniverseBlueprint::context($hub);$primary=[];foreach($ctx['roots']as$r)if($r->params->get('universe_v21')){$key=UniverseBlueprint::rootKey($r,$ctx['flat']);if($key&&!isset($primary[$key]))$primary[$key]=$r;}
        $db=ProductAccess::store()->db;$gate=new NativeAccess();$out=['aliases'=>[],'records_reconnected'=>0,'restricted_preserved'=>0,'custom_pages_preserved'=>0];
        foreach($ctx['roots']as$old){$key=UniverseBlueprint::rootKey($old,$ctx['flat']);if(!$key||!isset($primary[$key])||(int)$old->id===(int)$primary[$key]->id||$old->params->get('universe_v21'))continue;$target=$primary[$key];
            if(!in_array($old->alias,UniverseBlueprint::catalogue()[$key]['legacy_aliases'],true))continue;
            $ids=[(int)$old->id];foreach(\NexusForumSeven::flat($old->children)as$c)$ids[]=(int)$c->id;$records=$db->setQuery('SELECT DISTINCT record_id FROM #__js_res_record_category WHERE catid IN ('.implode(',',$ids).')')->loadColumn();
            foreach($records as$id){$id=(int)$id;$p=PublicMaterial::projection($id,false,$gate);if(!$p){$out['restricted_preserved']++;continue;}$r=$p['raw'];if((int)$r['section_id']!==$hub)continue;$cats=json_decode($r['categories'],true)?:[];$has=(bool)$db->setQuery('SELECT id FROM #__js_res_record_category WHERE record_id='.$id.' AND catid='.(int)$target->id)->loadResult();if(isset($cats[(int)$target->id])&&$has)continue;
                $backup('CATEGORIES-'.$id.'.json',['id'=>$id,'categories'=>$r['categories'],'mtime'=>$r['mtime']]);$cats[(int)$target->id]=(string)$target->id;$change=(object)['id'=>$id,'categories'=>Seo::json($cats),'mtime'=>gmdate('Y-m-d H:i:s')];$db->updateObject('#__js_res_record',$change,'id');
                if(!$has){$link=(object)['record_id'=>$id,'catid'=>(int)$target->id,'section_id'=>$hub,'published'=>(int)$r['published'],'access'=>(int)$r['access']];$db->insertObject('#__js_res_record_category',$link);}LinkIndex::record(new Store($db),$id);$out['records_reconnected']++;
            }
            if(DesignLayouts::published('universe',$hub,(int)$old->id)){$out['custom_pages_preserved']++;continue;}
            $raw=$db->setQuery('SELECT * FROM #__js_res_categories WHERE id='.(int)$old->id.' FOR UPDATE')->loadAssoc();$params=json_decode($raw['params'],true)?:[];
            if((int)($params['nexus_primary_category']??0)!==(int)$target->id){$backup('CATEGORY-'.(int)$old->id.'.json',$raw);$params['nexus_primary_category']=(int)$target->id;$change=(object)['id'=>(int)$old->id,'params'=>Seo::json($params)];$db->updateObject('#__js_res_categories',$change,'id');}$out['aliases'][]=['from'=>(int)$old->id,'to'=>(int)$target->id,'universe'=>$key];
        }return $out;
    }
}
