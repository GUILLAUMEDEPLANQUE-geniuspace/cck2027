from pathlib import Path
import json,math,textwrap
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).parent
STEPS={
'jeux_video':['Jeux et scènes','Écran et contraintes','Budget complet','Tests comparables'],
'emploi':['Missions concrètes','Conditions explicites','Preuves adaptées','Question et candidature'],
'pays_expat':['Jours disponibles','Trajets et contraintes','Priorités et options','Budget et réservations'],
'artisanat':['Usage du vêtement','Mesures et matière','État et provenance','Coût total et retour'],
'business':['Problème client','Offre et périmètre','Coûts et capacité','Test et révision'],
'investissement':['Horizon et usage','Risque et liquidité','Frais et contreparties','Décision révisable'],
 'traditions':['Document et édition','Attribution annoncée','Interprétation située','Allégations distinctes'],
'paranormal':['Fichier et provenance','Copie de travail','Observations séparées','Hypothèses testables'],
'manga':['Œuvre et version','Niveau de lecture','Exemples autorisés','Zone de spoilers'],
'gastronomie':['Aliments et gestes','Contraintes réelles','Entretien possible','Enveloppe complète'],
'sports':['Objectif personnel','Conditions pratiques','Échange avec encadrant','Suivi et révision'],
 'tech':['Sources autorisées','Extraction vérifiée','Recherche et classement','Réponse et évaluation']}
regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
f=lambda size,b=False:ImageFont.truetype(bold if b else regular,size)
items=json.loads((ROOT/'articles-premier-lot-12.json').read_text())
for r in items:
 im=Image.new('RGB',(1200,675),'#f8fafc');d=ImageDraw.Draw(im);d.rectangle((0,0,1200,15),fill='#ef233c');d.text((55,48),'GENIUSPACE · '+r['universe_label'].upper(),font=f(20,True),fill='#4f46e5')
 y=100
 for line in textwrap.wrap(r['title'],width=48):d.text((55,y),line,font=f(34,True),fill='#0f172a');y+=46
 steps=STEPS[r['universe']];box_y=325;box_w=250;gap=26
 for i,label in enumerate(steps):
  x=48+i*(box_w+gap);d.rounded_rectangle((x,box_y,x+box_w,box_y+170),radius=20,fill=['#eef2ff','#ecfdf5','#fff7ed','#fdf2f8'][i],outline='#cbd5e1',width=2);d.ellipse((x+18,box_y+18,x+55,box_y+55),fill='#4f46e5');d.text((x+31,box_y+24),str(i+1),anchor='mt',font=f(19,True),fill='white')
  yy=box_y+78
  for line in textwrap.wrap(label,width=18):d.text((x+18,yy),line,font=f(21,True),fill='#0f172a');yy+=31
  if i<3:d.line((x+box_w+4,box_y+86,x+box_w+gap-4,box_y+86),fill='#64748b',width=3)
 d.text((55,553),'Une méthode de décision, pas une promesse de résultat.',font=f(23),fill='#475569');d.text((55,609),'GUILLAUME DEPLANQUE — GENIUSPACE · Schéma original',font=f(18),fill='#64748b')
 path=ROOT/r['illustration']['path'];im.save(path,'WEBP',quality=88,method=6)
 preview=ROOT/'content'/(r['key']+'.html');preview.write_text('<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+r['title']+' | Geniuspace</title><style>body{max-width:850px;margin:32px auto;padding:16px;font:18px/1.65 system-ui;color:#17243c}img{width:100%;height:auto}table{border-collapse:collapse;width:100%;font-size:16px}td,th{border:1px solid #cbd5e1;padding:10px;text-align:left}.table-responsive{overflow:auto}h1{line-height:1.2}h2{margin-top:2em}</style><h1>'+r['title']+'</h1><p>GUILLAUME DEPLANQUE — GENIUSPACE · Brouillon éditorial</p><figure><img src="../'+r['illustration']['path']+'" alt="'+r['illustration']['alt']+'" width="1200" height="675"><figcaption>Schéma original de la méthode présentée.</figcaption></figure>'+r['body_html']+'</html>')
print('Original responsive WebP diagrams:',len(items),'total bytes:',sum((ROOT/r['illustration']['path']).stat().st_size for r in items))
