<?php
declare(strict_types=1);
namespace Geniuspace;

/** V21 Omni-Dock adds shortcuts and drawers without removing any existing destination. */
final class UniverseDock
{
    public static function wrap(string $legacy,int $hub,object $params): string
    {
        UniverseBlueprint::assets();$category=UniverseBlueprint::selected($hub);$context=UniverseBlueprint::context($hub,$category);$key=$context['key']??'';$canManage=UniverseAnnouncements::canManage($hub);$e=[Text::class,'escape'];
        $forum=UniverseWidgets::destination('discussion',$hub,$params,'Nouveau Sujet');$blog=UniverseWidgets::destination('article',$hub,$params,'Créer un Guide');$score=ProductAccess::user()->id?MultiverseMechanisms::score((int)ProductAccess::user()->id):['percent'=>null];
        $out='<div id="floating-omni-toolbar-wrapper" data-universe-dock-wrapper><nav id="floating-omni-toolbar" class="nx-omni-dock standard-toolbar-glow" aria-label="Omni-Dock" data-universe-manager="'.($canManage?'1':'0').'" data-universe-key="'.$e($key).'">';
        $out.='<button type="button" data-universe-role aria-label="Mode membre ou gestionnaire" aria-pressed="false"'.(!$canManage?' disabled':'').'>'.UniverseBlueprint::icon($canManage?'fa-crown':'fa-user').'<span data-universe-role-label>'.($canManage?'Vue membre':'Membre').'</span></button>';
        if($canManage)$out.='<button type="button" data-dock-open="announcement" data-universe-announce hidden>📢 <span>Annonce</span></button>';
        $out.=DesignInline::toolbar($hub);if(ProductAccess::user()->id)$out.='<button type="button" data-project-open>✦ <span>Missions</span></button><button type="button" data-work-queue-open>💼 <span>Travail pro</span></button>';
        $out.=str_replace('class="nx-tool-action"','class="nx-omni-blog"',$blog).str_replace('class="nx-tool-action"','class="nx-omni-forum"',$forum);
        $out.='<button type="button" data-dock-open="widgets" aria-label="Outils et calculateurs de cet univers">🧰 <span>Outils</span> <small>'.($key?'4':'Univers').'</small></button>'.UniverseExperience::creatorButton().'<button type="button" data-universe-minimize aria-controls="floating-omni-toolbar-wrapper" aria-label="Réduire les outils">➖ <span>Réduire</span></button></nav></div>';
        $out.='<div id="floating-toolbar-minimized" hidden><button type="button" data-universe-restore>⚡ Ouvrir les Outils'.($canManage?' · 👑':'').'</button></div>';
        $dialog=static fn($id,$title,$body)=>'<dialog id="nx-dock-'.$id.'" class="nx-dock-dialog nx-universe-drawer" data-dock-dialog="'.$id.'" aria-label="'.$e($title).'"><header><h2>'.$e($title).'</h2><button type="button" data-dock-close aria-label="Fermer">×</button></header>'.$body.'</dialog>';
        // Keep all six original navigation commands and their dialogs.
        $navEnd=strpos($legacy,'</nav>');$oldNav=substr($legacy,0,$navEnd+6);$oldDialogs=substr($legacy,$navEnd+6);$oldNav=str_replace('class="nx-app-dock"','class="nx-app-dock nx-omni-legacy"',$oldNav);
        $out.=$dialog('legacy','Tous mes accès',$oldNav).$oldDialogs;
        $widgets=$key?UniverseWidgets::cards($key,$hub,$params,'pip'):'<p>Choisissez un univers pour ouvrir ses quatre outils.</p>';
        $out.=$dialog('assistant','Assistant local · Sources',UniverseWidgets::body('memory',$hub,$params).(ProductAccess::user()->id?'<button type="button" data-ai-progress-open>✧ Sources et progrès mesurés de l’IA</button>':''));
        $out.=$dialog('widgets','Widgets PiP · '.($context['universe']['shortName']??'Univers'),'<div id="pip-widgets-body">'.$widgets.'</div>');
        if($canManage){$api=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.product';
            $body='<form data-universe-announcement-form data-endpoint="'.$e($api).'" data-section="'.$hub.'" data-category="'.$category.'"><p>Épinglez un sujet natif publié de la rubrique. Le texte, ses médias et sa discussion restent dans leur fiche.</p><label>Sujet de cette rubrique<input type="search" data-universe-record-find placeholder="Rechercher le titre d’un sujet publié…" autocomplete="off"></label><input type="hidden" name="record" required><div data-universe-record-choices></div><p data-universe-record-selection></p><label>Portée<select name="scope"><option value="category">Rubrique active</option><option value="universe">Univers actif</option></select></label><label>Durée en heures<input name="hours" type="number" min="1" max="720" value="24" required></label>'.\Joomla\CMS\HTML\HTMLHelper::_('form.token').'<button>Épingler l’annonce</button><button type="button" data-universe-unpin>Retirer l’annonce</button><p role="status"></p></form>';
            $out.=$dialog('announcement','Lancer une annonce flash',$body);
        }
        return $out.ProjectWorkspace::render().UniverseExperience::creatorPortal($hub,$params).PublicationExperience::modal($hub,$params);
    }
}
