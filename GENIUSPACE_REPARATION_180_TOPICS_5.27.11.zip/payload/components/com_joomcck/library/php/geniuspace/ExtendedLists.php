<?php
declare(strict_types=1);
namespace Geniuspace;

/** Three selectable JoomCCK record-list templates; the native page chrome stays intact. */
final class ExtendedLists
{
    private static function date(object $item,int $field,object $section): string
    {
        if(!isset($item->fields_by_id[$field])||!self::visible($item->fields_by_id[$field],$item,$section))return '';
        $v=$item->fields_by_id[$field]->value??null;if(is_array($v))$v=reset($v);if(!is_scalar($v)||trim((string)$v)==='')return '';
        try{$date=new \DateTimeImmutable((string)$v,new \DateTimeZone('UTC'));return $date->format('Y-m-d');}catch(\Throwable $e){return '';}
    }
    private static function card(object $view,object $item,string $mode,int $source): string
    {
        $p=$view->tmpl_params['list'];$html='<article class="gp-list-card" id="gp-list-record-'.(int)$item->id.'" data-gp-card'.($mode==='calendar'?' data-gp-date="'.self::date($item,$source,$view->section).'"':'').'>';
        $html.=\Joomcck\Layout\Helpers\Layout::render('core.list.recordParts.buttonsManage',['item'=>$item,'disabled'=>[],'section'=>$view->section,'submissionTypes'=>$view->submission_types,'params'=>$p]);
        $html.='<div class="gp-card-body">';
        if($mode==='gallery_mod'){
            $field=$item->fields_by_id[$source]??null;$pictures=[];
            if($field&&self::visible($field,$item,$view->section)&&in_array($field->type,['image','gallery'],true)){
                if($field->type==='image'){$v=$field->value;$file=is_string($v)?$v:(string)($v['image']??$v['hiddenimage']??'');if($url=ExtendedUi::imageUrl($file))$pictures[]=$url;}
                else{$base=trim((string)\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck')->get('general_upload'),'\/').'/'.trim((string)$field->params->get('params.subfolder','gallery'),'\/').'/';foreach(array_slice((array)$field->value,0,max(1,min(20,(int)$p->get('tmpl_params.pictures',3))))as$file)if(is_array($file)&&isset($file['fullpath'])&&($url=ExtendedUi::imageUrl($base.$file['fullpath'])))$pictures[]=$url;}
            }
            if($pictures){foreach($pictures as&$picture)$picture=self::thumbnail($picture,$item,$p);unset($picture);$html.='<div class="gp-gallery-pictures">';foreach($pictures as$i=>$url)$html.='<a href="'.ExtendedFields::e(\Joomla\CMS\Router\Route::_($item->url,false)).'" class="gp-gallery-photo"><img src="'.ExtendedFields::e($url).'" alt="'.ExtendedFields::e($item->title).'" loading="lazy" decoding="async" width="'.max(100,min(1200,(int)$p->get('tmpl_params.width',600))).'" height="'.max(100,min(1200,(int)$p->get('tmpl_params.height',400))).'"></a>';$html.='</div>';if($p->get('tmpl_params.captions',0))$html.='<p class="gp-gallery-caption">'.ExtendedFields::e($item->title).'</p>';}
        }
        if($p->get('tmpl_core.item_title',1)){$tag=in_array($p->get('tmpl_core.title_tag','h2'),['h2','h3','h4'],true)?$p->get('tmpl_core.title_tag','h2'):'h2';$html.='<'.$tag.'>';if($p->get('tmpl_core.item_link',1))$html.='<a href="'.ExtendedFields::e(\Joomla\CMS\Router\Route::_($item->url,false)).'"'.(!empty($item->nofollow)?' rel="nofollow"':'').'>'.ExtendedFields::e($item->title).'</a>';else $html.=ExtendedFields::e($item->title);$html.='</'.$tag.'>';}
        if(!$item->published)$html.='<span class="badge bg-warning text-dark">'.\Joomla\CMS\Language\Text::_('JUNPUBLISHED').'</span>';
        if($mode==='calendar'&&($date=self::date($item,$source,$view->section)))$html.='<time class="gp-event-date" datetime="'.$date.'">'.ExtendedFields::e($date).'</time>';
        $html.='<div class="gp-card-meta">';
        if($p->get('tmpl_core.item_author',1)){$html.='<span>';if($p->get('tmpl_core.item_author_avatar',1))$html.='<img class="gp-author-avatar" width="'.max(16,min(200,(int)$p->get('tmpl_core.item_author_avatar_width',32))).'" height="'.max(16,min(200,(int)$p->get('tmpl_core.item_author_avatar_height',32))).'" alt="" loading="lazy" src="'.ExtendedFields::e(\CCommunityHelper::getAvatar($item->user_id,32,32)).'">';$html.=\CCommunityHelper::getName($item->user_id,$view->section);if($p->get('tmpl_core.item_author_filter'))$html.=self::filter('filter_user',$item->user_id,$view);$html.='</span>';}
        if($p->get('tmpl_core.item_type',0))$html.='<span>'.ExtendedFields::e($item->type_name).($p->get('tmpl_core.item_type_filter')?self::filter('filter_type',$item->type_id,$view):'').'</span>';
        if($p->get('tmpl_core.item_categories',1))$html.='<span>'.implode(', ',(array)$item->categories_links).'</span>';
        if($p->get('tmpl_core.item_user_categories')&&!empty($item->ucatname_link))$html.='<span>'.$item->ucatname_link.'</span>';
        foreach(['ctime'=>'Créé','mtime'=>'Modifié','extime'=>'Expire']as$key=>$label)if($p->get('tmpl_core.item_'.$key)&&!empty($item->$key)){$v=$item->$key instanceof \DateTimeInterface?$item->$key->format('Y-m-d'):(string)$item->$key;$html.='<span>'.ExtendedFields::e($label).' · '.ExtendedFields::e($v).'</span>';}
        $html.='</div>';
        $exclude=ExtendedFields::ids($p->get('tmpl_params.field_id_exclude',[]));
        foreach((array)($item->fields_by_id??[])as$id=>$f){if((int)$id===$source||in_array((int)$id,$exclude,true)||empty($f->result)||!self::visible($f,$item,$view->section))continue;$html.='<div class="gp-card-field">';if($p->get('tmpl_params.show_field_labels',0))$html.='<strong>'.ExtendedFields::e($f->label).'</strong>'; $html.=$f->result.'</div>';}
        $html.='<div class="gp-card-stats">';foreach(['rating'=>'rating','hits'=>'hits','comments_num'=>'comments','favorite_num'=>'favorite_num','follow_num'=>'subscriptions_num','vote_num'=>'votes']as$option=>$key)if($p->get('tmpl_core.item_'.$option)&&isset($item->$key))$html.='<span>'.($key==='rating'?(string)$item->$key:ExtendedFields::e($item->$key)).' '.ExtendedFields::e(['rating'=>'','hits'=>'vues','comments'=>'commentaires','favorite_num'=>'favoris','subscriptions_num'=>'abonnés','votes'=>'votes'][$key]).'</span>';$html.='</div>';
        if($p->get('tmpl_core.item_readon'))$html.='<a class="gp-read-more" href="'.ExtendedFields::e(\Joomla\CMS\Router\Route::_($item->url,false)).'">'.ExtendedFields::e($p->get('tmpl_core.item_readon_label','En savoir plus')).' →</a>';
        return $html.'</div></article>';
    }
    private static function filter(string $name,int $value,object $view): string
    {return \Joomcck\Layout\Helpers\Layout::render('core.list.recordParts.recordFilter',['name'=>$name,'value'=>$value,'type'=>null,'tip'=>\Joomla\CMS\Language\Text::_('CFILTER'),'section'=>$view->section,'icon'=>$view->tmpl_params['list']->get('tmpl_core.item_'.($name==='filter_user'?'author':'type').'_filter_icon','funnel-small.png')]);}
    private static function visible(object $f,object $record,object $section): bool
    {
        $u=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!in_array((int)($f->access??1),$u->getAuthorisedViewLevels(),true)||!in_array((int)$f->params->get('core.field_view_access',1),$u->getAuthorisedViewLevels(),true)||!$f->params->get('core.show_intro',1))return false;
        return \CEmeraldHelper::allowField('display',$f,$record->user_id,$section,$record)!==false&&\CEmeraldHelper::allowField('view',$f,$u->id,$section,$record)!==false;
    }
    public static function render(object $view,string $mode): string
    {
        ExtendedFields::assets($mode==='map');$p=$view->tmpl_params['list'];$source=(int)$p->get('tmpl_params.'.['calendar'=>'field_id_cal','map'=>'field_id_geo','gallery_mod'=>'field_id_gallery'][$mode],0);$uid='gp-list-'.$mode.'-'.bin2hex(random_bytes(4));$cards='';$points=[];$nodes=[];$events=[];
        foreach((array)$view->items as$item){$cards.=self::card($view,$item,$mode,$source);$date=self::date($item,$source,$view->section);if($mode==='calendar'&&$date)$events[]=['id'=>(int)$item->id,'date'=>$date,'title'=>(string)$item->title,'url'=>\Joomla\CMS\Router\Route::_($item->url,false)];
            if($mode==='map'){$f=$item->fields_by_id[$source]??null;$v=$f&&self::visible($f,$item,$view->section)?($f->value??[]):[];if(is_string($v))$v=json_decode($v,true)?:[];$pos=$v['position']??$v;if(isset($pos['lat'],$pos['lng'])&&is_numeric($pos['lat'])&&is_numeric($pos['lng'])&&abs((float)$pos['lat'])<=90&&abs((float)$pos['lng'])<=180)$points[]=['id'=>(int)$item->id,'lat'=>(float)$pos['lat'],'lng'=>(float)$pos['lng'],'title'=>(string)$item->title,'url'=>\Joomla\CMS\Router\Route::_($item->url,false)];}
            if($r=ExtendedFields::publicRecord((int)$item->id))$nodes[]=['@type'=>'ListItem','position'=>count($nodes)+1,'item'=>['@type'=>'WebPage','@id'=>self::absolute(ExtendedFields::url($r)),'name'=>(string)$r->title]];
        }
        $gap=max(4,min(40,(int)$p->get('tmpl_params.margin',20)));$cols=max(1,min(6,(int)$p->get('tmpl_params.frames',3)));$layout=(string)$p->get('tmpl_params.gallery_layout','grid');if(!in_array($layout,['grid','collage','carousel'],true))$layout='grid';
        $out=\Joomcck\Layout\Helpers\Layout::render('core.list.onThisPage',['params'=>$p,'items'=>$view->items]);
        $out.='<section class="gp-ext gp-ext-list gp-list-'.$mode.' gp-layout-'.$layout.'" id="'.$uid.'" style="--gp-gap:'.$gap.'px;--gp-cols:'.$cols.'" data-gp-list="'.$mode.'" data-gp-gallery-direction="'.ExtendedFields::e(in_array($p->get('tmpl_params.listmode'),['vertical','horizontal','fade'],true)?$p->get('tmpl_params.listmode'):'horizontal').'" data-gp-gallery-move="'.max(1,min(10,(int)$p->get('tmpl_params.move',2))).'">';
        if(!$source)$out.='<p class="alert alert-info">Sélectionnez le champ source dans la configuration de ce template de liste JoomCCK.</p>';
        if($mode==='calendar'){
            $out.='<div class="gp-calendar-toolbar"><div>';if($p->get('tmpl_params.cal_nav',1))$out.='<button type="button" data-gp-cal-nav="prev" aria-label="Période précédente">←</button><button type="button" data-gp-cal-nav="today">Aujourd’hui</button><button type="button" data-gp-cal-nav="next" aria-label="Période suivante">→</button>';$out.='</div><strong data-gp-cal-label aria-live="polite">Calendrier</strong><div>';
            foreach(['year'=>'Année','month'=>'Mois','week'=>'Semaine','day'=>'Jour']as$key=>$label)if($p->get('tmpl_params.cal_view_'.$key,1))$out.='<button type="button" data-gp-cal-view="'.$key.'">'.$label.'</button>';$out.='</div>';if($p->get('tmpl_params.cal_weekday',1))$out.='<label>Premier jour <select data-gp-first-day><option value="1"'.((int)$p->get('tmpl_params.first_day',1)===1?' selected':'').'>Lundi</option><option value="0"'.((int)$p->get('tmpl_params.first_day',1)===0?' selected':'').'>Dimanche</option></select></label>';$out.='<button type="button" data-gp-ics>Exporter .ics</button></div><div class="gp-calendar-grid" hidden data-gp-calendar="'.ExtendedFields::e(json_encode(['events'=>$events,'view'=>$p->get('tmpl_params.view','month'),'start'=>$p->get('tmpl_params.cal_start','now'),'first_day'=>(int)$p->get('tmpl_params.first_day',1),'url'=>self::ajaxUrl($view,$source,'getCalendarEvents')],JSON_THROW_ON_ERROR)).'"></div>';
        }
        if($mode==='map'){$settings=self::mapOptions($p);$out.='<div class="gp-map" data-gp-map="'.ExtendedFields::e(json_encode($points,JSON_THROW_ON_ERROR)).'" data-gp-map-settings="'.ExtendedFields::e(json_encode($settings,JSON_THROW_ON_ERROR)).'" data-gp-map-url="'.ExtendedFields::e(self::ajaxUrl($view,$source,'onGetMarkersList')).'" data-gp-cluster="'.(int)$p->get('tmpl_params.map_claster',1).'" data-gp-heat="'.(int)$p->get('tmpl_params.map_heat',1).'" data-gp-zoom="'.max(1,min(18,(int)$p->get('tmpl_params.map_init_zoom',5))).'"><div class="gp-map-toolbar"><button type="button" data-gp-map-load>Explorer la carte</button>'.($p->get('tmpl_params.map_fitbonds',1)?'<button type="button" data-gp-map-fit hidden>Tout afficher</button>':'').'<button type="button" data-gp-map-heat hidden>Densité</button></div><div class="gp-map-canvas" hidden style="height:'.max(240,min(900,(int)$p->get('tmpl_params.map_height',500))).'px;width:'.ExtendedFields::e(self::dimension($p->get('tmpl_params.map_width','100%'))).'"></div><p class="gp-map-status" aria-live="polite">'.count($points).' positions sur cette page. La liste reste accessible ci-dessous.</p></div>';}
        if($mode==='gallery_mod'&&$layout==='carousel')$out.='<div class="gp-gallery-toolbar"><button type="button" data-gp-slide="prev" aria-label="Images précédentes">←</button><button type="button" data-gp-slide="next" aria-label="Images suivantes">→</button></div>';
        if($mode!=='gallery_mod'&&$p->get('tmpl_core.tmpl_list')==='0')$out.='<noscript><div class="gp-list-cards">'.$cards.'</div></noscript>';else{if($mode==='calendar'&&$p->get('tmpl_core.list_title'))$out.='<h3>'.ExtendedFields::e($p->get('tmpl_core.list_title')).'</h3>';$selected=(string)$p->get('tmpl_core.tmpl_list','');$out.=self::secondary($view,$selected,$mode)??('<div class="gp-list-cards">'.$cards.'</div>');}
        if(!$cards)$out.='<p>Aucune fiche ne correspond aux filtres actuels.</p>';
        if($p->get('tmpl_params.seo_schema',1)&&$nodes)$out.=ExtendedFields::schema(['@context'=>'https://schema.org','@type'=>'ItemList','itemListElement'=>$nodes]);
        return $out.'</section>';
    }
    private static function dimension(mixed $value): string
    {return preg_match('/^(?:100|[1-9][0-9]?)(?:%)$/D',(string)$value)?(string)$value:'100%';}
    private static function thumbnail(string $url,object $record,object $p): string
    {
        $root=\Joomla\CMS\Uri\Uri::root();if(!str_starts_with($url,$root))return $url;$relative=ltrim(substr($url,strlen($root)),'/');if(!is_file(JPATH_ROOT.'/'.$relative))return $url;
        try{return \CImgHelper::getThumb($relative,max(100,min(1200,(int)$p->get('tmpl_params.width',600))),max(100,min(1200,(int)$p->get('tmpl_params.height',400))),'extended-gallery-'.(int)$record->id,(int)$record->user_id,['mode'=>max(1,min(6,(int)$p->get('tmpl_params.mode',1))),'strache'=>(int)$p->get('tmpl_params.stretch',0),'quality'=>max(10,min(100,(int)$p->get('tmpl_params.quality',90)))]);}catch(\Throwable){return $url;}
    }
    private static function secondary(object $view,string $selected,string $current): ?string
    {
        if(!$selected||$selected==='0')return null;$name=explode('.',$selected)[0];if(!preg_match('/^[a-z0-9_]{1,60}$/D',$name)||in_array($name,['calendar','map','gallery_mod'],true))return null;$file=JPATH_ROOT.'/components/com_joomcck/views/records/tmpl/default_list_'.$name.'.php';if(!is_file($file))return null;
        $copy=clone $view;$copy->section=clone $view->section;$copy->section->params=clone $view->section->params;$copy->section->params->set('general.tmpl_list',$selected);$copy->tmpl_params['list']=\CTmpl::prepareTemplate('default_list_','general.tmpl_list',$copy->section->params);
        return (function($file){ob_start();try{include $file;return (string)ob_get_contents();}finally{ob_end_clean();}})->call($copy,$file);
    }
    private static function ajaxUrl(object $view,int $field,string $func): string
    {
        if(!$field)return '';$query=\Joomla\CMS\Factory::getApplication()->getInput()->getArray();$keys=['cat_id','user_id','ucat_id','view_what','_rrid','_rfid','_rmrid','_rmfid','_rdist','Itemid'];$data=['option'=>'com_joomcck','task'=>'ajax.field_call','field_id'=>$field,'func'=>$func,'section_id'=>(int)$view->section->id];foreach($keys as$key)if(isset($query[$key])&&is_scalar($query[$key]))$data[$key]=$query[$key];return \Joomla\CMS\Uri\Uri::root().'?'.http_build_query($data,'','&',PHP_QUERY_RFC3986);
    }
    private static function mapOptions(object $p): array
    {
        $settings=['provider'=>$p->get('tmpl_params.map_provider','local'),'initial'=>(int)$p->get('tmpl_params.map_init',1),'lat'=>max(-90,min(90,(float)$p->get('tmpl_params.map_init_lat',0))),'lng'=>max(-180,min(180,(float)$p->get('tmpl_params.map_init_lng',0))),'clusterSize'=>max(20,min(100,(int)$p->get('tmpl_params.map_claster_size',40)))];
        foreach(['zoom','pan','scale','drag','scroll','rotate','type','overview','street','anim','bike','trans','traff']as$key)$settings[$key]=(bool)$p->get('tmpl_params.map_'.$key,1);
        $view=(string)$p->get('tmpl_params.map_view','ROADMAP');$settings['view']=in_array($view,['ROADMAP','HYBRID','SATELLITE','TERRAIN'],true)?strtolower($view):'roadmap';
        if($settings['provider']==='google'){$settings['key']=(string)\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck')->get('map_key','');$style=(string)$p->get('tmpl_params.map_style','');if(preg_match('/^[a-zA-Z0-9_-]+\.json$/D',$style)){$file=JPATH_ROOT.'/components/com_joomcck/library/js/mapstyles/'.$style;if(is_file($file)&&filesize($file)<262144){$styles=json_decode(file_get_contents($file),true);if(is_array($styles))$settings['styles']=$styles;}}}
        return $settings;
    }
    public static function markerData(object $field,array $post): array
    {
        $section=\ItemsStore::getSection((int)\Joomla\CMS\Factory::getApplication()->getInput()->getInt('section_id'));if(!$section||empty($section->id))return [];
        $model=\MModelBase::getInstance('Records','JoomcckModel');$model->section=$section;$db=ExtendedFields::db();$db->setQuery($model->getListQuery(),0,1000);$rows=$db->loadObjectList();$out=[];
        foreach($rows as$row){$r=ExtendedFields::publicRecord((int)$row->id);if(!$r||!ExtendedFields::publicField($r,(int)$field->id))continue;$levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();if(!in_array((int)$field->params->get('params.map_view',1),$levels,true))continue;
            $value=json_decode($r->fields?:'{}',true)[$field->id]??[];$pos=$value['position']??[];if(!isset($pos['lat'],$pos['lng'])||!is_numeric($pos['lat'])||!is_numeric($pos['lng'])||abs((float)$pos['lat'])>90||abs((float)$pos['lng'])>180)continue;
            $marker=(string)($pos['marker']??$field->params->get('params.map_icon_src.icon',''));$directory=(string)$field->params->get('params.map_icon_src.dir','custom');if(!preg_match('/^[a-zA-Z0-9_-]{1,50}$/D',$directory)||!preg_match('/^[a-zA-Z0-9_.-]{1,100}$/D',$marker))$marker='';
            $out[(int)$r->id]=['id'=>(int)$r->id,'lat'=>(float)$pos['lat'],'lng'=>(float)$pos['lng'],'marker'=>$marker?\Joomla\CMS\Uri\Uri::root().'components/com_joomcck/fields/geo/markers/'.$directory.'/'.$marker:'','title'=>(string)$r->title,'url'=>ExtendedFields::url($r)];
        }return $out;
    }
    public static function calendarEvents(object $field,array $post): array
    {
        $app=\Joomla\CMS\Factory::getApplication();$from=$app->getInput()->getInt('from');$to=$app->getInput()->getInt('to');if($from<=0||$to<=$from||$to-$from>370*86400000)throw new \DomainException('Période du calendrier invalide.',422);
        $section=\ItemsStore::getSection($app->getInput()->getInt('section_id'));if(!$section||empty($section->id))return [];
        $model=\MModelBase::getInstance('Records','JoomcckModel');$model->section=$section;$db=ExtendedFields::db();$query=$model->getListQuery();$db->setQuery($query,0,1000);$events=[];
        foreach($db->loadObjectList()as$row){$r=ExtendedFields::publicRecord((int)$row->id);if(!$r||!ExtendedFields::publicField($r,(int)$field->id))continue;$values=(array)(json_decode($r->fields?:'{}',true)[$field->id]??[]);$range=$field->params->get('params.type','single')==='range';$start=isset($values[0])?strtotime((string)$values[0].' UTC'):false;$end=$range&&isset($values[1])?strtotime((string)$values[1].' UTC'):$start;if(!$start||!$end)continue;
            foreach($range?[[$start,$end]]:array_map(fn($v)=>[$v,$v],array_filter(array_map(fn($v)=>strtotime((string)$v.' UTC'),$values)))as[$begin,$finish])if($begin*1000<$to&&$finish*1000>=$from)$events[]=['id'=>(int)$r->id,'title'=>(string)$r->title,'url'=>ExtendedFields::url($r),'start'=>$begin*1000,'end'=>max($begin,$finish)*1000];
        }return $events;
    }
    public static function absolute(string $url): string
    {return preg_match('~^https?://~i',$url)?$url:rtrim(\Joomla\CMS\Uri\Uri::root(),'/').'/'.ltrim($url,'/');}
}
