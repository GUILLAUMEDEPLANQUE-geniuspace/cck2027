<?php
declare(strict_types=1);
namespace Geniuspace;

/** Consolidate the explicitly owned Geniuspace hostname; other Joomla sites are untouched. */
final class BrandSeo
{
    public static function redirect(string $url,string $method='GET',bool $site=true): ?string
    {
        if(!$site||!in_array(strtoupper($method),['GET','HEAD'],true))return null;
        $p=parse_url($url);$host=strtolower((string)($p['host']??''));
        if(!in_array($host,['geniuspace.io','www.geniuspace.io'],true)||isset($p['user'])||isset($p['pass'])||isset($p['port']))return null;
        if(($p['scheme']??'')==='https'&&$host==='geniuspace.io')return null;
        $target='https://geniuspace.io'.($p['path']??'/').(isset($p['query'])?'?'.$p['query']:'');
        return Text::url($target)?:null;
    }
    public static function render(string $body,string $origin): string
    {
        if(rtrim($origin,'/')!=='https://geniuspace.io'||!str_contains($body,'</head>'))return $body;
        $found=false;$publisherFound=false;
        $body=preg_replace_callback('~(<script\b[^>]*\btype=["\x27]application/ld\+json["\x27][^>]*>)([\s\S]*?)(</script\s*>)~i',static function($m)use(&$found,&$publisherFound){
            $data=json_decode($m[2],true);if(!is_array($data))return $m[0];$changed=false;
            $walk=function(&$node)use(&$walk,&$found,&$publisherFound,&$changed){if(!is_array($node))return;
                if(($node['@id']??'')==='https://geniuspace.io/#geniuspace'&&($node['@type']??'')==='Organization')$publisherFound=true;
                if(($node['@type']??'')==='WebSite'&&in_array(rtrim((string)($node['url']??''),'/'),['https://geniuspace.io','https://www.geniuspace.io','http://geniuspace.io','http://www.geniuspace.io'],true)){
                    $node['name']='Geniuspace';$node['url']='https://geniuspace.io/';$node['@id']='https://geniuspace.io/#website';
                    $node['publisher']=['@id'=>'https://geniuspace.io/#geniuspace'];
                    $names=is_array($node['alternateName']??null)?$node['alternateName']:(isset($node['alternateName'])?[$node['alternateName']]:[]);if(!in_array('Geniuspace.io',$names,true))$names[]='Geniuspace.io';$node['alternateName']=array_values($names);$found=true;$changed=true;
                }
                foreach($node as&$child)if(is_array($child))$walk($child);unset($child);
            };$walk($data);return $changed?$m[1].Seo::json($data).$m[3]:$m[0];
        },$body)??$body;
        if(!$found){$node=['@context'=>'https://schema.org','@type'=>'WebSite','@id'=>'https://geniuspace.io/#website','name'=>'Geniuspace','alternateName'=>['Geniuspace.io'],'url'=>'https://geniuspace.io/','publisher'=>['@id'=>'https://geniuspace.io/#geniuspace']];$body=str_replace('</head>','<script type="application/ld+json" data-nx-brand>'.Seo::json($node).'</script></head>',$body);}
        if(!$publisherFound){$node=['@context'=>'https://schema.org','@type'=>'Organization','@id'=>'https://geniuspace.io/#geniuspace','name'=>'Geniuspace','url'=>'https://geniuspace.io/','description'=>'Geniuspace réunit des communautés, des guides, des discussions et des espaces emploi, formation et entreprise.'];$body=str_replace('</head>','<script type="application/ld+json" data-nx-brand-publisher>'.Seo::json($node).'</script></head>',$body);}
        return $body;
    }
}
