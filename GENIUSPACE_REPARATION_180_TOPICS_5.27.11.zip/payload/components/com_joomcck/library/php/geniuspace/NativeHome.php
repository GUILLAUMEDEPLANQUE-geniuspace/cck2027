<?php
declare(strict_types=1);
namespace Geniuspace;

/** Use Joomla's native empty home menu for the hub; keep authored home pages intact. */
final class NativeHome
{
    public static function url(int $section): string
    {
        $row=ReadMemo::get('geniuspace-native-home',static fn()=>ProductAccess::store()->rows("SELECT link,params,published,access FROM #__menu WHERE client_id=0 AND home=1 AND language='*'",1)[0]??null);
        if(!$row||(int)$row['published']!==1||!in_array((int)$row['access'],(new \Joomla\CMS\User\User())->getAuthorisedViewLevels(),true))return '';
        $p=json_decode($row['params'],true)?:[];$q=[];parse_str(parse_url($row['link'],PHP_URL_QUERY)?:'',$q);
        return !empty($p['nexus_brand_home'])&&($q['option']??'')==='com_joomcck'&&($q['view']??'')==='records'&&(int)($q['section_id']??0)===$section&&empty($q['cat_id'])?\Joomla\CMS\Uri\Uri::root():'';
    }
    public static function install(int $hub,callable $backup): array
    {
        $db=ProductAccess::store()->db;$rows=$db->setQuery("SELECT * FROM #__menu WHERE client_id=0 AND home=1 AND language='*' FOR UPDATE")->loadAssocList();
        if(count($rows)!==1)return ['changed'=>false,'reason'=>'Accueil natif unique non identifié.'];$row=$rows[0];$q=[];parse_str(parse_url($row['link'],PHP_URL_QUERY)?:'',$q);$params=json_decode($row['params'],true)?:[];
        if(!empty($params['nexus_brand_home'])&&($q['option']??'')==='com_joomcck'&&(int)($q['section_id']??0)===$hub)return ['changed'=>false,'already_native'=>true];
        if(($q['option']??'')!=='com_content'||($q['view']??'')!=='featured')return ['changed'=>false,'reason'=>'Accueil personnalisé conservé.'];
        if((int)$db->setQuery('SELECT COUNT(*) FROM #__content WHERE state=1 AND featured=1')->loadResult()>0)return ['changed'=>false,'reason'=>'Articles de l’accueil conservés.'];
        if((int)$row['published']!==1||!in_array((int)$row['access'],(new \Joomla\CMS\User\User())->getAuthorisedViewLevels(),true))return ['changed'=>false,'reason'=>'Accueil non public conservé.'];
        $backup('HOME-MENU.json',$row);$ext=(int)$db->setQuery("SELECT extension_id FROM #__extensions WHERE type='component' AND element='com_joomcck'")->loadResult();if(!$ext)throw new \RuntimeException('Composant natif absent.');
        $params['nexus_brand_home']=true;$params['nexus_brand_home_section']=$hub;$params['nexus_forum7_role']='brand-home';
        $table=\Joomla\CMS\Table\Table::getInstance('Menu');if(!$table->load((int)$row['id']))throw new \RuntimeException('Accueil natif introuvable.');$table->link='index.php?option=com_joomcck&view=records&section_id='.$hub;$table->type='component';$table->component_id=$ext;$table->params=Seo::json($params);
        if(in_array(mb_strtolower(trim($row['title'])),['home','accueil'],true))$table->title='Geniuspace';
        $menu=ForumRoutes::menu($hub,'hub');if($menu){$style=(int)$db->setQuery('SELECT template_style_id FROM #__menu WHERE id='.$menu)->loadResult();if($style>0)$table->template_style_id=$style;}
        if(!$table->check()||!$table->store())throw new \RuntimeException('Accueil natif non enregistré.');
        return ['changed'=>true,'menu_id'=>(int)$row['id'],'url'=>\Joomla\CMS\Uri\Uri::root()];
    }
}
