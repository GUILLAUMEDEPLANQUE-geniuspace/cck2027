<?php
defined('_JEXEC') or die;
require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php';
$app=\Joomla\CMS\Factory::getApplication();$u=$app->getIdentity();if(!$app->isClient('administrator')||!$u->id||$u->block||!$u->authorise('core.admin'))throw new \DomainException('Accès super administrateur requis.',403);
$app->getDocument()->setMetaData('robots','noindex, nofollow');$app->setHeader('Cache-Control','private, no-store',true);$e=[\Geniuspace\Text::class,'escape'];$root=\Joomla\CMS\Uri\Uri::root();$audit=\Geniuspace\InnoDbMaintenance::audit();
?>
<section class="card p-4" data-innodb-maintenance data-endpoint="<?= $e($root.'administrator/index.php') ?>" data-csrf="<?= \Joomla\CMS\Session\Session::getFormToken() ?>" style="max-width:1100px;margin:20px auto">
 <h1>Fiabiliser la base Geniuspace</h1>
 <p>Préparez les tables nécessaires aux publications et au journal de modération. Chaque table sélectionnée est sauvegardée hors du site public, restaurée sur une copie de contrôle puis vérifiée avant sa conversion vers InnoDB.</p>
 <p class="alert alert-info"><strong>Avant de démarrer :</strong> conservez aussi une sauvegarde complète récente de l’hébergement. Mettez le site hors ligne dans <a href="<?= $e($root.'administrator/index.php?option=com_config') ?>">Configuration globale</a> et arrêtez les tâches cron, imports et traitements qui écrivent dans la base. L’administration reste accessible.</p>
 <p class="alert alert-warning">La conversion d’un moteur ne peut pas être annulée avec un simple rollback SQL. En cas d’erreur, le processus s’arrête et le site reste en maintenance. Les sauvegardes sont conservées pour inspection ou restauration.</p>
 <p data-db-offline><?= $audit['offline']?'✓ Le site est actuellement hors ligne.':'Le site est actuellement en ligne : le diagnostic est disponible, la conversion est bloquée.' ?></p>
 <details open><summary><strong>Tables de l’installation</strong></summary><div style="overflow:auto;max-height:360px"><table class="table"><thead><tr><th>Table</th><th>Moteur</th><th>Lignes estimées</th><th>Utilisation</th></tr></thead><tbody data-db-tables><?php foreach($audit['tables']as$t): ?><tr><td><?= $e($t['name']) ?></td><td><?= $e($t['engine']) ?></td><td><?= $t['rows_estimated'] ?></td><td><?= $t['required']?'Requise pour la réparation':($t['moderation']?'Commentaires / journal':'Autre table Geniuspace') ?></td></tr><?php endforeach; ?></tbody></table></div></details>
 <form data-db-form>
  <label for="db-scope">Périmètre</label><select id="db-scope" name="scope" class="form-select"><option value="repair">Publication, commentaires et journal de modération</option><option value="all">Toutes les tables Geniuspace compatibles encore en MyISAM / Aria</option></select>
  <p><label><input type="checkbox" name="writers_stopped" value="1" required> J’ai arrêté les tâches qui écrivent dans la base et conservé une sauvegarde complète de l’hébergement.</label></p>
  <button type="button" class="btn btn-secondary" data-db-audit>Actualiser le diagnostic</button>
  <button type="submit" class="btn btn-primary">Sauvegarder, vérifier et convertir</button>
  <button type="button" class="btn btn-secondary" data-db-resume hidden>Reprendre les étapes</button>
  <button type="button" class="btn btn-outline-secondary" data-db-archive hidden>Archiver ce journal et refaire le diagnostic</button>
 </form>
 <p role="status" aria-live="polite" data-db-status></p><progress data-db-progress max="1" value="0" style="width:100%"></progress>
 <ol data-db-receipts></ol><details><summary>Télécharger mes sauvegardes SQL privées</summary><ul data-db-backups></ul><p>Ces fichiers contiennent des données du site. Conservez-les dans un endroit privé. Ils ne sont accessibles qu’à un super administrateur.</p></details>
 <p><strong>Après réussite :</strong> réinstallez le ZIP de réparation 5.27.11, puis laissez son panneau terminer les 180 topics et 240 articles. Réactivez les tâches et remettez le site en ligne après vos vérifications. Cet outil ne rouvre pas le site automatiquement.</p>
</section>
<script type="module" src="<?= $e($root.'media/com_joomcck/nexus/innodb-maintenance.js?v=5.27.12') ?>"></script>
