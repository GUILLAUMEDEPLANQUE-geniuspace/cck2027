<?php
declare(strict_types=1);
namespace Geniuspace;

/** Optional declared recruitment bounty. Local ledger only, with no payment provider. */
final class CreatorRevenue
{
    private static function store(): Store { return new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class)); }
    public static function parse(string $raw): array
    {
        if(strlen($raw)>4096)throw new \InvalidArgumentException('Prime trop volumineuse.');$d=json_decode($raw,true,5,JSON_THROW_ON_ERROR);$amount=$d['bounty']??null;$share=$d['creator_percent']??10;
        if(!is_array($d)||!is_scalar($amount)||!preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D',(string)$amount)||($n=(float)$amount)<=0||$n>10000000||!is_int($share)||$share<1||$share>100||!preg_match('/^[A-Z]{3}$/D',$d['currency']??''))throw new \InvalidArgumentException('Prime positive, devise ISO et part créateur de 1 à 100 % requises.');
        return ['bounty_minor'=>(int)round($n*100),'creator_percent'=>$share,'currency'=>$d['currency']];
    }
    public static function hired(array $application,Quiz $quiz): void
    {
        $s=self::store();$job=(int)$application['job']['id'];$values=json_decode($application['job']['fields'],true)?:[];$reward=null;
        foreach($s->rows("SELECT id FROM #__js_res_fields WHERE type_id=".(int)$application['job']['type_id']." AND field_type='gpbounty' AND published=1 ORDER BY ordering,id",1000)as$f)if(!empty($values[$f['id']])){$reward=self::parse((string)$values[$f['id']]);break;}
        if(!$reward)return;$definition=$quiz->definition($job,(int)$application['gate']['quiz_field_id']);$creators=[];
        foreach(array_unique(array_filter(array_column($definition['quiz']['questions'],'course_record_id')))as$id){$course=(new NativeAccess())->record((int)$id);if(!$course)continue;
            foreach($s->rows("SELECT id FROM #__js_res_fields WHERE type_id=".(int)$course['raw']['type_id']." AND field_type='gppath' AND published=1",1000)as$f){try{$state=(new LearningPath($quiz))->state((int)$id,(int)$f['id']);}catch(\DomainException|\InvalidArgumentException $e){continue;}if(!$state['complete'])continue;
                $creator=(int)$course['raw']['user_id'];if($creator>0&&$creator!==(int)$application['record']['user_id']&&$s->rows('SELECT id FROM #__users WHERE id='.$creator.' AND block=0',1))$creators[$creator]=(int)$id;break;
            }
        }
        if(!$creators)return;ksort($creators);$pool=intdiv($reward['bounty_minor']*$reward['creator_percent'],100);$part=intdiv($pool,count($creators));$remainder=$pool%count($creators);
        foreach($creators as$creator=>$course){$amount=$part+($remainder-->0?1:0);if(!$amount)continue;
            $s->run('INSERT IGNORE INTO #__gp_social_creator_revenue (application_id,job_id,creator_id,course_id,amount_minor,currency,state,actor_id,reference,ctime,mtime) VALUES ('.(int)$application['record']['id'].','.$job.','.$creator.','.$course.','.$amount.','.$s->q($reward['currency']).",'pending',0,'',".$s->q(gmdate('Y-m-d H:i:s')).','.$s->q(gmdate('Y-m-d H:i:s')).')');
        }
    }
    public static function settle(int $application,int $creator,string $reference): void
    {
        $u=\Joomla\CMS\Factory::getApplication()->getIdentity();$reference=Text::plain($reference);
        if(!$u->id||$u->block||!$u->authorise('core.manage','com_joomcck'))throw new \DomainException('Règlement réservé à la gestion JoomCCK.',403);
        if(!$reference||mb_strlen($reference)>180)throw new \InvalidArgumentException('Référence du règlement effectué requise.');$s=self::store();
        if(!$s->rows('SELECT application_id FROM #__gp_social_creator_revenue WHERE application_id='.$application.' AND creator_id='.$creator,1))throw new \DomainException('Écriture introuvable.',404);
        $s->run("UPDATE #__gp_social_creator_revenue SET state='recorded',actor_id=".(int)$u->id.',reference='.$s->q($reference).',mtime='.$s->q(gmdate('Y-m-d H:i:s')).' WHERE application_id='.$application.' AND creator_id='.$creator." AND state='pending'");
    }
    public static function render(object $record,?object $field=null,bool $ledger=false): string
    {
        $u=\Joomla\CMS\Factory::getApplication()->getIdentity();$out='';
        if(!$ledger&&$field&&$field->value){$d=self::parse((string)$field->value);$out='<p>Prime de recrutement déclarée : '.Text::escape((string)($d['bounty_minor']/100).' '.$d['currency']).' · Part des créateurs de cours validés : '.$d['creator_percent'].' %. Aucun versement automatique.</p>';}
        if(!$u->id||$u->block||($ledger&&(int)$record->user_id!==(int)$u->id))return $out;
        \Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);$s=self::store();$manager=$u->authorise('core.manage','com_joomcck');$owner=(int)$record->user_id===(int)$u->id;
        $where=$ledger?'creator_id='.(int)$u->id:'job_id='.(int)$record->id.($manager||$owner?'':' AND creator_id='.(int)$u->id);
        $rows=$s->rows('SELECT * FROM #__gp_social_creator_revenue WHERE '.$where.' ORDER BY ctime DESC',100);if(!$rows)return $out;
        $out.='<section class="nx-creator-ledger"><h3>Registre des primes pédagogiques</h3><p>Ces écritures résultent des embauches et des parcours validés. Un règlement déclaré doit être effectué hors du site.</p>';
        foreach($rows as$r){$course=(new NativeAccess())->title((int)$r['course_id']);$out.='<div class="nx-connect-block"><strong>'.Text::escape($course['title']??'Cours').'</strong><p>'.Text::escape((string)($r['amount_minor']/100).' '.$r['currency']).' · '.($r['state']==='pending'?'À régler':'Règlement consigné').'</p>';
            if($manager&&$r['state']==='pending')$out.='<form method="post" action="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'"><input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="task" value="geniuspace.creatorRevenue"><input type="hidden" name="record" value="'.(int)$record->id.'"><input type="hidden" name="application" value="'.(int)$r['application_id'].'"><input type="hidden" name="creator" value="'.(int)$r['creator_id'].'"><label>Référence du règlement effectué <input required name="reference" maxlength="180"></label><button>Consigner le règlement</button>'.\Joomla\CMS\HTML\HTMLHelper::_('form.token').'</form>';$out.='</div>';}
        return $out.'</section>';
    }
}
