<?php
/** Two native views matching forum7: Blog + its debate, Forum + its directory/feed. */
defined('_JEXEC') or die;
require_once __DIR__.'/NexusForumSeven.php';

final class NexusForumApp
{
    private static array $modeHeads=[];
    /** Only public page metadata crosses into the progressively enhanced shell. */
    private static function head(array $head): array
    {
        $out=['title'=>(string)($head['title']??''),'description'=>(string)($head['description']??''),'canonical'=>'','meta'=>[]];
        foreach($head['links']??[]as$url=>$link)if(($link['relation']??'')==='canonical')$out['canonical']=(string)$url;
        foreach(['name','property']as$kind)foreach($head['metaTags'][$kind]??[]as$name=>$value)
            if(in_array($name,self::SOCIAL_META,true))$out['meta'][]=['kind'=>$kind,'name'=>$name,'content'=>(string)$value];
        return$out;
    }
    private const SOCIAL_META=['description','robots','og:title','og:description','og:url','og:type','og:site_name','og:image','og:image:alt','og:image:width','og:image:height','og:image:type','twitter:title','twitter:description','twitter:card','twitter:image','twitter:image:alt','article:published_time','article:modified_time','article:author'];
    public static function social(string $url,string $type,string $image='',string $alt=''): void
    {
        \Geniuspace\PublicDiscovery::head();
        $doc=\Joomla\CMS\Factory::getApplication()->getDocument();$head=$doc->getHeadData();
        foreach(['name','property']as$kind)foreach(array_keys($head['metaTags'][$kind]??[])as$name)if(in_array($name,self::SOCIAL_META,true)&&!in_array($name,['description','robots'],true))unset($head['metaTags'][$kind][$name]);
        $doc->setHeadData($head);
        foreach(['og:title'=>$doc->getTitle(),'og:description'=>$doc->getDescription(),'og:url'=>$url,'og:type'=>$type]as$name=>$content)$doc->setMetaData($name,$content,'property');
        if($site=trim((string)\Joomla\CMS\Factory::getApplication()->get('sitename','')))$doc->setMetaData('og:site_name',$site,'property');
        foreach(['twitter:title'=>$doc->getTitle(),'twitter:description'=>$doc->getDescription(),'twitter:card'=>$image?'summary_large_image':'summary']as$name=>$content)$doc->setMetaData($name,$content);
        if($image){$image=\Geniuspace\ExtendedLists::absolute($image);
            if($asset=\Geniuspace\EditorialImages::metadata($image)){
                $alt=\Geniuspace\EditorialImages::alternative($image,$alt);$image=$asset['social_url'];
                foreach(['og:image:width'=>(string)$asset['social_width'],'og:image:height'=>(string)$asset['social_height'],'og:image:type'=>'image/jpeg']as$name=>$content)$doc->setMetaData($name,$content,'property');
                $robots=trim((string)($doc->getMetaData('robots')?:\Joomla\CMS\Factory::getApplication()->get('robots','')));
                if($asset['social_width']>=1200&&!preg_match('~(?:noindex|nosnippet|noimageindex|\bnone\b|max-image-preview\s*:)~i',$robots))
                    $doc->setMetaData('robots',trim($robots,', ').($robots?', ':'').'max-image-preview:large');
            }
            $doc->setMetaData('og:image',$image,'property');$doc->setMetaData('og:image:alt',$alt,'property');$doc->setMetaData('twitter:image',$image);$doc->setMetaData('twitter:image:alt',$alt);}
    }
    public static function listParams(int $section): \Joomla\Registry\Registry
    {
        static $cache=[];
        if(isset($cache[$section]))return clone $cache[$section];
        $s=\Geniuspace\ProductAccess::store()->rows('SELECT params FROM #__js_res_sections WHERE id='.$section,1)[0]??[];
        $params=new \Joomla\Registry\Registry($s['params']??'{}');
        $selection=$params->get('general.tmpl_list','nexus_forum7');
        if(is_array($selection))$selection=reset($selection);
        $cache[$section]=\CTmpl::getTemplateParametrs('default_list_', (string)$selection);
        return clone $cache[$section];
    }
    public static function isArticle(object $r,$p=null): bool
    {
        static $types=[];
        $id=(int)$r->type_id;
        $raw=$types[$id]??=\Geniuspace\ProductAccess::store()->rows('SELECT params FROM #__js_res_types WHERE id='.$id,1)[0]??[];
        $type=(object)['params'=>new \Joomla\Registry\Registry($raw['params']??'{}')];$selection=$type->params->get('properties.tmpl_article','');
        if(is_array($selection))$selection=reset($selection);
        $selection=(string)$selection;
        $params=$p??\CTmpl::getTemplateParametrs('default_record_',$selection);
        $key=NexusPlatform::config($params,'field_content_type');{
            $f=\Geniuspace\ReadMemo::get('content-nature-field:'.(int)$r->type_id.':'.$key,static fn()=>\Geniuspace\ProductAccess::store()->rows("SELECT id FROM #__js_res_fields WHERE published=1 AND type_id=".(int)$r->type_id." AND (`key`=".\Geniuspace\ProductAccess::store()->q($key)." OR alias IN ('content-type','content_type')) ORDER BY (`key`=".\Geniuspace\ProductAccess::store()->q($key).") DESC",1)[0]??[]);
            $values=is_array($r->fields??null)?$r->fields:(json_decode((string)($r->fields??'{}'),true)?:[]);
            $v=$values[(int)($f['id']??0)]??null;if(is_array($v))$v=reset($v);
            if(is_scalar($v)&&trim((string)$v)!=='')return in_array(trim((string)$v),['article','reportage','review','video','audio'],true);
        }
        // A selected native publication format remains recognisable if its type
        // does not contain the optional content-nature field.
        $rp=$r->params??null;if($rp===null&&!empty($r->id))$rp=\Geniuspace\ProductAccess::store()->rows('SELECT params FROM #__js_res_record WHERE id='.(int)$r->id,1)[0]['params']??'{}';
        $rp=$rp instanceof \Joomla\Registry\Registry?$rp:new \Joomla\Registry\Registry($rp??'{}');$slug=(string)$rp->get('nexus_publication_form','');
        if($slug){require_once __DIR__.'/NexusAuthorForms.php';$profile=NexusAuthorForms::definitions(self::listParams((int)$r->section_id))[$slug]??null;if($profile)return in_array($profile['kind'],['article','reportage','review','video','audio'],true);}
        return in_array(NexusPlatform::config($params,'content_kind'),['BlogPosting','Article'],true)
            ||in_array((string)$type->params->get('semantic.entity'),['BlogPosting','Article'],true)
            ||(bool)preg_match('/(?:nexus_article|editorial|blog)/',$selection);
    }
    public static function allowed(object $r,int $hub,?\Geniuspace\NativeAccess $access=null): bool
    {
        $section=\Geniuspace\ForumRoutes::section($hub);$levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();
        if(!$section||!in_array((int)$section['access'],$levels,true)||!$section['settings']->get('general.status',1)||$section['settings']->get('emerald.section_subscription')||!self::isArticle($r))return false;
        $p=self::listParams($hub);$source=(int)NexusPlatform::config($p,'blog_section_id');$type=(int)NexusPlatform::config($p,'blog_type_id');
        $sections=array_merge([$hub,$source],\Geniuspace\ShellBindings::sections($hub,'blog'));
        if(!in_array((int)$r->section_id,array_filter($sections),true)||($type&&(int)$r->type_id!==$type&&!in_array((int)$r->section_id,\Geniuspace\ShellBindings::sections($hub,'blog'),true)))return false;
        return ($access??new \Geniuspace\NativeAccess())->record((int)$r->id)!==null;
    }
    public static function article(int $hub,$p,array $items=[]): ?object
    {
        $chosen=\Joomla\CMS\Factory::getApplication()->input->getInt('nx_article');
        if($chosen){$r=\Geniuspace\ProductAccess::raw($chosen);if($r&&(self::allowed((object)$r,$hub)||((in_array((int)$r['section_id'],\Geniuspace\ShellBindings::sections($hub),true)||((int)(\Geniuspace\ShellBindings::specialized((object)$r)['hub']??0)===$hub))&&\Geniuspace\PublicMaterial::record($chosen,false))))return(object)$r;return null;}
        $source=(int)NexusPlatform::config($p,'blog_section_id');$type=(int)NexusPlatform::config($p,'blog_type_id');
        if(!$source)foreach($items as$r)if(self::allowed($r,$hub))return$r;
        $s=\Geniuspace\ProductAccess::store();$sections=array_merge([$hub,$source],\Geniuspace\ShellBindings::sections($hub,'blog'));$where=' AND section_id IN ('.implode(',',array_unique(array_filter($sections))).')';
        // Explicit section connections retain their own native content types.
        foreach($s->rows('SELECT id,section_id,type_id,fields FROM #__js_res_record WHERE published=1 AND hidden=0'.$where.' ORDER BY ctime DESC,id DESC',200)as$r)
            if(self::allowed((object)$r,$hub))return(object)$r;
        return null;
    }
    public static function articleUrl(object $r,int $hub): string
    {
        $url=NexusPlatform::recordUrl($r);
        if((int)$r->section_id!==$hub&&!\Geniuspace\ShellBindings::scope((int)$r->section_id)){$u=new \Joomla\CMS\Uri\Uri($url);$u->setVar('nx_hub',$hub);$url=$u->toString();}
        return NexusForumSeven::modeUrl($url,'blog');
    }
    /** Restore request/menu state while keeping assets needed by the native field/editor widgets. */
    private static function native(string $kind,int $hub,?object $record=null): string
    {
        $app=\Joomla\CMS\Factory::getApplication();$input=$app->input;$menu=$app->getMenu();$active=$menu->getActive();
        $keys=['id','view','section_id','cat_id','filter_cat','filter','start','limitstart','Itemid','layout','tmpl','nx_embed','nx_mode','nx_hub'];$prior=[];
        foreach($keys as$key)$prior[$key]=$input->get($key,null,'raw');
        $primaryHead=$app->getDocument()->getHeadData();$depth=ob_get_level();ob_start();
        try{
            $input->set('view',$kind);$input->set('section_id',$record?(int)$record->section_id:$hub);$input->set('id',$record?(int)$record->id:0);
            $input->set('cat_id',$record?0:\Geniuspace\UniverseBlueprint::selected($hub));$input->set('filter_cat',[]);$input->set('filter',[]);$input->set('start',0);$input->set('limitstart',0);$input->set('nx_embed',0);
            $itemid=\Geniuspace\ForumRoutes::menu($record?(int)$record->section_id:$hub,$record?'thread':'hub');$input->set('Itemid',$itemid);if($itemid)$menu->setActive($itemid);
            require_once JPATH_ROOT.'/components/com_joomcck/models/'.$kind.'.php';
            require_once JPATH_ROOT.'/components/com_joomcck/views/'.$kind.'/view.html.php';
            $modelClass=$kind==='record'?'JoomcckModelRecord':'JoomcckModelRecords';$viewClass=$kind==='record'?'JoomcckViewRecord':'JoomcckViewRecords';
            $model=new $modelClass(['ignore_request'=>true]);$model->getState();
            if($record){$model->setState('com_joomcck.record.id',(int)$record->id);$model->setState('com_joomcck.record.section_id',(int)$record->section_id);$nativeItem=$model->getItem();$nativeCategories=is_array($nativeItem->categories)?$nativeItem->categories:(json_decode((string)$nativeItem->categories,true)?:[]);$input->set('cat_id',(int)array_key_last($nativeCategories));}
            else{$model->setState('records.section_id',$hub);$model->setState('records.category',[]);$model->setState('list.start',0);}
            $view=new $viewClass(['name'=>$kind,'base_path'=>JPATH_ROOT.'/components/com_joomcck']);
            $view->document=$app->getDocument();
            $view->addTemplatePath(JPATH_ROOT.'/components/com_joomcck/views/'.$kind.'/tmpl');$view->setModel($model,true);
            $view->nexusForumSevenEmbedded=true;
            if($record){$view->nexusForumSevenHub=$hub;$view->nexusForumSevenArticle=true;}
            $specialized=$record&&(in_array((int)$record->section_id,\Geniuspace\ShellBindings::sections($hub),true)||((int)(\Geniuspace\ShellBindings::specialized($record)['hub']??0)===$hub));
            if($specialized)$view->nexusShellEmbedOnly=true;
            $layout=$record?($specialized?'nexus_shell_reading':'nexus_forum7_blog'):'nexus_forum7_feed';$input->set('layout',$layout);$view->setLayout($layout);
            $view->display();self::$modeHeads[$kind==='record'?'blog':'forum']=self::head($app->getDocument()->getHeadData());return(string)ob_get_contents();
        }catch(\Throwable $e){\Joomla\CMS\Log\Log::add('Forum7 native view: '.get_class($e).': '.$e->getMessage(),\Joomla\CMS\Log\Log::WARNING,'joomcck');return '<p class="forum7-empty">Cette vue est momentanément indisponible. Ouvrez sa page complète.</p>';}
        finally{
            while(ob_get_level()>$depth)ob_end_clean();foreach($prior as$key=>$v)$input->set($key,$v);if($active)$menu->setActive((int)$active->id);
            // Embedding the other view may load editors and their assets, but must
            // not replace the primary route's SEO identity with the Hub menu title.
            $head=$app->getDocument()->getHeadData();foreach(['title','description','metaTags']as$key)if(array_key_exists($key,$primaryHead))$head[$key]=$primaryHead[$key];
            foreach($head['links']??[]as$key=>$link)if(($link['relation']??'')==='canonical')unset($head['links'][$key]);
            foreach($primaryHead['links']??[]as$key=>$link)if(($link['relation']??'')==='canonical')$head['links'][$key]=$link;
            $app->getDocument()->setHeadData($head);
        }
    }
    private static function fragment(string $html,bool $active,array &$used,string $prefix): string
    {
        // libxml's HTML4 parser changes JavaScript template literals containing HTML.
        // Keep native upload/editor programs, textareas and code examples byte-for-byte.
        $protected=[];$token='forum7-preserve-'.hash('sha256',$html).'-';
        $inspect=preg_replace_callback('~<(script|style|textarea|pre|code)\b[^>]*>[\s\S]*?</\1\s*>~i',static function($m)use(&$protected,$token){$key='<!--'.$token.count($protected).'-->';$protected[$key]=$m[0];return$key;},$html)??$html;
        $d=new \DOMDocument('1.0','UTF-8');$previous=libxml_use_internal_errors(true);
        try{$d->loadHTML('<?xml encoding="UTF-8"><div id="forum7-fragment">'.$inspect.'</div>',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);}finally{libxml_clear_errors();libxml_use_internal_errors($previous);}
        $x=new \DOMXPath($d);$wrap=$x->query('//*[@id="forum7-fragment"]')->item(0);if(!$wrap)return$html;
        // Joomla's comment submit/moderation handlers reserve adminForm. Filters submit themselves.
        foreach($x->query('.//form[contains(concat(" ",normalize-space(@class)," ")," nx-native-filters ")]',$wrap)as$index=>$form){
            $id=$prefix.'filters-'.$index;$form->setAttribute('id',$id);$form->setAttribute('name',$id);
            $mode=$d->createElement('input');$mode->setAttribute('type','hidden');$mode->setAttribute('name','nx_mode');$mode->setAttribute('value',str_contains($prefix,'blog')?'blog':'forum');$form->appendChild($mode);
        }
        $main=$x->query('.//h1',$wrap)->item(0);if($main){$main->setAttribute('data-forum7-primary-heading','');if(!$active){$h=$d->createElement('h2');foreach($main->attributes as$a)$h->setAttribute($a->name,$a->value);while($main->firstChild)$h->appendChild($main->firstChild);$main->parentNode->replaceChild($h,$main);}}
        $map=[];foreach($x->query('.//*[@id]',$wrap)as$node){$old=$node->getAttribute('id');if(isset($used[$old])){$new=$prefix.$old;$map[$old]=$new;$node->setAttribute('id',$new);$used[$new]=true;}else$used[$old]=true;}
        foreach($x->query('.//*',$wrap)as$node){foreach(['for','aria-controls','aria-labelledby','aria-describedby']as$attr)if($node->hasAttribute($attr)){$v=explode(' ',$node->getAttribute($attr));$node->setAttribute($attr,implode(' ',array_map(static fn($id)=>$map[$id]??$id,$v)));}
            foreach(['href','data-bs-target','data-target']as$attr)if($node->hasAttribute($attr)){$v=$node->getAttribute($attr);if(str_starts_with($v,'#')&&isset($map[substr($v,1)]))$node->setAttribute($attr,'#'.$map[substr($v,1)]);}}
        $out='';foreach($wrap->childNodes as$n)$out.=$d->saveHTML($n);return strtr($out,$protected);
    }
    private static function index(object $view,int $hub,object $params): string
    {
        $doc=\Joomla\CMS\Factory::getApplication()->getDocument();$primary=$doc->getHeadData();
        $html=\Geniuspace\NexusBlogIndex::render($view,$hub,$params);
        $designCategory=\Geniuspace\UniverseBlueprint::selected($hub);
        if($design=\Geniuspace\DesignLayouts::published('universe',$hub,$designCategory)){
            $ctx=\Geniuspace\UniverseBlueprint::context($hub,$designCategory);$nativeBlog=preg_replace('~^<main\b~','<div',$html);$nativeBlog=preg_replace('~</main>$~','</div>',$nativeBlog);$nativeBlog=str_replace('class="nx-blog-index"','class="nx-blog-index nd-native-blog-body"',$nativeBlog);
            $html='<div class="nd-universe-canvas">'.\Geniuspace\DesignRenderer::render($design,['scope'=>'universe','section'=>$hub,'target'=>$designCategory,'mode'=>'blog-index'],['community'=>$nativeBlog,'directory'=>NexusForumSeven::directory($ctx['roots'],$designCategory),'sidebar'=>NexusForumSeven::sidebar([],$params,$hub),'discovery'=>'<a href="'.Geniuspace\Text::escape(Geniuspace\ForumRoutes::categoryUrl($hub,$designCategory)).'">Explorer les scènes et outils de cet univers →</a>']).'</div>';
        }
        self::$modeHeads['blog']=self::head($doc->getHeadData());
        $head=$doc->getHeadData();foreach(['title','description','metaTags','links']as$key)if(array_key_exists($key,$primary))$head[$key]=$primary[$key];$doc->setHeadData($head);return \Geniuspace\DesignInline::host($html,'universe',$hub,$designCategory);
    }
    public static function render(object $view,string $body,string $kind): string
    {
        self::$modeHeads=[];$initialHead=self::head(\Joomla\CMS\Factory::getApplication()->getDocument()->getHeadData());
        self::$modeHeads[$kind==='article'?'blog':'forum']=$initialHead;
        if($kind!=='hub'&&empty($view->nexusForumSevenEmbedded))\Joomla\CMS\Factory::getApplication()->getSession()->set('nexus.path.return',NexusPlatform::recordUrl($view->item));
        $record=$kind!=='hub';$hub=(int)(($view->nexusForumSevenHub??0)?:($record?$view->item->section_id:$view->section->id));
        $p=self::listParams($hub);$roots=NexusForumSeven::categories($hub);$items=$record?[$view->item]:(array)$view->items;
        \Geniuspace\UniverseBlueprint::select($hub,$record?$view->item:null);$home=NexusPlatform::sameSite(\Geniuspace\ForumRoutes::categoryUrl($hub));$blog='';$forum='';$article=null;$blogIndex=false;
        if($kind==='article'){$article=$view->item;$blog=$body;$forum=self::native('records',$hub);}
        elseif($kind==='discussion'){$forum='<div class="forum7-layout">'.NexusForumSeven::directory($roots).'<main class="forum7-forum-thread">'.$body.'</main>'.NexusForumSeven::sidebar($items,$p,$hub).'</div>';$blogIndex=true;$blog=self::index($view,$hub,$p);}
        else{$forum=$body;$blogIndex=true;$blog=self::index($view,$hub,$p);}
        $category=\Geniuspace\UniverseBlueprint::selected($hub);
        $filtered=$kind==='hub'&&(!empty($view->worns)||\Joomla\CMS\Factory::getApplication()->input->getString('nx_query','')!==''||\Joomla\CMS\Factory::getApplication()->input->getString('q','')!==''||\Joomla\CMS\Factory::getApplication()->input->getInt('nx_search')||\Joomla\CMS\Factory::getApplication()->input->getInt('limitstart')>0);
        $default=$kind==='article'?'blog':($kind==='discussion'||$category||$filtered?'forum':NexusPlatform::config($p,'default_mode','blog'));
        // The clean hub canonical must represent the same brand view as the home redirect.
        if($kind==='hub'&&!$category&&!$filtered&&!\Geniuspace\BrandGateway::redirectToUniverse())$default='forum';
        if(!empty($view->nexusShellCollection))$default=!empty($view->nexusBlogCollection)?'blog':'forum';
        $requested=\Joomla\CMS\Factory::getApplication()->input->getCmd('nx_mode');$mode=in_array($requested,['blog','forum'],true)?$requested:$default;
        // Each native conversation keeps its record-scoped form and editor id.
        // Both views are ready before a toggle, without another page request.
        if($kind==='discussion')$mode='forum';
        if($kind!=='discussion'&&NexusForumSeven::focused())$mode='blog';
        $blogUrl=$article?self::articleUrl($article,$hub):\Geniuspace\NexusBlogIndex::url($hub);
        if($blogIndex&&$mode==='blog')\Geniuspace\NexusBlogIndex::metadata($hub,\Geniuspace\NexusBlogIndex::state($hub));
        $forumUri=new \Joomla\CMS\Uri\Uri($kind==='hub'?\Joomla\CMS\Uri\Uri::getInstance()->toString():$home);
        if($article)$forumUri->setVar('nx_article',(int)$article->id);
        $forumUrl=NexusForumSeven::modeUrl($forumUri->toString(),'forum');
        $used=['forum7-top','view-blog','view-forum'];$used=array_fill_keys($used,true);
        if($blog)$blog=self::fragment($blog,$mode==='blog',$used,'forum7-blog-');$forum=self::fragment($forum,$mode==='forum',$used,'forum7-forum-');
        $e=[NexusSuite::class,'e'];
        $out='<section class="nx-multivers nx-forum7 nx-forum8 nx-forum-absolu forum7-app'.($kind==='article'?' forum7-article':'').($kind==='discussion'?' forum7-discussion':'').'" data-v21 data-v23 data-universe-fallback="'.$e(\Joomla\CMS\Uri\Uri::root(true).'/media/com_joomcck/nexus/editorial/playtest-observations-utiles-1200.webp').'" data-meta-hub data-forum7 data-forum7-heads="'.$e(json_encode(self::$modeHeads,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'" data-forum7-kind="'.$e($kind).'" data-forum7-article="'.(int)($article->id??0).'" data-forum7-current-mode="'.$mode.'" id="forum7-top">';
        $out.=NexusForumSeven::header($p,$hub,$forumUrl,$blogUrl,$mode).\Geniuspace\UniverseBlueprint::navigation($hub,$category);
        $out.='<div class="forum7-app-layout">'.NexusForumSeven::rail($roots,$p,$items,$home).'<div class="forum7-view-stack">';
        if($blog)$out.='<div id="view-blog" class="forum7-view app-view'.($blogIndex?' nx-blog-collection':'').($mode==='blog'?' active':'').'" data-forum7-view="blog"'.($mode!=='blog'?' hidden':'').'>'.$blog.'</div>';
        else $out.='<div id="view-blog" class="forum7-view app-view'.($mode==='blog'?' active':'').'" data-forum7-view="blog"'.($mode!=='blog'?' hidden':'').'><div class="forum7-empty"><h1 data-forum7-primary-heading>Articles &amp; reportages</h1><p>Découvrez les récits et les analyses de la communauté. Publiez le premier article pour ouvrir la conversation.</p><a href="'.$e(NexusPlatform::sameSite(NexusPlatform::config($p,'submit_url')).'&nx_form=article').'">Rédiger un article</a></div></div>';
        $out.='<div id="view-forum" class="forum7-view app-view'.($mode==='forum'?' active':'').'" data-forum7-view="forum"'.($mode!=='forum'?' hidden':'').'>'.$forum.'</div></div></div>'.\Geniuspace\AppDock::render($hub,$p).'</section>';
        return $out.\Geniuspace\JourneyCatalogue::modal();
    }
}
