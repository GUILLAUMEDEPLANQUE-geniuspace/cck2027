<?php
/** Rich presentation belongs to native records/comments; media belongs to native fields. */
defined('_JEXEC') or die;
require_once __DIR__.'/bootstrap.php';

final class NexusParticipation
{
    public const MAX_IMAGES = 6;
    public const EMOTIONS = ['', 'happy', 'grateful', 'curious', 'inspired', 'support', 'celebrate', 'concerned'];
    public const TONES = ['neutral', 'blue', 'green', 'amber', 'rose', 'violet'];
    public const STATUSES = ['', 'idea', 'question', 'progress', 'solved', 'announcement'];
    private static ?array $pendingComment = null;
    private static $ticketLock = null;
    private static string $lockedTicket = '';
    private static array $ticketState = [];

    /** These identifiers may become CSS classes. Free-form CSS and HTML never do. */
    public static function style(mixed $value, bool $strict = false): array
    {
        $value = is_object($value) ? (array)$value : (is_array($value) ? $value : []);
        $out = [];
        foreach (['emotion'=>[self::EMOTIONS, ''], 'tone'=>[self::TONES, 'neutral'], 'status'=>[self::STATUSES, '']] as $key=>[$allowed, $default]) {
            $candidate = $value[$key] ?? $default;
            if (!is_string($candidate) || !in_array($candidate, $allowed, true)) {
                if ($strict) throw new \DomainException('Choisissez une présentation proposée par cet espace.', 422);
                $candidate = $default;
            }
            $out[$key] = $candidate;
        }
        return $out;
    }

    public static function recordStyle(array|object $record): array
    { return self::storedStyle($record); }

    public static function commentStyle(array|object $comment): array
    { return self::storedStyle($comment); }

    private static function storedStyle(array|object $row): array
    {
        $row = (array)$row;
        $params = $row['params'] ?? '{}';
        if (!$params instanceof \Joomla\Registry\Registry) $params = new \Joomla\Registry\Registry($params);
        return self::style($params->get('nexus_participation', []));
    }

    /** Call after the native comment controller has authorised its target and edit. */
    public static function beforeComment(array &$data, object $record, object $type, object $user): void
    {
        self::$pendingComment = null;
        $app = \Joomla\CMS\Factory::getApplication();
        $style = $app->input->post->get('nexus_comment_style', null, 'array');
        if ($style === null) return; // An ordinary native editor preserves an existing style.
        if (strtoupper($app->input->getMethod()) !== 'POST' || !\Joomla\CMS\Session\Session::checkToken('post')) throw new \DomainException('Session expirée.', 403);
        if ((int)($data['record_id'] ?? 0) !== (int)$record->id || (int)$record->type_id !== (int)$type->id) throw new \DomainException('Contribution incompatible.', 403);
        self::$pendingComment = ['id'=>(int)($data['id'] ?? 0), 'record'=>(int)$record->id, 'type'=>(int)$type->id, 'user'=>(int)$user->id, 'style'=>self::style($style, true)];
    }

    /** No publication/access/text/attachment fields are changed by this hook. */
    public static function afterComment(int $commentId): void
    {
        $pending = self::$pendingComment;
        self::$pendingComment = null;
        if (!$pending || $commentId < 1 || ($pending['id'] && $pending['id'] !== $commentId)) return;
        $db = \Joomla\CMS\Factory::getDbo();
        $row = $db->setQuery('SELECT id,record_id,type_id,user_id FROM #__js_res_comments WHERE id='.$commentId)->loadObject();
        if (!$row || (int)$row->record_id !== $pending['record'] || (int)$row->type_id !== $pending['type'] || (!$pending['id'] && (int)$row->user_id !== $pending['user'])) throw new \DomainException('Contribution incompatible.', 403);
        self::mergeStyle('#__js_res_comments', $commentId, $pending['style']);
    }

    /** A native quick ticket binds staged bytes and the final native form submission. */
    public static function quickTicket(string $key, int $section, int $type): array
    {
        $app = \Joomla\CMS\Factory::getApplication();
        $user = $app->getIdentity();
        $ticket = ((array)$app->getUserState('nexus.quick.tickets', []))[$key] ?? null;
        if (!$user->id || $user->block || !preg_match('/^[a-f0-9]{48}$/D', $key) || !is_array($ticket) || (int)$ticket['user'] !== (int)$user->id || (int)$ticket['time'] < time()-1800 || (int)$ticket['section'] !== $section || (int)$ticket['type'] !== $type) throw new \DomainException('Renouvelez le formulaire pour joindre votre image.', 403);
        return $ticket;
    }

    /** Joomla database sessions have no mutex. A private receipt serializes retries across workers. */
    public static function lockTicket(string $key, int $section, int $type): void
    {
        if (self::$ticketLock) { if (self::$lockedTicket !== $key) throw new \LogicException('Another quick ticket is in use'); return; }
        $ticket = self::quickTicket($key, $section, $type);
        $user = \Joomla\CMS\Factory::getApplication()->getIdentity();
        $directory = \Geniuspace\NativeMedia::root(0).'/.participation/'.(int)$user->id;
        if (!is_dir($directory) && !\Joomla\Filesystem\Folder::create($directory, 0700)) throw new \RuntimeException('Enregistrement indisponible.');
        $path = $directory.'/'.hash('sha256', $key).'.json';
        $handle = @fopen($path, 'c+');
        if (!$handle || !flock($handle, LOCK_EX)) { if ($handle) fclose($handle); throw new \RuntimeException('Enregistrement occupé. Réessayez.'); }
        @chmod($path,0600); self::$ticketLock=$handle;self::$lockedTicket=$key;
        try {
            rewind($handle);$state=json_decode((string)stream_get_contents($handle,65537),true);
            if (!is_array($state)) $state=['images'=>array_map('intval',(array)($ticket['images']??[]))];
            self::$ticketState=$state;
        } catch (\Throwable $error) { self::releaseTicket();throw $error; }
    }

    public static function ticketResult(): ?array
    { return isset(self::$ticketState['result']) && is_array(self::$ticketState['result']) ? self::$ticketState['result'] : null; }

    public static function finishTicket(array $result): void
    { self::$ticketState['result']=$result;unset(self::$ticketState['saving']);self::writeTicket(); }

    public static function beginSave(): void
    {
        if(!empty(self::$ticketState['saving']))throw new \DomainException('La confirmation de cette tentative reste à vérifier. Consultez vos publications avant de réessayer.',409);
        self::$ticketState['saving']=time();self::writeTicket();
    }

    public static function cancelSave(): void
    { unset(self::$ticketState['saving']);self::writeTicket(); }

    public static function releaseTicket(): void
    {
        if(self::$ticketLock){flock(self::$ticketLock,LOCK_UN);fclose(self::$ticketLock);}
        self::$ticketLock=null;self::$lockedTicket='';self::$ticketState=[];
    }

    private static function writeTicket(): void
    {
        if(!self::$ticketLock)throw new \LogicException('Quick ticket lock required');
        $json=json_encode(self::$ticketState,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);rewind(self::$ticketLock);
        if(!ftruncate(self::$ticketLock,0)||fwrite(self::$ticketLock,$json)!==strlen($json)||!fflush(self::$ticketLock))throw new \RuntimeException('Confirmation à vérifier. Réessayez avec le même message.');
    }

    /** Public metadata does not alter or replace the composer's existing format links. */
    public static function imageDestination(array|object $field, int $section, int $type): ?array
    {
        $field = (object)$field;
        $p = $field->params instanceof \Joomla\Registry\Registry ? $field->params : new \Joomla\Registry\Registry($field->params ?? '{}');
        if (!in_array($field->field_type, ['gallery', 'uploads'], true)) return null;
        $formats = array_values(array_intersect(explode(',', strtolower(str_replace(' ', '', (string)$p->get('params.file_formats', 'jpg,jpeg,png,webp,avif')))), ['jpg', 'jpeg', 'png', 'webp', 'avif']));
        if (!$formats) return null;
        $mime = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','avif'=>'image/avif'];
        $max = (int)$p->get('params.max_count', 0);
        // Gallery's native input uses KiB; uploads uses MiB. The explicit native media limit is MiB.
        $limit = (int)$p->get('params.nexus_upload_limit_mb', 0);
        $bytes = $limit > 0 ? $limit*1048576 : (int)$p->get('params.max_size', $field->field_type === 'gallery' ? 4000 : 2)*($field->field_type === 'gallery' ? 1024 : 1048576);
        return ['id'=>(int)$field->id, 'label'=>strip_tags((string)$field->label), 'type'=>$field->field_type, 'name'=>'jform[fields]['.(int)$field->id.'][]', 'section_id'=>$section, 'type_id'=>$type, 'max_count'=>$max > 0 ? min(self::MAX_IMAGES, $max) : self::MAX_IMAGES, 'max_bytes'=>min(12582912, max(0, $bytes)), 'formats'=>$formats, 'accept'=>implode(',', array_unique(array_map(static fn($ext)=>$mime[$ext], $formats))), 'upload_url'=>\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.participationUpload'];
    }

    private static function imageField(int $field, int $section, int $type): array
    {
        $db = \Joomla\CMS\Factory::getDbo();
        $row = $db->setQuery('SELECT * FROM #__js_res_fields WHERE id='.$field.' AND type_id='.$type.' AND published=1')->loadObject();
        if (!$row || !($meta = self::imageDestination($row, $section, $type)) || $meta['max_bytes'] < 1) throw new \DomainException('Ce champ ne reçoit pas d’images rapides.', 403);
        $row->params = new \Joomla\Registry\Registry($row->params);
        \Geniuspace\NativeUploadGate::check($row, 0, $section, false);
        $user = \Joomla\CMS\Factory::getApplication()->getIdentity();
        if (!\CEmeraldHelper::allowField('submit', $row, (int)$user->id, \ItemsStore::getSection($section), (object)['id'=>0,'type_id'=>$type,'user_id'=>(int)$user->id], false, false)) throw new \DomainException('Ce champ est réservé.', 403);
        return [$row, $meta];
    }

    /** Image bytes are decoded and checked again when attaching, not trusted from the browser. */
    private static function checkedImage(string $path, string $extension, array $meta): array
    {
        $mime = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','avif'=>'image/avif'];
        $size = is_file($path) ? filesize($path) : 0;
        $info = $size > 0 && $size <= $meta['max_bytes'] ? @getimagesize($path) : false;
        if (!in_array($extension, $meta['formats'], true) || !$info || $info[0] < 1 || $info[1] < 1 || $info[0]*$info[1] > 25000000 || ($info['mime'] ?? '') !== ($mime[$extension] ?? '') || (new \finfo(FILEINFO_MIME_TYPE))->file($path) !== ($mime[$extension] ?? '')) throw new \DomainException('Cette image dépasse les limites ou son format n’est pas autorisé.', 422);
        $setting = trim((string)ini_get('memory_limit')); $memory = (int)$setting;
        if ($memory > 0) $memory *= match(strtolower(substr($setting,-1))) {'g'=>1073741824,'m'=>1048576,'k'=>1024,default=>1};
        if (!function_exists('imagecreatefromstring') || ($memory > 0 && $info[0]*$info[1]*6+$size*2+16777216 > $memory-memory_get_usage(true))) throw new \DomainException('Réduisez la taille de votre image avant de la joindre.', 422);
        $decoded = @imagecreatefromstring((string)file_get_contents($path));
        if (!$decoded) throw new \DomainException('Cette image est incomplète ou illisible.', 422);
        imagedestroy($decoded);
        return ['size'=>$size, 'width'=>$info[0], 'height'=>$info[1]];
    }

    /** The native field renderer can use its existing protected gallery template. */
    public static function protectedGallery(mixed $value, int $field): bool
    {
        if (is_string($value)) $value = json_decode($value, true);
        foreach ((array)$value as $file) if ((is_array($file) || is_object($file)) && \Geniuspace\NativeMedia::protectedFile($file, $field)) return true;
        return false;
    }

    public static function upload(): void
    {
        $app = \Joomla\CMS\Factory::getApplication();
        $post = $app->input->post;
        $status = 422;
        try {
            if (strtoupper($app->input->getMethod()) !== 'POST' || !\Joomla\CMS\Session\Session::checkToken('post')) throw new \DomainException('Session expirée.', 403);
            $section = $post->getInt('section_id'); $type = $post->getInt('type_id'); $key = $post->getString('nx_quick_ticket');
            $ticket = self::quickTicket($key, $section, $type);
            self::lockTicket($key,$section,$type);
            if (self::ticketResult() || !empty($ticket['result']) || !empty(self::$ticketState['saving'])) throw new \DomainException('Ce message a déjà été enregistré ou reste à confirmer.', 422);
            [$field, $meta] = self::imageField($post->getInt('field_id'), $section, $type);
            $db = \Joomla\CMS\Factory::getDbo(); $user = $app->getIdentity();
            // A bounded ticket also bounds abandoned uploads and repeated upload requests.
            $staged = array_map('intval', (array)(self::$ticketState['images'] ?? []));
            if (count($staged) >= self::MAX_IMAGES*2) throw new \DomainException('Renouvelez le formulaire pour ajouter d’autres images.', 422);
            $upload = $app->input->files->get('image', null, 'array');
            if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string)($upload['tmp_name'] ?? ''))) throw new \DomainException('Transfert incomplet. Réessayez avec votre image.', 422);
            $name = basename(str_replace('\\', '/', (string)$upload['name'])); $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $info = self::checkedImage($upload['tmp_name'], $ext, $meta);
            $alt = self::plain($post->getString('alt'), 180); $caption = self::plain($post->getString('caption'), 500);
            if ($alt === '') throw new \DomainException('Décrivez votre image avant de la joindre.', 422);
            $filename = time().'_'.bin2hex(random_bytes(16)).'.'.$ext;
            $relative = gmdate('Y-m').'/'.$filename; $path = \Geniuspace\NativeMedia::root((int)$field->id).'/'.$relative;
            if (!is_dir(dirname($path)) && !\Joomla\Filesystem\Folder::create(dirname($path), 0700)) throw new \RuntimeException('Transfert indisponible.');
            if (!move_uploaded_file($upload['tmp_name'], $path)) throw new \RuntimeException('Transfert indisponible.');
            @chmod($path, 0600);
            try {
                $row = (object)(['filename'=>$filename, 'realname'=>mb_substr($name,0,240), 'section_id'=>$section, 'type_id'=>$type, 'field_id'=>(int)$field->id, 'record_id'=>0, 'user_id'=>(int)$user->id, 'saved'=>0, 'ctime'=>gmdate('Y-m-d H:i:s'), 'ip'=>(string)($_SERVER['REMOTE_ADDR'] ?? ''), 'ext'=>$ext, 'fullpath'=>$relative, 'title'=>$alt, 'description'=>$caption, 'params'=>json_encode(['nexus_participation_ticket'=>hash('sha256', $key)], JSON_UNESCAPED_UNICODE)] + $info);
                $db->insertObject('#__js_res_files', $row, 'id');
            } catch (\Throwable $error) { @unlink($path); throw $error; }
            $staged[]=(int)$row->id;self::$ticketState['images']=$staged;self::writeTicket();$ticket['images']=$staged;
            $tickets = (array)$app->getUserState('nexus.quick.tickets', []); $tickets[$key] = $ticket; $app->setUserState('nexus.quick.tickets', $tickets);
            $result = ['success'=>true, 'id'=>(int)$row->id, 'filename'=>$filename, 'url'=>\Geniuspace\NativeMedia::url((int)$row->id), 'width'=>$info['width'], 'height'=>$info['height'], 'alt'=>$alt, 'caption'=>$caption]; $status = 200;
        } catch (\Throwable $error) {
            $status = in_array($error->getCode(), [403,422,429], true) ? (int)$error->getCode() : 422;
            $result = ['success'=>false, 'message'=>$error instanceof \DomainException ? $error->getMessage() : 'Le transfert est interrompu. Votre message reste disponible.'];
        } finally { self::releaseTicket(); }
        self::output($result, $status);
    }

    /** Returns checked presentation metadata; all files continue through native validation/save. */
    public static function prepareQuick(array &$data, string $key): array
    {
        $app = \Joomla\CMS\Factory::getApplication(); $post = $app->input->post;
        $section = (int)$data['section_id']; $type = (int)$data['type_id'];
        $ticket = self::quickTicket($key, $section, $type);
        $raw = $post->get('nx_quick_images', [], 'array');
        if (count($raw) > self::MAX_IMAGES) throw new \DomainException('Joignez au maximum six images à ce message.', 422);
        $ids = [];
        foreach ($raw as $id) { if ((!is_string($id) && !is_int($id)) || !ctype_digit((string)$id) || (int)$id < 1 || isset($ids[(int)$id])) throw new \DomainException('Pièce jointe invalide.', 422); $ids[(int)$id] = (int)$id; }
        $db = \Joomla\CMS\Factory::getDbo(); $user = $app->getIdentity(); $byField = [];
        // Quick requests cannot smuggle unverified filenames through another upload field.
        $uploadFields = $db->setQuery('SELECT id FROM #__js_res_fields WHERE type_id='.$type.' AND field_type IN ('.$db->quote('gallery').','.$db->quote('uploads').')')->loadColumn();
        foreach ($uploadFields as $field) unset($data['fields'][(int)$field]);
        foreach ($ids as $id) {
            if (self::$lockedTicket !== $key || !in_array($id, array_map('intval',(array)(self::$ticketState['images'] ?? [])), true)) throw new \DomainException('Cette image ne fait pas partie de votre message.', 403);
            $file = $db->setQuery('SELECT * FROM #__js_res_files WHERE id='.$id)->loadObject();
            if (!$file || (int)$file->user_id !== (int)$user->id || (int)$file->section_id !== $section || (int)$file->type_id !== $type || (int)$file->record_id !== 0 || (int)$file->saved !== 0 || strtotime((string)$file->ctime) < time()-1800 || !hash_equals(hash('sha256',$key),(string)(new \Joomla\Registry\Registry($file->params))->get('nexus_participation_ticket',''))) throw new \DomainException('Cette image n’est plus disponible pour ce message.', 403);
            [$field, $meta] = self::imageField((int)$file->field_id, $section, $type);
            self::checkedImage(\Geniuspace\NativeMedia::path($file), strtolower((string)$file->ext), $meta);
            $byField[(int)$field->id][] = $file->filename;
            if (count($byField[(int)$field->id]) > $meta['max_count']) throw new \DomainException('Le nombre maximal d’images de ce champ est atteint.', 422);
        }
        foreach ($byField as $field=>$names) $data['fields'][$field] = $names;
        return self::style(['emotion'=>$post->getString('nx_quick_emotion',''), 'tone'=>$post->getString('nx_quick_tone','neutral'), 'status'=>$post->getString('nx_quick_status','')], true);
    }

    public static function afterQuick(int $recordId, array $style): void
    { self::mergeStyle('#__js_res_record', $recordId, self::style($style, true)); }

    /** Compare-and-swap preserves metadata written by moderation, reviews and other native hooks. */
    private static function mergeStyle(string $table, int $id, array $style): void
    {
        if (!in_array($table, ['#__js_res_record', '#__js_res_comments'], true) || $id < 1) throw new \LogicException('Invalid participation target');
        $db = \Joomla\CMS\Factory::getDbo();
        for ($attempt=0; $attempt<4; $attempt++) {
            $row = $db->setQuery('SELECT params FROM '.$table.' WHERE id='.$id)->loadObject();
            if (!$row) throw new \DomainException('Contribution introuvable.', 404);
            $params = new \Joomla\Registry\Registry($row->params ?? '{}'); $params->set('nexus_participation', $style); $next = $params->toString();
            if ($next === $row->params) return;
            $db->setQuery('UPDATE '.$table.' SET params='.$db->quote($next).' WHERE id='.$id.' AND '.($row->params === null ? 'params IS NULL' : 'params='.$db->quote($row->params)))->execute();
            if ($db->getAffectedRows() > 0) return;
        }
        throw new \RuntimeException('La présentation de votre contribution reste à enregistrer.');
    }

    private static function plain(string $value, int $length): string
    { return mb_substr(trim(preg_replace('/[\x00-\x1f\x7f]/u', ' ', strip_tags($value)) ?? ''), 0, $length); }

    private static function output(array $result, int $status): void
    {
        $app = \Joomla\CMS\Factory::getApplication(); http_response_code($status);
        $app->setHeader('Content-Type','application/json; charset=utf-8',true); $app->setHeader('Cache-Control','private, no-store',true); $app->sendHeaders();
        echo json_encode($result, JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP); $app->close();
    }
}
