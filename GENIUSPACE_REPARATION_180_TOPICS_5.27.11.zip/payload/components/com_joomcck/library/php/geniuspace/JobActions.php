<?php
declare(strict_types=1);
namespace Geniuspace;
final class JobActions
{
    public static function render(object $r,string $apply,string $ask,array $quiz,bool $expired,string $salary,string $city): string
    {
        ElementLibrary::assets();if(ProductAccess::user()->id)\Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);$url=$expired?'':(($quiz['field']&&!$quiz['passed'])?$quiz['url']:$apply);$label=$expired?'Offre indisponible':(($quiz['field']&&!$quiz['passed'])?'Vérifier mes prérequis':'Postuler');
        $attrs=' data-product-kind="element" data-record="'.(int)$r->id.'" data-endpoint="'.Text::escape(\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.product').'" data-csrf="'.(ProductAccess::user()->id?\Joomla\CMS\Session\Session::getFormToken():'').'"';$out='<aside'.$attrs.' class="gp-job-actions" aria-label="Actions de candidature"><div><strong>'.Text::escape($r->title).'</strong><small>'.Text::escape(trim($salary.' · '.$city,' ·')).'</small></div><nav>';
        if($url)$out.='<a class="gp-job-primary" href="'.Text::escape($url).'">'.Text::escape($label).' →</a>';else $out.='<strong>'.Text::escape($expired?$label:'Candidature à configurer par l’auteur').'</strong>';
        if($ask)$out.='<a class="gp-job-secondary" href="#gp-job-questions-'.(int)$r->id.'">Poser une question</a>';
        if(ProductAccess::user()->id)$out.=ProductAccess::form('experience.resume',(int)$r->id,['kind'=>'saved','position'=>0]).'<button class="gp-job-secondary gp-job-save" title="Garder pour plus tard"><i class="fa-solid fa-bookmark" aria-hidden="true"></i><span> Enregistrer</span></button></form>';
        $out.='</nav>'.(($quiz['field']&&!$quiz['passed'])?'<details class="nx-application-gate"><summary>1. Vérifier les prérequis → 2. Envoyer la candidature</summary><p>Cette évaluation est demandée pour ce poste. Les ressources proposées vous aident à vous préparer ; elles ne remplacent pas la validation.</p></details>':'').'</aside><button type="button" class="gp-job-secondary" data-gp-compare="'.(int)$r->id.'" data-endpoint="'.Text::escape(\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.productRead').'">Comparer cette offre</button><nav class="gp-job-chapters" aria-label="Parties de l’offre">';foreach(['essential'=>'L’essentiel','mission'=>'Missions','skills'=>'Compétences et preuves','conditions'=>'Conditions et équipe','recruitment'=>'Recrutement','questions'=>'Questions']as$key=>$text)$out.='<a href="#gp-job-'.$key.'-'.(int)$r->id.'">'.$text.'</a>';return $out.'</nav>';
    }
}
