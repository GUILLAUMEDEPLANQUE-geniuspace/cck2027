<?php
declare(strict_types=1);
namespace Geniuspace;

/** Local calculations and native field destinations. A simulation never certifies a fact or moves money. */
final class UniverseWidgets
{
    private const TOOLS=[
        'jeux_video-1'=>'rig','jeux_video-2'=>'review','jeux_video-3'=>'gaming','jeux_video-4'=>'playtest',
        'emploi-1'=>'salary','emploi-2'=>'finance','emploi-3'=>'expert','emploi-4'=>'academy',
        'pays_expat-1'=>'cost','pays_expat-2'=>'akiya','pays_expat-3'=>'expert','pays_expat-4'=>'buying-pool',
        'artisanat-1'=>'images','artisanat-2'=>'basket','artisanat-3'=>'buying-pool','artisanat-4'=>'steel',
        'business-1'=>'cfo','business-2'=>'partner','business-3'=>'article','business-4'=>'audio',
        'investissement-1'=>'compound','investissement-2'=>'irr','investissement-3'=>'fees','investissement-4'=>'allocation',
        'traditions-1'=>'interactions','traditions-2'=>'images','traditions-3'=>'moon','traditions-4'=>'buying-pool',
        'paranormal-1'=>'forensics','paranormal-2'=>'fact-check','paranormal-3'=>'gaming','paranormal-4'=>'video',
        'manga-1'=>'spoiler','manga-2'=>'oracle','manga-3'=>'finance','manga-4'=>'article',
        'gastronomie-1'=>'review','gastronomie-2'=>'steel','gastronomie-3'=>'buying-pool','gastronomie-4'=>'hydration',
        'sports-1'=>'shoes','sports-2'=>'gaming','sports-3'=>'playtest','sports-4'=>'video',
        'tech-1'=>'memory','tech-2'=>'code','tech-3'=>'business','tech-4'=>'fact-check'];
    public static function kinds(): array{return self::TOOLS;}
    public static function cards(string $key,int $section,object $params,string $instance='main'): string
    {
        $u=UniverseBlueprint::catalogue()[$key]??null;if(!$u)return '';$out='';$reference=UniverseComposition::contract($key);
        foreach($u['centralWidgets']as$index=>$widget){$kind=self::TOOLS[$widget['id']]??'';$visual=$reference['centralWidgets'][$index]??[];
            $out.='<article class="nx-universe-tool nx-reference-tool bg-white border border-slate-200 hover:border-primary/40 rounded-xl p-3 flex flex-col justify-between shadow-sm" data-universe-widget="'.Text::escape($widget['id']).'" data-widget-kind="'.$kind.'"><div><header class="flex items-center justify-between mb-1"><span class="w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold '.Text::escape($visual['iconColor']??'bg-indigo-50 text-indigo-600').'">'.UniverseBlueprint::icon($widget['icon']).'</span><small class="text-[9px] font-black uppercase px-2 py-0.5 rounded-full '.Text::escape($visual['badgeClass']??'bg-indigo-100 text-indigo-800').'">'.Text::escape($widget['badge']).'</small></header><h3 class="text-xs font-display font-black text-slate-900">'.Text::escape($widget['title']).'</h3><p class="text-[11px] text-slate-500 mb-2">'.Text::escape($visual['desc']??self::label($kind)).'</p></div>';
            // PiP retains the complete existing tools. At rest the reference uses one compact call to action.
            $out.=$instance==='pip'?self::body($kind,$section,$params):'<button type="button" data-reference-action="'.$kind.'" class="nx-reference-tool-open w-full bg-slate-900 text-white font-bold py-2 rounded-xl text-[11px]">'.Text::escape(self::label($kind)).' →</button>';
            $out.='</article>';}
        return $out;
    }
    public static function body(string $kind,int $section,object $params): string
    {
        if(in_array($kind,['rig','salary','cost','akiya','basket','steel','cfo','irr','compound','fees','allocation','interactions','moon','hydration','shoes'],true))return self::calculator($kind);
        if($kind==='spoiler')return self::spoiler();
        if($kind==='forensics')return '<div data-universe-fingerprint><p>Calculez l’empreinte SHA-256 d’un fichier sur votre appareil. Une empreinte permet de reconnaître cette version du fichier. Reliez le document original et ses sources à votre enquête.</p><input type="file" aria-label="Fichier à examiner"><button type="button">Calculer l’empreinte locale</button><output aria-live="polite"></output></div>';
        if($kind==='memory')return '<form data-universe-memory data-read-url="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'"><label>Votre question<input name="query" maxlength="200" required></label><button>Rechercher les sources locales</button><div role="status"></div><div data-memory-hits></div></form>';
        if($kind==='academy'){$url=\NexusPlatform::sameSite(\NexusPlatform::config($params,'academy_url'));return $url?'<a class="nx-tool-action" href="'.Text::escape($url).'">Choisir un cours et un exercice →</a>':self::destination('city',$section,$params,'Relier un cours et un exercice');}
        if($kind==='oracle')return self::destination('discussion',$section,$params,'Ouvrir un sujet pour sceller une prédiction').'<p class="nx-widget-note">Le scellement horodaté et sa résolution sourcée sont disponibles dans les échanges du sujet.</p>';
        $labels=['review'=>'Publier un avis et ses preuves','gaming'=>'Créer ou rejoindre une équipe','playtest'=>'Proposer un playtest ou une session','finance'=>'Renseigner les montants et un justificatif privé','expert'=>'Proposer un rendez-vous expert','buying-pool'=>'Créer une coalition documentée','partner'=>'Proposer un mandat ou une introduction','images'=>'Joindre les images et leurs sources','audio'=>'Enregistrer un pitch et demander un retour','fact-check'=>'Ouvrir une enquête sourcée','video'=>'Publier une vidéo, ses chapitres et annotations','article'=>'Écrire ou enrichir un dossier','code'=>'Publier un code dans sa sandbox','business'=>'Publier les mesures et leur protocole'];
        $out=self::destination($kind,$section,$params,$labels[$kind]??'Ouvrir le formulaire');
        if(in_array($kind,['finance','images','fact-check'],true))$out.='<p class="nx-widget-note">Un document ou un résultat OCR reste à examiner. Aucun badge de certification n’est attribué par ce bouton.</p>';
        if(in_array($kind,['playtest','buying-pool','partner'],true))$out.='<p class="nx-widget-note">Les conditions et montants sont ceux de l’offre publiée. Aucun paiement n’est déclenché ici.</p>';
        return $out;
    }
    public static function destination(string $format,int $section,object $p,string $label): string
    {
        $submit=\NexusPlatform::sameSite(\NexusPlatform::config($p,'submit_url'));if(!$submit)return '<p>La publication sera disponible après configuration de cet espace.</p>';
        $uri=new \Joomla\CMS\Uri\Uri($submit);$uri->setVar('nx_form',$format);$uri->setVar('nx_dialog',1);$category=UniverseBlueprint::selected($section);if($category)$uri->setVar('cat_id',$category);
        return '<a class="nx-tool-action" data-universe-native-form href="'.Text::escape($uri->toString()).'">'.Text::escape($label).' →</a>';
    }
    public static function spoiler(): string
    {
        return '<div data-universe-spoiler><label>Ma progression (chapitre ou épisode)<input type="number" min="0" max="1000000" value="0" data-universe-progress></label><button type="button">Appliquer mon bouclier</button><output aria-live="polite"></output><p class="nx-widget-note">Le filtre agit sur les contenus dont l’auteur a renseigné le niveau de révélation. Le réglage natif du bouclier reste disponible.</p></div>';
    }
    public static function definitions(): array
    {
        return [
            'compound'=>['Intérêts composés · DCA net',['capital'=>['Capital initial (€)',10000],'monthly'=>['Versement mensuel (€)',500],'years'=>['Durée (années)',20],'rate'=>['Rendement brut annuel (%)',7],'fees'=>['Frais annuels (%)',0.5],'tax'=>['Impôt sur la plus-value à la sortie (%)',17.2]]],
            'fees'=>['Comparer les frais dans le temps',['capital'=>['Capital (€)',10000],'years'=>['Durée (années)',15],'rate'=>['Rendement brut annuel (%)',6],'current'=>['Frais actuels (%/an)',2],'alternative'=>['Frais comparés (%/an)',0.5]]],
            'allocation'=>['Construire une répartition · hypothèses personnelles',['capital'=>['Montant à répartir (€)',50000],'safety'=>['Épargne disponible (%)',20],'equity'=>['Actions / ETF (%)',50],'property'=>['Immobilier (%)',30]]],
            'salary'=>['CDI ↔ TJM · Hypothèses ajustables',['annual'=>['Salaire brut annuel (€)',60000],'charges'=>['Charges employeur (%)',42],'overhead'=>['Frais professionnels annuels (€)',6000],'days'=>['Jours facturés par an',210]]],
            'akiya'=>['Budget Akiya & rendement',['purchase'=>['Prix d’achat (€)',42000],'works'=>['Travaux (€)',14000],'fees'=>['Frais d’acquisition (€)',0],'aid'=>['Aide estimée (€)',5000],'rent'=>['Loyers annuels (€)',9000],'costs'=>['Charges annuelles (€)',3000]]],
            'cost'=>['Coût de la vie & change',['origin'=>['Dépenses de départ (€ / mois)',2500],'destination'=>['Dépenses sur place (devise locale / mois)',300000],'rate'=>['Unités locales pour 1 €',160],'income'=>['Revenu mensuel net (€)',3000]]],
            'cfo'=>['Cockpit · scénarios déclarés',['revenue'=>['CA annuel HT (€)',140000],'expenses'=>['Dépenses annuelles (€)',20000],'micro'=>['Taux global Micro (%)',25],'eurl'=>['Taux global EURL (%)',40],'sasu'=>['Taux global SASU (%)',45],'dividend'=>['Dividendes transférés (€)',20000],'quote'=>['Quote-part imposable (%)',5],'is'=>['Impôt sur les sociétés (%)',25]]],
            'irr'=>['Comparateur · rendement net & TRI',['capital'=>['Capital initial (€)',10000],'years'=>['Durée en années',10],'pea'=>['Rendement ETF brut (%)',7],'lmnp'=>['Rendement immobilier brut (%)',8],'scpi'=>['Rendement SCPI brut (%)',5],'tax'=>['Fiscalité effective (%)',30],'fee'=>['Frais annuels (%)',1],'annual'=>['Revenu annuel (€)',800],'exit'=>['Valeur de sortie (€)',12000]]],
            'shoes'=>['Coût réel par kilomètre',['price'=>['Prix de l’équipement (€)',150],'distance'=>['Distance parcourue (km)',800]]],
            'hydration'=>['Ratios de recette',['flour'=>['Farine (g)',500],'water'=>['Hydratation (%)',65],'salt'=>['Sel (%)',2],'kansui'=>['Kansui (%)',0]]],
            'basket'=>['Coffret et transport partagé',['items'=>['Prix des articles (€)',100],'shipping'=>['Transport commun (€)',120],'members'=>['Nombre de commandes',10],'tax'=>['Taxes et frais de votre commande (€)',0]]],
            'rig'=>['Mesures FPS documentées',['frames'=>['Images comptées',6000],'seconds'=>['Durée mesurée (secondes)',60],'low'=>['FPS du centile bas mesuré',0]]],
            'moon'=>['Phase lunaire approchée',[]],
            'steel'=>['Acier et entretien',[]],
            'interactions'=>['Vérification botanique documentée',[]]
        ];
    }
    public static function label(string $kind): string
    {
        if(isset(self::definitions()[$kind]))return self::definitions()[$kind][0];
        return ['review'=>'Avis et preuves','gaming'=>'Équipe et partenaires','playtest'=>'Session et playtest','finance'=>'Données financières et justificatif','expert'=>'Rendez-vous expert','buying-pool'=>'Coalition d’achat','partner'=>'Mandat et offre partenaire','images'=>'Images et preuves','audio'=>'Audio et pitch','fact-check'=>'Enquête sourcée','video'=>'Vidéo et chapitres','article'=>'Dossier vivant','code'=>'Code et protocole','business'=>'Mesures et protocole documentés','spoiler'=>'Bouclier de révélations','memory'=>'Mémoire commune','forensics'=>'Empreinte locale de fichier','oracle'=>'Prédiction scellée','academy'=>'Cours et exercices','connections'=>'Connexions et liens contextuels'][$kind]??'Outil de la communauté';
    }
    public static function fieldText(string $value): string
    {
        try{$d=json_decode($value,true,12,JSON_THROW_ON_ERROR);}catch(\JsonException){return '';}
        if(!is_array($d)||!is_string($d['kind']??null))return '';return self::label($d['kind']).' · Hypothèses déclarées de simulation : '.Text::plain(Seo::json($d['data']??[]));
    }
    public static function calculator(string $kind,array $data=[]): string
    {
        $definitions=self::definitions();
        if(!isset($definitions[$kind]))return '';$d=$definitions[$kind];$out='<form data-read-url="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'" class="nx-universe-calculator" data-universe-calculator="'.$kind.'"><h3>'.Text::escape($d[0]).'</h3><div class="nx-tool-inputs">';
        foreach($d[1]as$key=>[$label,$default])$out.='<label>'.Text::escape($label).'<input type="number" name="'.$key.'" min="0" max="1000000000000" step="any" value="'.Text::escape((string)($data[$key]??$default)).'" required></label>';
        if($kind==='moon')$out.='<label>Date UTC<input type="datetime-local" name="date" value="'.gmdate('Y-m-d\TH:i').'" required></label>';
        if($kind==='steel')$out.='<label>Acier<select name="steel"><option value="vg10">VG-10</option><option value="sg2">SG2</option><option value="aogami">Aogami Super</option></select></label><label>Angle par côté (°)<input type="number" name="angle" min="5" max="40" value="15"></label>';
        if($kind==='interactions')$out.='<label>Plante et médicament à examiner<input name="combination" maxlength="300" placeholder="Plante, traitement, source documentaire…" required></label><p>Les interactions ne peuvent pas être exclues par un simple calcul. Consultez une source spécialisée et un pharmacien avant toute utilisation.</p>';
        $out.='</div><button>'.($kind==='interactions'?'Rechercher des sources':'Calculer').'</button><output aria-live="polite"></output><p class="nx-widget-note">';
        $out.=$kind==='moon'?'Calcul astronomique approché, sans connexion NASA JPL. Aucune donnée géomagnétique K n’est inventée.':($kind==='rig'?'Résultat de vos mesures saisies ; aucun accès Steam/PSN ni benchmark matériel automatique.':($kind==='cfo'?'Modèle de scénarios avec taux saisis. La trésorerie de holding et le revenu personnel sont distincts ; faites valider votre situation.':'Simulation à partir de vos hypothèses, sans garantie contractuelle ou financière.'));
        return $out.'</p></form>';
    }
}
