<?php
declare(strict_types=1);
namespace Geniuspace;

/** Local editorial tools for native fields; Joomla retains responsibility for filtering and saving. */
final class HtmlInsights
{
    public static function document(string $html): array
    {
        $dom=new \DOMDocument('1.0','UTF-8');$prior=libxml_use_internal_errors(true);
        try{$dom->loadHTML('<?xml encoding="UTF-8"><div id="gp-insights-root">'.$html.'</div>',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);}
        finally{libxml_clear_errors();libxml_use_internal_errors($prior);}
        return [$dom,$dom->getElementById('gp-insights-root')];
    }
    public static function audit(string $html): array
    {
        if(strlen($html)>131072)throw new \InvalidArgumentException('HTML trop volumineux pour le contrôle.');
        [$dom,$root]=self::document($html);$issues=[];$headings=[];$images=[];$last=1;$ids=[];$links=[];
        if(!$root)return ['issues'=>['HTML non analysable.'],'headings'=>[],'words'=>0];
        foreach($root->getElementsByTagName('*')as$n){$tag=strtolower($n->tagName);$id=$n->getAttribute('id');if($id!==''){if(isset($ids[$id]))$issues[]='Ancre dupliquée : '.$id;$ids[$id]=true;}
            if(preg_match('/^h([1-6])$/D',$tag,$m)){ $level=(int)$m[1];if($level===1)$issues[]='Ce champ comporte un H1 : vérifier le H1 de la fiche.';if($level>$last+1)$issues[]='Niveau de titre sauté : '.$tag;$last=$level;$headings[]=['level'=>$level,'text'=>Text::plain($n->textContent),'id'=>$id];}
            if($tag==='img'){$src=$n->getAttribute('src');$missing=!$n->hasAttribute('alt');$alt=$n->getAttribute('alt');
                if($missing)$issues[]='Image sans attribut alt : '.$src;
                elseif($alt==='')$issues[]='Texte alternatif vide : confirmer que l’image est décorative.';
                if(!$n->hasAttribute('width')||!$n->hasAttribute('height'))$issues[]='Image sans dimensions : risque de décalage à son chargement.';
                $images[]=['src'=>$src,'alt'=>$alt,'missing'=>$missing];}
            if($tag==='a'){$href=$n->getAttribute('href');if($href===''||$href==='#'||preg_match('/^(?:javascript|data):/i',$href))$issues[]='Lien vide ou non navigable.';if(trim($n->textContent)===''&&!$n->getElementsByTagName('img')->length)$issues[]='Lien sans intitulé.';$links[]=$href;}
        }
        foreach($links as$href)if(str_starts_with($href,'#')&&strlen($href)>1&&!isset($ids[rawurldecode(substr($href,1))]))$issues[]='Ancre introuvable dans ce champ : '.$href;
        return ['issues'=>array_values(array_unique($issues)),'headings'=>$headings,'images'=>$images,'links'=>count($links),'words'=>count(preg_split('/\s+/u',Text::plain($html),-1,PREG_SPLIT_NO_EMPTY))];
    }
    /** Identify native record links only; no external requests or guessed SEF resolution. */
    public static function recordLinks(string $html): array
    {
        [$dom,$root]=self::document($html);$out=[];if(!$root)return $out;
        $host=parse_url(\Joomla\CMS\Uri\Uri::root(),PHP_URL_HOST);
        foreach($root->getElementsByTagName('a')as$link){$href=$link->getAttribute('href');$parts=parse_url($href);if(!$parts||isset($parts['host'])&&strcasecmp($parts['host'],$host)!==0)continue;
            parse_str($parts['query']??'',$query);
            if(($query['option']??'')==='com_joomcck'&&($query['view']??'')==='record'&&is_scalar($query['id']??null)&&ctype_digit((string)$query['id'])&&(int)$query['id']>0)$out[(int)$query['id']]=$href;
        }return $out;
    }
    public static function decorate(string $html,int $field): string
    {
        [$dom,$root]=self::document($html);if(!$root)return $html;$links=[];$ids=[];
        foreach($root->getElementsByTagName('*')as$n)if($n->hasAttribute('id'))$ids[$n->getAttribute('id')]=true;
        $xpath=new \DOMXPath($dom);foreach($xpath->query('.//h2 | .//h3 | .//h4',$root)as$i=>$node){$id=$node->getAttribute('id');if($id===''){ $id='gp-toc-'.$field.'-'.$i;while(isset($ids[$id]))$id.='x';$node->setAttribute('id',$id);$ids[$id]=true;}$links[]=['id'=>$id,'title'=>Text::plain($node->textContent)];}
        if(count($links)<2)return $html;$out='<nav class="gp-field-toc" aria-label="Sommaire du contenu"><strong>Dans ce contenu</strong><ol>';
        foreach($links as$link)$out.='<li><a href="#'.Text::escape(rawurlencode($link['id'])).'">'.Text::escape($link['title']).'</a></li>';
        $out.='</ol></nav>';foreach($root->childNodes as$child)$out.=$dom->saveHTML($child);return $out;
    }
    public static function editor(int $field,?int $record = 0,$params = null,string $format = 'html'): string
    {
        $record=max(0,(int)$record);
        $doc=\Joomla\CMS\Factory::getDocument();$base=\Joomla\CMS\Uri\Uri::root(true).'/components/com_joomcck/library/php/geniuspace/media/';
        $doc->addScript($base.'passage-assistant.js',['version'=>'5.14.1'],['type'=>'module']);$doc->addScript($base.'content-insights.js',['version'=>'5.14.1'],['defer'=>true]);$doc->addScript($base.'ai/brain-ui.js',['version'=>'5.14.1'],['type'=>'module']);$doc->addStyleSheet($base.'author-tools.css',['version'=>'5.14.1']);
        $url=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.assist';
        $mode=$params?$params->get('params.geniuspace_author_mode','analyse'):'analyse';if(!in_array($mode,['manual','analyse','auto'],true))$mode='analyse';
        return '<details class="gp-content-insights" data-field="'.$field.'" data-record="'.$record.'" data-mode="'.$mode.'" data-omega="'.($params&&$params->get('params.geniuspace_omega',0)?'1':'0').'" data-publisher="'.(\Joomla\CMS\Factory::getApplication()->getIdentity()->authorise('core.manage','com_joomcck')?'1':'0').'" data-format="'.Text::escape($format).'" data-api="'.Text::escape($url).'" data-csrf="'.Text::escape(\Joomla\CMS\Session\Session::getFormToken()).'"><summary>Atelier auteur · titres, images et maillage interne</summary><div class="gp-insights-toolbar"><button type="button" data-insight="audit">Analyser les titres, images et liens</button><label>Assistance <select data-insight-mode><option value="manual">À la demande</option><option value="analyse">Analyse pendant la rédaction</option><option value="auto">Maillage automatique</option></select></label><button type="button" data-insight="undo" disabled>Annuler la dernière modification</button></div><p class="gp-insights-status" role="status">Analyse locale, sans service externe.</p><div class="gp-insights-result"></div><p class="gp-insights-note">Les modifications apparaissent dans votre éditeur. Utilisez Enregistrer ou Appliquer pour sauvegarder votre article.</p></details>';
    }
}
