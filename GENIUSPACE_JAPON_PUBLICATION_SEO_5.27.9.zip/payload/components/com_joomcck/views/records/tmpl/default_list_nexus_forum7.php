<?php
defined('_JEXEC') or die;
require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusForumApp.php';
NexusForumSeven::assets();$p=$this->tmpl_params['list'];$e=[NexusSuite::class,'e'];$section=(int)$this->section->id;
$items=array_values(array_filter((array)($this->items??[]),[NexusPlatform::class,'publicRecord']));
$roots=NexusForumSeven::categories($section);$categories=NexusForumSeven::flat($roots);$active=(int)($this->category->id??0);$category=$categories[$active]??null;
$input=\Joomla\CMS\Factory::getApplication()->input;
if(empty($this->nexusForumSevenEmbedded)&&!$active&&strtoupper($input->getMethod())==='GET'&&$input->getCmd('nx_mode')!=='blog'&&!$input->getInt('nx_all_universes')&&!$input->getString('q')&&!$input->getString('nx_query')&&!$input->getInt('nx_search')&&!$input->getInt('limitstart')&&!$input->get('filter',[],'array')){
    $defaultKey=(string)\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck')->get('geniuspace_default_universe','jeux_video');
    foreach($roots as$root)if(\Geniuspace\UniverseBlueprint::rootKey($root,$categories)===$defaultKey){\Joomla\CMS\Factory::getApplication()->redirect(\Geniuspace\UniverseBlueprint::link($section,$root),302);return;}
}
$home=NexusPlatform::sameSite(\Geniuspace\ForumRoutes::categoryUrl($section));NexusForumSeven::metadata($section,$roots,$category,$items);
if(!empty($this->worns))\Joomla\CMS\Factory::getApplication()->getDocument()->setMetaData('robots','noindex, follow');
$filters=\Joomcck\Layout\Helpers\Layout::render('nexus.platform.filters',['current'=>$this]);
$submit=NexusPlatform::sameSite(NexusPlatform::config($p,'submit_url'));if(!$submit&&count((array)$this->submission_types)===1){$type=reset($this->submission_types);$submit=NexusAurora::formUrl($section,(int)$type->id);}
if($submit&&$active){$submitUri=new \Joomla\CMS\Uri\Uri($submit);$submitUri->setVar('cat_id',$active);$submit=$submitUri->toString();}
$universeContext=\Geniuspace\UniverseBlueprint::context($section,$active);
ob_start();
?>
<div class="forum7-layout" data-design-preferences-key="<?= $section ?>:<?= $active ?>" data-universe-layout="<?= $e($universeContext['key']??'') ?>">
<?= \Geniuspace\DesignInline::slot(NexusForumSeven::directory($roots,$active),'directory') ?>
<main class="forum7-feed"><div class="forum7-feed-content">
<?php ob_start();ob_start(); ?>
<?php if($universeContext['universe']): echo \Geniuspace\UniverseBlueprint::hero($universeContext);else: ?>
<header class="forum7-feed-heading">
<?php if($category): ?><div class="forum7-category-heading"><?= NexusForumSeven::imageHtml($category,256,'forum7-category-cover',true) ?><div><h1><?= $e($category->title) ?></h1><p><?= $e(NexusSuite::plain($category->description)) ?></p></div></div>
<?php else: ?><h1><?= $e(NexusPlatform::config($p,'feed_title','La communauté Geniuspace')) ?></h1><p><?= $e(NexusPlatform::config($p,'feed_description','Reliez les idées, les métiers et les expériences.')) ?></p><?php endif; ?>
</header>
<?php endif; ?>

<?php $designHeading=(string)ob_get_clean();echo \Geniuspace\DesignInline::slot($designHeading,'universe-heading');$designAnnouncements=\Geniuspace\UniverseAnnouncements::render($section,$active);echo \Geniuspace\DesignInline::slot($designAnnouncements,'universe-announcements'); ?>
<?php $designFeatured=\Geniuspace\UniverseExperience::featured($universeContext);echo \Geniuspace\DesignInline::slot($designFeatured,'universe-featured'); ?>
<?php $designStage=\Geniuspace\UniverseBlueprint::stage($universeContext,$items,$p);echo str_contains($designStage,'data-design-native=')?$designStage:\Geniuspace\DesignInline::slot($designStage,'universe-stage'); ?>
<?php $designDiscovery=(string)ob_get_clean();ob_start(); ?>
<section class="nx-reference-community" id="nx-community-feed"><header class="nx-reference-community-heading"><h2>Les échanges de la communauté</h2><p>Publiez une idée, posez une question ou choisissez un format.</p></header>
<details class="forum7-mobile-directory"><summary><?= NexusConnect::icon('layer-group') ?> Explorer les catégories</summary><?= NexusForumSeven::directory($roots,$active,'forum7-directory-mobile') ?></details>
<?php $query=trim(\Joomla\CMS\Factory::getApplication()->input->getString('q',\Joomla\CMS\Factory::getApplication()->input->getString('nx_query','')));$search=\Geniuspace\ForumRoutes::searchUrl($section);$searchUri=new \Joomla\CMS\Uri\Uri($search); ?>
<form method="get" action="<?= $e($search) ?>" class="forum7-search"><?php foreach($searchUri->getQuery(true)as$key=>$value)if(is_scalar($value)): ?><input type="hidden" name="<?= $e($key) ?>" value="<?= $e($value) ?>"><?php endif; ?><label class="sr-only" for="forum7-query">Rechercher dans la communauté</label><input id="forum7-query" name="q" type="search" placeholder="Rechercher dans la communauté…" value="<?= $e($query) ?>" maxlength="200"><button>Explorer</button></form>
<?= !$active&&$query===''?\Geniuspace\PathPresentation::welcome($section):'' ?>
<?= NexusMultivers::composer($p,$submit) ?>

<div class="nx-topics-toolbar"><?= NexusMultivers::tags($roots,$p,$home,$active) ?><?php if(trim($filters)): ?><button type="button" data-native-filter-toggle aria-expanded="false" aria-controls="forum7-filters"><?= NexusConnect::icon('sliders') ?> Filtres</button><?php endif; ?></div>
<?php if(trim($filters)): ?><details class="meta-native-filters nx-on-demand-filters" id="forum7-filters" data-native-filter-panel><summary><?= NexusConnect::icon('sliders') ?> Affiner la recherche</summary><?= $filters ?></details><?php endif; ?>
<?php $designHighlights=\Geniuspace\DesignInline::slot(NexusAbsolu::slider($section,$p,$items),'community-highlights'); ?>
<?php if($query!==''): ?><p class="nx-search-summary" role="status">Recherche : <strong><?= $e($query) ?></strong> · <?= count($items) ?> résultat(s) sur cette page <a href="<?= $e($home) ?>">Tout afficher</a></p><?php endif; ?>
<?php if($query!==''): $related=\Geniuspace\PathPresentation::suggestions($query); ?><details class="nx-search-all-types"<?= !$items?' open':'' ?>><summary>Explorer les autres types de contenus</summary><p><?= $e($related['message']) ?></p><?php foreach($related['groups']as$group): ?><section><h2><?= $e($group['label']) ?></h2><?php foreach($group['items']as$hit): ?><a href="<?= $e($hit['url']) ?>"><?= $e($hit['title']) ?></a><?php endforeach; ?></section><?php endforeach; ?><a href="#nx-journey-explorer" data-journey-open>Explorer les parcours et leurs synonymes →</a></details><?php endif; ?>
<?php foreach($items as$i)echo NexusMultivers::card($i,$p,NexusConversation::comments((int)$i->id,3)['items']); ?>
<?php if(!$items): ?><section class="forum7-empty"><h2>À vous d’ouvrir la conversation</h2><p>Aucun sujet publié avec ces filtres.</p><?php if($submit): ?><a class="btn-shiny bg-primary text-white" href="<?= $e($submit) ?>">Créer un sujet</a><?php endif; ?></section><?php endif; ?>
<?php if(!$items&&$query===''&&!$input->get('filter',[],'array')&&empty($this->worns)): echo \Geniuspace\PublicationRecovery::neighbors($section,$active);endif; ?>
<?php $designRelated=\Geniuspace\ShellBindings::panel($section);echo \Geniuspace\DesignInline::slot($designRelated,'community-related'); ?>
<?php if($universeContext['key']==='emploi'): ?><details class="nx-employment-other-universes"><summary>Explorer aussi les autres univers</summary><a href="?nx_tab=discover" data-universe-tab="discover">Voir les sélections de tous les univers →</a></details><?php endif; ?>
<?= NexusAbsolu::regions($items,$p,'intent','field_intent') ?>
<?= \Joomcck\Layout\Helpers\Layout::render('core.list.pagination',['params'=>$p,'pagination'=>$this->pagination]) ?>
<a class="forum7-back-top" href="#forum7-top"><?= NexusConnect::icon('arrow-up') ?> Retour en haut de la communauté</a>
</section><?php $designCommunity=(string)ob_get_clean();echo \Geniuspace\Ergonomics::universe($section,$active,(string)($category->title??'La communauté Geniuspace'),$designDiscovery,\Geniuspace\DesignInline::slot($designCommunity,'community'),$designHighlights); ?></div></main>
<?= \Geniuspace\DesignInline::slot(NexusForumSeven::sidebar($items,$p,$section),'sidebar') ?>
</div>
<?php
$fragment=(string)ob_get_clean();
if($design=\Geniuspace\DesignLayouts::published('universe',$section,$active)){
    $ctx=['scope'=>'universe','section'=>$section,'target'=>$active,'heading'=>$category->title??'La communauté'];
    $slots=['community'=>$designCommunity,'discovery'=>preg_replace('~<(\/?)(h1)(\s|>)~i','<$1h2$3',$designDiscovery),'directory'=>NexusForumSeven::directory($roots,$active),'sidebar'=>NexusForumSeven::sidebar($items,$p,$section)];
    $slots+=['community-highlights'=>$designHighlights,'community-related'=>$designRelated];$slots+=['universe-heading'=>preg_replace('~<(\/?)(h1)(\s|>)~i','<$1h2$3',$designHeading),'universe-announcements'=>$designAnnouncements,'universe-featured'=>$designFeatured];$slots+=\Geniuspace\DesignInlineParts::stage($designDiscovery);$slots+=\Geniuspace\DesignInlineParts::sidebar($slots['sidebar']);
    $fragment='<div class="nd-universe-canvas">'.\Geniuspace\DesignRenderer::render($design,$ctx,$slots).'</div>';
}
\Geniuspace\DesignRenderer::assets();
// Page editing is exposed once by the authorized Omni-Dock toolbar.

require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/NexusOutline.php';
$fragment=NexusOutline::decorate($fragment,$section,$p,'feed');
$fragment=\Geniuspace\DesignInline::host($fragment,'universe',$section,$active);
if(!empty($this->nexusForumSevenEmbedded))echo $fragment;else echo NexusForumApp::render($this,$fragment,'hub');
