<?php
declare(strict_types=1);
namespace Geniuspace;

/** Public media and links, derived from native fields rather than a stale search index. */
final class PublicDiscovery
{
    /** A root-relative SEF route must not acquire the Joomla subfolder twice. */
    public static function absolute(string $url,?string $root=null): string
    {
        if($url===''||str_starts_with($url,'//')||preg_match('~^(?!https?://)[a-z][a-z0-9+.-]*:~i',$url))return '';
        if(!preg_match('~^https?://~i',$url)){
            $root??=\Joomla\CMS\Uri\Uri::root();$parts=parse_url($root);
            if(str_starts_with($url,'/')){
                $url=($parts['scheme']??'https').'://'.($parts['host']??'')
                    .(isset($parts['port'])?':'.$parts['port']:'').$url;
            }else $url=rtrim($root,'/').'/'.$url;
        }
        return Text::url($url);
    }

    public static function images(array $projection,int $limit=12): array
    {
        $out=[];$limit=max(1,min(12,$limit));
        foreach(PublicMaterial::visuals($projection)['images']as$image){
            $url=Text::url((string)$image['url']);if(!$url||strlen($url)>2048)continue;
            $entry=['url'=>$url,'title'=>Text::plain((string)($image['title']??''))];
            if($meta=EditorialImages::metadata($url)){
                $entry['title']=EditorialImages::alternative($url,$entry['title']);
                $entry['width']=(int)$meta['width'];$entry['height']=(int)$meta['height'];
                if(!empty($meta['credit']))$entry['credit']=Text::plain($meta['credit']);
            }
            $out[$url]=$entry;if(count($out)>=$limit)break;
        }
        return array_values($out);
    }

    public static function related(array $projection,NativeAccess $access,int $limit=12): array
    {
        $out=[];$limit=max(1,min(12,$limit));
        foreach($projection['fields']as$f){
            if(!in_array($f['field_type'],['parent','child'],true))continue;
            $native=(object)$f;$native->params=new \Joomla\Registry\Registry($f['params']);
            if(!$native->params->get('params.seo_links',1)||$native->params->get('params.seo_rel','')==='nofollow')continue;
            $property=(string)$native->params->get('params.seo_property','mentions');
            if(!in_array($property,['mentions','hasPart','isPartOf','about','isRelatedTo'],true))$property='mentions';
            foreach(ExtendedFields::targets($native,(object)$projection['raw'])as$target){
                $p=PublicMaterial::projection((int)$target->id,true,$access);
                if(!$p||!empty($p['raw']['nofollow']))continue;
                $url=self::absolute((string)$p['record']['url']);if(!$url)continue;
                $key=$property.':'.(int)$target->id;
                $out[$key]=['id'=>(int)$target->id,'title'=>$p['record']['title'],'url'=>$url,
                    'relation'=>$property,'field_id'=>(int)$f['id'],'field_label'=>Text::plain((string)$f['label'])];
                if(count($out)>=$limit)break 2;
            }
        }
        return array_values($out);
    }

    public static function head(): void
    {
        $doc=\Joomla\CMS\Factory::getApplication()->getDocument();$root=\Joomla\CMS\Uri\Uri::root();
        $doc->addHeadLink(NexusSitemap::url(),'sitemap','rel',['type'=>'application/xml','title'=>'Plan du site Geniuspace']);
        $doc->addHeadLink($root.'?option=com_joomcck&task=geniuspace.openapi','service-desc','rel',['type'=>'application/json','title'=>'Catalogue public Geniuspace · API de découverte']);
    }
}
