from pathlib import Path
import json,re,html
ROOT=Path(__file__).parent
ARTICLES={
'jeux_video':r'''Un PC de jeu se choisit à partir d’une situation : quels jeux, sur quel écran, avec quels réglages et quelle tolérance aux ralentissements ? Commencer par une carte graphique ou un processeur inverse le problème. Une machine peut être adaptée à un jeu compétitif peu exigeant visuellement et décevante pour une simulation chargée, sans que son prix explique à lui seul cette différence.

## Décrire le résultat attendu avant le matériel

Écrivez trois scénarios représentatifs. Pour chacun, notez le jeu, sa version, la définition de l’écran, les réglages importants et le type de séquence : exploration, combat, ville dense ou partie en ligne. Ajoutez une contrainte de bruit, d’encombrement ou de consommation si elle compte réellement. Une configuration silencieuse sous le bureau ne répond pas au même cahier des charges qu’un ordinateur transporté chaque semaine.

La fréquence de l’écran indique le nombre de rafraîchissements possibles par seconde ; elle ne garantit pas que le jeu produira autant d’images régulières. Pour suivre le mouvement, le temps entre les images compte aussi. À cadence constante, 60 images par seconde correspondent à environ 16,7 millisecondes par image ; 120 correspondent à environ 8,3 millisecondes. Ce calcul explique un objectif de cadence, pas le comportement d’un jeu particulier.

## Construire une fiche de décision comparable

| Question | Information à conserver | Pourquoi elle change le choix |
|---|---|---|
| Que jouerez-vous ? | Trois jeux et leurs versions | Les charges diffèrent selon le moteur et la scène |
| Que doit afficher l’écran ? | Définition, fréquence, réglages | Une comparaison doit garder le même objectif visuel |
| Qu’acceptez-vous de réduire ? | Réglages négociables et indispensables | Le compromis devient explicite avant l’achat |
| Que faut-il financer ? | Tour, écran, périphériques et marge de maintenance | Le budget ne se limite pas à un composant |

Un benchmark devient exploitable lorsqu’il décrit sa configuration, ses réglages et sa procédure. Deux chiffres pris sur des scènes différentes ne constituent pas une confrontation équitable. Conservez aussi la date du test : une mise à jour du jeu ou des pilotes peut rendre une conclusion moins représentative.

## Un budget fictif pour mettre les compromis à plat

Supposons une enveloppe totale de 1 400 euros, dont 250 pour l’écran et 150 pour les périphériques et petits équipements. Il reste 1 000 euros pour la tour. Ce sont des hypothèses de calcul, pas des prix de marché. Si une proposition consacre déjà 1 350 euros à la tour, elle ne respecte pas le besoin de départ, même si son rapport performances/prix paraît séduisant.

Comparez ensuite deux configurations candidates sur les trois mêmes scénarios. Une proposition qui gagne nettement dans un jeu rarement utilisé peut être moins pertinente qu’une autre, plus régulière dans le jeu principal et plus compatible avec le bruit accepté. Documentez la raison du compromis plutôt que de désigner un vainqueur universel.

## Vérifier la décision après l’achat

Gardez la fiche de départ pour la réception. Vérifiez le modèle des pièces, les branchements, l’affichage et les conditions d’un essai reproductible. Si un résultat diffère fortement d’un test, cherchez d’abord une différence de réglage ou de contexte avant de conclure à une panne.

- Définissez les usages avant de choisir des références.
- Comparez des tests dont les conditions sont explicites.
- Faites entrer tous les achats dans la même enveloppe.
- Notez le compromis accepté et la condition qui ferait changer de choix.

L’étape suivante consiste à examiner les temps de trame et les ralentissements, puis à ouvrir une discussion avec les paramètres de votre scénario. Une réponse communautaire sera plus précise avec ce dossier qu’avec la seule question « Quelle est la meilleure configuration ? ».''',
'emploi':r'''Une offre d’emploi est utile si elle permet de comprendre le travail et de décider s’il vaut la peine de poursuivre l’échange. Le titre du poste et une liste de qualités ne suffisent pas. Pour la lire, séparez trois choses : ce qui sera fait, les conditions dans lesquelles ce sera fait et la manière dont une candidature sera évaluée.

## Transformer chaque formule en question concrète

« Autonome », « dynamique » ou « à l’aise dans un environnement exigeant » décrivent peu le quotidien. Cherchez l’action observable derrière la formule. L’autonomie signifie-t-elle préparer une proposition, décider seul dans un périmètre défini ou conduire une mission sans accompagnement ? Ces situations demandent des informations différentes.

Pour chaque mission, demandez un exemple des premières semaines : un livrable, un interlocuteur, un outil et une règle de validation. Le but est de comprendre l’organisation, sans exiger de l’entreprise qu’elle rende publics des documents internes ou l’identité de ses clients.

## Séparer les exigences qui n’ont pas le même statut

| Élément de l’annonce | Question à poser | Conséquence pour la candidature |
|---|---|---|
| Prérequis présenté comme obligatoire | Dans quelle situation doit-il être maîtrisé dès l’arrivée ? | Préparer une preuve ou vérifier si la candidature est pertinente |
| Compétence souhaitée | Peut-elle être acquise pendant la prise de poste ? | Montrer une capacité d’apprentissage et un point de départ |
| Condition de travail | Quelle est la règle et quelles exceptions sont possibles ? | Vérifier la compatibilité avec sa situation |
| Étape de recrutement | Quel résultat sera évalué et sur quels critères ? | Préparer l’entretien ou l’exercice sans deviner les attentes |

Une compétence absente d’un CV n’est pas automatiquement une absence de capacité. Une candidature peut expliquer ce qui est déjà démontré, ce qui est transférable et ce qui reste à apprendre. Cette distinction est plus honnête que l’ajout de mots-clés sans exemple.

## Préparer une matrice de preuves courte

Prenez une mission de l’annonce : « améliorer le suivi des demandes clients ». Une preuve possible peut être un tableau anonymisé, la description d’une réorganisation ou un exercice construit pour montrer le raisonnement. Présentez le contexte, votre rôle exact, le résultat et les limites de ce que le document démontre.

Ne transformez pas une contribution collective en résultat individuel. Si les données sont confidentielles, expliquez la méthode sans publier les fichiers. Une preuve bien délimitée est plus crédible qu’un chiffre spectaculaire impossible à vérifier.

## Lire aussi les conditions et le processus

Conservez séparément rémunération, localisation, présence attendue, horaires, déplacements et modalités de candidature. Une formule comme « télétravail possible » mérite une semaine type : jours de présence, contraintes d’équipe, période d’intégration et règle de modification.

Pour un exercice de recrutement, demandez le temps attendu, le livrable et les critères. Il faut pouvoir distinguer une démonstration de compétence d’un travail opérationnel dont le périmètre ne serait pas annoncé. Les points juridiques précis se vérifient auprès des sources officielles adaptées au pays et au contrat ; cette grille est une méthode de lecture, pas une consultation juridique.

## Poser une question qui aide aussi les autres

Au lieu de « Votre offre est-elle sérieuse ? », citez la condition concernée : « Vous indiquez une présence régulière à Paris : quelle semaine type correspond à ce poste ? ». Une question attachée à la phrase conserve son contexte et évite de répéter le même échange dans plusieurs candidatures.

Avant de postuler, cherchez donc une mission comprise, des conditions suffisamment explicites et une preuve adaptée. Ce trio rend la décision plus solide, même si l’annonce ne répond pas encore à toutes les questions.''',
'pays_expat':r'''Un itinéraire réussi ne remplit pas chaque case du calendrier. Il laisse assez de temps pour se déplacer, comprendre les lieux et absorber les imprévus. Pour préparer un voyage au Japon, commencez par le temps réellement disponible et vos contraintes, puis choisissez les visites. Faire l’inverse produit facilement un programme séduisant sur une carte mais pénible une fois sur place.

## Compter des journées utilisables

Distinguez jours calendaires, journées de visite et temps de transfert. Une arrivée en fin de journée n’équivaut pas à une journée libre ; un changement de logement mobilise aussi du temps pour les bagages et l’installation. Les horaires exacts doivent être vérifiés sur les services et réservations retenus.

Écrivez vos contraintes : mobilité, rythme des enfants, besoin de repos, alimentation, travail à distance ou rendez-vous fixes. Elles ne sont pas des détails à ajouter à la fin. Elles servent à écarter des combinaisons qui resteraient inconfortables même avec un budget plus élevé.

## Regrouper les visites par zones et par priorité

Classez les idées en trois niveaux : indispensable, souhaitable et optionnelle. Regroupez ensuite les lieux proches, en tenant compte des trajets réels plutôt que de la seule distance sur une carte. Une activité optionnelle devient une réserve ; elle ne doit pas obliger à accélérer toutes les autres.

| Bloc du séjour | Ce qu’il faut décider | Ce qu’il faut vérifier |
|---|---|---|
| Première installation | Logement, bagages, rythme de départ | Heure d’arrivée et modalités d’accès |
| Journées dans une même ville | Une priorité et des options proches | Horaires, réservation, accessibilité |
| Changement de ville | Trajet et marge logistique | Service choisi, bagages, arrivée au logement |
| Dernière étape | Retour et rangement du séjour | Horaires confirmés et scénario de secours |

## Tester un programme avec un exemple fictif

Imaginez douze jours calendaires, avec une arrivée tardive et un départ qui impose de rejoindre un aéroport dans la matinée. Retenir dix journées de visite constitue une hypothèse de travail, à corriger selon les horaires réels. Si deux transferts consomment chacun une demi-journée utilisable, il reste neuf équivalents de journées pour les activités.

Cette arithmétique n’indique pas combien de villes il faut visiter. Elle montre le coût d’un ajout : une étape supplémentaire prend du temps de trajet, de préparation et de changement de logement. Un lieu attirant mérite parfois un prochain voyage plutôt qu’une visite précipitée.

## Construire un budget qui raconte le programme

Séparez dépenses confirmées et estimées : transport, hébergement, repas, visites, bagages et réserve. Chaque estimation doit avoir une date et une origine. Un prix observé pour une autre période ou un autre nombre de personnes n’est pas une preuve du coût de votre séjour.

N’achetez pas un forfait de transport parce qu’il semble indispensable à tous les voyageurs. Comparez les trajets que votre itinéraire contient réellement, puis vérifiez les conditions du produit choisi. De même, les formalités d’entrée, assurances et éventuelles obligations se vérifient dans les sources officielles actuelles selon votre situation ; ce dossier ne prétend pas fixer une règle administrative universelle.

## Prévoir une version plus légère

Pour chaque journée importante, préparez une alternative qui demande moins de déplacement ou dépend moins d’une réservation. Ce n’est pas une deuxième liste exhaustive : une seule option réaliste suffit souvent à rendre le programme moins fragile.

Le carnet final doit montrer ce qui est réservé, ce qui reste à décider et ce que l’on peut abandonner sans désorganiser le séjour. Après le voyage, conservez les dates et les conditions de vos retours : les futurs visiteurs pourront comprendre à qui votre conseil est applicable.''',
'artisanat':r'''Pour choisir un kimono ou un yukata à distance, il faut transformer une photographie attirante en informations utilisables : dimensions, matière annoncée, état, usage et entretien. Le nom du vêtement ne suffit pas à garantir son origine, sa composition ou son adaptation à votre situation. Une fiche produit doit permettre de vérifier ces points sans deviner.

## Partir de l’usage prévu

Un vêtement destiné à être porté régulièrement, un achat de collection et une tenue pour un événement n’appellent pas les mêmes arbitrages. Décrivez le contexte et ce que vous êtes prêt à adapter : ajustement, accessoires, entretien ou accompagnement pour l’habillage.

Si un événement comporte des attentes particulières, demandez-les à son organisateur ou à une personne compétente. Une règle de convenance ne doit pas être reconstruite à partir d’une seule photographie de boutique. La distinction entre information de vente et conseil culturel mérite d’être conservée.

## Demander des mesures dont on comprend la méthode

Une taille en lettres ne remplace pas les dimensions du vêtement. Demandez les mesures pertinentes, leurs unités et la façon dont elles ont été prises. Les illustrations doivent montrer les points de départ et d’arrivée ; sinon deux nombres apparemment comparables peuvent décrire des mesures différentes.

| Point à éclaircir | Preuve ou information utile | Mauvais raccourci à éviter |
|---|---|---|
| Dimensions | Mesures du vêtement et méthode de prise | Déduire la coupe d’une taille standard non expliquée |
| Matière | Composition annoncée et étiquette si disponible | Identifier une fibre avec la seule apparence d’une photo |
| État | Photos rapprochées et défauts décrits | Considérer l’absence de photo comme une absence d’usure |
| Origine | Affirmation précise et document associé | Confondre style japonais et fabrication documentée |

## Relier la matière à l’entretien réellement possible

Ne choisissez pas une matière uniquement pour son prestige supposé. Cherchez les instructions du fabricant ou du vendeur et vérifiez que vous pourrez les respecter. Si elles sont absentes ou contradictoires, faites clarifier ce point avant l’achat. Il serait imprudent d’inventer une procédure de lavage à partir d’un nom de tissu.

Pour une pièce d’occasion, demandez si des transformations ont été réalisées et si elles modifient les dimensions ou l’usage. Une photo de l’ensemble aide à comprendre le vêtement ; des détails servent à vérifier coutures, zones d’usure et réparations annoncées. Ces deux types de vues se complètent.

## Comparer le coût livré, pas seulement le prix affiché

Dans un exemple fictif, un vêtement coûte 120 euros, l’expédition 25 euros et un accessoire nécessaire 30 euros. L’enveloppe connue est déjà de 175 euros avant tout autre coût applicable à la commande. Ce calcul n’indique ni taxe ni droit réel : ces éléments doivent être vérifiés selon la destination et les conditions de vente.

Ajoutez aussi les conditions de retour, les délais et les frais qui pourraient rester à votre charge. Une proposition moins chère peut être moins adaptée si une information décisive manque ou si le retour est difficile à organiser.

## Faire une demande simple au vendeur

Rassemblez vos questions dans un message court : usage prévu, mesure incertaine, détail de matière ou d’état, coût total et délai. Évitez d’exiger une garantie vague comme « authentique » sans expliquer ce que vous cherchez à vérifier.

Une fois l’objet reçu, comparez-le aux informations conservées. Un avis utile décrira la conformité, l’usage et la durée d’observation. Il aidera davantage les autres acheteurs qu’une note isolée fondée uniquement sur la première impression.''',
'business':r'''Un modèle économique est une façon de relier un besoin client à une offre, des coûts et une capacité de livraison. Le choisir ne consiste pas seulement à fixer un prix ou à copier un abonnement qui fonctionne ailleurs. La question décisive est plus concrète : qui obtient quel résultat, qui paie et qu’est-ce que l’entreprise doit mobiliser pour tenir sa promesse ?

## Décrire une transaction avant de dessiner un grand marché

Prenez un client plausible et une situation précise. Écrivez le problème, l’alternative qu’il utilise déjà, le résultat attendu et les conditions d’achat. « Les petites entreprises ont besoin de visibilité » est trop large pour dimensionner une offre. « Un atelier veut recevoir des demandes de devis mieux renseignées » permet déjà de discuter d’un livrable et de ses limites.

Ne transformez pas un entretien intéressé en preuve d’achat. Notez ce que la personne a expliqué, les documents ou usages observés et les questions encore ouvertes. L’intérêt, l’engagement et le paiement sont des étapes distinctes.

## Séparer valeur, prix et coût de livraison

| Élément | Question à résoudre | Trace utile |
|---|---|---|
| Valeur proposée | Quel problème est suffisamment important pour être traité ? | Situation et alternative actuelles du client |
| Prix | Quel montant et quelles conditions seront réellement proposés ? | Offre datée, périmètre et exclusions |
| Coût variable | Que coûte une livraison supplémentaire ? | Temps, achats, sous-traitance et support |
| Capacité | Combien de livraisons peuvent être tenues correctement ? | Planning et responsabilités |
| Trésorerie | Quand les dépenses et encaissements auront-ils lieu ? | Calendrier des flux, pas seulement une marge |

## Faire un calcul limité mais honnête

Supposons un service vendu 800 euros, avec 200 euros de dépenses variables identifiées. La différence de 600 euros ne constitue pas automatiquement un bénéfice : il reste notamment à traiter les autres charges, le temps de travail, la structure de l’activité et les obligations applicables. Les montants de cet exemple sont fictifs.

Si une livraison demande douze heures, quatre ventes mobilisent quarante-huit heures avant les tâches commerciales et administratives. Une promesse de dix livraisons peut donc être incohérente avec le temps disponible, même si chaque vente semble rentable dans un tableau incomplet.

Ce test sert à trouver la question suivante : réduire le périmètre, changer la méthode, déléguer une partie ou revoir le prix. Il ne remplace pas une simulation professionnelle adaptée au statut et au pays de l’activité.

## Tester l’offre sans masquer son niveau de maturité

Présentez un périmètre que vous pouvez réellement livrer. Définissez un résultat, un délai, ce qui est fourni par le client et une règle d’acceptation. Si l’offre est un pilote, dites-le ; ne lui attribuez pas des références ou des performances inexistantes.

Choisissez ensuite un critère pour poursuivre, modifier ou arrêter le test. Ce peut être la qualité des demandes reçues, le temps réel de livraison ou une étape d’engagement définie à l’avance. Un simple nombre de visites ne répond pas à toutes ces questions.

## Conserver une décision révisable

Le dossier doit montrer les hypothèses qui ont justifié le choix et ce qui pourrait les invalider. Une entreprise pourra ainsi expliquer pourquoi son offre a évolué, au lieu de présenter chaque modification comme une nouvelle certitude.

La prochaine étape est de confronter le coût et le calendrier d’encaissement, puis de transformer les questions clients en améliorations du périmètre. Cette continuité rend le modèle économique plus utile qu’un diagramme rempli une seule fois.''',
'investissement':r'''Avant de comparer des placements, il faut comprendre la décision à financer : à quel horizon l’argent pourrait-il être nécessaire, quelle perte serait supportable et quelles contraintes peuvent obliger à sortir plus tôt ? Un rendement affiché ne répond pas à ces questions. Ce dossier propose une méthode d’analyse ; il ne sélectionne pas de produit pour une situation personnelle.

## Définir l’usage de l’argent et les dates possibles

« Long terme » reste vague si une partie de la somme peut servir à un achat ou à une dépense imprévue. Séparez les projets et leurs contraintes. L’horizon annoncé doit être cohérent avec les moments où une sortie pourrait devenir nécessaire, pas seulement avec la durée souhaitée pour obtenir un gain.

Pour chaque scénario, notez ce qui arriverait si la valeur du placement baissait au mauvais moment. La capacité à attendre et la volonté d’attendre sont deux sujets différents : une personne peut accepter intellectuellement une baisse sans disposer de la marge financière nécessaire.

## Rendre le risque observable

| Dimension | Question utile | Ce qu’un chiffre isolé ne montre pas |
|---|---|---|
| Valeur | Quelle baisse peut survenir et comment serait-elle vécue ? | Le rendement moyen ne décrit pas toutes les trajectoires |
| Liquidité | À quelles conditions peut-on sortir ? | Une valeur affichée n’est pas toujours un montant immédiatement disponible |
| Contrepartie | Qui détient, administre ou doit rembourser ? | Un nom commercial ne décrit pas toute la chaîne |
| Coûts | Quels frais s’appliquent à l’achat, à la détention et à la sortie ? | Un seul pourcentage peut laisser de côté plusieurs postes |
| Concentration | Quelles expositions dépendent du même facteur ? | Un nombre élevé de lignes ne suffit pas à démontrer une diversification |

## Calculer un scénario sans le transformer en prévision

Dans un exemple purement mathématique, une somme de 10 000 euros qui progresserait de 4 % par an pendant cinq ans atteindrait environ 12 166,53 euros avant les coûts et prélèvements non inclus. La formule est 10 000 multiplié par 1,04 à la puissance 5. Le taux de 4 % est une hypothèse, pas un rendement attendu.

Si l’hypothèse nette retenue devient 3 % par an, le même calcul donne environ 11 592,74 euros. L’écart illustre la sensibilité du scénario au taux choisi ; il ne prouve pas qu’un produit reproduira l’une de ces trajectoires. Un calcul présenté sans ses hypothèses crée facilement une précision trompeuse.

## Chercher ce qui pourrait invalider le choix

Lisez les documents du produit, identifiez les frais et les conditions de sortie, puis notez les questions que vous ne savez pas encore résoudre. Vérifiez les acteurs et les documents auprès des sources officielles compétentes. Une expérience de membre ou une communication commerciale ne remplace pas ce contrôle.

Écrivez aussi une règle de réexamen. Elle peut être liée à un changement de projet, de situation, de document ou de risque identifié. Décider uniquement après une hausse ou une baisse revient à laisser le dernier résultat réécrire les raisons du choix.

## Discuter sans exposer son patrimoine

Pour poser une question à une communauté, il est souvent suffisant de décrire le mécanisme, l’horizon et le point incertain. Il n’est pas nécessaire de publier ses comptes, ses identifiants ou l’intégralité de ses avoirs.

Une bonne réponse devrait expliquer ses limites et distinguer information générale et recommandation personnelle. La qualité de la décision dépend du dossier et de sa cohérence, pas de la popularité d’un avis ou de la promesse d’un classement de performance.''',
 'traditions':r'''Un grimoire peut être étudié comme un document : qui l’a produit, dans quel contexte, sous quelle forme et à travers quelle transmission ? Cette démarche permet de s’intéresser aux récits et aux pratiques sans transformer chaque formule en fait historique établi ou en mécanisme démontré. La première tâche est de décrire la source avant de l’interpréter.

## Identifier l’objet que l’on est réellement en train de lire

Une photographie de page, une transcription, une traduction et une édition commentée ne sont pas des objets équivalents. Relevez le titre utilisé, l’auteur attribué, la date annoncée, l’édition, la provenance et la personne responsable d’une éventuelle traduction. Quand une information manque, conservez ce manque au lieu de le remplacer par une supposition.

L’ancienneté revendiquée dans un texte n’établit pas à elle seule la date du document consulté. De même, une copie numérique peut reproduire une édition récente qui reprend des éléments plus anciens. Il faut garder distinctes la date du récit, celle de son témoin matériel et celle de l’édition accessible.

## Séparer les niveaux de lecture

| Niveau | Question | Formulation prudente |
|---|---|---|
| Description | Que voit-on sur la page ou dans l’édition ? | « Le passage contient cette formulation » |
| Attribution | À qui et à quelle période le texte est-il rattaché ? | « L’édition attribue le texte à… » |
| Interprétation | Quel sens propose-t-on dans ce contexte ? | « Une lecture possible est… » |
| Allégation | Le texte prétend-il produire un effet dans le monde ? | « Le document affirme…, ce qui demande une preuve distincte » |

Cette séparation n’appauvrit pas le texte. Elle permet au contraire de discuter une hypothèse sans demander au lecteur d’accepter toutes les autres en bloc.

## Construire une fiche de passage révisable

Pour un passage choisi, notez son emplacement, sa transcription et les difficultés de lecture. Ajoutez ensuite les variantes d’une autre édition en indiquant exactement d’où elles proviennent. Une différence peut venir d’une traduction, d’une modernisation ou d’un choix éditorial ; l’observer ne suffit pas à en expliquer l’origine.

Dans un exemple de travail, une édition écrit « cueillir au matin » et une autre « cueillir avant le lever du soleil ». La divergence mérite d’être conservée et comparée à leurs sources. Elle ne permet pas, à elle seule, de reconstituer une pratique générale ou de démontrer un effet du moment de cueillette. Cet exemple est fictif et ne constitue pas une citation historique.

## Ne pas confondre étude culturelle et conseil de santé

Un texte peut mentionner une plante, une préparation ou une ingestion. Son intérêt historique n’autorise pas à reproduire la recette. L’identification, la toxicité, les interactions et la situation d’une personne demandent d’autres compétences et d’autres preuves. Une photographie ou un nom vernaculaire peuvent laisser subsister une ambiguïté importante.

Un dossier documentaire doit donc éviter de transformer une description ancienne en recommandation pratique. Il peut expliquer ce que la source dit et pourquoi cela mérite une vérification, tout en maintenant une limite claire sur l’usage.

## Partager une enquête plutôt qu’une certitude fabriquée

Conservez les références d’édition, les droits applicables aux images et l’attribution des transcriptions ou traductions. Si une interprétation change, ajoutez la correction et la nouvelle référence au dossier.

Une discussion collective devient productive lorsqu’elle porte sur un passage repérable et sur la nature exacte d’un désaccord. Il est alors possible d’enrichir le lexique, de comparer les versions et de documenter les zones d’incertitude sans transformer les traditions en un ensemble de réponses invérifiables.''',
'paranormal':r'''Devant une observation inhabituelle, la première décision utile n’est pas de nommer sa cause. C’est de conserver assez d’informations pour que quelqu’un d’autre puisse examiner le dossier. Une vidéo impressionnante accompagnée de quelques mots peut laisser beaucoup moins de possibilités d’analyse qu’un document moins spectaculaire mais correctement contextualisé.

## Préserver le document reçu et décrire son origine

Gardez une copie du fichier tel qu’il a été obtenu, puis travaillez sur une copie distincte. Notez qui l’a fourni, par quel canal et si une recompression ou un montage est déjà connu. Le terme « original » doit être réservé à ce que l’on peut effectivement établir ; un fichier transmis par messagerie peut déjà avoir été transformé.

Une empreinte cryptographique permet de comparer des fichiers : la même empreinte calculée avec le même algorithme sert à vérifier que les données comparées sont identiques selon ce contrôle. Elle ne prouve ni l’auteur de l’image, ni la date réelle de la scène, ni l’explication du phénomène. Il faut distinguer l’intégrité suivie dans le dossier et l’authenticité revendiquée du contenu.

## Recueillir les observations avant les interprétations

Demandez ce qui a été vu, pendant combien de temps et dans quelles conditions. Conservez séparément le récit spontané et les hypothèses apparues ensuite. Des réponses obtenues après avoir proposé une explication peuvent être plus difficiles à interpréter.

| Information | Ce qu’il faut conserver | Limite à rappeler |
|---|---|---|
| Temps | Heure annoncée, fuseau et origine de l’horodatage | L’heure d’un appareil peut être incorrecte |
| Lieu | Zone utile et direction d’observation | Une adresse personnelle n’a pas à être publiée |
| Prise de vue | Appareil, réglages connus, zoom, mouvements | Une information absente ne se devine pas de façon fiable |
| Transmission | Fichier reçu, canal et transformations connues | Une copie partagée n’est pas nécessairement le fichier de capture |

## Comparer des hypothèses qui peuvent être mises en difficulté

Écrivez plusieurs explications possibles et, pour chacune, l’information qui permettrait de la tester. Évitez de compter une même source plusieurs fois : dix republications d’une vidéo ne sont pas dix observations indépendantes.

Supposons qu’une lumière paraisse se déplacer rapidement dans une séquence. Sans distance suffisamment connue, un déplacement dans l’image ne fournit pas directement une vitesse réelle. Le dossier doit d’abord préciser ce qui est mesuré : pixels, angle estimé, durée ou distance. Transformer une donnée manquante en valeur implicite produit un résultat apparemment exact mais fragile.

## Montrer les manipulations et les limites

Si vous stabilisez, recadrez ou augmentez le contraste d’une image, conservez les paramètres et l’objectif de la manipulation. Une version améliorée pour la lecture ne doit pas remplacer silencieusement le document de départ.

Les métadonnées et les recherches d’images peuvent aider à poser des questions, mais leurs résultats se vérifient dans leur contexte. L’absence d’une correspondance ou d’un champ ne suffit pas à démontrer qu’un document est nouveau ou authentique.

## Publier un état du dossier, pas une conclusion forcée

Un compte rendu utile distingue documents disponibles, observations, hypothèses écartées et questions ouvertes. Il doit accepter une correction et garder son historique. La boîte à outils publique de Bellingcat peut servir de point d’entrée vers des moyens d’enquête ; elle ne dispense pas de comprendre les limites de chaque outil.

La formulation « non expliqué avec les éléments disponibles » décrit un état de connaissance. Elle ne donne pas, à elle seule, une cause au phénomène.''',
'manga':r'''Une discussion sur une série peut accueillir des lecteurs à des étapes différentes, à condition de rendre sa frontière de spoilers visible. Un simple avertissement au milieu d’un message arrive trop tard si le titre, une vignette ou la première phrase révèle déjà l’information. Le niveau de lecture doit être défini avant de commencer l’échange.

## Décrire précisément le périmètre autorisé

Indiquez l’œuvre, la version et le point de progression : manga ou adaptation, chapitre, épisode ou volume. Ces repères ne sont pas toujours interchangeables. Si une correspondance entre versions est incertaine, il vaut mieux ouvrir deux espaces plutôt que de supposer une équivalence.

La frontière doit préciser ce qui est permis : éléments déjà montrés, références à une adaptation différente, interviews ou informations promotionnelles. Un lecteur peut connaître tous les épisodes disponibles et ne pas souhaiter voir une révélation provenant d’un support qu’il n’a pas consulté.

## Séparer les zones de contribution

| Zone | Contenu adapté | Ce qu’il faut éviter |
|---|---|---|
| Présentation publique | Question et niveau de lecture, sans révélation | Un titre qui donne la réponse à un mystère |
| Discussion au niveau annoncé | Scènes déjà accessibles et arguments associés | Une allusion à une révélation ultérieure présentée comme anodine |
| Zone volontairement dévoilée | Contenu explicitement annoncé comme spoiler | Une révélation dans l’aperçu ou la notification |
| Comparaison entre versions | Références et limites propres à chaque support | Une équivalence supposée sans vérification |

Une protection de spoiler ne remplace pas une permission d’accès privée. Elle organise le confort de lecture de contenus qui peuvent rester publics. Cette distinction évite de croire qu’une information révélée volontairement dans une page ne pourra jamais être retrouvée ailleurs.

## Argumenter sans annoncer ce que l’autre ne sait pas encore

Prenez un personnage fictif qui abandonne une mission dans une scène précoce. Un lecteur peut analyser ce choix avec les informations déjà montrées : dialogue, cadrage, action précédente. Il ne doit pas faire reposer son argument sur une révélation future en écrivant seulement « vous comprendrez plus tard ».

Cet exemple inventé permet de distinguer une analyse située d’un commentaire rétrospectif. Les deux peuvent être intéressants, mais ils ne s’adressent pas au même espace de discussion.

## Conserver le contexte d’une réponse

Lorsqu’une question porte sur une réplique ou une scène, citez son emplacement et le niveau de lecture concerné. Distinguez ce qui est explicitement montré de votre interprétation. Une théorie peut être examinée avec des indices et une condition qui l’invaliderait ; elle ne devient pas un fait parce qu’elle recueille de nombreuses réactions.

Les résumés, titres de liens et vignettes demandent la même attention que le corps du message. Une discussion correctement masquée peut être rendue inutile par une notification qui en révèle le contenu.

## Faire progresser le club de lecture sans fermer les anciennes étapes

Gardez des fils par paliers pour que les nouveaux lecteurs puissent rejoindre la conversation. Quand le groupe avance, ouvrez un nouveau périmètre et reliez-le à l’ancien sans réécrire les premières impressions.

La qualité de la communauté ne dépend pas de la vitesse à laquelle tout le monde termine l’œuvre. Elle dépend de la possibilité d’argumenter à l’intérieur d’un contexte compris et consenti. Un titre sobre, un niveau explicite et des exemples repérables suffisent déjà à rendre l’échange beaucoup plus accueillant.''',
'gastronomie':r'''Un couteau de cuisine se choisit pour des tâches et des gestes, pas pour une réputation seule. Avant de comparer les noms d’acier ou les prix, demandez ce que vous coupez, sur quelle surface et quelles habitudes d’entretien vous pourrez tenir. Un outil adapté à une personne expérimentée peut être inutilement contraignant pour un premier équipement.

## Décrire les tâches les plus fréquentes

Listez trois préparations habituelles et les opérations qu’elles demandent : émincer, détailler, parer ou portionner. Notez aussi ce qui ne devrait pas être réalisé avec le couteau envisagé selon les instructions du fabricant. Un outil spécialisé n’est pas automatiquement un remplacement de tous les autres.

La prise en main doit être évaluée avec prudence. Une impression de confort sur une photographie ne remplace pas la possibilité d’essayer un manche, de comprendre le poids annoncé ou de vérifier les conditions de retour. Si vous manipulez l’objet, respectez les consignes du vendeur et évitez tout essai improvisé dangereux.

## Comparer des informations qui changent l’usage

| Critère | Question concrète | Information à demander |
|---|---|---|
| Tâches | Quels aliments et quelles opérations reviennent souvent ? | Usages et restrictions annoncés pour la référence |
| Dimensions | L’outil est-il compatible avec le plan de travail et le rangement ? | Longueur utile, encombrement et protection de la lame |
| Entretien | Quelles opérations faudra-t-il réellement effectuer ? | Instructions précises, matériel et fréquence à adapter à l’usage |
| Manipulation | Le poids et le manche conviennent-ils à la personne ? | Mesures et possibilités d’essai ou de retour |
| Budget | Qu’est-ce qui est nécessaire en plus de la lame ? | Protection, entretien et éventuels services associés |

Une valeur de dureté ou le nom d’un matériau ne résume pas le comportement d’un couteau. La géométrie, l’état du tranchant, l’usage et l’entretien font aussi partie de la comparaison. Pour une référence précise, demandez les caractéristiques et instructions au fabricant plutôt que de déduire une procédure à partir d’une appellation générale.

## Comparer deux enveloppes complètes

Dans un exemple fictif, le couteau A coûte 90 euros et demande 30 euros d’équipement d’entretien et de rangement retenu dans le projet. Le couteau B coûte 110 euros avec un équipement supplémentaire estimé à 10 euros. Les deux enveloppes arrivent à 120 euros, sans être pour autant équivalentes.

Il reste à comparer les tâches, les contraintes et le service. Ces montants servent uniquement à montrer la méthode de calcul ; ils ne décrivent ni une offre actuelle ni un niveau de qualité attendu à ce prix.

## Préparer la réception et l’entretien

Vérifiez la référence reçue, les accessoires annoncés et les éventuels défauts visibles sans effectuer de geste risqué pour « tester » le tranchant. Conservez les instructions et les conditions de garantie ou de retour.

L’entretien doit suivre les consignes applicables à l’objet. S’il existe une incertitude sur une réparation ou sur une lame abîmée, un avis compétent vaut mieux qu’une méthode générique trouvée dans une discussion. Ne confondez pas l’entretien courant avec une intervention qui peut modifier la géométrie ou aggraver un défaut.

## Écrire un avis qui aide le prochain acheteur

Décrivez la durée d’usage, les tâches effectuées et les conditions. Séparez conformité à la fiche, confort personnel et qualité du service. Un point fort peut être important pour vous et secondaire pour une autre cuisine.

Le bon premier choix est donc celui dont vous comprenez les usages et les contraintes, dans une enveloppe cohérente avec votre équipement. Il ne faut pas posséder toute une collection pour préparer un dossier d’achat sérieux.''',
'sports':r'''Reprendre une activité physique commence par une situation réelle : temps disponible, pratique envisagée, expérience, contraintes et besoin éventuel d’un avis professionnel. Choisir immédiatement un programme standard peut masquer la question la plus utile : qu’est-ce qui rendra la prochaine séance appropriée et réellement praticable ? Ce dossier aide à préparer cet échange ; il ne prescrit pas un entraînement individuel.

## Définir un objectif que l’on peut observer

« Me remettre en forme » peut recouvrir des attentes très différentes. Une personne souhaite rejoindre un cours collectif ; une autre veut retrouver une habitude de déplacement ou préparer une pratique particulière. Décrivez l’activité visée et une situation qui montrerait une amélioration, sans choisir un indicateur uniquement parce qu’il est facile à afficher.

Un objectif n’est pas une obligation de progresser à la même vitesse qu’un autre membre. Il doit pouvoir être ajusté lorsque le contexte change. Si un problème de santé, une douleur ou une inquiétude particulière intervient, la décision adaptée relève d’un professionnel compétent, pas d’un classement communautaire.

## Préparer les informations utiles à l’encadrant

| Dimension | Ce qu’il est utile de clarifier | Ce qui peut rester privé dans la communauté |
|---|---|---|
| Pratique | Activité envisagée et expérience pertinente | Détails personnels sans intérêt pour la discussion |
| Organisation | Créneaux, déplacements et régularité possible | Adresse ou emploi du temps détaillé |
| Accompagnement | Accueil des débutants et modalités de progression | Documents de santé à transmettre uniquement au bon interlocuteur |
| Conditions | Équipement, règles et coûts annoncés | Informations financières personnelles |
| Réexamen | Quand faire le point et avec qui ? | Données que l’on ne souhaite pas partager publiquement |

Pour un club, demandez comment se déroule une première séance, qui encadre et comment sont gérées les différences de niveau. Les réponses doivent être concrètes : déroulé, interlocuteur et conditions d’accueil. Une promesse générale d’adaptation ne remplace pas cette compréhension.

## Réduire la friction avant de rechercher l’intensité

Prenons un exemple d’organisation, sans prescription d’effort. Une personne dispose de deux créneaux possibles dans sa semaine, mais l’un exige un trajet difficile à tenir. Choisir le créneau le plus réaliste peut être plus utile que construire un calendrier théorique qui échoue dès la deuxième semaine.

Préparer le sac, comprendre la réservation et identifier le trajet de retour sont de petites décisions, mais elles influencent la possibilité de participer. Ce raisonnement porte sur l’organisation ; le contenu et l’intensité des séances doivent être adaptés au contexte et à l’encadrement.

## Tenir une trace courte et interprétable

Après une séance, quelques informations peuvent suffire : activité réalisée, contexte, ressenti utile et question à poser. Évitez de transformer chaque mesure issue d’un appareil en diagnostic ou en obligation quotidienne.

Une observation isolée demande souvent du contexte. Un mauvais résultat ou une séance manquée ne démontre pas à lui seul que le projet est mal choisi. La trace sert à préparer une discussion et à repérer une tendance, pas à produire automatiquement une conclusion médicale.

## Prévoir un point de révision

Fixez avec l’interlocuteur approprié le moment où l’on vérifiera si l’organisation et les objectifs conviennent. Notez aussi les questions qui ne peuvent pas être résolues par des conseils généraux.

Une communauté accueillante aide à formuler ces questions, à comprendre les conditions d’une pratique et à partager des expériences bien délimitées. Elle ne doit pas transformer une reprise en compétition de chiffres ni attribuer à tous les membres le même besoin d’entraînement.''',
 'tech':r'''Une IA locale peut mieux répondre après l’ajout d’un document sans que les paramètres de son modèle de langage aient changé. Cette distinction est essentielle pour mesurer ses progrès. Les ressources disponibles, leur indexation, le classement des passages et la génération de réponse forment des mécanismes différents ; chacun peut améliorer ou dégrader le résultat final.

## Dessiner la chaîne avant de choisir un score

Commencez par identifier les étapes : acquisition d’une ressource, extraction de son contenu, contrôle de ses permissions, recherche de passages, classement, puis réponse. Une erreur d’extraction ne se corrige pas nécessairement en changeant le modèle ; un passage pertinent mais privé ne doit pas devenir une réponse publique.

Conservez une référence de la configuration utilisée : modèle, version de l’index, règles de recherche et paramètres utiles à la reproduction. Il n’est pas nécessaire d’exposer ces détails à chaque utilisateur, mais l’équipe doit pouvoir savoir ce qui a changé entre deux évaluations.

| Couche | Amélioration possible | Test adapté |
|---|---|---|
| Ressources | Une information autorisée devient disponible | Retrouver le document, sa provenance et sa date |
| Extraction | Le texte ou la transcription devient exploitable | Comparer le passage extrait au document source |
| Recherche et classement | Le bon passage remonte plus haut | Juger les passages trouvés pour les mêmes questions |
| Génération | La réponse utilise correctement les éléments fournis | Vérifier exactitude, citations et traitement de l’incertitude |
| Permissions | Une source retirée cesse d’être révélée | Tester les comptes, niveaux d’accès et changements de statut |

## Construire un jeu de questions qui peut contredire la promesse

Préparez des questions dont la réponse est connue, d’autres qui demandent plusieurs sources et certaines auxquelles le système ne devrait pas répondre. Ajoutez des cas où une source a été modifiée, retirée ou rendue privée. Le test ne doit pas seulement contenir les démonstrations qui réussissent déjà.

Séparez les exemples utilisés pour ajuster le système de ceux qui servent à décider si le changement est retenu. Si les mêmes questions pilotent les réglages et justifient le résultat final, le gain observé peut refléter une adaptation au test plutôt qu’une amélioration utile ailleurs.

## Mesurer plusieurs résultats sans inventer une note d’intelligence

Dans un exemple fictif de vingt questions, douze réponses vérifiables sur une première configuration et quinze sur une seconde correspondent à 60 % et 75 % sur ce petit jeu. Ce calcul ne démontre ni un gain général de quinze points sur toutes les tâches ni une certitude statistique. Il faut examiner les trois améliorations, les éventuelles régressions et la manière dont les réponses ont été jugées.

Une citation doit être vérifiée au niveau du passage : la source contient-elle réellement l’information invoquée, et le lecteur a-t-il le droit d’y accéder ? Afficher un titre de document ne suffit pas à valider le contenu de la réponse.

## Tester les permissions comme une fonction de qualité

L’authentification vérifie le compte ; l’autorisation détermine ce qu’il peut consulter ou modifier. La fiche OWASP sur l’authentification aide à clarifier cette première frontière, mais un accès correct demande aussi des contrôles sur les ressources et leurs champs.

Testez un membre autorisé, un autre membre, un visiteur et une ressource devenue privée. Les réponses, résumés, historiques et caches doivent respecter le changement. Un système qui retrouve davantage de documents mais révèle une information interdite n’est pas simplement « plus performant ».

## Rendre les progrès visibles et réversibles

Publiez le périmètre mesuré, la version retenue, les cas en régression et la possibilité de revenir à une version validée. Si aucune comparaison n’a encore été faite, dites-le au lieu d’afficher un pourcentage de progression.

La prochaine amélioration se choisit alors à partir d’un défaut observé : document manquant, extraction faible, classement inadapté ou réponse non étayée. Cette approche transforme l’ambition d’une IA qui apprend en une suite de décisions vérifiables.'''
}

def render(md):
 out=[];lines=md.strip().splitlines();i=0
 while i<len(lines):
  line=lines[i].strip()
  if not line:i+=1;continue
  if line.startswith('## '):out.append('<h2>'+html.escape(line[3:])+'</h2>');i+=1;continue
  if line.startswith('|'):
   rows=[]
   while i<len(lines)and lines[i].strip().startswith('|'):
    cells=[c.strip()for c in lines[i].strip().strip('|').split('|')]
    if not all(re.fullmatch(r':?-+:?',c)for c in cells):rows.append(cells)
    i+=1
   out.append('<div class="table-responsive"><table><thead><tr>'+''.join('<th scope="col">'+html.escape(c)+'</th>'for c in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(c)+'</td>'for c in row)+'</tr>'for row in rows[1:])+'</tbody></table></div>');continue
  if line.startswith('- '):
   items=[]
   while i<len(lines)and lines[i].strip().startswith('- '):items.append(lines[i].strip()[2:]);i+=1
   out.append('<ul>'+''.join('<li>'+html.escape(x)+'</li>'for x in items)+'</ul>');continue
  para=[]
  while i<len(lines)and lines[i].strip()and not lines[i].startswith(('## ','|','- ')):para.append(lines[i].strip());i+=1
  out.append('<p>'+html.escape(' '.join(para))+'</p>')
 return '\n'.join(out)
records=json.loads((ROOT/'catalogue-420.json').read_text());out=[]
for u,md in ARTICLES.items():
 r=next(x for x in records if x['universe']==u and x['kind']=='article');(ROOT/'content'/(r['key']+'.md')).write_text('# '+r['title']+'\n\n'+md.strip()+'\n');body=render(md)
 out.append(r|{'state':'draft_written_requires_editorial_signoff','body_html':body,'word_count':len(re.findall(r"[\w’'-]+",md)),'meta_description':md.split('\n\n')[0][:157].rsplit(' ',1)[0]+'…','related_content_keys':[u+'-article-02',u+'-discussion-01'],'illustration':{'path':'illustrations/'+r['key']+'.webp','width':1200,'height':675,'alt':'Méthode de décision : '+r['title']},'claims_policy':'No invented personal experience, review, price, traffic or professional credential. Numerical examples are hypothetical.'})
(ROOT/'articles-premier-lot-12.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('First authored article batch:',len(out),'words',sum(x['word_count']for x in out),'minimum',min(x['word_count']for x in out))
