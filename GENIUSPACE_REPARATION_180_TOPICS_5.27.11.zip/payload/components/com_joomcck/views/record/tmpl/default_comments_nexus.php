<?php
/** Nexus comment card — uses JoomCCK native comment controller / ACL. */
defined('_JEXEC') or die;
require_once JPATH_ROOT . '/components/com_joomcck/library/php/geniuspace/NexusSuite.php';
require_once JPATH_ROOT . '/components/com_joomcck/library/php/geniuspace/NexusParticipation.php';
require_once JPATH_ROOT . '/components/com_joomcck/library/php/geniuspace/NexusParticipationUI.php';
\NexusSuite::assets();
\NexusParticipationUI::assets();
$c = $this->comment ?? null;
if (!$c || (int)($c->id ?? 0) < 1) return;
if (empty($c->published) && empty($c->canmoderate) && !(($this->user->id??0)>0 && (int)($c->user_id??0)===(int)$this->user->id)) return;
if(!empty($c->hide)&&!(($this->user->id??0)>0&&(!empty($c->canmoderate)||(int)($c->user_id??0)===(int)$this->user->id)))return;
$e = [NexusSuite::class, 'e'];
$id = (int)$c->id;
$public = NexusSuite::publicComment($c);
$style = class_exists('NexusParticipation') ? NexusParticipation::commentStyle($c) : [];
$isSelf = (int)($this->user->id ?? 0) > 0 && (int)($c->user_id ?? 0) === (int)$this->user->id;
$depth = max(0, min(8, (int)($this->nexusCommentDepth ?? max(0, (int)($c->level ?? 1) - 1))));
$author = trim((string)($c->name ?? ''));
if ($author === '' && !empty($c->user_id)) $author = NexusSuite::plain(CCommunityHelper::getName((int)$c->user_id, $this->section));
if ($author === '') $author = 'Member';
$displayDate = NexusSuite::iso($c->created ?? $c->ctime ?? null);
$initial = function_exists('mb_substr') ? mb_substr($author,0,1,'UTF-8') : substr($author,0,1);
$canReply = $public && isset($this->tmpl_params['comment']) && (int)$this->tmpl_params['comment']->get('tmpl_core.comments_nested', 1) > (int)($c->level ?? 1);
$canRate = !empty($c->canrate);
$canPost = MECAccess::allowCommentPost($this->type,$this->item,$this->section);
$replyUrl = \Joomla\CMS\Router\Route::_('index.php?option=com_joomcck&view=comment&record_id='.(int)$this->item->id.'&parent_id='.$id.'&id=0',false);
$allowRateView = in_array($this->type->params->get('comments.comments_rate_view', 1), $this->user->getAuthorisedViewLevels());
$path = NexusSuite::url((string)($this->item->url ?? ''));
if (!$path) $path = NexusSuite::url('index.php?option=com_joomcck&view=record&id=' . (int)$this->item->id, true);
$permalink = \Geniuspace\CommentLocator::link($path,$id);
?>
<article data-nxm-author="<?= $e($author) ?>" class="nxm-comment <?= $isSelf ? 'nxm-comment-self' : 'nxm-comment-other' ?> nxm-comment-depth-<?= $depth ?> <?= $e(NexusParticipationUI::classes($style)) ?><?= !$public ? ' nxm-comment-pending' : '' ?><?= !empty($c->private) ? ' nxm-comment-private' : '' ?>" id="comment-<?= $id ?>" data-nxm-comment data-nxm-depth="<?= $depth ?>">
  <div class="nxm-comment-head">
    <div class="nxm-comment-author"><span aria-hidden="true" class="nxm-avatar"><?= $e($initial) ?></span>
      <div><strong><?= $e($author) ?></strong>
        <?php if($displayDate): ?><div class="nxm-comment-date"><time datetime="<?= $e($displayDate) ?>"><?= $e(date('Y-m-d H:i', strtotime($displayDate))) ?></time></div><?php endif; ?>
      </div>
    </div>
    <div class="nxm-comment-author">
      <?php if (!$public): ?><span class="nxm-pill"><?= $e(!empty($c->private) ? NexusSuite::t('private') : NexusSuite::t('pending')) ?></span><?php endif; ?>
      <?php if ($allowRateView): ?><span id="comment_rate_control_<?= $id ?>" class="nxm-score" aria-label="<?= $e(NexusSuite::t('vote')) ?>">▲ <?= (int)($c->rate ?? 0) ?></span><?php endif; ?>
    </div>
  </div>
  <?= NexusParticipationUI::badge($style) ?>
  <?= \Geniuspace\ContextQuestions::render($c).\Geniuspace\VideoMoments::render($c).\Geniuspace\ForumReviews::commentDetails($c) ?>
  <div class="nxm-comment-body"><?= NexusSuite::commentHtml($c->comment ?? '') ?></div>
  <?php if(!empty($c->attachment) && is_iterable($c->attachment)): ?>
    <div class="nxm-dialog-note"><?= $e(NexusSuite::t('attachment')) ?></div><ul class="nxm-attachment-list">
      <?php foreach($c->attachment as $attach):
        $attachUrl = NexusSuite::url((string)($attach->url ?? '')); if (!$attachUrl) continue; ?>
        <li><?php if(in_array(strtolower((string)($attach->ext??'')),['jpg','jpeg','png','webp','avif','gif'],true)): $image=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=files.commentImage&id='.(int)$attach->id.'&comment_id='.$id; ?><figure class="nx-comment-image"><img src="<?= $e($image) ?>" alt="<?= $e(($attach->title??'')?:pathinfo((string)$attach->realname,PATHINFO_FILENAME)) ?>" width="<?= max(1,(int)($attach->width??800)) ?>" height="<?= max(1,(int)($attach->height??600)) ?>" loading="lazy" decoding="async"><?php if(!empty($attach->description)): ?><figcaption><?= $e($attach->description) ?></figcaption><?php endif; ?></figure><?php endif; ?>↧ <a href="<?= $e($attachUrl) ?>" rel="nofollow ugc"><?= $e($attach->realname ?? 'File') ?></a></li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
  <div class="nxm-comment-actions">
    <?php if($public && $this->user->id && in_array((int)$this->type->params->get('comments.comments_report_access',2),$this->user->getAuthorisedViewLevels(),true)): ?><button type="button" class="nxm-button" data-nxm-report="<?= $id ?>" data-nxm-token="<?= $e(\Joomla\CMS\Session\Session::getFormToken()) ?>" data-nxm-endpoint="<?= $e(\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=comment.report&tmpl=component') ?>"><?= $e(str_starts_with(NexusSuite::locale(),'fr')?'Signaler':'Report') ?></button><?php endif; ?>
    <?php if(!empty($c->canmoderate)): $reports=(new \Joomla\Registry\Registry($c->params??'{}'))->get('nexus_reports',[]);if($reports): ?><details class="nxm-reports"><summary>⚑ <?= count((array)$reports) ?></summary><?php foreach((array)$reports as$report): ?><p><?= $e(is_object($report)?($report->reason??''):($report['reason']??'')) ?></p><?php endforeach; ?></details><?php endif;endif; ?>
    <?php if ($public): ?><button type="button" class="nxm-button" data-nxm-copy="<?= $e($permalink) ?>" title="<?= $e(NexusSuite::t('copy')) ?>">↗ <?= $e(NexusSuite::t('share')) ?></button><?php endif; ?>
    <?php if ($public): ?>
      <a href="<?= $e($replyUrl) ?>" data-nxm-parent="<?= $canReply?$id:1 ?>" class="nxm-button" data-nxm-cite data-nxm-author="<?= $e($author) ?>" data-nxm-link="<?= $e($permalink) ?>">❝ <?= $e(NexusSuite::t('cite')) ?></a>
      <button type="button" class="nxm-button" data-nxm-perspective="<?= $e($author) ?>">◉ <?= $e(NexusSuite::t('perspective')) ?></button>
    <?php endif; ?>
    <?php if ($canReply && $canPost): ?><a class="nxm-button nxm-button-primary" href="<?= $e($replyUrl) ?>" data-nxm-reply="<?= $id ?>" data-nxm-author="<?= $e($author) ?>">↳ <?= $e(NexusSuite::t('reply')) ?></a><?php endif; ?>
    <?php if ($canRate && $allowRateView): ?>
      <button type="button" class="nxm-button" onclick="ajax_rateComment(<?= $id ?>,1)" aria-label="<?= $e(NexusSuite::t('vote')) ?> +1">▲</button>
      <button type="button" class="nxm-button" onclick="ajax_rateComment(<?= $id ?>,0)" aria-label="<?= $e(NexusSuite::t('vote')) ?> -1">▼</button>
    <?php endif; ?>
    <?php if(!empty($c->canedit)): ?><button class="nxm-button" type="button" onclick="Joomcck.editComment(<?= $id ?>, <?= $e(json_encode(NexusSuite::t('edit'), JSON_HEX_QUOT | JSON_HEX_APOS | JSON_HEX_TAG)) ?>)"><?= $e(NexusSuite::t('edit')) ?></button><?php endif; ?>
    <?php if(!empty($c->candelete)): ?><button class="nxm-button" type="button" onclick="deleteComment(<?= $id ?>,this)"><?= $e(NexusSuite::t('delete')) ?></button><?php endif; ?>
    <?php if(!empty($c->canmoderate)): ?>
      <button type="button" class="nxm-button" onclick="publishComment(<?= $id ?>,'<?= !empty($c->published) ? 'unpublish' : 'publish' ?>',this)"><?= !empty($c->published) ? $e(NexusSuite::t('hide')) : $e(NexusSuite::t('show')) ?></button>
    <?php endif; ?>
  </div>
</article>
