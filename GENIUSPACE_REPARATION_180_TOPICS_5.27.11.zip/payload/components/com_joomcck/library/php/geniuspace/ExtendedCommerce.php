<?php
declare(strict_types=1);
namespace Geniuspace;

/** Native CCK paid fields: server-side prices, signed Stripe events, unique voucher allocation. */
final class ExtendedCommerce
{
    public static function stripe(): Stripe
    {
        $p=\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck');
        return new Stripe((string)$p->get('geniuspace_stripe_secret',''),(string)$p->get('geniuspace_stripe_webhook',''),(bool)$p->get('geniuspace_stripe_live',0));
    }
    public static function input(object $f): string
    {
        ExtendedFields::assets();$pay=(array)($f->pay??$f->value['pay']??[]);$name='jform[fields]['.(int)$f->id.'][pay]';$currency=strtoupper((string)($pay['default_currency']??$f->params->get('pay.default_currency','EUR')));
        $out='<div class="gp-ext gp-price"><label>Prix <input class="form-control" type="number" min="0" max="1000000" step="0.01" name="'.$name.'[amount]" value="'.ExtendedFields::e($pay['amount']??$f->params->get('pay.default_amount',0)).'"></label><label>Devise <select class="form-select" name="'.$name.'[default_currency]">';
        foreach(['EUR','USD','GBP','CNY','JPY']as$c)$out.='<option'.($c===$currency?' selected':'').'>'.$c.'</option>';
        return $out.'</select></label></div>';
    }
    public static function button(object $f): string
    {
        if(!self::stripe()->ready())return '<p class="alert alert-info">Configurez Stripe dans les options JoomCCK pour activer le paiement.</p>';
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id)return '<p class="alert alert-info">Connectez-vous pour acheter.</p>';
        $id=(int)$f->record->id;$field=(int)$f->id;$action=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.extendedPay';$nonce=bin2hex(random_bytes(24));$session=\Joomla\CMS\Factory::getApplication()->getSession();$nonces=(array)$session->get('gp.checkout.nonces',[]);$nonces[$nonce]=[$id,$field,time()];$session->set('gp.checkout.nonces',array_slice($nonces,-30,null,true));
        return '<form method="post" action="'.ExtendedFields::e($action).'" class="gp-ext gp-buy"><input type="hidden" name="record_id" value="'.$id.'"><input type="hidden" name="field_id" value="'.$field.'"><input type="hidden" name="nonce" value="'.$nonce.'"><input type="hidden" name="'.\Joomla\CMS\Session\Session::getFormToken().'" value="1"><button class="btn btn-primary" type="submit">Acheter · '.ExtendedFields::e($f->pay['amount']??0).' '.ExtendedFields::e($f->pay['default_currency']??'EUR').'</button></form>';
    }
    private static function field(int $record,int $field): array
    {
        $db=ExtendedFields::db();$db->setQuery('SELECT r.*,f.params AS field_params,f.access AS field_access,f.field_type,t.published AS type_published,s.params AS section_params FROM #__js_res_record r INNER JOIN #__js_res_fields f ON f.type_id=r.type_id INNER JOIN #__js_res_types t ON t.id=r.type_id INNER JOIN #__js_res_sections s ON s.id=r.section_id WHERE r.id='.$record.' AND f.id='.$field.' AND f.published=1 AND r.published=1 AND r.hidden=0 AND r.archive=0');$r=$db->loadAssoc();
        if(!$r||!in_array($r['field_type'],['paytoaccess','payvoucher','paytodownload'],true))throw new \DomainException('Offre indisponible.',404);
        $p=new \Joomla\Registry\Registry($r['field_params']);$levels=\Joomla\CMS\Factory::getApplication()->getIdentity()->getAuthorisedViewLevels();$section=new \Joomla\Registry\Registry($r['section_params']);
        if(!$r['type_published']||!$section->get('general.status',1)||!in_array((int)$r['access'],$levels,true)||!in_array((int)$r['field_access'],$levels,true)||!in_array((int)$p->get('core.field_view_access',1),$levels,true))throw new \DomainException('Offre inaccessible.',403);
        foreach(['pubtime'=>false,'extime'=>true]as$key=>$expired){$date=$r[$key]??'';if($date&&$date!=='0000-00-00 00:00:00'&&($expired?strtotime($date.' UTC')<=time():strtotime($date.' UTC')>time()))throw new \DomainException('Offre hors de sa période de publication.',403);}
        $db->setQuery('SELECT COUNT(*) FROM #__js_res_record_category rc LEFT JOIN #__js_res_categories c ON c.id=rc.catid WHERE rc.record_id='.$record.' AND (c.id IS NULL OR c.published<>1 OR c.access NOT IN ('.implode(',',$levels?:[0]).') OR c.section_id<>'.(int)$r['section_id'].')');if($db->loadResult())throw new \DomainException('Catégorie inaccessible.',403);
        if($p->get('params.default_gateway','stripe')!=='stripe')throw new \DomainException('Cette offre utilise une autre passerelle.',409);
        $value=json_decode($r['fields']?:'{}',true)[$field]??[];$value=ExtendedFields::commerceValue($value);$amount=(int)round((float)($value['pay']['amount']??0)*100);$cur=strtolower($value['pay']['default_currency']??'EUR');
        // Stripe expects integer yen, unlike the two-decimal currencies supported by this field.
        if($cur==='jpy')$amount=(int)round((float)$value['pay']['amount']);
        if($amount<=0)throw new \DomainException('Cette offre ne nécessite pas de paiement.',422);
        return [$r,$value,$amount,$cur];
    }
    /** Authoritative inventory includes paid codes and reservations awaiting a signed expiration. */
    public static function remaining(int $record,int $field,string $inventory): array
    {
        $s=new Store(ExtendedFields::db());$used=array_column($s->rows('SELECT code_hash FROM #__gp_social_extended_vouchers WHERE record_id='.$record.' AND field_id='.$field,5001),'code_hash');
        return array_values(array_filter(array_unique(array_filter(array_map('trim',explode("\n",str_replace("\r",'',$inventory))))),fn($c)=>!in_array(hash('sha256',$c),$used,true)));
    }
    private static function locked(string $name,callable $callback): mixed
    {
        $db=ExtendedFields::db();$name='gp.extended.'.hash('sha256',$name);$db->setQuery('SELECT GET_LOCK('.$db->quote($name).',5)');if(!(int)$db->loadResult())throw new \DomainException('Paiement en cours. Réessayez.',409);
        try{return $callback();}finally{$db->setQuery('SELECT RELEASE_LOCK('.$db->quote($name).')');$db->loadResult();}
    }
    public static function checkout(int $record,int $field,string $nonce,?Stripe $stripe=null): string
    {
        $app=\Joomla\CMS\Factory::getApplication();$u=$app->getIdentity();if(!$u->id||!\Geniuspace\ExtendedFields::tokenValid('post'))throw new \DomainException('Session ou jeton invalide.',403);
        $n=(array)$app->getSession()->get('gp.checkout.nonces',[]);if(!isset($n[$nonce])||$n[$nonce][0]!==$record||$n[$nonce][1]!==$field||$n[$nonce][2]<time()-3600)throw new \DomainException('Formulaire de paiement expiré.',403);
        [$r,$v,$amount,$currency]=self::field($record,$field);if((int)$r['user_id']===(int)$u->id)throw new \DomainException('Vous êtes propriétaire de cette offre.',409);
        $model=\MModelBase::getInstance('Record','JoomcckModel');$accessible=$model->getItem($record);if(!$accessible||!$accessible->id)throw new \DomainException('Fiche inaccessible.',403);
        $s=new Store(ExtendedFields::db());$token=hash('sha256',$nonce.':'.$u->id.':'.$record.':'.$field);
        return self::locked($record.':'.$field,function()use($s,$token,$record,$field,$u,$r,$amount,$currency,$v,$stripe){
        $existing=$s->rows('SELECT * FROM #__gp_social_extended_orders WHERE token='.$s->q($token),1)[0]??null;
        if($existing&&$existing['state']!=='pending')throw new \DomainException('Cette commande est déjà traitée.',409);
        $created=time();if(!$existing){$id=$s->atomic(function()use($s,$token,$u,$record,$field,$amount,$currency,$r,$v){$code='';if($r['field_type']==='payvoucher'){$code=self::remaining($record,$field,(string)($v['vouchers']??''))[0]??'';if(!$code)throw new \DomainException('Tous les bons sont vendus ou réservés.',409);}
            $id=$s->insert('extended_orders',['token'=>$token,'user_id'=>(int)$u->id,'record_id'=>$record,'field_id'=>$field,'amount'=>$amount,'currency'=>$currency,'snapshot'=>json_encode(['title'=>$r['title'],'seller'=>(int)$r['user_id'],'type'=>$r['field_type'],'section'=>(int)$r['section_id'],'type_id'=>(int)$r['type_id']],JSON_THROW_ON_ERROR),'ctime'=>gmdate('Y-m-d H:i:s')]);
            if($code)$s->insert('extended_vouchers',['record_id'=>$record,'field_id'=>$field,'code_hash'=>hash('sha256',$code),'order_id'=>$id,'code'=>$code]);return $id;});}
        else{$id=(int)$existing['id'];$created=strtotime($existing['ctime'].' UTC');if($created<time()-1800)throw new \DomainException('Cette session a expiré. Rechargez la fiche.',409);if((int)$existing['amount']!==$amount||$existing['currency']!==$currency)throw new \DomainException('Le prix a changé. Rechargez la fiche.',409);}
        $root=\Joomla\CMS\Uri\Uri::root();$return=$root.'index.php?option=com_joomcck&view=record&id='.$record;
        $data=['mode'=>'payment','success_url'=>$return,'cancel_url'=>$return,'client_reference_id'=>(string)$id,'metadata'=>['geniuspace_extended_order'=>(string)$id],'line_items'=>[['price_data'=>['currency'=>$currency,'unit_amount'=>$amount,'product_data'=>['name'=>mb_substr(strip_tags($r['title']),0,200)]],'quantity'=>1]]];
        if($r['field_type']==='payvoucher'){$data['payment_method_types']=['card'];$data['expires_at']=$created+1801;}
        $result=($stripe??self::stripe())->checkout($data,$token);
        $s->run('UPDATE #__gp_social_extended_orders SET checkout_id='.$s->q($result['id']).' WHERE id='.$id.' AND state=\'pending\'');return $result['url'];
        });
    }
    public static function event(string $body,string $signature,?Stripe $stripe=null): void
    {
        $event=($stripe??self::stripe())->verify($body,$signature);$o=$event['data']['object'];$s=new Store(ExtendedFields::db());
        if(!in_array($event['type'],['checkout.session.completed','checkout.session.async_payment_succeeded','checkout.session.expired','charge.refunded','charge.dispute.created'],true))return;
        if(str_starts_with($event['type'],'checkout.')){$id=(int)($o['metadata']['geniuspace_extended_order']??0);if(!$id)return;$where='id='.$id;}
        else{$intent=(string)($o['payment_intent']??'');if(!$intent)return;$where='intent_id='.$s->q($intent);}
        $candidate=$s->rows('SELECT record_id,field_id FROM #__gp_social_extended_orders WHERE '.$where,1)[0]??null;if(!$candidate)throw new \DomainException('Commande inconnue.',404);
        self::locked($candidate['record_id'].':'.$candidate['field_id'],function()use($s,$where,$event,$o){$s->atomic(function()use($s,$where,$event,$o){
            $row=$s->rows('SELECT * FROM #__gp_social_extended_orders WHERE '.$where.' FOR UPDATE',1)[0]??null;if(!$row)throw new \DomainException('Commande inconnue.',404);
            $prior=$s->rows('SELECT checksum FROM #__gp_social_extended_events WHERE event_id='.$s->q($event['id']),1)[0]??null;$checksum=hash('sha256',json_encode($event,JSON_THROW_ON_ERROR));if($prior){if(!hash_equals($prior['checksum'],$checksum))throw new \DomainException('Événement incohérent.',409);return;}
            $state='revoked';if(str_starts_with($event['type'],'checkout.')){
                if((string)($o['id']??'')!==$row['checkout_id']||(string)($o['client_reference_id']??'')!==(string)$row['id']||(int)($o['amount_total']??-1)!==(int)$row['amount']||($o['currency']??'')!==$row['currency']||($o['mode']??'')!=='payment')throw new \DomainException('Paiement incohérent.',409);
                if($event['type']==='checkout.session.expired'){
                    if(($o['status']??'')!=='expired'||$row['state']!=='pending')return;
                    $s->run('DELETE FROM #__gp_social_extended_vouchers WHERE order_id='.(int)$row['id']);$s->run("UPDATE #__gp_social_extended_orders SET state='expired' WHERE id=".(int)$row['id']);$s->insert('extended_events',['event_id'=>$event['id'],'order_id'=>(int)$row['id'],'checksum'=>$checksum,'ctime'=>gmdate('Y-m-d H:i:s')]);return;
                }
                if(($o['payment_status']??'')!=='paid')return;if(in_array($row['state'],['revoked','expired'],true))throw new \DomainException('Commande révoquée ou expirée.',409);$state='paid';
            }
            $snapshot=json_decode($row['snapshot'],true,16,JSON_THROW_ON_ERROR);$voucher='';
            if($state==='paid'&&$snapshot['type']==='payvoucher'){
                $allocated=$s->rows('SELECT code FROM #__gp_social_extended_vouchers WHERE order_id='.(int)$row['id'],1)[0]??null;
                if(!$allocated)throw new \DomainException('Réservation de bon introuvable.',409);$voucher=$allocated['code'];
            }
            $s->run('UPDATE #__gp_social_extended_orders SET state='.$s->q($state).',intent_id='.$s->q((string)($o['payment_intent']??$row['intent_id'])).' WHERE id='.(int)$row['id']);
            $gateway='gpstripe-'.$row['id'];$s->db->setQuery('SELECT id FROM #__js_res_sales WHERE gateway_id='.$s->q($gateway).' AND record_id='.(int)$row['record_id'].' AND field_id='.(int)$row['field_id'].' AND user_id='.(int)$row['user_id']);$sale=(int)$s->db->loadResult();
            $data=(object)['user_id'=>(int)$row['user_id'],'saler_id'=>$snapshot['seller'],'record_id'=>(int)$row['record_id'],'field_id'=>(int)$row['field_id'],'section_id'=>$snapshot['section'],'type_id'=>$snapshot['type_id'],'gateway_id'=>$gateway,'gateway'=>'stripe','status'=>$state==='paid'?5:4,'amount'=>(int)$row['amount']/($row['currency']==='jpy'?1:100),'currency'=>strtoupper($row['currency']),'name'=>$snapshot['title'],'params'=>$voucher,'mtime'=>gmdate('Y-m-d H:i:s')];
            if($sale){$data->id=$sale;$s->db->updateObject('#__js_res_sales',$data,'id');}else{$data->ctime=$data->mtime;$s->db->insertObject('#__js_res_sales',$data);}
            $s->insert('extended_events',['event_id'=>$event['id'],'order_id'=>(int)$row['id'],'checksum'=>$checksum,'ctime'=>gmdate('Y-m-d H:i:s')]);
        });});
    }
}
