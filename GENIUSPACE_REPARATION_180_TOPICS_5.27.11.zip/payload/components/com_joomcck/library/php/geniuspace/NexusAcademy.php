<?php
/** Multisector academy: native CCK course records and server-validated assessments. */
defined('_JEXEC') or die;
require_once __DIR__.'/NexusConnect.php';
require_once __DIR__.'/bootstrap.php';
final class NexusAcademy
{
    public static function assessments($params): array
    {
        $section=(int)NexusPlatform::config($params,'assessment_section_id');if(!$section)return [];
        $db=\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);$store=new \Geniuspace\Store($db);$public=new \Geniuspace\NativeAccess();$identity=\Joomla\CMS\Factory::getApplication()->getIdentity();$out=[];
        foreach($store->rows('SELECT r.id,f.id AS field_id FROM #__js_res_record r INNER JOIN #__js_res_fields f ON f.type_id=r.type_id WHERE r.section_id='.$section." AND r.published=1 AND f.published=1 AND f.field_type='gpquiz' ORDER BY r.id DESC",48)as$row){
            if(!$public->record((int)$row['id']))continue;
            try{$quiz=\Geniuspace\QuizBridge::service($section);$definition=$quiz->definition((int)$row['id'],(int)$row['field_id']);$eligible=$identity->id&&$quiz->eligible((int)$row['id'],(int)$row['field_id']);$feedback=$identity->id?$quiz->feedback((int)$row['id'],(int)$row['field_id']):[];
                $out[]=['record'=>$definition['record'],'field_id'=>(int)$row['field_id'],'threshold'=>$definition['settings']['pass_percent'],'duration'=>$definition['settings']['duration_minutes'],'questions'=>count($definition['quiz']['questions']),'eligible'=>$eligible,'feedback'=>$feedback,'url'=>\Geniuspace\QuizBridge::link($section,(int)$row['id'],(int)$row['field_id']),'apply'=>$eligible?\Geniuspace\QuizBridge::applicationUrl($quiz,(int)$row['id'],(int)$row['field_id']):null];
            }catch(\Throwable $e){continue;}if(count($out)>=12)break;
        }return $out;
    }
    /** Guest filter registry is also available beside a full record, using its native section. */
    public static function filters(object $view,$params): string
    {
        if(!(int)NexusPlatform::config($params,'show_native_filters','1'))return '';
        $model=\Joomla\CMS\MVC\Model\BaseDatabaseModel::getInstance('Records','JoomcckModel');if(!$model)return '';
        $model->section=$view->section;$model->setState('records.section_id',(int)$view->section->id);$filters=$model->getFilters();
        // Apply native field visibility before onRenderFilter, just like normal list rendering.
        $levels=\Joomla\CMS\Factory::getApplication()->getIdentity()->getAuthorisedViewLevels();
        $filters=array_filter($filters,static fn($f)=>in_array((int)($f->access??1),$levels,true)&&in_array((int)$f->params->get('core.field_view_access',1),$levels,true)&&!$f->params->get('params.filter_hide'));
        if(!$filters&&NexusPlatform::config($params,'filter_source','component')!=='module')return '';
        $p=new \Joomla\Registry\Registry(['tmpl_params'=>['filter_source'=>NexusPlatform::config($params,'filter_source','component'),'filter_module_id'=>(int)NexusPlatform::config($params,'filter_module_id')],'filters'=>['filters'=>1,'filters_home'=>1]]);
        $current=(object)['section'=>$view->section,'filters'=>$filters,'show_filters'=>true,'tmpl_params'=>['markup'=>$p],'action'=>\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&view=records&section_id='.(int)$view->section->id];
        return \Joomcck\Layout\Helpers\Layout::render('nexus.platform.filters',['current'=>$current]);
    }
}
