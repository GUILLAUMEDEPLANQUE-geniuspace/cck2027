<?php
declare(strict_types=1);
namespace Geniuspace;

/** V21 design contract. Native categories and fields remain the content authority. */
final class UniverseBlueprint
{
    private static array $selected=[];
    public static function select(int $section,?object $record=null): int
    {
        $category=\Joomla\CMS\Factory::getApplication()->input->getInt('cat_id',0);$context=self::context($section,$category);if($category&&$context['current'])return self::$selected[$section]=$category;
        if($record){$cats=$record->categories??[];if(!is_array($cats))$cats=json_decode((string)$cats,true)?:[];$best=0;
            foreach(array_keys($cats)as$id)if(isset($context['flat'][(int)$id])){$node=$context['flat'][(int)$id];$depth=count(self::context($section,(int)$node->id)['chain']);if($depth>$best){$best=$depth;$category=(int)$node->id;}}
        }
        return self::$selected[$section]=(int)$category;
    }
    public static function selected(int $section): int
    {return self::$selected[$section]??\Joomla\CMS\Factory::getApplication()->input->getInt('cat_id',0);}
    public static function catalogue(): array
    {
        static $data;return $data??=json_decode((string)file_get_contents(__DIR__.'/universe/catalogue.json'),true,64,JSON_THROW_ON_ERROR);
    }
    public static function assets(): void
    {
        static $done=false;if($done)return;$done=true;require_once __DIR__.'/NexusForumSeven.php';\NexusForumSeven::assets();$d=\Joomla\CMS\Factory::getApplication()->getDocument();$base=\Joomla\CMS\Uri\Uri::root(true).'/media/com_joomcck/nexus/';
        $d->addStyleSheet($base.'universe-v21.css',['version'=>'5.20.0']);$d->addStyleSheet($base.'reference-v23.css',['version'=>'5.20.0']);$d->addStyleSheet($base.'reference-shell.css',['version'=>'5.27.10']);$d->addScript($base.'publication-studio.js',['version'=>'5.20.0-rc1'],['type'=>'module']);$d->addScript($base.'universe-v21.js',['version'=>'5.25.0'],['type'=>'module']);
    }
    public static function icon(string $name): string
    {
        $name=preg_replace('/^fa-(?:solid|brands)\s+/','',$name);$name=preg_replace('/^fa-/','',$name);
        return \NexusConnect::icon((string)$name);
    }
    public static function rootKey(object $category,array $flat): ?string
    {
        $seen=[];while($category){$id=(int)$category->id;if(isset($seen[$id]))break;$seen[$id]=true;
            $key=(string)$category->params->get('universe_key','');if(isset(self::catalogue()[$key]))return $key;
            foreach(self::catalogue()as$key=>$u)if($category->alias===basename($u['sefPath'])||in_array($category->alias,$u['legacy_aliases'],true))return $key;
            $category=$flat[(int)$category->parent_id]??null;
        }return null;
    }
    public static function context(int $section,int $category=0): array
    {
        require_once __DIR__.'/NexusForumSeven.php';
        $roots=\NexusForumSeven::categories($section);$flat=\NexusForumSeven::flat($roots);$current=$flat[$category]??null;$key=$current?self::rootKey($current,$flat):null;
        $u=$key?self::catalogue()[$key]:null;$chain=[];$node=$current;$seen=[];
        while($node&&!isset($seen[(int)$node->id])){$seen[(int)$node->id]=true;array_unshift($chain,$node);$node=$flat[(int)$node->parent_id]??null;}
        return ['section'=>$section,'category'=>$category,'roots'=>$roots,'flat'=>$flat,'current'=>$current,'key'=>$key,'universe'=>$u,'chain'=>$chain];
    }
    public static function link(int $section,object $category,string $mode='forum'): string
    {return \NexusForumSeven::modeUrl(ForumRoutes::categoryUrl($section,(int)$category->id),$mode);}
    public static function categoryIcon(object $category): string
    {return self::icon((string)$category->params->get('icon','hashtag'));}
    public static function navigation(int $section,int $category): string
    {
        $c=self::context($section,$category);$out='<nav data-universe-section="'.$section.'" data-universe-category="'.$category.'" data-read-url="'.Text::escape(\Joomla\CMS\Uri\Uri::root()).'" id="top-universes-bar" class="nx-universe-nav" aria-label="Les univers"><strong>Univers</strong>';
        $shown=[];foreach($c['roots']as$root){$key=self::rootKey($root,$c['flat']);if(!$key||$key==='tech'||isset($shown[$key]))continue;$shown[$key]=true;$color=$key?self::catalogue()[$key]['color']:'#64748b';
            $out.='<a href="'.Text::escape(self::link($section,$root)).'" style="--universe-color:'.$color.'"'.(($c['chain'][0]->id??0)===$root->id?' aria-current="page"':'').'>'.self::categoryIcon($root).'<span>'.Text::escape(self::label($root)).'</span></a>';
        }return $out.'</nav>';
    }
    public static function label(object $category): string
    {
        $key=(string)$category->params->get('universe_key','');
        return (int)$category->parent_id<=1?(self::catalogue()[$key]['shortName']??$category->title):$category->title;
    }
    public static function hero(array $c): string{return UniverseComposition::hero($c);}
    public static function stage(array $c,array $items,object $params): string{return UniverseExperience::stage($c,$items,$params);}
    public static function sidebar(int $section,int $category,object $params): string{return UniverseExperience::sidebar($section,$category,$params);}
    private static function feature(array $items,object $p): string
    {
        if(!$items)return '<p class="nx-universe-empty">Publiez un dossier pour ouvrir cet espace.</p>';$i=$items[0];$cover=\NexusPlatform::value($i,$p,'field_cover');$image=\NexusAurora::safeImage($cover);
        return '<a class="nx-universe-feature" href="'.Text::escape(\NexusPlatform::recordUrl($i)).'">'.($image?'<img src="'.Text::escape($image).'" alt="'.Text::escape($i->title).'" width="960" height="540" loading="lazy">':'').'<h3>'.Text::escape($i->title).'</h3></a>';
    }
    private static function links(array $items): string
    {
        $out='';foreach(array_slice($items,0,5)as$i)$out.='<a class="nx-universe-card-link" href="'.Text::escape(\NexusPlatform::recordUrl($i)).'">'.Text::escape($i->title).'</a>';return $out?:'<p class="nx-universe-empty">Les publications de cette rubrique apparaîtront ici.</p>';
    }
    private static function nativeRegion(array $items,object $p,string $key): string
    {
        $out='';foreach(array_slice($items,0,6)as$i)$out.=\NexusPlatform::widget($i,$p,$key);return $out?:'<p class="nx-universe-empty">Ajoutez un contenu documenté dans cette rubrique.</p>';
    }
}
