<?php
declare(strict_types=1);
namespace Geniuspace;

/** Audio is stored as a native-field asset and served through current record/field access gates. */
final class AudioWorkshop
{
    public static function upload(int $record,int $field,string $bytes,int $section=0): array
    {
        $user=ProductAccess::authenticated();
        if($record)$a=ProductAccess::field($record,$field,'gpaudio',true);
        else{$raw=ProductAccess::store()->rows('SELECT * FROM #__js_res_fields WHERE id='.$field.' AND field_type=\'gpaudio\'',1)[0]??null;if(!$raw)throw new \DomainException('Field audio inaccessible.',403);$f=(object)$raw;$f->params=new \Joomla\Registry\Registry($f->params);NativeUploadGate::check($f,0,$section,false);}
        $size=strlen($bytes);if($size<32||$size>10*1024*1024)throw new \InvalidArgumentException('Audio entre 32 octets et 10 Mo requis.');
        $mime=(new \finfo(FILEINFO_MIME_TYPE))->buffer($bytes);
        if(!in_array($mime,['audio/wav','audio/x-wav','audio/mpeg','audio/ogg','video/webm','audio/webm','application/ogg'],true))throw new \InvalidArgumentException('Format audio non reconnu.');
        if(in_array($mime,['video/webm','audio/webm'],true)&&substr($bytes,0,4)!=="\x1a\x45\xdf\xa3")throw new \InvalidArgumentException('Conteneur WebM invalide.');
        $s=ProductAccess::store();$s->run('DELETE FROM #__gp_social_audio_assets WHERE record_id=0 AND user_id='.$user.' AND ctime<'.$s->q(gmdate('Y-m-d H:i:s',time()-86400)));
        $quota=(int)($s->rows('SELECT SUM(bytes) AS n FROM #__gp_social_audio_assets WHERE user_id='.$user.' AND ctime>'.$s->q(gmdate('Y-m-d H:i:s',time()-86400)),1)[0]['n']??0);
        if($quota+$size>50*1024*1024)throw new \DomainException('Quota audio quotidien de 50 Mo atteint.',429);
        $id=$s->insert('audio_assets',['record_id'=>$record,'field_id'=>$field,'user_id'=>$user,'mime'=>$mime,'bytes'=>$size,
            'checksum'=>hash('sha256',$bytes),'payload'=>base64_encode($bytes),'ctime'=>gmdate('Y-m-d H:i:s')]);
        return ['asset_id'=>$id,'src'=>self::url($id),'bytes'=>$size];
    }
    public static function url(int $id): string
    { return \Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.productMedia&asset='.$id; }
    public static function download(int $id): Response
    {
        $s=ProductAccess::store();$row=$s->rows('SELECT * FROM #__gp_social_audio_assets WHERE id='.max(0,$id),1)[0]??null;
        if(!$row)throw new \DomainException('Audio introuvable.',404);
        if(!(int)$row['record_id']){if(ProductAccess::user()->block||(int)ProductAccess::user()->id!==(int)$row['user_id']||strtotime($row['ctime'])<time()-86400)throw new \DomainException('Audio non publié.',404);$a=['value'=>''];}
        else $a=ProductAccess::field((int)$row['record_id'],(int)$row['field_id'],'gpaudio');
        try{$d=ProductData::parse('audio',(string)$a['value']);}catch(\InvalidArgumentException){$d=[];}
        if(($d['asset_id']??0)!==$id&&(int)ProductAccess::user()->id!==(int)$row['user_id'])throw new \DomainException('Audio non publié dans ce field.',404);
        $bytes=base64_decode($row['payload'],true);if($bytes===false||!hash_equals($row['checksum'],hash('sha256',$bytes)))throw new \DomainException('Audio indisponible.',503);
        return new Response($bytes,$row['mime'],200,['Cache-Control'=>'private, no-store','Content-Disposition'=>'inline',
            'X-Content-Type-Options'=>'nosniff','X-Robots-Tag'=>'noindex','Accept-Ranges'=>'none']);
    }
    public static function guardAsset(int $asset,int $record,int $field): void
    {
        if(!$asset)return;$r=ProductAccess::store()->rows('SELECT record_id,field_id,user_id,ctime FROM #__gp_social_audio_assets WHERE id='.$asset,1)[0]??null;
        $staged=$r&&!(int)$r['record_id']&&(int)$r['user_id']===(int)ProductAccess::user()->id&&strtotime($r['ctime'])>=time()-86400;
        if(!$r||(!$record&&!$staged)||((int)$r['record_id']!==$record&&!$staged)||(int)$r['field_id']!==$field)throw new \InvalidArgumentException('Cet audio appartient à un autre field.');
    }
    public static function bindAsset(int $asset,int $record,int $field): void
    {
        if(!$asset)return;self::guardAsset($asset,$record,$field);$s=ProductAccess::store();
        $s->run('UPDATE #__gp_social_audio_assets SET record_id='.$record.' WHERE id='.$asset.' AND field_id='.$field.' AND record_id=0 AND user_id='.(int)ProductAccess::user()->id);
    }
    public static function feedback(array $data): void
    {
        $user=ProductAccess::authenticated();$record=ProductData::id($data['record']??0);$field=ProductData::id($data['field']??0);
        $a=ProductAccess::field($record,$field,'gpaudio');$d=ProductData::parse('audio',(string)$a['value']);
        if((int)$a['record']['user_id']===$user)throw new \DomainException('Votre propre retour ne compte pas dans la note de votre audio.',403);
        $scores=ProductData::list($data['scores']??[],12);if(count($scores)!==count($d['criteria'])||!$scores)throw new \InvalidArgumentException('Évaluez chaque critère.');
        $clean=[];foreach($scores as$score){if(!is_int($score)||$score<1||$score>5)throw new \InvalidArgumentException('Note de 1 à 5 requise.');$clean[]=$score;}
        $comment=ProductData::text($data['feedback']??'',2000);$s=ProductAccess::store();
        $s->run('INSERT INTO #__gp_social_audio_feedback (record_id,field_id,user_id,source_hash,scores,feedback,ctime) VALUES ('.$record.','.$field.','.$user.','.$s->q(hash('sha256',Seo::json($d))).','.$s->q(Seo::json($clean)).','.$s->q($comment).','.$s->q(gmdate('Y-m-d H:i:s')).') ON DUPLICATE KEY UPDATE source_hash=VALUES(source_hash),scores=VALUES(scores),feedback=VALUES(feedback),ctime=VALUES(ctime)');
    }
    public static function summary(array $d,int $record,int $field): array
    {
        $rows=ProductAccess::store()->rows('SELECT scores FROM #__gp_social_audio_feedback WHERE record_id='.$record.' AND field_id='.$field.' AND source_hash='.ProductAccess::store()->q(hash('sha256',Seo::json($d))),1000);$sum=0;$n=0;
        foreach($rows as$row)foreach(json_decode($row['scores'],true)?:[]as$score){$sum+=$score;$n++;}
        return ['count'=>count($rows),'average'=>$n?round($sum/$n,1):null];
    }
    public static function render(array $d,array $r,int $field,bool $full): string
    {
        if(!$d['src']&&!$d['asset_id']&&!$d['transcript'])return '';
        $id=(int)$r['id'];$src=$d['asset_id']?self::url($d['asset_id']):$d['src'];$summary=self::summary($d,$id,$field);
        $out='<div class="interactive-sandbox gp-audio-sandbox"><h3>'.Text::escape($d['title']).'</h3>';
        if($src)$out.='<audio controls preload="metadata" class="gp-audio-player" src="'.Text::escape($src).'" aria-label="'.Text::escape($d['title']).'">Votre navigateur ne peut pas lire cet audio.</audio>';
        $out.='<div class="gp-audio-wave" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>';
        if($d['transcript'])$out.='<details><summary>Lire la transcription</summary><p class="gp-audio-transcript">'.Text::escape($d['transcript']).'</p></details>';
        $out.='<p class="gp-product-note">'.($summary['average']!==null?'Retours de la communauté : '.$summary['average'].'/5 · '.$summary['count'].' avis':'Aucun retour évalué pour cette version.').'</p></div>';
        if($full&&$d['criteria']&&ProductAccess::user()->id&&(int)ProductAccess::user()->id!==(int)$r['user_id']){
            $out.=ProductAccess::form('audio.feedback',$id,['field'=>$field]);foreach($d['criteria']as$i=>$criterion){$out.='<label>'.Text::escape($criterion).'<select name="scores['.$i.']">';for($n=1;$n<=5;$n++)$out.='<option value="'.$n.'">'.$n.'/5</option>';$out.='</select></label>';}
            $out.='<label>Votre retour <textarea name="feedback" maxlength="2000"></textarea></label><button>Partager ce retour</button></form>';
        }return $out;
    }
}
