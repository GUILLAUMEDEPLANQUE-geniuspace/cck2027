<?php
declare(strict_types=1);
namespace Geniuspace;

/** Metadata and media inheritance apply to existing and future native categories. */
final class ForumCategories
{
    public static function public(array $c): bool
    {
        $s=ProductAccess::store();$levels=(new \Joomla\CMS\User\User())->getAuthorisedViewLevels();$section=$s->rows('SELECT published,access,params FROM #__js_res_sections WHERE id='.(int)$c['section_id'],1)[0]??null;
        $p=new \Joomla\Registry\Registry($section['params']??'{}');if(!$section||(int)$section['published']!==1||!in_array((int)$section['access'],$levels,true)||!$p->get('general.status',1)||$p->get('emerald.section_subscription')||$p->get('more.nexus_demo')||str_contains((string)$p->get('more.robots'),'noindex'))return false;
        $seen=[];while(true){$id=(int)$c['id'];if(isset($seen[$id])||(int)$c['published']!==1||!in_array((int)$c['access'],$levels,true))return false;$seen[$id]=true;
            $metadata=new \Joomla\Registry\Registry($c['metadata']??'{}');if(str_contains((string)$metadata->get('robots'),'noindex'))return false;
            $parent=(int)$c['parent_id'];if($parent<=1)return true;$c=$s->rows('SELECT * FROM #__js_res_categories WHERE id='.$parent,1)[0]??null;if(!$c)return false;}
    }
    public static function title(array|object $category): string
    { $c=(array)$category;$p=self::params($category);return Text::plain((string)$p->get('seo_title')?:$c['title'].' | '.\Joomla\CMS\Factory::getApplication()->get('sitename')); }
    public static function description(array|object $category): string
    { $c=(array)$category;$text=Text::plain((string)($c['metadesc']?:$c['description']));return $text?:'Échanges, questions et ressources sur '.$c['title'].' dans la communauté '.\Joomla\CMS\Factory::getApplication()->get('sitename').'.'; }
    public static function params(array|object $c): \Joomla\Registry\Registry
    { $c=(array)$c;return $c['params'] instanceof \Joomla\Registry\Registry?$c['params']:new \Joomla\Registry\Registry($c['params']??'{}'); }
    public static function image(array|object $category,int $width=64): string
    {
        $c=(array)$category;$s=ProductAccess::store();$seen=[];$levels=\Joomla\CMS\Factory::getApplication()->getIdentity()->getAuthorisedViewLevels();
        while(true){$id=(int)$c['id'];if(isset($seen[$id]))return '';$seen[$id]=true;$p=self::params($c);
            $native=(string)($c['image']??'');$variant=(string)$p->get('image_'.$width,'');
            // A newly selected native image takes precedence over the old bundled variants.
            $src=$native&&$native!==$p->get('image_256')?$native:($variant?:$native);
            if($url=\NexusAurora::safeImage($src))return $url;
            $parent=(int)$c['parent_id'];if($parent<=1)return \NexusAurora::safeImage('media/com_joomcck/nexus/forum7/categories/communaute-geniuspace-'.$width.'.webp');$c=$s->rows('SELECT * FROM #__js_res_categories WHERE id='.$parent,1)[0]??null;
            if(!$c||(int)$c['published']!==1||!in_array((int)$c['access'],$levels,true))return '';
        }
    }
    public static function alt(array|object $category): string
    { $c=(array)$category;return Text::plain((string)self::params($category)->get('image_alt')?:'Illustration du forum '.$c['title']); }
    public static function dimensions(string $url,int $fallback=64): array
    {
        $uri=new \Joomla\CMS\Uri\Uri($url);$root=new \Joomla\CMS\Uri\Uri(\Joomla\CMS\Uri\Uri::root());
        if($uri->getHost()===$root->getHost()){$path=rawurldecode($uri->getPath());$prefix=$root->getPath();if(str_starts_with($path,$prefix)){$local=realpath(JPATH_ROOT.'/'.substr($path,strlen($prefix)));$base=realpath(JPATH_ROOT);if($local&&str_starts_with($local,$base.DIRECTORY_SEPARATOR)&&is_file($local)&&filesize($local)<5*1024*1024){$size=@getimagesize($local);if($size)return [(int)$size[0],(int)$size[1]];}}}
        return [$fallback,$fallback===768?432:$fallback];
    }
    public static function corpus(array $sectionIds=[]): array
    {
        $s=ProductAccess::store();$out=[];$sectionIds=array_values(array_filter(array_map('intval',$sectionIds),fn($id)=>$id>0));
        foreach($s->db->setQuery('SELECT * FROM #__js_res_categories WHERE published=1'.($sectionIds?' AND section_id IN('.implode(',',$sectionIds).')':'').' ORDER BY lft,id')->loadAssocList()as$c){
            if(!ForumRoutes::section((int)$c['section_id'])||!self::public($c))continue;
            if(CategoryBridge::primary($c))continue;
            $out[]=['id'=>(int)$c['id'],'section'=>(int)$c['section_id'],'title'=>$c['title'],'seo_title'=>self::title($c),'description'=>self::description($c),'url'=>\NexusPlatform::sameSite(ForumRoutes::categoryUrl((int)$c['section_id'],(int)$c['id'])),'image'=>self::image($c,768),'alt'=>self::alt($c),'parent'=>(int)$c['parent_id'],'modified'=>$c['modified_time']?:$c['created_time']];
        }return $out;
    }
}
