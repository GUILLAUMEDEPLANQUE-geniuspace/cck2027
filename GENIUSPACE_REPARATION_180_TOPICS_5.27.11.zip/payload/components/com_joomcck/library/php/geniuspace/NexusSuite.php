<?php
/** Nexus Multilingual — isolated rendering and SEO helpers. GPL-2.0-or-later. */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Filter\InputFilter;

final class NexusSuite
{
    private static bool $assets = false;

    public static function e($value): string
    {
        return htmlspecialchars(is_scalar($value) ? (string) $value : '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function plain($html): string
    {
        return trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string)$html), ENT_QUOTES | ENT_HTML5, 'UTF-8')) ?? '');
    }

    public static function safeHtml($html): string
    {
        // Preserve semantic editorial markup while filtering active content and unsafe attributes.
        $filter = new InputFilter(
            ['p','br','hr','h2','h3','h4','h5','h6','ul','ol','li','dl','dt','dd','a','strong','b','em','i','u','s','blockquote','pre','code','figure','figcaption','img','table','thead','tbody','tfoot','tr','th','td','span','div','details','summary','time','sup','sub','abbr'],
            ['href','src','alt','title','width','height','loading','rel','class','id','colspan','rowspan','scope','datetime','open'],
            0, 0, 1
        );
        return (string) $filter->clean((string)$html, 'html');
    }

    public static function commentHtml($html): string
    {
        $html = self::safeHtml($html);
        // Links entered by untrusted users are not editorial endorsements.
        return preg_replace_callback('~<a\b([^>]*)>~iu', static function ($match) {
            $attrs = $match[1];
            if (!preg_match('~\bhref\s*=\s*([\"\'])(.*?)\1~iu', $attrs, $found)) return $match[0];
            $dest = html_entity_decode($found[2], ENT_QUOTES | ENT_HTML5,'UTF-8');
            $url = parse_url($dest);
            $site = parse_url(\Joomla\CMS\Uri\Uri::root());
            if (!is_array($url) || empty($url['host']) || strtolower((string)$url['host']) === strtolower((string)($site['host'] ?? ''))) return $match[0];
            if (preg_match('~\brel\s*=\s*([\"\'])(.*?)\1~iu', $attrs, $rel)) {
                $merged = implode(' ',array_unique(array_filter(preg_split('/\s+/',trim($rel[2].' ugc nofollow')) ?: [])));
                $attrs = str_replace($rel[0], 'rel="'.self::e($merged).'"', $attrs);
            } else $attrs .= ' rel="ugc nofollow"';
            return '<a'.$attrs.'>';
        }, $html) ?? $html;
    }

    public static function url(string $url, bool $route = false): string
    {
        $url = trim(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($url === '' || preg_match('~^(?:javascript|data|vbscript|file):~i', $url) || str_starts_with($url, '//')) return '';
        if ($route && str_starts_with($url, 'index.php')) $url = Route::_($url, false);
        if (preg_match('~^https?://~i', $url)) return $url;
        if (preg_match('~^[a-z][a-z0-9+.-]*:~i', $url)) return '';
        $root = rtrim(Uri::root(), '/');
        if (str_starts_with($url, '/')) {
            $origin = parse_url(Uri::root());
            if (!is_array($origin) || empty($origin['scheme']) || empty($origin['host'])) return '';
            return $origin['scheme'] . '://' . $origin['host'] . (isset($origin['port']) ? ':' . $origin['port'] : '') . $url;
        }
        return $root . '/' . ltrim($url, '/');
    }

    public static function href(string $url): string
    {
        return self::e(self::url($url, true));
    }

    public static function locale(): string
    {
        $override=(string)\Joomla\CMS\Component\ComponentHelper::getParams('com_joomcck')->get('geniuspace_nexus_locale','');
        if(in_array($override,['fr-FR','en-GB','de-DE','es-ES','zh-CN'],true))return $override;
        try { $locale = Factory::getApplication()->getLanguage()->getTag(); }
        catch (\Throwable $e) { $locale = 'en-GB'; }
        return preg_match('/^[a-z]{2,3}(?:-[A-Za-z]{2,8})?$/iD', (string)$locale) ? $locale : 'en-GB';
    }

    public static function t(string $key): string
    {
        $map = [
            'fr'=>['knowledge'=>'Centre de connaissances','explore'=>'Explorer les sujets','discuss'=>'Discussions','article'=>'Article','guide'=>'Guide','category'=>'Catégories','read'=>'Lire la publication','replies'=>'Réponses','reply'=>'Répondre','edit'=>'Modifier','delete'=>'Supprimer','hide'=>'Masquer','show'=>'Afficher','share'=>'Copier le lien','search'=>'Filtrer les réponses','write'=>'Contribuer à la discussion','post'=>'Publier','related'=>'À découvrir','compare'=>'Comparer','back'=>'Retour','noresults'=>'Aucune publication','new'=>'Nouveau sujet','ago'=>'Publié','attachment'=>'Pièces jointes','private'=>'Privé','pending'=>'En modération','vote'=>'Évaluer','copy'=>'Lien vers cette réponse','all'=>'Toutes les contributions','editorial'=>'Éditorial','formtip'=>'Un titre précis, une réponse vérifiable et des liens utiles aident les lecteurs à trouver votre publication.','home'=>'Accueil','source'=>'Liens cités','cite'=>'Citer cette réponse','perspective'=>'Voir cet auteur','sort'=>'Trier les réponses','first'=>'Réponses les plus anciennes','last'=>'Réponses les plus récentes'],
            'en'=>['knowledge'=>'Knowledge hub','explore'=>'Explore topics','discuss'=>'Discussions','article'=>'Article','guide'=>'Guide','category'=>'Categories','read'=>'Read publication','replies'=>'Replies','reply'=>'Reply','edit'=>'Edit','delete'=>'Delete','hide'=>'Collapse','show'=>'Expand','share'=>'Copy link','search'=>'Filter replies','write'=>'Join the conversation','post'=>'Publish','related'=>'Explore further','compare'=>'Compare','back'=>'Back','noresults'=>'No posts found','new'=>'New topic','ago'=>'Published','attachment'=>'Attachments','private'=>'Private','pending'=>'Pending review','vote'=>'Vote','copy'=>'Copy reply link','all'=>'All contributions','editorial'=>'Editorial','formtip'=>'A precise title, verifiable answer and helpful links make your post easier to discover.','home'=>'Home','source'=>'Referenced links','cite'=>'Quote this reply','perspective'=>'Filter by author','sort'=>'Sort replies','first'=>'Oldest first','last'=>'Newest first'],
            'zh'=>['knowledge'=>'知识中心','explore'=>'探索主题','discuss'=>'讨论','article'=>'文章','guide'=>'指南','category'=>'分类','read'=>'阅读文章','replies'=>'回复','reply'=>'回复','edit'=>'编辑','delete'=>'删除','hide'=>'收起','show'=>'展开','share'=>'复制链接','search'=>'筛选回复','write'=>'参与讨论','post'=>'发布','related'=>'相关内容','compare'=>'比较','back'=>'返回','noresults'=>'暂无内容','new'=>'新主题','ago'=>'发布于','attachment'=>'附件','private'=>'私密','pending'=>'等待审核','vote'=>'投票','copy'=>'复制回复链接','all'=>'全部内容','editorial'=>'专栏','formtip'=>'准确的标题、可信的内容和有用的参考链接可以帮助读者找到您的文章。','home'=>'首页','source'=>'引用链接','cite'=>'引用此回复','perspective'=>'只看该作者','sort'=>'排序','first'=>'最早优先','last'=>'最新优先'],
            'es'=>['knowledge'=>'Centro de conocimiento','explore'=>'Explorar temas','discuss'=>'Debates','article'=>'Artículo','guide'=>'Guía','category'=>'Categorías','read'=>'Leer publicación','replies'=>'Respuestas','reply'=>'Responder','edit'=>'Editar','delete'=>'Eliminar','hide'=>'Ocultar','show'=>'Mostrar','share'=>'Copiar enlace','search'=>'Filtrar respuestas','write'=>'Participar','post'=>'Publicar','related'=>'Explorar más','compare'=>'Comparar','back'=>'Volver','noresults'=>'Sin publicaciones','new'=>'Nuevo tema','ago'=>'Publicado','attachment'=>'Adjuntos','private'=>'Privado','pending'=>'Pendiente','vote'=>'Votar','copy'=>'Copiar enlace','all'=>'Todos','editorial'=>'Editorial','formtip'=>'Un título preciso y referencias útiles facilitan encontrar tu publicación.','home'=>'Inicio','source'=>'Enlaces citados','cite'=>'Citar respuesta','perspective'=>'Ver autor','sort'=>'Ordenar','first'=>'Más antiguos','last'=>'Más recientes'],
            'de'=>['knowledge'=>'Wissenszentrum','explore'=>'Themen entdecken','discuss'=>'Diskussionen','article'=>'Artikel','guide'=>'Ratgeber','category'=>'Kategorien','read'=>'Artikel lesen','replies'=>'Antworten','reply'=>'Antworten','edit'=>'Bearbeiten','delete'=>'Löschen','hide'=>'Einklappen','show'=>'Ausklappen','share'=>'Link kopieren','search'=>'Antworten filtern','write'=>'Mitdiskutieren','post'=>'Veröffentlichen','related'=>'Weitere Themen','compare'=>'Vergleichen','back'=>'Zurück','noresults'=>'Keine Beiträge','new'=>'Neues Thema','ago'=>'Veröffentlicht','attachment'=>'Anhänge','private'=>'Privat','pending'=>'In Prüfung','vote'=>'Bewerten','copy'=>'Antwortlink kopieren','all'=>'Alle Beiträge','editorial'=>'Redaktion','formtip'=>'Präzise Titel und überprüfbare Quellen machen Beiträge auffindbar.','home'=>'Startseite','source'=>'Quellenlinks','cite'=>'Antwort zitieren','perspective'=>'Autor anzeigen','sort'=>'Sortieren','first'=>'Älteste zuerst','last'=>'Neueste zuerst'],
        ];
        $language = strtolower(explode('-', self::locale())[0]);
        return $map[$language][$key] ?? $map['en'][$key] ?? $key;
    }

    public static function assets(): void
    {
        if (self::$assets) return;
        self::$assets = true;
        if (class_exists('Joomla\\CMS\\Factory')) {
            $doc = Factory::getApplication()->getDocument();
            if (method_exists($doc, 'addStyleSheet')) $doc->addStyleSheet(rtrim(Uri::root(true), '/') . '/media/com_joomcck/nexus/nexus-multi.css');
            if (method_exists($doc, 'addScript')) $doc->addScript(rtrim(Uri::root(true), '/') . '/media/com_joomcck/nexus/nexus-multi.js', ['version'=>'5.11.0'], ['defer'=>true]);
        }
    }

    public static function iso($date): string
    {
        if (!$date || $date === '0000-00-00 00:00:00') return '';
        try { return (new DateTimeImmutable((string)$date, new DateTimeZone('UTC')))->format(DATE_ATOM); }
        catch (\Throwable $e) { return ''; }
    }

    /** Public visibility is distinct from permission to index a page. */
    public static function readableRecord($record): bool
    {
        if (!is_object($record) || (int)($record->id ?? 0) <= 0) return false;
        if ((int)($record->published ?? 0) !== 1 || (int)($record->access ?? 1) !== 1) return false;
        return empty($record->hidden) && empty($record->archive) && empty($record->expired) && empty($record->future);
    }

    public static function publicListRecord($record): bool
    {
        if (!is_object($record) || (int)($record->id ?? 0) <= 0) return false;
        if ((int)($record->published ?? 0) !== 1 || (int)($record->access ?? 1) !== 1) return false;
        if (!empty($record->hidden) || !empty($record->archive) || !empty($record->expired) || !empty($record->future)) return false;
        if (!empty($record->nofollow) || stripos((string)($record->meta_index ?? ''),'noindex') !== false) return false;
        return true;
    }

    public static function publicComment($comment): bool
    {
        if (!is_object($comment) || (int)($comment->id ?? 0) <= 0) return false;
        if ((int)($comment->published ?? 0) !== 1 || !empty($comment->hide) || !empty($comment->private)) return false;
        // A restrictive ACL may be visible to a logged-in viewer but not public search engines.
        if (isset($comment->access) && (int)$comment->access !== 1) return false;
        return true;
    }

    public static function publicCommentNode($comment, string $canonical): ?array
    {
        if (!self::publicComment($comment)) return null;
        $body = self::plain($comment->comment ?? '');
        $author = trim((string)($comment->name ?? ''));
        $date = self::iso($comment->created ?? $comment->ctime ?? null);
        if ($body === '' || $author === '' || $date === '') return null;
        $node = [
            '@type' => 'Comment', '@id' => $canonical . '#comment-' . (int)$comment->id,
            'url' => $canonical . '#comment-' . (int)$comment->id,
            'datePublished' => $date,
            'author' => ['@type'=>'Person','name'=>$author],
            'text' => $body,
        ];
        if(class_exists('\\Geniuspace\\VideoMoments')&&($moment=\Geniuspace\VideoMoments::resolve($comment)))$node['associatedMedia']=['@type'=>'VideoObject','url'=>$moment['url']];
        if(class_exists('\\Geniuspace\\ContextQuestions')&&($passage=\Geniuspace\ContextQuestions::resolve($comment))&&!empty($passage['quote']))$node['about']=['@type'=>'CreativeWork','url'=>$passage['url'],'name'=>$passage['label'],'description'=>$passage['quote']];
        // Only images attached to this public comment enter its visible schema.
        foreach(is_iterable($comment->attachment??null)?$comment->attachment:[]as$file){$f=(object)$file;$ext=strtolower((string)($f->ext??''));if(!in_array($ext,['jpg','jpeg','png','webp','avif','gif'],true)||empty($f->id))continue;
            $image=['@type'=>'ImageObject','contentUrl'=>\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=files.commentImage&id='.(int)$f->id.'&comment_id='.(int)$comment->id,'name'=>self::plain((string)(($f->title??'')?:($f->realname??''))),'encodingFormat'=>'image/'.($ext==='jpg'?'jpeg':$ext)];
            if(!empty($f->description))$image['caption']=self::plain($f->description);if(!empty($f->width)&&!empty($f->height)){$image['width']=(int)$f->width;$image['height']=(int)$f->height;}$node['image'][]=$image;
        }
        return $node;
    }

    public static function threadTree(array $roots): array
    {
        // JoomCCK's model groups *all* descendants in root->sub_comments. Rebuild real parent nesting.
        $out = [];
        foreach ($roots as $record) {
            if (!is_object($record) || empty($record->id)) continue;
            $root = clone $record;
            $original = (array)($root->sub_comments ?? []);
            $root->sub_comments = [];
            $nodes = [(int)$root->id => $root];
            $walk = static function (array $items) use (&$walk, &$nodes): void {
                foreach ($items as $child) {
                    if (!is_object($child) || empty($child->id)) continue;
                    $id=(int)$child->id;
                    if (isset($nodes[$id])) continue;
                    $clone=clone $child;
                    $nested=(array)($clone->sub_comments ?? []);
                    $clone->sub_comments=[];
                    $nodes[$id]=$clone;
                    if ($nested) $walk($nested);
                }
            };
            $walk($original);
            foreach($nodes as $id=>$child) {
                if ($id === (int)$root->id) continue;
                $parentId=(int)($child->parent_id ?? 0);
                if (!$parentId || $parentId===$id || !isset($nodes[$parentId])) $parentId=(int)$root->id;
                // Guard against circular parent chains from malformed migrated data.
                $cursor=$parentId;$chain=[];
                while($cursor && $cursor !== (int)$root->id && isset($nodes[$cursor])) {
                    if ($cursor===$id || isset($chain[$cursor])) {$parentId=(int)$root->id;break;}
                    $chain[$cursor]=true;
                    $cursor=(int)($nodes[$cursor]->parent_id ?? 0);
                }
                $nodes[$parentId]->sub_comments[]=$child;
            }
            $out[]=$root;
        }
        return $out;
    }

    public static function commentGraph(array $comments, string $canonical): array
    {
        $seen = []; $used = 0;
        $walk = static function (array $comments, int $depth = 0) use (&$walk, &$seen, &$used, $canonical): array {
            if ($depth > 8 || $used >= 100) return [];
            $out = [];
            foreach ($comments as $comment) {
                $id = (int)($comment->id ?? 0);
                if (!$id || isset($seen[$id]) || $used >= 100) continue;
                $seen[$id] = true;
                $node = NexusSuite::publicCommentNode($comment, $canonical);
                if ($node === null) continue;
                $used++;
                $children = (array)($comment->sub_comments ?? []);
                if ($children) {
                    $nested = $walk($children, $depth + 1);
                    if ($nested) $node['comment'] = $nested;
                }
                $out[] = $node;
            }
            return $out;
        };
        return $walk(self::threadTree($comments));
    }

    public static function jsonLd(array $node): string
    {
        return json_encode($node, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_AMP | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_INVALID_UTF8_SUBSTITUTE) ?: '{}';
    }

    public static function localizedAlternates(string $input): array
    {
        // Manual & documented: editors must publish reciprocal hreflang on all variants.
        $out = [];
        foreach (preg_split('/\R/u', $input) ?: [] as $line) {
            if (!preg_match('/^\s*([a-z]{2,3}(?:-[A-Za-z]{2,8})?|x-default)\s*\|\s*(https?:\/\/[^\s]+)\s*$/i', $line, $m)) continue;
            $url = self::url($m[2]);
            if ($url) $out[strtolower($m[1])] = $url;
        }
        return $out;
    }
    /** Human-reviewed base translations for the template chrome (French, English, Chinese, Spanish, German). */
    public static function u(string $phrase): string
    {
        static $translations = [
            "Rechercher dans cette discussion" => ["Search this discussion", "搜索此讨论", "Buscar en este debate", "In dieser Diskussion suchen"],
            "Explorer" => ["Explore", "探索", "Explorar", "Entdecken"],
            "Changer de thème" => ["Change theme", "切换主题", "Cambiar tema", "Design wechseln"],
            "Thème" => ["Theme", "主题", "Tema", "Design"],
            "Fil d’Ariane" => ["Breadcrumb", "面包屑导航", "Ruta de navegación", "Brotkrumennavigation"],
            "À la une" => ["Featured", "精选", "Destacado", "Empfohlen"],
            "vues" => ["views", "次浏览", "visitas", "Aufrufe"],
            "commentaires" => ["comments", "条评论", "comentarios", "Kommentare"],
            "min de lecture" => ["min read", "分钟阅读", "min de lectura", "Min. Lesezeit"],
            "Garder pour plus tard" => ["Save for later", "稍后阅读", "Guardar para después", "Für später speichern"],
            "Copier le lien" => ["Copy link", "复制链接", "Copiar enlace", "Link kopieren"],
            "Explorer les connexions" => ["Explore connections", "探索关联", "Explorar conexiones", "Verbindungen erkunden"],
            "Lecture sans distraction" => ["Distraction-free reading", "专注阅读", "Lectura sin distracciones", "Ungestört lesen"],
            "⌘ K pour naviguer dans la page" => ["⌘ K to navigate this page", "按 ⌘ K 浏览页面", "⌘ K para navegar", "⌘ K zum Navigieren"],
            "Liens explorables sans JavaScript" => ["Links work without JavaScript", "链接无需 JavaScript 也可访问", "Enlaces accesibles sin JavaScript", "Links funktionieren ohne JavaScript"],
            "Illustration de " => ["Illustration of ", "插图：", "Ilustración de ", "Illustration zu "],
            "Navigation dans la discussion" => ["Discussion navigation", "讨论导航", "Navegación del debate", "Diskussionsnavigation"],
            "Sommaire intelligent" => ["Smart outline", "智能目录", "Índice inteligente", "Intelligente Übersicht"],
            "Introduction" => ["Introduction", "导言", "Introducción", "Einführung"],
            "La discussion est disponible dans son intégralité." => ["The complete discussion is available below.", "完整讨论如下。", "El debate completo está disponible abajo.", "Die vollständige Diskussion folgt unten."],
            "Votre progression" => ["Your progress", "阅读进度", "Tu progreso", "Dein Fortschritt"],
            "Progression de lecture" => ["Reading progress", "阅读进度", "Progreso de lectura", "Lesefortschritt"],
            "Lecture" => ["Reading", "阅读", "Lectura", "Lesen"],
            "Le contenu de cette discussion n’est pas encore disponible." => ["This discussion does not have content yet.", "此讨论暂时没有内容。", "Este debate todavía no tiene contenido.", "Diese Diskussion hat noch keinen Inhalt."],
            "Afficher toute la discussion" => ["Show full discussion", "展开完整讨论", "Mostrar debate completo", "Ganze Diskussion anzeigen"],
            "Réduire la discussion" => ["Collapse discussion", "收起讨论", "Contraer debate", "Diskussion einklappen"],
            "Copier un extrait sélectionné" => ["Copy selected excerpt", "复制所选摘录", "Copiar fragmento seleccionado", "Markierten Auszug kopieren"],
            "Boussole de connaissances" => ["Knowledge compass", "知识导航", "Brújula del conocimiento", "Wissenskompass"],
            "Naviguez entre les idées" => ["Connect the ideas", "连接知识观点", "Conecta las ideas", "Ideen verknüpfen"],
            "Parcours contextuels" => ["Contextual paths", "关联路径", "Rutas contextuales", "Kontextpfade"],
            "Les connexions entre discussions apparaîtront ici dès que les champs relationnels seront associés à cette vue." => ["Related content will appear once relationship fields are configured.", "配置关联字段后，这里将显示相关内容。", "El contenido relacionado aparecerá al configurar los campos de relaciones.", "Verknüpfte Inhalte erscheinen, wenn Beziehungsfelder konfiguriert sind."],
            "Bibliothèque du sujet" => ["Topic library", "主题资料库", "Biblioteca del tema", "Themenbibliothek"],
            "Ressources partagées" => ["Shared resources", "共享资源", "Recursos compartidos", "Geteilte Ressourcen"],
            "catégories" => ["categories", "个分类", "categorías", "Kategorien"],
            "Types de ressources" => ["Resource types", "资源类型", "Tipos de recursos", "Ressourcentypen"],
            "Synthèse de la communauté" => ["Community insights", "社区知识总结", "Síntesis comunitaria", "Community-Wissen"],
            "Questions fréquentes" => ["Frequently asked questions", "常见问题", "Preguntas frecuentes", "Häufige Fragen"],
            "Pistes complémentaires" => ["More to explore", "更多内容", "Más por explorar", "Weiterführende Themen"],
            "Autres publications de l’auteur" => ["More from this author", "作者的更多内容", "Más publicaciones del autor", "Weitere Beiträge des Autors"],
            "Contexte de la discussion" => ["Discussion context", "讨论背景", "Contexto del debate", "Diskussionskontext"],
            "Signal de conversation" => ["Conversation insights", "讨论数据", "Señales de conversación", "Diskussionsdaten"],
            "Lectures" => ["Reads", "阅读次数", "Lecturas", "Aufrufe"],
            "Statistiques disponibles pour cette discussion. Il ne s’agit pas d’un comptage en temps réel." => ["Available discussion statistics; these figures are not live.", "以下为讨论统计数据，并非实时数据。", "Estadísticas disponibles; los datos no son en tiempo real.", "Verfügbare Statistiken; keine Echtzeitdaten."],
            "Passer à l’action" => ["Take action", "参与互动", "Pasar a la acción", "Mitmachen"],
            "Enregistrez cette page sur votre appareil et partagez un passage précis avec sa source." => ["Save this page on your device and share an excerpt with its source.", "在设备上保存此页，并连同来源分享摘录。", "Guarda esta página y comparte un extracto con su fuente.", "Speichere diese Seite und teile einen Auszug mit Quellenangabe."],
            "Partager un passage" => ["Share an excerpt", "分享摘录", "Compartir un fragmento", "Auszug teilen"],
            "Raccourcis vers les idées" => ["Knowledge shortcuts", "知识快捷入口", "Accesos al conocimiento", "Wissens-Shortcuts"],
            "Forum indexable par conception." => ["Search-ready by design.", "为搜索引擎设计的论坛。", "Foro diseñado para buscadores.", "Suchmaschinenfreundlich gestaltet."],
            "Les textes, liens et relations restent accessibles sans dépendre de l’interface interactive." => ["Text, links and relationships are accessible without interactive scripts.", "文字、链接和关联内容无需交互脚本即可访问。", "Los textos, enlaces y relaciones son accesibles sin scripts interactivos.", "Texte, Links und Beziehungen bleiben ohne Skripte zugänglich."],
            "Revenir au début" => ["Back to top", "返回顶部", "Volver arriba", "Nach oben"],
            "Naviguer dans cette discussion" => ["Navigate this discussion", "浏览讨论", "Navegar por el debate", "Diskussion navigieren"],
            "Rechercher une section…" => ["Search sections…", "搜索章节…", "Buscar secciones…", "Abschnitte suchen…"],
            "Rechercher parmi les sections" => ["Search sections", "搜索章节", "Buscar secciones", "Abschnitte suchen"],
            "Introduction de la discussion" => ["Discussion introduction", "讨论导言", "Introducción al debate", "Diskussionseinführung"],
            "Connexions et parcours contextuels" => ["Related content and paths", "相关内容与关联路径", "Contenido y rutas relacionados", "Verwandte Inhalte und Pfade"],
            "Recherche locale parmi les sections visibles, sans service externe" => ["Local search of visible sections, no external service", "仅搜索可见章节，无外部服务", "Búsqueda local de secciones visibles", "Lokale Suche in sichtbaren Abschnitten"],
            "Fermer" => ["Close", "关闭", "Cerrar", "Schließen"],
            "Revenir au contexte" => ["Back to the context", "返回上下文", "Volver al contexto", "Zurück zum Kontext"],
            "Prolonger la discussion" => ["Continue exploring", "深入讨论", "Seguir explorando", "Weiter erkunden"],
            "Connexions pertinentes" => ["Relevant connections", "相关链接", "Conexiones relevantes", "Relevante Verbindungen"],
            "Pour aller plus loin" => ["Explore more", "深入探索", "Para saber más", "Mehr entdecken"],
            "Découvrir un autre angle" => ["Explore another perspective", "探索其他角度", "Explorar otra perspectiva", "Andere Perspektive entdecken"],
            "Fichiers" => ["Files", "文件", "Archivos", "Dateien"],
            "Documents" => ["Documents", "文档", "Documentos", "Dokumente"],
            "Liens" => ["Links", "链接", "Enlaces", "Links"],
            "Galerie" => ["Gallery", "图库", "Galería", "Galerie"],
            "Discussion introuvable." => ["Discussion not found.", "找不到讨论。", "Debate no encontrado.", "Diskussion nicht gefunden."],
            "Discussion et échanges de la communauté." => ["Community discussion and exchange.", "社区讨论与交流。", "Debate e intercambio comunitario.", "Diskussion und Austausch."],
            "Communauté" => ["Community", "社区", "Comunidad", "Community"],
            "Lien copié." => ["Link copied.", "链接已复制。", "Enlace copiado.", "Link kopiert."],
            "Impossible de copier automatiquement." => ["Automatic copying failed.", "自动复制失败。", "No se pudo copiar automáticamente.", "Automatisches Kopieren fehlgeschlagen."],
            "Sélectionnez un extrait du texte, puis réessayez." => ["Select an excerpt of text and try again.", "请选择文字后重试。", "Selecciona un fragmento e inténtalo de nuevo.", "Markiere zuerst einen Textauszug."],
            "Citation et source copiées." => ["Quote and source copied.", "摘录及来源已复制。", "Cita y fuente copiadas.", "Zitat und Quelle kopiert."],
            "La copie automatique a échoué." => ["Automatic copying failed.", "自动复制失败。", "Error al copiar automáticamente.", "Automatisches Kopieren fehlgeschlagen."],
            "Dans votre liste de lecture ✓" => ["Saved to your reading list ✓", "已加入稍后阅读 ✓", "Guardado en tu lista ✓", "Zur Leseliste hinzugefügt ✓"],
            "Ajouté sur cet appareil." => ["Saved on this device.", "已保存在此设备。", "Guardado en este dispositivo.", "Auf diesem Gerät gespeichert."],
            "Retiré de la liste locale." => ["Removed from this device.", "已从此设备移除。", "Eliminado de este dispositivo.", "Von diesem Gerät entfernt."],
        ];
        $locale = strtolower(explode('-', self::locale())[0]);
        $index = ['en'=>0, 'zh'=>1, 'es'=>2, 'de'=>3][$locale] ?? -1;
        return $index < 0 || !isset($translations[$phrase][$index]) ? $phrase : $translations[$phrase][$index];
    }

}
