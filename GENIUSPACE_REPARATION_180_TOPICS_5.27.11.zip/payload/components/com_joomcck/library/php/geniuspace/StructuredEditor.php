<?php
declare(strict_types=1);
namespace Geniuspace;

/** Guided controls are rendered on the server; the native field remains authoritative. */
final class StructuredEditor
{
    public static function definitions(): array
    {
        static $definitions;
        return $definitions ??= json_decode((string) file_get_contents(__DIR__ . '/editor-specs.json'), true, 32, JSON_THROW_ON_ERROR);
    }
    private static function get(array $data, string $key, mixed $default = ''): mixed
    {
        foreach (explode('.', $key) as $part) {
            if (!is_array($data) || !array_key_exists($part, $data)) return $default;
            $data = $data[$part];
        }
        return $data;
    }
    private static function set(array &$data, string $key, mixed $value): void
    {
        $parts = explode('.', $key); $target =& $data;
        foreach ($parts as $part) { if (!isset($target[$part]) || !is_array($target[$part])) $target[$part] = []; $target =& $target[$part]; }
        $target = $value;
    }
    private static function name(string $prefix, string $key): string
    { return $prefix . '[' . str_replace('.', '][', $key) . ']'; }
    public static function duration(mixed $value): int
    {
        if ($value === '' || $value === null) return 0;
        if (is_numeric($value)) return (int) $value;
        if (!is_string($value) || !preg_match('/^(\d{1,3}):([0-5]\d)(?::([0-5]\d))?$/D', $value, $m)) throw new \InvalidArgumentException('Indiquez une durée en minutes:secondes.');
        return isset($m[3]) ? (int) $m[1] * 3600 + (int) $m[2] * 60 + (int) $m[3] : (int) $m[1] * 60 + (int) $m[2];
    }
    private static function controls(array $specs, array $data, string $prefix, array $defaults, int $field): string
    {
        $e = [Text::class, 'escape']; $out = ''; $advanced = '';
        foreach ($specs as $spec) {
            $key = $spec['key']; $type = $spec['type']; $value = self::get($data, $key, $defaults[$key] ?? '');
            $name = self::name($prefix, $key); $id = 'nx-input-' . $field . '-' . substr(hash('sha256', $name), 0, 12) . (str_contains($prefix, '__row__') ? '-__row__' : ''); $html = '';
            if ($type === 'rows') {
                $rows = is_array($value) ? array_values($value) : []; $rows[] = [];
                $html = '<fieldset class="nx-input-rows" data-structured-rows="' . $e($key) . '"><legend>' . $e($spec['title']) . '</legend><input type="hidden" name="'.$e($name).'[_present]" value="1"><div data-structured-row-list>';
                foreach ($rows as $index => $row) $html .= '<div class="nx-input-row" data-structured-row><div class="nx-input-row-fields">' . self::controls($spec['fields'], is_array($row) ? $row : [], $name . '[' . $index . ']', [], $field) . '</div><button type="button" class="nx-input-remove" data-structured-remove aria-label="Retirer cette ligne">×</button></div>';
                $template = self::controls($spec['fields'], [], $name . '[__row__]', [], $field);
                $html .= '</div><template data-structured-row-template><div class="nx-input-row" data-structured-row><div class="nx-input-row-fields">' . $template . '</div><button type="button" class="nx-input-remove" data-structured-remove aria-label="Retirer cette ligne">×</button></div></template><button type="button" class="nx-input-add" data-structured-add>+ Ajouter</button></fieldset>';
            } else {
                if (is_array($value)) $value = $type === 'json' ? Seo::json($value) : implode("\n", $value);
                if ($type === 'datetime-local' && $value) $value = substr((string) $value, 0, 16);
                if ($type === 'duration') { $seconds = max(0, (int) $value); $value = sprintf('%d:%02d', intdiv($seconds, 60), $seconds % 60); }
                $attrs = ' name="' . $e($name) . '" id="' . $id . '" data-structured-key="' . $e($key) . '"';
                $html = '<label class="nx-input-control" for="' . $id . '"><span>' . $e($spec['title']) . '</span>';
                if ($type === 'select') {
                    $html .= '<select' . $attrs . '>';
                    foreach ($spec['options'] as $option) {
                        $labels = ['global'=>'Communauté', 'guild'=>'Groupe', 'company'=>'Entreprise', 'Hotel'=>'Hôtel', 'Restaurant'=>'Restaurant', 'Place'=>'Lieu ou pays', 'Book'=>'Livre ou manga', 'Movie'=>'Film ou série', 'VideoGame'=>'Jeu vidéo', 'Product'=>'Produit', 'Course'=>'Formation', 'CreativeWork'=>'Autre création', 'personal'=>'Progression personnelle', 'server'=>'Progression vérifiée', 'fr'=>'Français', 'en'=>'English', 'es'=>'Español', 'de'=>'Deutsch', 'zh'=>'中文', 'ja'=>'日本語'];
                        $labels+=['explore'=>'Explorer','candidate'=>'Candidature','series'=>'Séries & fiction','japan'=>'Japon','craft'=>'Folklore & création','resource'=>'Ressource','fiction'=>'Récit fictif','history'=>'Source historique','opinion'=>'Opinion','testimony'=>'Témoignage','creative_workshop'=>'Atelier créatif','discovery'=>'Découverte','visit'=>'Visite','residence'=>'Résidence déclarée','study'=>'Études','work'=>'Travail','creation'=>'Création'];
                        $labels+=['buying-pool'=>'Coalition d’achat','playtest'=>'Raid ou playtest','bounty'=>'Prime et enquête','partner'=>'Partenaire du dossier','consultation'=>'Rendez-vous expert','sponsor'=>'Sponsoring d’équipe','intent'=>'Offre inter-univers','TouristDestination'=>'Destination touristique','SoftwareApplication'=>'Application ou logiciel'];
                        $html .= '<option value="' . $e($option) . '"' . ((string) $value === $option ? ' selected' : '') . '>' . $e($labels[$option] ?? $option) . '</option>';
                    }
                    $html .= '</select>';
                } elseif ($type === 'checkbox') {
                    $html .= '<input type="hidden" name="' . $e($name) . '" value="0"><input type="checkbox"' . $attrs . ' value="1"' . ($value ? ' checked' : '') . '>';
                } elseif (in_array($type, ['record', 'records'], true)) {
                    $ids = $type === 'record' ? [(int) $value] : array_map('intval', preg_split('/[;,\s]+/', (string) $value, -1, PREG_SPLIT_NO_EMPTY));
                    if ($type === 'records') $attrs = str_replace(' name="'.$e($name).'"', ' name="'.$e($name).'[]"', $attrs);
                    $html .= '<select' . $attrs . ($type === 'records' ? ' multiple' : '') . ' data-structured-records><option value="0">Choisir une ressource</option>';
                    foreach ($ids as $record) if ($record > 0 && ($r = (new NativeAccess())->title($record))) $html .= '<option value="' . $record . '" selected>' . $e($r['title']) . '</option>';
                    $html .= '</select><input type="search" class="nx-record-lookup" data-structured-lookup placeholder="Rechercher par titre…" aria-label="Rechercher une ressource">';
                } elseif (in_array($type, ['textarea', 'lines', 'ids', 'numbers', 'json'], true)) {
                    $html .= '<textarea' . $attrs . ' rows="' . ($type === 'textarea' ? 5 : 2) . '">' . $e((string) $value) . '</textarea>';
                } else {
                    $html .= '<input type="' . ($type === 'duration' ? 'text' : $e($type)) . '"' . $attrs . ' value="' . $e((string) $value) . '"' . ($type === 'number' ? ' step="any"'.(isset($spec['min'])?' min="'.$e((string)$spec['min']).'"':'').(isset($spec['max'])?' max="'.$e((string)$spec['max']).'"':'') : '') . ($type === 'duration' ? ' placeholder="0:00" inputmode="decimal"' : '').($type==='datetime-local'?' data-utc-value="'.$e((string)self::get($data,$key,'')).'"':'') . '>';
                }
                $html .= '</label>';
            }
            if (!empty($spec['hidden'])) $html = '<div hidden>' . $html . '</div>';
            if (!empty($spec['advanced'])) $advanced .= $html; else $out .= $html;
        }
        if ($advanced) $out .= '<details class="nx-input-options"><summary>Options supplémentaires</summary><div class="nx-input-grid">' . $advanced . '</div></details>';
        return $out;
    }
    public static function render(object $field, string $kind, string $value, int $record): string
    {
        $definitions = self::definitions(); $specs = $definitions['lists'][$kind] ?? null;
        if (!$specs) return '';
        try { $data = json_decode($value ?: '{}', true, 32, JSON_THROW_ON_ERROR); } catch (\JsonException) { $data = []; }
        if (!is_array($data) || array_is_list($data) && $data) $data = [];
        $defaults = $definitions['defaults'][$kind] ?? []; $e = [Text::class, 'escape']; $id = (int) $field->id;
        $help = (string) $field->params->get('params.editor_help', '');
        if (!$help || preg_match('/JoomCCK|\bCCK\b|\bfields?\b|JSON|contrôles guidés/u', $help)) $help = match ($kind) {
            'market'=>'Ajoutez vos chiffres, leur date et leur source.', 'audio'=>'Joignez un audio ou enregistrez un mémo, puis ajoutez votre transcription.',
            'timedmedia'=>'La durée est détectée depuis votre vidéo. Ajoutez des chapitres et une transcription pour faciliter sa découverte.',
            'code'=>'Partagez votre code et expliquez ce que vous souhaitez réaliser.', 'room'=>'Présentez votre salon et choisissez votre horaire.',
            'review'=>'Présentez le contenu à évaluer. Les notes et les avis sont calculés à partir des contributions publiées.',
            default=>'Complétez les informations utiles à votre publication.'};
        $attributes = ['class'=>'gp-product-editor nx-structured-editor', 'data-structured-editor'=>$kind, 'data-product-editor'=>$kind, 'data-kind'=>$kind,
            'data-field'=>$id, 'data-record'=>$record, 'data-section'=>\Joomla\CMS\Factory::getApplication()->input->getInt('section_id'),
            'data-endpoint'=>\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.product', 'data-csrf'=>\Joomla\CMS\Session\Session::getFormToken()];
        $html = '<section'; foreach ($attributes as $key=>$v) $html .= ' '.$key.'="'.$e((string)$v).'"'; $html .= '><p class="nx-input-help">'.$e($help).'</p>';
        $prefix = 'nexus_fields['.$id.']';
        $html .= '<textarea hidden class="nx-structured-value" name="jform[fields]['.$id.']" id="field_'.$id.'">'.$e($value).'</textarea>';
        $html .= '<input type="hidden" name="'.$prefix.'[_timezone]" value="'.$e((string)ProductAccess::user()->getParam('timezone',\Joomla\CMS\Factory::getApplication()->get('offset','UTC'))).'" data-structured-timezone><input type="hidden" name="'.$prefix.'[_guided]" value="1"><input type="hidden" name="'.$prefix.'[asset_id]" value="'.(int)($data['asset_id']??0).'" data-structured-key="asset_id">';
        $html .= '<div class="nx-input-grid" data-product-controls>'.self::controls($specs, $data, $prefix, $defaults, $id).'</div>';
        if (ProductAccess::user()->authorise('core.admin')) $html .= '<details class="nx-input-import"><summary>Importer des données existantes</summary><label><input type="checkbox" name="'.$prefix.'[_mode]" value="import"> Utiliser les données importées</label><textarea name="'.$prefix.'[_import]" data-structured-import rows="5" aria-label="Données à importer">'.$e($value).'</textarea></details>';
        $html .= '<p class="gp-product-status" role="status"></p></section>';
        $doc = \Joomla\CMS\Factory::getApplication()->getDocument(); $base=\Joomla\CMS\Uri\Uri::root(true).'/components/com_joomcck/library/php/geniuspace/media/';
        $doc->addStyleSheet($base.'structured-editor.css', ['version'=>'5.11.0']);
        $doc->addScript($base.'structured-editor.js', ['version'=>'5.10.0'], ['type'=>'module']);
        return $html;
    }
    private static function normalize(array $specs, array $input, array $old, array $defaults,string $timezone='UTC'): array
    {
        foreach ($specs as $spec) {
            $key=$spec['key']; $value=self::get($input,$key,null); if ($value===null) continue;
            if (!empty($spec['optional']) && $value==='') continue;
            $type=$spec['type'];
            if ($type==='rows') {
                if (!is_array($value) || count($value)>100) throw new \InvalidArgumentException('Trop de lignes.');
                $existing=self::get($old,$key,[]); $rows=[];
                foreach ($value as $index=>$row) { if ($index==='_present') continue; if (!is_array($row)) throw new \InvalidArgumentException('Ligne invalide.');
                    $filled=false; foreach ($spec['fields'] as $child) { if(in_array($child['key'],['icon','color'],true))continue;$v=self::get($row,$child['key'],''); if($child['type']==='select'&&$v===($child['options'][0]??''))continue; if ($v!=='' && $v!=='0' && $v!==0 && $v!=='0:00' && $v!==[]) $filled=true; }
                    if ($filled) $rows[]=self::normalize($spec['fields'],$row,is_array($existing[$index]??null)?$existing[$index]:[],[],$timezone);
                }
                $value=$rows;
            } elseif ($type==='number') { if (!is_scalar($value) || $value!==''&&!is_numeric($value)) throw new \InvalidArgumentException('Nombre invalide.'); $value=$value===''?($defaults[$key]??0):0+$value; }
            elseif ($type==='record') $value=(int)$value;
            elseif ($type==='duration') $value=self::duration($value);
            elseif ($type==='checkbox') $value=(string)$value==='1';
            elseif (in_array($type,['ids','records','numbers','lines'],true)) {
                $values=is_array($value)?$value:preg_split($type==='lines'?'/[;\r\n]+/':'/[;,\s]+/',(string)$value,-1,PREG_SPLIT_NO_EMPTY);
                if ($type==='numbers') { foreach($values as $v) if(!is_scalar($v)||!is_numeric($v)) throw new \InvalidArgumentException('Valeur numérique invalide.'); $value=array_values(array_map(static fn($v)=>0+$v,$values)); }
                else $value=$type==='lines'?array_values(array_filter(array_map('trim',$values))):array_values(array_filter(array_map(static fn($v)=>(int)$v,$values),static fn($v)=>$v!==0));
            } elseif ($type==='json') { $value=$value===''?[]:json_decode((string)$value,true,24,JSON_THROW_ON_ERROR); }
            elseif ($type==='datetime-local') { try{$value=$value===''?'':(new \DateTimeImmutable((string)$value,new \DateTimeZone($timezone)))->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z');}catch(\Exception){throw new \InvalidArgumentException('Date invalide.');} }
            else { if (!is_scalar($value)) throw new \InvalidArgumentException('Saisie invalide.'); $value=(string)$value;if($key==='icon'&&$value==='')$value='chart-line';if($type==='color'&&!preg_match('/^#[0-9a-f]{6}$/iD',$value))$value='#4f46e5'; }
            self::set($old,$key,$value);
        }
        return $old;
    }
    public static function submitted(object $field, string $kind, mixed $value): string
    {
        $raw=is_string($value)?$value:''; $all=\Joomla\CMS\Factory::getApplication()->input->post->get('nexus_fields',[],'array'); $input=$all[(int)$field->id]??null;
        if (!is_array($input) || !isset($input['_guided']))return $raw; if(($input['_mode']??'')==='import'){if(!ProductAccess::user()->authorise('core.admin'))throw new \DomainException('Import réservé à un administrateur.',403);return self::get($input,'_import',$raw);}
        if (strlen(Seo::json($input))>131072) throw new \InvalidArgumentException('Publication trop longue.');
        $definitions=self::definitions(); $specs=$definitions['lists'][$kind]??[]; $defaults=$definitions['defaults'][$kind]??[];
        try {$old=json_decode($raw?:'{}',true,32,JSON_THROW_ON_ERROR);} catch(\JsonException) {$old=[];}
        if (!is_array($old) || array_is_list($old)&&$old) throw new \InvalidArgumentException('Données initiales invalides.');
        $data=self::normalize($specs,$input,$old,$defaults,(string)($input['_timezone']??ProductAccess::user()->getParam('timezone',\Joomla\CMS\Factory::getApplication()->get('offset','UTC'))));if($kind==='proof')foreach($data['references']??[]as$index=>$reference){if(!empty($reference['record_id'])&&empty($reference['field_id'])){$public=(new NativeAccess())->record((int)$reference['record_id']);foreach($public['fields']??[]as$id=>$candidate)if(in_array($candidate['field_type'],['gpproof','gpvalidity'],true)&&!empty($public['values'][$id])){$data['references'][$index]['field_id']=(int)$id;break;}if(empty($data['references'][$index]['field_id']))throw new \InvalidArgumentException('Cette ressource ne comporte pas de sources documentées. Ajoutez son lien dans une affirmation.');}}
        if (isset($input['asset_id'])) $data['asset_id']=(int)$input['asset_id'];
        $filled=false; foreach ($specs as $spec) { $v=self::get($data,$spec['key'],''); if (!empty($spec['advanced'])||!empty($spec['hidden'])){if(in_array($spec['key'],['bindings','src'],true)&&$v)$filled=true;continue;} if ($v!==''&&$v!==0&&$v!==false&&$v!==[]&&$v!==($defaults[$spec['key']]??null)) $filled=true; }
        $known=array_merge(array_column($specs,'key'),['asset_id']);foreach(array_diff_key($data,array_flip($known))as$v)if($v)$filled=true;
        if (!$filled && empty($data['asset_id'])) return '';
        return Seo::json($data);
    }
}
