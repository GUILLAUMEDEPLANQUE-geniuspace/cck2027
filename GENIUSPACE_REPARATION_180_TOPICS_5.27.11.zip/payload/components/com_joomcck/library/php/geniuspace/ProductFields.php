<?php
declare(strict_types=1);
namespace Geniuspace;

/** Native-field rendering shared by Multivers and existing CCK templates. */
final class ProductFields
{
    public static function assets(): void
    {
        // A product field also works in the original CCK templates, without the forum shell.
        require_once __DIR__.'/NexusConnect.php';
        static $done=false;if($done)return;$done=true;$doc=\Joomla\CMS\Factory::getApplication()->getDocument();
        $base=\Joomla\CMS\Uri\Uri::root(true).'/components/com_joomcck/library/php/geniuspace/media/';
        $doc->addStyleSheet(\Joomla\CMS\Uri\Uri::root(true).'/media/com_joomcck/nexus/connect-icons.css',['version'=>'5.10.0']);
        $doc->addStyleSheet($base.'product-fields.css',['version'=>'5.11.0']);
        $doc->addScript($base.'product-fields.js',['version'=>'5.14.1'],['type'=>'module']);
    }
    public static function editor(object $f,string $value,int $record): string
    {
        require_once __DIR__.'/StructuredEditor.php';
        if($guided=StructuredEditor::render($f,$f->gpKind,$value,$record))return $guided;
        $e=[Text::class,'escape'];$help=(string)$f->params->get('params.editor_help','Renseignez les données du field.');
        $data=['data-product-editor'=>$f->gpKind,'data-record'=>$record,'data-section'=>\Joomla\CMS\Factory::getApplication()->input->getInt('section_id'),'data-field'=>(int)$f->id,
            'data-endpoint'=>\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.product',
            'data-csrf'=>\Joomla\CMS\Session\Session::getFormToken()];
        if($f->gpKind==='element'){$type=(int)($f->type_id??0);$levels=ProductAccess::user()->getAuthorisedViewLevels();$available=[];foreach(ProductAccess::store()->rows('SELECT id,label,params FROM #__js_res_fields WHERE published=1 AND type_id='.$type.' AND access IN ('.implode(',',$levels?:[0]).') ORDER BY ordering',500)as$row){$params=json_decode($row['params']??'{}',true)?:[];if(in_array((int)($params['core']['field_view_access']??1),$levels,true)&&in_array((int)($params['core'][$record?'field_edit_access':'field_submit_access']??2),$levels,true))$available[]=['id'=>(int)$row['id'],'label'=>$row['label']];}$data['data-available-fields']=Seo::json($available);}
        $attrs='';foreach($data as$key=>$v)$attrs.=' '.$key.'="'.$e((string)$v).'"';
        return '<section class="gp-product-editor"'.$attrs.'><p>'.$e($help).'</p><div data-product-controls></div><details><summary>Données structurées / import</summary><textarea class="form-control" rows="8" name="jform[fields]['.(int)$f->id.']" id="field_'.(int)$f->id.'">'.$e($value?:'{}').'</textarea></details><p class="gp-product-status" role="status"></p></section>';
    }
    public static function render(object $f,object $record,bool $full): string
    {
        self::assets();try{$d=ProductData::parse($f->gpKind,(string)$f->value);}catch(\InvalidArgumentException){return '<p>Ce contenu doit être révisé par son auteur.</p>';}
        if(!ProductData::hasContent($f->gpKind,$d))return '';if($f->gpKind==='element'&&!$full)return '<span class="gp-element-summary">'.Text::escape($d['title']?:ElementData::ELEMENTS[$d['element']]).'</span>';
        $dependencies=['hub'=>['record_followers'],'audio'=>['audio_assets','audio_feedback'],'simulation'=>['simulation_submissions'],'passport'=>['passport_grants','proof_reviews'],'element'=>['resume_items','record_versions','experience_preferences'],'review'=>['forum_reviews'],'teamspace'=>['record_followers'],'room'=>['room_sessions','room_signals'],'team'=>['company_team'],'opportunity'=>['hub_participations','hub_proposals']];
        if(isset($dependencies[$f->gpKind])&&!SchemaHealth::has(...$dependencies[$f->gpKind]))return '<p class="gp-product-note">Cet outil est en maintenance ; le contenu de la fiche reste accessible.</p>';
        $r=get_object_vars($record);$id=(int)$record->id;$field=(int)$f->id;
        $out=match($f->gpKind){
            'journey'=>PathPresentation::field($d,$r,$field,$full),
            'hub'=>self::hub($d,$r,$field),'market'=>self::market($d,$f),'audio'=>AudioWorkshop::render($d,$r,$field,$full),
            'code'=>self::code($d),'simulation'=>Simulation::render($d,$r,$field,$full),
            'skillterm'=>self::term($d),'passport'=>Passport::render($d,$r,$field),'room'=>AudioRoom::render($d,$r,$field),
            'element'=>ElementLibrary::render($d,$r,$field,$full),'team'=>CompanyTeam::render($r,$field),'review'=>ForumReviews::render($d,$r,$field),'timedmedia'=>TimedMedia::render($d,$r,$field),'teamspace'=>GamingTeam::render($d,$r,$field),'opportunity'=>HubOpportunity::render($d,$r,$field),'spoiler'=>'<aside class="forum8-spoiler-notice">'.Text::escape($d['label'].' '.$d['chapter']).'</aside>',default=>''};
        if($out==='')return '';
        if(ProductAccess::user()->id)\Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);
        $attrs=['data-product-kind'=>$f->gpKind,'data-record'=>$id,'data-field'=>$field,
            'data-endpoint'=>\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.product',
            'data-csrf'=>ProductAccess::user()->id?\Joomla\CMS\Session\Session::getFormToken():''];$attrs['data-metrics']=ProductAccess::user()->id&&SchemaHealth::has('experience_preferences')&&Experience::preferences()['metrics']?'1':'0';$a='';foreach($attrs as$key=>$v)$a.=' '.$key.'="'.Text::escape((string)$v).'"';
        return '<section class="gp-product-widget"'.$a.'>'.$out.'</section>';
    }
    public static function hub(array $d,array $r,int $field): string
    {
        $id=(int)$r['id'];$s=ProductAccess::store();$total=(int)($s->rows('SELECT COUNT(*) AS n FROM #__gp_social_record_followers WHERE record_id='.$id.' AND field_id='.$field,1)[0]['n']??0);
        $out='<div class="gp-hub-summary"><span class="gp-hub-symbol" style="--gp-hub-color:'.Text::escape($d['color']).'"><i class="fa-solid fa-'.Text::escape($d['icon']).'" aria-hidden="true"></i></span><div><h3>'.Text::escape($r['title']).'</h3><p>'.Text::escape($d['description']).'</p><small>'.$total.' membres abonnés</small></div></div>';
        if(ProductAccess::user()->id){$following=$s->rows('SELECT user_id FROM #__gp_social_record_followers WHERE record_id='.$id.' AND field_id='.$field.' AND user_id='.(int)ProductAccess::user()->id,1);
            $out.=ProductAccess::form('hub',$id,['field'=>$field,'join'=>$following?0:1]).'<button>'.($following?'Ne plus suivre cet espace':'Suivre cet espace').'</button></form>';}
        foreach($d['record_ids']as$related)if(($p=(new NativeAccess())->title($related)))$out.='<a class="gp-record-link" href="'.Text::escape($p['url']).'">'.Text::escape($p['title']).' →</a>';
        return $out;
    }
    public static function market(array $d,object $f): string
    {
        $out='<div class="gp-market-metrics">';$days=max(1,(int)$f->params->get('params.stale_days',30));
        foreach($d['metrics']as$m){$old=!$m['observed_at']||strtotime($m['observed_at'])<time()-$days*86400;
            $out.='<article class="gp-market-metric"><span class="gp-market-icon" style="color:'.Text::escape($m['color']).'"><i class="fa-solid fa-'.Text::escape($m['icon']).'" aria-hidden="true"></i></span><div><h4>'.Text::escape($m['label']).'</h4><p>'.Text::escape($m['context']).'</p><small>'.($old?'À actualiser':'Daté').' · '.Text::escape($m['observed_at']).'</small></div><strong>'.Text::escape(self::format($m['value']).' '.$m['unit']).'</strong></article>';
            $source=$m['source_record']?(new NativeAccess())->title($m['source_record']):null;$url=$source['url']??$m['source_url'];
            if($url)$out.='<a class="gp-source-link" href="'.Text::escape($url).'" rel="nofollow noopener">Source de cette donnée</a>';
        }$out.='</div>';
        if($d['conversions']){$out.='<div data-product-conversion><label>Montant <input type="number" min="0" step=".01" value="100" data-conversion-amount></label><label>Conversion <select data-conversion-rate>';
            foreach($d['conversions']as$c)$out.='<option value="'.Text::escape((string)$c['rate']).'" data-unit="'.Text::escape($c['to']).'">'.Text::escape($c['from'].' → '.$c['to'].' · '.$c['observed_at']).'</option>';
            $out.='</select></label><output data-conversion-result></output></div>';}
        if($d['disclaimer'])$out.='<p class="gp-product-note">'.Text::escape($d['disclaimer']).'</p>';return $out;
    }
    public static function format(float $value): string
    { return number_format($value,fmod($value,1.0)===0.0?0:2,',',' '); }
    public static function code(array $d): string
    {
        $e=[Text::class,'escape'];$escaped=$e($d['source']);$keywords=['fn','if','else','return','const','let','function','async','await','pub','use','struct','impl','match','def','class','true','false','null'];
        $highlight=preg_replace_callback('~(//[^\r\n]*|\b(?:fn|if|else|return|const|let|function|async|await|pub|use|struct|impl|match|def|class|true|false|null)\b|\b[a-zA-Z_][a-zA-Z0-9_]*(?=\s*\())~',static function($m)use($keywords){$class=str_starts_with($m[0],'//')?'comment':(in_array($m[0],$keywords,true)?'keyword':'function');return '<span class="'.$class.'">'.$m[0].'</span>';},$escaped);
        return '<div class="interactive-sandbox code-sandbox gp-code" data-product-code data-language="'.$e($d['language']).'" data-timeout="'.$d['timeout_ms'].'"><div class="gp-code-toolbar"><span>'.$e($d['language']).'</span><button type="button" data-code-run>'.($d['language']==='javascript'?'Exécuter':'Analyser').'</button></div><pre><code>'.$highlight.'</code></pre><p>'.$e($d['description']).'</p>'.($d['expected']?'<p>Attendu : '.$e($d['expected']).'</p>':'').'<output data-code-output aria-live="polite"></output></div>';
    }
    public static function term(array $d): string
    {
        $out='<h3>'.Text::escape($d['label']).'</h3><p>'.Text::escape($d['description']).'</p><p><code>'.Text::escape($d['code']).'</code> · '.Text::escape($d['domain']).'</p>';
        if($d['aliases'])$out.='<p>Alias : '.Text::escape(implode(', ',$d['aliases'])).'</p>';
        if($d['reference_url'])$out.='<a href="'.Text::escape($d['reference_url']).'" rel="noopener">Référentiel associé</a>';return $out;
    }
}
