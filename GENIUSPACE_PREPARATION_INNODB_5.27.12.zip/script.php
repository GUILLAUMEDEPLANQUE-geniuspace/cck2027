<?php
defined('_JEXEC') or die;
class files_geniuspace_innodbmaintenanceInstallerScript
{
    private string $source='';
    private array $manifest=[];
    public function preflight($type,$parent): bool
    {
        if($type==='uninstall')return true;
        try{$u=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$u->id||$u->block||!$u->authorise('core.admin'))throw new \RuntimeException('Installation par un super administrateur requise.');if(PHP_VERSION_ID<80300)throw new \RuntimeException('PHP 8.3 minimum requis.');if(!function_exists('gzopen'))throw new \RuntimeException('Activez zlib pour les sauvegardes compressées.');if(!is_file(JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php'))throw new \RuntimeException('Installez d’abord le composant Geniuspace / JoomCCK.');
            $this->source=$parent->getParent()->getPath('source');$this->manifest=json_decode(file_get_contents($this->source.'/MAINTENANCE.json'),true,16,JSON_THROW_ON_ERROR);
            $allowed=['components/com_joomcck/library/php/geniuspace/InnoDbMaintenance.php','components/com_joomcck/controllers/innodb.php','components/com_joomcck/views/tools/tmpl/nexusdatabase.php','media/com_joomcck/nexus/innodb-maintenance.js'];
            if(array_diff(array_keys($this->manifest['files']),$allowed)||count($this->manifest['files'])!==4)throw new \RuntimeException('Périmètre du paquet invalide.');foreach($this->manifest['files']as$p=>$sha){$target=JPATH_ROOT.'/'.$p;for($walk=$target;strlen($walk)>strlen(JPATH_ROOT);$walk=dirname($walk))if(is_link($walk))throw new \RuntimeException('Lien symbolique refusé.');if(!hash_equals($sha,hash_file('sha256',$this->source.'/payload/'.$p)))throw new \RuntimeException('Paquet altéré.');if(is_file($target)&&!hash_equals($sha,hash_file('sha256',$target)))throw new \RuntimeException('Un outil de maintenance personnalisé existe déjà : '.$p);}
            return true;
        }catch(\Throwable $e){\Joomla\CMS\Factory::getApplication()->enqueueMessage($e->getMessage(),'error');return false;}
    }
    public function install($p): bool{return $this->apply();}
    public function update($p): bool{return $this->apply();}
    private function apply(): bool
    {
        $created=[];try{foreach($this->manifest['files']as$p=>$sha){$target=JPATH_ROOT.'/'.$p;if(is_file($target))continue;if(!is_dir(dirname($target))&&!mkdir(dirname($target),0755,true))throw new \RuntimeException('Dossier cible inaccessible.');$tmp=$target.'.prepare-'.bin2hex(random_bytes(6));if(!copy($this->source.'/payload/'.$p,$tmp))throw new \RuntimeException('Copie interrompue.');chmod($tmp,0644);if(!rename($tmp,$target)){@unlink($tmp);throw new \RuntimeException('Enregistrement interrompu.');}$created[]=$target;if(function_exists('opcache_invalidate'))opcache_invalidate($target,true);}return true;}
        catch(\Throwable $e){foreach($created as$p)if(is_file($p))unlink($p);\Joomla\CMS\Factory::getApplication()->enqueueMessage($e->getMessage(),'error');return false;}
    }
    public function postflight($type,$p): void
    {
        if($type==='uninstall')return;$url=\Joomla\CMS\Uri\Uri::root().'administrator/index.php?option=com_joomcck&view=tools&layout=nexusdatabase';echo '<div class="alert alert-info"><strong>Assistant InnoDB installé.</strong> Aucun moteur de table n’a été modifié. <a class="btn btn-primary" href="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'">Ouvrir l’assistant de préparation InnoDB</a></div>';
    }
    public function uninstall($p): bool{return true;}
}
