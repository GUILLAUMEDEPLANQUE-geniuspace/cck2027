# Choisir une configuration PC à partir des jeux et de l’écran, pas d’une liste de composants

Un PC de jeu se choisit à partir d’une situation : quels jeux, sur quel écran, avec quels réglages et quelle tolérance aux ralentissements ? Commencer par une carte graphique ou un processeur inverse le problème. Une machine peut être adaptée à un jeu compétitif peu exigeant visuellement et décevante pour une simulation chargée, sans que son prix explique à lui seul cette différence.

## Décrire le résultat attendu avant le matériel

Écrivez trois scénarios représentatifs. Pour chacun, notez le jeu, sa version, la définition de l’écran, les réglages importants et le type de séquence : exploration, combat, ville dense ou partie en ligne. Ajoutez une contrainte de bruit, d’encombrement ou de consommation si elle compte réellement. Une configuration silencieuse sous le bureau ne répond pas au même cahier des charges qu’un ordinateur transporté chaque semaine.

La fréquence de l’écran indique le nombre de rafraîchissements possibles par seconde ; elle ne garantit pas que le jeu produira autant d’images régulières. Pour suivre le mouvement, le temps entre les images compte aussi. À cadence constante, 60 images par seconde correspondent à environ 16,7 millisecondes par image ; 120 correspondent à environ 8,3 millisecondes. Ce calcul explique un objectif de cadence, pas le comportement d’un jeu particulier.

## Construire une fiche de décision comparable

| Question | Information à conserver | Pourquoi elle change le choix |
|---|---|---|
| Que jouerez-vous ? | Trois jeux et leurs versions | Les charges diffèrent selon le moteur et la scène |
| Que doit afficher l’écran ? | Définition, fréquence, réglages | Une comparaison doit garder le même objectif visuel |
| Qu’acceptez-vous de réduire ? | Réglages négociables et indispensables | Le compromis devient explicite avant l’achat |
| Que faut-il financer ? | Tour, écran, périphériques et marge de maintenance | Le budget ne se limite pas à un composant |

Un benchmark devient exploitable lorsqu’il décrit sa configuration, ses réglages et sa procédure. Deux chiffres pris sur des scènes différentes ne constituent pas une confrontation équitable. Conservez aussi la date du test : une mise à jour du jeu ou des pilotes peut rendre une conclusion moins représentative.

## Un budget fictif pour mettre les compromis à plat

Supposons une enveloppe totale de 1 400 euros, dont 250 pour l’écran et 150 pour les périphériques et petits équipements. Il reste 1 000 euros pour la tour. Ce sont des hypothèses de calcul, pas des prix de marché. Si une proposition consacre déjà 1 350 euros à la tour, elle ne respecte pas le besoin de départ, même si son rapport performances/prix paraît séduisant.

Comparez ensuite deux configurations candidates sur les trois mêmes scénarios. Une proposition qui gagne nettement dans un jeu rarement utilisé peut être moins pertinente qu’une autre, plus régulière dans le jeu principal et plus compatible avec le bruit accepté. Documentez la raison du compromis plutôt que de désigner un vainqueur universel.

## Vérifier la décision après l’achat

Gardez la fiche de départ pour la réception. Vérifiez le modèle des pièces, les branchements, l’affichage et les conditions d’un essai reproductible. Si un résultat diffère fortement d’un test, cherchez d’abord une différence de réglage ou de contexte avant de conclure à une panne.

- Définissez les usages avant de choisir des références.
- Comparez des tests dont les conditions sont explicites.
- Faites entrer tous les achats dans la même enveloppe.
- Notez le compromis accepté et la condition qui ferait changer de choix.

L’étape suivante consiste à examiner les temps de trame et les ralentissements, puis à ouvrir une discussion avec les paramètres de votre scénario. Une réponse communautaire sera plus précise avec ce dossier qu’avec la seule question « Quelle est la meilleure configuration ? ».
