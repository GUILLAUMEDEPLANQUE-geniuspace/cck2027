<?php
/** Multivers design follows the user prototype; all content is native CCK output. GPL-2.0-or-later. */
defined('_JEXEC') or die;
require_once __DIR__.'/NexusHub.php';
require_once __DIR__.'/NexusConversation.php';
require_once __DIR__.'/NexusParticipationUI.php';
require_once __DIR__.'/NexusParticipation.php';

final class NexusMultivers
{
    public static function assets(): void
    {
        NexusConnect::assets();\Geniuspace\ProductFields::assets();NexusParticipationUI::assets();static $done=false;if($done)return;$done=true;
        $app=\Joomla\CMS\Factory::getApplication();$doc=$app->getDocument();$root=\Joomla\CMS\Uri\Uri::root(true);
        $doc->addStyleSheet($root.'/media/com_joomcck/nexus/multivers-v57.css',['version'=>'5.10.0']);
        $doc->addScript($root.'/media/com_joomcck/nexus/multivers-v57.js',['version'=>'5.16.0'],['type'=>'module']);
        if($app->getIdentity()->id)$app->setHeader('Cache-Control','private, no-store',true);
    }
    public static function avatar(string $name,string $color='#4f46e5',int $size=40): string
    {
        if(!preg_match('/^#[a-f0-9]{6}$/iD',$color))$color='#4f46e5';
        return '<span class="meta-avatar rounded-full border border-slate-200" style="--meta-avatar-color:'.$color.';width:'.$size.'px;height:'.$size.'px" aria-hidden="true">'.NexusSuite::e(mb_substr($name?:'V',0,1)).'</span>';
    }
    public static function field($item,$p,string $slot): ?object
    { return NexusConnect::field($item,NexusPlatform::config($p,$slot)); }
    public static function data($item,$p,string $slot,string $kind): ?array
    {
        $f=self::field($item,$p,$slot);if(!$f||!($f instanceof JFormFieldCProduct)||$f->gpKind!==$kind)return null;
        try{return \Geniuspace\ProductData::parse($kind,(string)$f->value);}catch(\InvalidArgumentException){return null;}
    }
    public static function widget($item,$p,string $slot,bool $rich=true): string
    {
        $f=self::field($item,$p,$slot);if(!$f)return '';
        return (string)$f->result;
    }
    public static function categories($view,$p): array
    {
        $cp=$view->tmpl_params['category']??$p;$categories=NexusForumIndex::categories($view,$cp);$flat=[];
        $visit=function($nodes)use(&$visit,&$flat){foreach($nodes as$c){$flat[]=$c;if(!empty($c->children))$visit($c->children);}};$visit($categories);return $flat;
    }
    public static function appearance($category,$p): array
    {
        $id=(int)$category->id;$appearance=['icon'=>'hashtag','color'=>'#4f46e5','style'=>''];
        if(($category->params??null) instanceof \Joomla\Registry\Registry){$icon=(string)$category->params->get('icon');$color=(string)$category->params->get('color');if(preg_match('/^[a-z][a-z0-9-]{0,59}$/D',$icon))$appearance['icon']=$icon;if(preg_match('/^#[a-f0-9]{6}$/iD',$color))$appearance['color']=$color;}
        foreach((array)$p->get('tmpl_params.category_appearance',[])as$row){$row=(array)$row;if((int)($row['category']??0)!==$id)continue;
            if(preg_match('/^[a-z][a-z0-9-]{0,59}$/D',(string)($row['icon']??'')))$appearance['icon']=$row['icon'];
            if(preg_match('/^#[a-f0-9]{6}$/iD',(string)($row['color']??'')))$appearance['color']=$row['color'];
            if(in_array($row['style']??'',['business','crypto','immo','gaming',''],true))$appearance['style']=$row['style'];
        }return $appearance;
    }
    public static function tags(array $categories,$p,string $home,int $active=0): string
    {
        $e=[NexusSuite::class,'e'];$out='<div class="relative w-full"><nav class="flex gap-3 overflow-x-auto hide-scroll pb-2 items-center" aria-label="Thématiques du Méta-Hub"><a class="holo-tag'.(!$active?' active':'').'" href="'.$e($home).'">'.NexusConnect::icon('wand-magic-sparkles').' '.$e(NexusPlatform::config($p,'feed_title','Méta-Feed')).'</a>';
        foreach($categories as$c){$url=NexusPlatform::sameSite((string)$c->link);if(!$url)continue;$a=self::appearance($c,$p);
            $out.='<a class="holo-tag '.$e($a['style']).($active===(int)$c->id?' active':'').'" style="--nx-topic-color:'.$e($a['color']).'" href="'.$e($url).'"'.($active===(int)$c->id?' aria-current="page"':'').'>'.NexusConnect::icon($a['icon']).' '.$e($c->title).'</a>';}
        return $out.'</nav></div>';
    }
    public static function regionFields(array $items,$p,string $position,string $slot=''): array
    {
        $out=[];foreach($items as$i){if($slot&&($f=self::field($i,$p,$slot)))$out[(int)$i->id.':'.(int)$f->id]=[$i,$f];
            foreach(NexusConnect::groups($i,$p)as$group)if($group['position']===$position)foreach($group['fields']as$f)$out[(int)$i->id.':'.(int)$f->id]=[$i,$f];}
        return array_values($out);
    }
    public static function ticker(array $items,$p): string
    {
        $entries=[];foreach(self::regionFields($items,$p,'ticker','field_ticker')as[$i,$f]){
            if($f instanceof JFormFieldCProduct&&$f->gpKind==='market')try{$d=\Geniuspace\ProductData::parse('market',(string)$f->value);
                foreach($d['metrics']as$m)$entries[]='<span class="ticker-item"><span style="color:'.NexusSuite::e($m['color']).'">'.NexusConnect::icon($m['icon']).' '.NexusSuite::e($m['label']).' :</span> '.NexusSuite::e(\Geniuspace\ProductFields::format($m['value']).' '.$m['unit']).($m['context']?' · '.NexusSuite::e($m['context']):'').'</span>';
            }catch(\InvalidArgumentException){}
            else $entries[]='<span class="ticker-item">'.NexusSuite::e(NexusSuite::plain($f->result)).'</span>';
        }
        if(!$entries)return '';
        return '<div class="ticker-wrap h-8 border-b border-cyan-900/50 flex items-center shrink-0"><div class="ticker">'.implode('',$entries).'</div><button type="button" class="ticker-toggle" data-meta-ticker-pause aria-label="Suspendre le bandeau" aria-pressed="false">Ⅱ</button></div>';
    }
    public static function header($p,int $section,string $home): string
    {
        $e=[NexusSuite::class,'e'];$icon=[NexusConnect::class,'icon'];$u=\Joomla\CMS\Factory::getApplication()->getIdentity();$input=\Joomla\CMS\Factory::getApplication()->input;
        $notifications=$u->id?\Geniuspace\ProductNotifications::items((int)$u->id):[];
        $account=NexusPlatform::sameSite('index.php?option=com_users&view='.($u->id?'profile':'login'));
        $out='<header class="meta-header bg-white/90 backdrop-blur-md px-6 py-3 flex justify-between items-center border-b border-slate-200 z-30 shrink-0 shadow-sm"><a href="'.$e($home).'" class="meta-brand text-2xl font-extrabold text-primary flex items-center gap-2 font-display">'.$icon('bolt').' '.$e(NexusPlatform::config($p,'brand','TalentNexus')).' <span class="text-[10px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded font-sans tracking-widest uppercase">'.$e(NexusPlatform::config($p,'brand_caption','Méta-Hub')).'</span></a>';
        $out.='<form method="get" action="'. $e(\Joomla\CMS\Uri\Uri::root()).'" class="meta-search-form flex bg-slate-50 rounded-full px-4 py-2 items-center w-full max-w-xl border border-slate-200 focus-within:border-primary focus-within:ring-2 focus-within:ring-indigo-100 transition-all shadow-inner"><input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="view" value="records"><input type="hidden" name="section_id" value="'.$section.'">';
        if($input->getInt('Itemid'))$out.='<input type="hidden" name="Itemid" value="'.$input->getInt('Itemid').'">';
        $out.=$icon('magnifying-glass').'<input name="nx_query" type="search" value="'.$e($input->getString('nx_query')).'" placeholder="'.$e(NexusPlatform::config($p,'search_placeholder','Rechercher un job, un pays, un token, une compétence…')).'" aria-label="Rechercher dans les contenus publics du site" class="bg-transparent border-none text-sm text-slate-900 ml-3 outline-none w-full placeholder-slate-400" maxlength="2000"><button class="bg-primary text-white text-[10px] uppercase tracking-wider font-bold px-4 py-1.5 rounded-full hover:bg-primary-hover transition-colors">Explorer</button></form>';
        $out.='<div class="flex items-center gap-5">';
        if(NexusPlatform::config($p,'show_wallet','1')==='1')$out.='<div><button type="button" class="meta-wallet-button hidden md:flex items-center gap-2 bg-slate-900 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-slate-800 transition shadow-md" data-meta-wallet><i class="fa-brands fa-ethereum text-web3" aria-hidden="true"></i><span data-meta-wallet-label>Connecter mon wallet</span></button><span class="meta-wallet-status" role="status"></span></div>';
        $out.='<div class="meta-notifications"><button type="button" class="relative bg-transparent" data-meta-notifications aria-label="Notifications" aria-expanded="false">'.$icon('bell');
        if($notifications)$out.='<span class="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 rounded-full border-2 border-white flex items-center justify-center text-[9px] text-white font-bold">'.count($notifications).'</span>';
        $out.='</button><div class="meta-notifications-panel" hidden>';
        if(!$notifications)$out.='<p class="text-xs text-slate-500">Aucune notification non lue.</p>';
        foreach($notifications as$n)$out.='<a href="'.$e($n['url']).'">'.$e($n['label']).'</a>';
        $identity=$u->id&&class_exists('Geniuspace\\AccountIdentity')?\Geniuspace\AccountIdentity::render((int)$u->id):'';
        $out.='</div></div>'.($identity?'<div class="nx-header-identity">'.$identity.'</div>':'').'<a href="'.$e($account).'" aria-label="'.($u->id?'Mon compte':'Se connecter').'">'.($identity?$icon('user-gear'):self::avatar($u->id?$u->name:'V')).'</a></div></header>';return $out;
    }
    public static function rail(array $categories,$p,array $items,string $home): string
    {
        $e=[NexusSuite::class,'e'];$out='<nav class="meta-rail shrink-0 flex flex-col items-center py-5 gap-4 z-20 shadow-2xl relative" aria-label="Espaces du Méta-Hub"><a class="meta-rail-link" href="'.$e($home).'" aria-label="Le Méta-Hub"><div class="w-12 h-12 bg-primary text-white rounded-[16px] flex items-center justify-center text-xl shadow-lg">'.NexusConnect::icon('earth-europe').'</div><span class="meta-rail-label">Le Méta-Hub</span></a><div class="meta-rail-divider w-8 h-[2px] bg-slate-800 rounded-full my-1"></div>';
        foreach($categories as$c){$a=self::appearance($c,$p);$url=NexusPlatform::sameSite((string)$c->link);if(!$url)continue;
            $out.='<a class="meta-rail-link opacity-70 hover:opacity-100 transition-all hover:scale-105" href="'.$e($url).'" aria-label="'.$e($c->title).'"><div class="w-12 h-12 text-white rounded-[24px] hover:rounded-[16px] transition-all flex items-center justify-center text-xl shadow-lg" style="background:'.$e($a['color']).'">'.NexusConnect::icon($a['icon']).'</div><span class="meta-rail-label">'.$e($c->title).'</span></a>';}
        $seen=[];foreach(self::regionFields($items,$p,'workspaces','field_workspaces')as[$i,$f]){
            $ids=[];if($f instanceof JFormFieldCProduct&&$f->gpKind==='hub'){$ids=[(int)$i->id];}else try{$d=\Geniuspace\FieldEngine::parse('relation',(string)$f->value,\Geniuspace\FieldOptions::params($f->params));$ids=$d['record_ids'];}catch(\InvalidArgumentException){}
            foreach($ids as$id){if(isset($seen[$id])||!($target=(new \Geniuspace\NativeAccess())->record($id)))continue;$seen[$id]=true;
                $out.='<a class="meta-rail-link opacity-70 hover:opacity-100 transition-all hover:scale-105" href="'.$e(NexusPlatform::sameSite($target['record']['url'])).'" aria-label="'.$e($target['record']['title']).'"><div class="w-12 h-12 bg-slate-800 text-white rounded-[24px] flex items-center justify-center text-xl border border-slate-700">'.$e(mb_substr($target['record']['title'],0,1)).'</div><span class="meta-rail-label">'.$e($target['record']['title']).'</span></a>';
            }
        }
        $submit=NexusPlatform::sameSite(NexusPlatform::config($p,'workspace_submit_url'));if($submit)$out.='<a href="'.$e($submit).'" aria-label="Proposer un nouvel espace" class="meta-rail-link"><div class="w-12 h-12 bg-slate-800 text-emerald-400 rounded-[24px] flex items-center justify-center text-xl">'.NexusConnect::icon('plus').'</div></a>';
        return $out.'</nav>';
    }
    public static function links($item,$p,string $slot,string $caption): string
    {
        $f=self::field($item,$p,$slot);if(!$f)return '';$targets=[];
        if(in_array((string)$f->type,['parent','child'],true))$targets=\Geniuspace\ExtendedFields::targets($f,$item,false);
        elseif($f->type==='gprelation')try{$d=\Geniuspace\FieldEngine::parse('relation',(string)$f->value,\Geniuspace\FieldOptions::params($f->params));foreach($d['record_ids']as$id)if($r=\Geniuspace\ExtendedFields::publicRecord($id,false))$targets[]=$r;}catch(\InvalidArgumentException){}
        $out='';foreach($targets as$r){$url=NexusPlatform::sameSite(\Geniuspace\ExtendedFields::url($r));if(!$url)continue;
            $logo=\Geniuspace\RelationCards::value($r,(string)$f->params->get('params.card_cover_fields',''),true);$intro=\Geniuspace\RelationCards::value($r,(string)$f->params->get('params.card_excerpt_fields',''));
            $out.='<a class="meta-linked-card group hover:bg-indigo-50 transition-colors" href="'.NexusSuite::e($url).'">'.($logo?'<img class="meta-linked-logo" src="'.NexusSuite::e($logo).'" alt="" width="40" height="40" loading="lazy">':'<span class="meta-linked-logo meta-avatar">'.NexusSuite::e(mb_substr($r->title,0,1)).'</span>').'<div><span class="text-[9px] font-bold text-primary uppercase tracking-widest">'.NexusConnect::icon('link').' '.NexusSuite::e($caption).'</span><strong>'.NexusSuite::e($r->title).'</strong><small>'.NexusSuite::e($intro).'</small></div></a>';
        }return $out;
    }
    public static function card($i,$p,array $comments): string
    {
        if(class_exists('NexusAbsolu'))$p=NexusAbsolu::paramsFor($i,$p);
        $e=[NexusSuite::class,'e'];$url=NexusPlatform::recordUrl($i);require_once __DIR__.'/NexusForumEight.php';$author=NexusForumEight::author($i,$p);
        $color=NexusPlatform::value($i,$p,'field_author_color');if(!preg_match('/^#[a-f0-9]{6}$/iD',$color))$color='#4f46e5';
        $participation=class_exists('NexusParticipation')?NexusParticipation::recordStyle($i):[];
        $reactionsReady=\Geniuspace\SchemaHealth::has('forum_reactions');$state=\Geniuspace\ForumKnowledge::state((int)$i->id);$counts=$reactionsReady?\Geniuspace\ForumKnowledge::reactions((int)$i->id):[];
        $identity=class_exists('Geniuspace\\AccountIdentity')?\Geniuspace\AccountIdentity::render((int)$i->user_id):'';
        $authorHtml=$identity?:self::avatar($author,$color).'<strong>'.$e($author).'</strong>';
        $out='<article class="meta-post '.NexusParticipationUI::classes($participation).' bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden" data-native-record="'.(int)$i->id.'"><div class="p-5 pb-2"><div class="flex items-center justify-between mb-4"><div class="nx-native-author"><div class="nx-native-author-identity">'.$authorHtml.NexusPlatform::widget($i,$p,'field_author_badges').'</div><div class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">'.NexusPlatform::widget($i,$p,'field_tags').NexusPlatform::widget($i,$p,'field_topic').' · '.$e(substr(NexusSuite::iso($i->ctime??''),0,10)).'</div></div>'.NexusPlatform::widget($i,$p,'field_bounty').'</div>';
        $out.=NexusParticipationUI::badge($participation).'<h2 class="meta-card-title font-bold text-xl text-slate-900 mb-2 leading-tight"><a href="'.$e($url).'">'.$e($i->title).'</a></h2><p class="text-sm text-slate-600 mb-5 leading-relaxed">'.$e(NexusPlatform::value($i,$p,'field_excerpt')?:mb_substr(NexusPlatform::value($i,$p,'field_body'),0,500)).'</p>';
        $out.='<a class="nx-feed-reply" href="'.$e($url).'#comments">'.NexusConnect::icon('reply').' Répondre à cette publication →</a><details class="nx-card-enrichment"><summary>Médias, données et ressources de cette publication</summary>';
        $out.=\Geniuspace\ForumPresence::badge((int)$i->id);
        if(class_exists('Geniuspace\\MultiverseMechanisms'))$out.=\Geniuspace\MultiverseMechanisms::compact((int)$i->id);
        $out.=self::widget($i,$p,'field_widgets').self::widget($i,$p,'field_audio').self::widget($i,$p,'field_code').NexusPlatform::widget($i,$p,'field_media').NexusPlatform::widget($i,$p,'field_video').NexusPlatform::widget($i,$p,'field_images').NexusPlatform::widget($i,$p,'field_files');
        if($cover=NexusAurora::cover($i,$p,'field_cover'))$out.='<img src="'.$e($cover).'" class="w-full rounded-xl mb-4" alt="'.$e(NexusPlatform::value($i,$p,'field_cover_alt')).'" width="900" height="500" loading="lazy">';
        $out.=self::links($i,$p,'field_company','Entreprise').self::links($i,$p,'field_job','Offre liée').self::links($i,$p,'field_related','Ressource reliée').self::links($i,$p,'field_courses','Apprendre pour aller plus loin');
        require_once __DIR__.'/NexusForumEight.php';$out.=NexusForumEight::extra($i,$p);
        foreach(['coalition','opportunity','factcheck','sponsorship']as$slot)$out.=NexusPlatform::widget($i,$p,'field_'.$slot);
        $out.='<div class="meta-field-groups">'.NexusConnect::region($i,$p,'header').NexusConnect::region($i,$p,'body').NexusConnect::region($i,$p,'widgets').NexusConnect::region($i,$p,'sandbox').'</div></details><span class="meta-state">'.$e(\Geniuspace\ForumKnowledge::STATES[$state['state']]??'').'</span></div>';
        $out.=NexusForumEight::metrics($i);$out.='<div class="px-5 py-3 border-t border-slate-100 flex gap-4 text-slate-500 text-sm font-medium bg-slate-50/50 items-center"><div class="flex gap-2 flex-wrap">';
        foreach(($reactionsReady?['vote'=>['arrow-up',''],'rocket'=>['rocket',''],'idea'=>['lightbulb','']]:[])as$kind=>[$symbol,$text]){
            if(\Geniuspace\ProductAccess::user()->id)$out.=\Geniuspace\ProductAccess::form('forum.react',(int)$i->id,['kind'=>$kind]).'<button class="reaction-pill" aria-label="Réagir : '.$e($kind).'">'.NexusConnect::icon($symbol).' '.$counts[$kind].'</button></form>';
            else $out.='<span class="reaction-pill">'.NexusConnect::icon($symbol).' '.$counts[$kind].'</span>';
        }
        $out.='</div><a href="'.$e($url).'#comments" class="flex items-center gap-1.5 hover:text-primary ml-auto text-xs font-bold bg-white border border-slate-200 px-3 py-1.5 rounded-lg shadow-sm">'.NexusConnect::icon('reply').' '.NexusConversation::comments((int)$i->id,1)['total'].' Réponses</a></div>';
        if(NexusPlatform::config($p,'show_reply_excerpts','1')==='1'&&$comments){$out.='<section class="meta-comments-excerpt" aria-label="Extraits des réponses">';foreach($comments as$c){$name=NexusSuite::plain($c->name??'Membre');$out.='<article>'.self::avatar($name,'#64748b',28).'<div><strong>'.$e($name).'</strong><p>'.NexusSuite::commentHtml($c->comment??'').'</p><a class="text-primary" href="'.$e($url).'#comment-'.(int)$c->id.'">Lire et répondre →</a></div></article>';}$out.='</section>';}
        $out.=NexusConnect::region($i,$p,'footer');
        $out.=\Joomcck\Layout\Helpers\Layout::render('core.list.recordParts.buttonsManage',['item'=>$i,'params'=>$p,'section'=>\ItemsStore::getSection((int)$i->section_id),'submissionTypes'=>[(int)$i->type_id=>\ItemsStore::getType((int)$i->type_id)]]);
        require_once __DIR__.'/NexusForumEight.php';return NexusForumEight::card($i,$p,$out.'<footer class="nx-next-step"><a href="#nx-journey-explorer" data-journey-open>'.NexusConnect::icon('route').' Et après ? Trouver mon prochain parcours →</a></footer></article>');
    }
    public static function results(string $query): string
    {
        if(trim($query)==='')return '';if(!\Geniuspace\SchemaHealth::has('knowledge_chunks'))return '<p class="meta-configuration-note">La recherche de passages est en maintenance. La liste native reste disponible.</p>';$hits=\Geniuspace\NexusKnowledge::search($query);$out='<section class="meta-search-results"><h2>Résultats dans les contenus publics</h2>';
        foreach($hits['items']as$hit)$out.='<article><h3><a href="'.NexusSuite::e(NexusPlatform::sameSite($hit['url'])).'">'.NexusSuite::e($hit['title']).'</a></h3><p>'.NexusSuite::e($hit['excerpt']).'</p><small>'.NexusSuite::e($hit['field_label'].' · '.$hit['updated_at']).'</small></article>';
        if(!$hits['items'])$out.='<p>Aucun passage public correspondant dans l’index actuel.</p>';
        return $out.'</section>';
    }
    public static function promoted(array $items,$p): string
    {
        $out='';foreach($items as$i){$badge=NexusPlatform::value($i,$p,'field_promoted');if(!$badge||in_array(mb_strtolower($badge),['0','non','no','false'],true))continue;
            $out.='<a href="'.NexusSuite::e(NexusPlatform::recordUrl($i)).'" class="topic-slide bg-white border border-slate-200 rounded-xl p-4 shadow-sm relative overflow-hidden group"><span class="text-[10px] font-bold uppercase tracking-widest text-primary">'.NexusSuite::e($badge).'</span><h2 class="font-bold text-slate-900 text-sm mb-1 mt-3">'.NexusSuite::e($i->title).'</h2><p class="text-xs text-slate-500 mb-3">'.NexusSuite::e(mb_substr(NexusPlatform::value($i,$p,'field_excerpt'),0,160)).'</p><span class="text-[10px] font-bold text-primary">'.NexusPlatform::widget($i,$p,'field_bounty').' Explorer →</span></a>';
        }return $out?'<div class="topic-slider hide-scroll" aria-label="Sujets mis en avant">'.$out.'</div>':'';
    }
    public static function composer($p,string $submit): string
    {
        require_once __DIR__.'/NexusComposer.php';
        $u=\Joomla\CMS\Factory::getApplication()->getIdentity();$e=[NexusSuite::class,'e'];
        $endpoint=\Joomla\CMS\Uri\Uri::root().'?option=com_joomcck&task=geniuspace.productRead';
        $tools=NexusComposer::destinations($submit,$p);$toolbar='';
        require_once __DIR__.'/NexusAuthorForms.php';
        $definitions=NexusAuthorForms::definitions($p);$groups=['Contenus & médias'=>'','Communauté & gaming'=>'','Solutions B2B'=>''];$context=\Geniuspace\UniverseBlueprint::context((int)\Joomla\CMS\Factory::getApplication()->input->getInt('section_id',0),\Joomla\CMS\Factory::getApplication()->input->getInt('cat_id',0));$primary=$context['universe']['primary_formats']??['discussion','article','review','buying-pool'];
        foreach($definitions as$kind=>$profile){
            $fallback=$tools[$kind][0]['url']??$submit;$link='<a class="meta-composer-tool" href="'.$e($fallback).'" data-meta-tool="'.$e($kind).'" aria-label="'.$e($profile['label']).'" title="'.$e($profile['label']).'">'.NexusConnect::icon($profile['icon']).'<span>'.$e($profile['label']).'</span></a>';
            if(in_array($kind,$primary,true))$toolbar.=$link;
            else{$group=in_array($kind,['expert','partner','sponsorship'],true)?'Solutions B2B':(in_array($kind,['gaming','playtest','fact-check','city'],true)?'Communauté & gaming':'Contenus & médias');$groups[$group].=$link;}
        }
        $more='<details class="nx-format-menu"><summary>'.NexusConnect::icon('layer-group').' '.max(0,count($definitions)-count(array_intersect(array_keys($definitions),$primary))).' Formats & B2B</summary><div class="nx-format-panel">';
        foreach($groups as$label=>$links)if($links)$more.='<section><h3>'.$e($label).'</h3>'.$links.'</section>';$more.='</div></details>';
        $uri=new \Joomla\CMS\Uri\Uri($submit);$section=(int)$uri->getVar('section_id',\Joomla\CMS\Factory::getApplication()->input->getInt('section_id',0));$options='';
        require_once __DIR__.'/NexusForumSeven.php';
        if($section){$active=\Joomla\CMS\Factory::getApplication()->input->getInt('cat_id',0);foreach(NexusForumSeven::flat(NexusForumSeven::categories($section))as$c)if($c->params->get('submission',1))$options.='<option value="'.(int)$c->id.'"'.($active===(int)$c->id?' selected':'').'>'.$e($c->title).'</option>';}
        $category=$options?'<label class="nx-quick-category">Dans <select data-quick-category aria-label="Espace de publication"><option value="">Espace automatique</option>'.$options.'</select></label>':'';
        return '<section class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm" id="nx-community-compose" data-meta-composer data-submit="'.$e($submit).'" data-tools="'.$e(NexusSuite::jsonLd($tools)).'" data-read="'.$e($endpoint).'" data-authenticated="'.($u->id?'1':'0').'"><div class="flex gap-3">'.self::avatar($u->id?$u->name:'V').'<div class="w-full"><label class="sr-only" for="meta-compose-text">Partager une idée ou une question</label><textarea id="meta-compose-text" data-quick-rich-source class="w-full bg-slate-50 rounded-xl p-3 text-sm outline-none border border-slate-100 focus:border-primary transition-colors resize-y" placeholder="Partagez une idée ou une question… / sources · @ ressources" rows="2" maxlength="12000"></textarea><div class="meta-composer-menu" hidden></div><div class="meta-composer-sources"></div>'.NexusParticipationUI::composer().'<div class="meta-composer-footer"><nav class="meta-composer-tools" aria-label="Enrichir la publication">'.$toolbar.$more.'<button type="button" class="meta-composer-tool" data-local-dictation aria-pressed="false">'.NexusConnect::icon('microphone').'<span>Dicter</span></button></nav><div class="nx-quick-actions">'.$category.'<a class="bg-slate-900 text-white px-5 py-2 rounded-xl text-xs font-bold shadow-md" data-meta-publish href="'.$e($submit).'">'.($u->id?'Publier mon message':'Se connecter pour publier').'</a></div></div><p data-dictation-status role="status"></p><section class="meta-composer-toolbox" data-meta-toolbox hidden aria-label="Formats de publication"><h3></h3><div></div><button type="button" data-meta-tool-close>Fermer</button></section><p class="meta-composer-status" role="status" aria-live="polite"></p></div></div></section>';
    }

    public static function sidebar(array $items,$p): string
    {
        $out='<aside class="meta-right bg-white border-l border-slate-200" aria-label="Salons, données et réseaux"><div class="meta-right-scroll p-6 space-y-6">';
        foreach(['rooms'=>'field_room','market'=>'field_market','guilds'=>'field_guild']as$position=>$slot){
            foreach(self::regionFields($items,$p,$position,$slot)as[$i,$f]){
                $html=(string)$f->result;if(!$html)continue;
                $dark=$position==='rooms';$out.='<section class="'.($dark?'bg-slate-900 text-white':'bg-slate-50 border border-slate-200').' p-4 rounded-xl shadow-sm"><h2 class="font-bold text-sm mb-4">'.NexusConnect::icon(['rooms'=>'headphones','market'=>'chart-pie','guilds'=>'users'][$position]).' '.NexusSuite::e(['rooms'=>'Salon audio','market'=>'Données du réseau','guilds'=>'Guilde & réseau'][$position]).'</h2>'.$html.'</section>';
            }
        }
        foreach($items as$i)$out.=NexusConnect::region($i,$p,'sidebar');
        $nav=NexusConnect::nav($p);if($nav)$out.='<section class="meta-site-links"><h2 class="font-bold text-sm mb-3">Relier les savoirs et les opportunités</h2>'.$nav.'</section>';
        $out.=\Geniuspace\MultiverseMechanisms::sidebar(array_map(static fn($i)=>(int)$i->id,$items));
        return $out.'</div></aside>';
    }
    public static function controls($item,$p): string
    {
        $id=(int)$item->id;$out='';if(!\Geniuspace\SchemaHealth::has('forum_states','field_corrections','record_events'))return '';$u=\Geniuspace\ProductAccess::user();$state=\Geniuspace\ForumKnowledge::state($id);
        if($u->id){$public=(new \Geniuspace\NativeAccess())->record($id);$choices='';
            foreach($public['fields']??[]as$fid=>$f)if(in_array($f['field_type'],['text','textarea','html','select','digits'],true))$choices.='<option value="'.(int)$fid.'">'.NexusSuite::e($f['label']).'</option>';
            if($choices)$out.='<details class="meta-native-filters"><summary>Proposer une correction sourcée</summary>'.\Geniuspace\ProductAccess::form('correction.propose',$id,['target'=>$id]).'<label>Information à corriger <select name="field">'.$choices.'</select></label><label>Valeur proposée <textarea name="proposed" required maxlength="20000"></textarea></label><label>Explication <textarea name="reason" required maxlength="2000"></textarea></label><label>Source <input type="url" name="source" maxlength="2000"></label><button>Soumettre à l’auteur</button></form></details>';
        }
        if(\MECAccess::allowEdit($item,\ItemsStore::getType((int)$item->type_id),\ItemsStore::getSection((int)$item->section_id))){
            $out.='<details class="meta-native-filters"><summary>Suivi du sujet · réservé à l’auteur et aux éditeurs autorisés</summary>'.\Geniuspace\ProductAccess::form('forum.state',$id).'<label>État <select name="state">';
            foreach(\Geniuspace\ForumKnowledge::STATES as$key=>$label)$out.='<option value="'.$key.'"'.($key===$state['state']?' selected':'').'>'.NexusSuite::e($label).'</option>';
            $out.='</select></label><label>Réponse retenue <select name="comment"><option value="0">Choisir une réponse publique</option>';
            foreach(NexusConversation::comments($id,6)['items']as$c)$out.='<option value="'.(int)$c->id.'">'.NexusSuite::e($c->name.' · '.mb_substr(NexusSuite::plain($c->comment),0,100)).'</option>';
            $out.='</select></label><label>Record de synthèse publique <input type="number" name="summary" min="0" value="'.(int)$state['summary_record'].'"></label><button>Enregistrer cet état</button></form></details>';
            $out.=\Geniuspace\FieldCorrection::render($id);
        }
        if($state['state']==='reviewed'&&($r=\Geniuspace\ExtendedFields::publicRecord((int)$state['summary_record'],false)))$out.='<a class="meta-linked-card" href="'.NexusSuite::e(NexusPlatform::sameSite(\Geniuspace\ExtendedFields::url($r))).'">Synthèse relue : '.NexusSuite::e($r->title).'</a>';
        if($state['state']==='resolved')$out.='<a class="meta-linked-card" href="#comment-'.(int)$state['accepted_comment'].'">Consulter la réponse retenue →</a>';
        return $out;
    }

}
