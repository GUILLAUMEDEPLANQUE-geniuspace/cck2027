<?php
declare(strict_types=1);
namespace Geniuspace;

/** Originals remain private. Only a reviewed, rebuilt salary summary can be published. */
final class OfferVault
{
    private static function store(): Store { return new Store(\Joomla\CMS\Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class)); }
    private static function definition(int $record,int $field): array
    {
        $r=(new NativeAccess())->record($record);if(!$r)throw new \DomainException('Coffre inaccessible.',404);
        $f=self::store()->rows("SELECT params FROM #__js_res_fields WHERE id=$field AND type_id=".(int)$r['raw']['type_id']." AND field_type='gpvault' AND published=1 AND access=1",1)[0]??null;
        $p=$f?json_decode($f['params'],true):[];
        if(!$f||empty($p['params']['enabled'])||empty($p['core']['show_full'])||(int)($p['core']['field_view_access']??1)!==1)throw new \DomainException('Coffre inaccessible.',404);
        foreach($p['emerald']??[]as$k=>$v)if(str_ends_with($k,'_subscription')&&$v)throw new \DomainException('Coffre inaccessible.',404);
        return $r;
    }
    public static function declaration(array $d): array
    {
        $title=Text::plain((string)($d['job_title']??''));$currency=$d['currency']??'EUR';$period=$d['period']??'YEAR';
        if(!$title||mb_strlen($title)>180||!is_string($currency)||!preg_match('/^[A-Z]{3}$/D',$currency)||!in_array($period,['YEAR','MONTH'],true))throw new \InvalidArgumentException('Poste, devise ISO et période requis.');
        $amounts=[];foreach(['salary','bonus']as$k){$v=$d[$k]??'0';if(!is_scalar($v)||!preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D',(string)$v)||($n=(float)$v)>10000000||($k==='salary'&&$n<=0))throw new \InvalidArgumentException('Montant invalide.');$amounts[$k.'_minor']=(int)round($n*100);}
        return ['job_title'=>$title,'currency'=>$currency,'period'=>$period]+$amounts;
    }
    public static function upload(int $record,int $field,array $data,string $filename,string $bytes): int
    {
        $user=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$user->id||$user->block)throw new \DomainException('Connexion requise.',403);self::definition($record,$field);
        if(strlen($bytes)>2*1024*1024)throw new \InvalidArgumentException('PDF de 2 Mo maximum.');$meta=Documents::inspect($filename,$bytes);if($meta['mime']!=='application/pdf')throw new \InvalidArgumentException('PDF requis.');
        if(empty($data['consent']))throw new \InvalidArgumentException('Confirmez le dépôt privé et la revue du résumé.');$declaration=self::declaration($data);$s=self::store();
        // Optional local extraction is a proposal, never an authenticity claim or public raw text.
        $analysis=['local_extraction'=>false,'salary_candidates'=>[]];
        try{$text=DocumentInsights::pdfBytes($bytes);preg_match_all('/(\d[\d \x{00A0}]{3,9}(?:[,.]\d{1,2})?)\s*(?:€|EUR)/u',$text,$matches);foreach(array_slice($matches[1],0,20)as$v)$analysis['salary_candidates'][]=preg_replace('/\s|\x{00A0}/u','',$v);$analysis['local_extraction']=true;}catch(\DomainException|\InvalidArgumentException $e){$analysis['reason']='Extraction locale indisponible ou PDF non textuel : revue manuelle requise.';}
        return $s->atomic(function()use($s,$user,$record,$field,$meta,$bytes,$declaration,$analysis){
            $s->rows('SELECT id FROM #__users WHERE id='.(int)$user->id.' FOR UPDATE',1);
            $used=$s->rows('SELECT COUNT(*) AS n,COALESCE(SUM(bytes),0) AS bytes FROM #__gp_social_verified_offers WHERE user_id='.(int)$user->id,1)[0];
            $total=(int)($s->rows('SELECT COALESCE(SUM(bytes),0) AS n FROM #__gp_social_verified_offers',1)[0]['n']??0);
            if((int)$used['n']>=20||$total+$meta['bytes']>100*1024*1024)throw new \DomainException('Quota documentaire atteint.',413);
            return $s->insert('verified_offers',['record_id'=>$record,'field_id'=>$field,'user_id'=>(int)$user->id,'filename'=>$meta['filename'],'bytes'=>$meta['bytes'],'checksum'=>$meta['checksum'],'payload'=>$bytes,'declaration'=>Seo::json($declaration),'analysis'=>Seo::json($analysis),'state'=>'pending','reviewer_id'=>0,'ctime'=>gmdate('Y-m-d H:i:s'),'mtime'=>gmdate('Y-m-d H:i:s')]);
        });
    }
    public static function review(int $id,string $state): void
    {
        $u=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$u->id||$u->block||!$u->authorise('core.manage','com_joomcck'))throw new \DomainException('Revue réservée à la gestion JoomCCK.',403);
        if(!in_array($state,['reviewed','rejected'],true))throw new \InvalidArgumentException('Décision invalide.');$s=self::store();$r=$s->rows('SELECT record_id,field_id FROM #__gp_social_verified_offers WHERE id='.$id,1)[0]??null;if(!$r)throw new \DomainException('Document introuvable.',404);self::definition((int)$r['record_id'],(int)$r['field_id']);
        $s->run('UPDATE #__gp_social_verified_offers SET state='.$s->q($state).',reviewer_id='.(int)$u->id.',mtime='.$s->q(gmdate('Y-m-d H:i:s')).' WHERE id='.$id." AND state='pending'");
    }
    public static function revoke(int $id): void
    {
        $u=\Joomla\CMS\Factory::getApplication()->getIdentity();$s=self::store();$r=$s->rows('SELECT user_id FROM #__gp_social_verified_offers WHERE id='.$id,1)[0]??null;
        if(!$u->id||$u->block||!$r||((int)$r['user_id']!==(int)$u->id&&!$u->authorise('core.manage','com_joomcck')))throw new \DomainException('Révocation interdite.',403);
        $s->run("UPDATE #__gp_social_verified_offers SET state='revoked',payload='',bytes=0,mtime=".$s->q(gmdate('Y-m-d H:i:s')).' WHERE id='.$id);
    }
    /** A new PDF includes only declared salary fields; no original pages, signatures or metadata. */
    public static function summaryPdf(array $d,string $company,string $checksum): string
    {
        $lines=['NEXUS - Resume salarial relu','Entreprise : '.Text::plain($company),'Poste : '.$d['job_title'],'Remuneration : '.number_format($d['salary_minor']/100,2,'.',' ').' '.$d['currency'].' / '.$d['period'],'Prime declaree : '.number_format($d['bonus_minor']/100,2,'.',' ').' '.$d['currency'],'Declaration relue - authenticite non certifiee.','Ce resume reconstruit ne reproduit pas le contrat original.','Empreinte du document source : '.$checksum];
        $stream="BT /F1 12 Tf 50 790 Td 22 TL\n";foreach($lines as$line){$line=mb_convert_encoding(mb_substr($line,0,180),'Windows-1252','UTF-8');$stream.='('.strtr($line,['\\'=>'\\\\','('=>'\\(',')'=>'\\)',"\r"=>' ',"\n"=>' ']).") Tj T*\n";}$stream.="ET\n";
        $objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>','<< /Length '.strlen($stream).' >>'."\nstream\n".$stream.'endstream'];
        $pdf="%PDF-1.4\n";$offsets=[0];foreach($objects as$i=>$object){$offsets[]=strlen($pdf);$pdf.=($i+1)." 0 obj\n".$object."\nendobj\n";}$xref=strlen($pdf);$pdf.="xref\n0 6\n0000000000 65535 f \n";foreach(array_slice($offsets,1)as$o)$pdf.=sprintf("%010d 00000 n \n",$o);return $pdf."trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n".$xref."\n%%EOF\n";
    }
    public static function download(int $id,bool $original=false): Response
    {
        $s=self::store();$r=$s->rows('SELECT * FROM #__gp_social_verified_offers WHERE id='.$id,1)[0]??null;if(!$r||in_array($r['state'],['rejected','revoked'],true))throw new \DomainException('Document inaccessible.',404);$record=self::definition((int)$r['record_id'],(int)$r['field_id']);
        if($original){$u=\Joomla\CMS\Factory::getApplication()->getIdentity();if(!$u->id||$u->block||((int)$r['user_id']!==(int)$u->id&&!$u->authorise('core.manage','com_joomcck')))throw new \DomainException('Original privé.',403);if(!hash_equals($r['checksum'],hash('sha256',$r['payload'])))throw new \RuntimeException('Intégrité documentaire incorrecte.');$bytes=$r['payload'];}
        else{if($r['state']!=='reviewed')throw new \DomainException('Résumé en attente de revue.',404);$bytes=self::summaryPdf(json_decode($r['declaration'],true),$record['record']['title'],$r['checksum']);}
        return new Response($bytes,'application/pdf',200,['Content-Disposition'=>'attachment; filename="nexus-salary-'.$id.'.pdf"','Cache-Control'=>'private, no-store','X-Robots-Tag'=>'noindex, noarchive','Content-Security-Policy'=>"default-src 'none'; sandbox",'X-Content-Type-Options'=>'nosniff']);
    }
    public static function render(object $record,object $field): string
    {
        $id=(int)$record->id;$fid=(int)$field->id;try{self::definition($id,$fid);}catch(\DomainException $e){return '';}$u=\Joomla\CMS\Factory::getApplication()->getIdentity();$s=self::store();$moderator=$u->id&&!$u->block&&$u->authorise('core.manage','com_joomcck');$e=[Text::class,'escape'];$base=\Joomla\CMS\Uri\Uri::root();$hidden='<input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="task" value="geniuspace.vault"><input type="hidden" name="record" value="'.$id.'"><input type="hidden" name="field" value="'.$fid.'">'.\Joomla\CMS\HTML\HTMLHelper::_('form.token');
        $out='<section class="nx-vault"><h3>Coffre des offres · rémunérations documentées</h3><p>Les originaux restent privés. Les résumés sont reconstruits et relus, sans certification d’authenticité par une IA.</p>';
        $where='record_id='.$id.' AND field_id='.$fid." AND (state='reviewed'".($moderator?" OR state='pending'":($u->id?' OR user_id='.(int)$u->id:'' )).')';
        foreach($s->rows('SELECT id,user_id,declaration,state,analysis FROM #__gp_social_verified_offers WHERE '.$where.' ORDER BY id DESC',100)as$r){$d=json_decode($r['declaration'],true);$out.='<div class="nx-connect-block"><strong>'.$e($d['job_title']).'</strong><p>'.$e((string)($d['salary_minor']/100).' '.$d['currency'].' / '.$d['period']).' · '.$e($r['state']==='reviewed'?'Résumé relu':($r['state']==='pending'?'En attente de revue':'Retiré')).'</p>';
            if($r['state']==='reviewed')$out.='<a href="'.$e($base.'?option=com_joomcck&task=geniuspace.vaultDownload&id='.(int)$r['id']).'">Télécharger le résumé anonymisé</a>';
            if($moderator||($u->id&&(int)$r['user_id']===(int)$u->id)){if($r['state']==='pending'||$r['state']==='reviewed')$out.='<p><a href="'.$e($base.'?option=com_joomcck&task=geniuspace.vaultDownload&original=1&id='.(int)$r['id']).'">Consulter l’original privé</a></p>';$out.='<form method="post" action="'.$e($base).'">'.$hidden.'<input type="hidden" name="offer" value="'.(int)$r['id'].'"><button name="action" value="revoke">Retirer mon document et son résumé</button></form>';}
            if($moderator&&$r['state']==='pending'){$a=json_decode($r['analysis'],true);$out.='<p>Propositions de montants de l’extracteur local : '.$e(implode(', ',$a['salary_candidates']??[])).'</p><form method="post" action="'.$e($base).'">'.$hidden.'<input type="hidden" name="offer" value="'.(int)$r['id'].'"><button name="action" value="reviewed">Publier le résumé après revue</button><button name="action" value="rejected">Refuser</button></form>';}$out.='</div>';}
        if($u->id&&!$u->block){\Joomla\CMS\Factory::getApplication()->setHeader('Cache-Control','private, no-store',true);$out.='<form method="post" enctype="multipart/form-data" action="'.$e($base).'" class="nx-vault-upload">'.$hidden.'<input type="hidden" name="action" value="upload"><label>Poste <input required name="job_title" maxlength="180"></label><label>Rémunération de base <input required type="number" name="salary" min=".01" max="10000000" step=".01"></label><label>Prime <input type="number" name="bonus" min="0" value="0" step=".01"></label><label>Devise <input name="currency" value="EUR" pattern="[A-Z]{3}" maxlength="3"></label><label>Période <select name="period"><option value="YEAR">Annuelle</option><option value="MONTH">Mensuelle</option></select></label><label>Original privé PDF (2 Mo) <input required type="file" name="proof" accept="application/pdf"></label><label><input required type="checkbox" name="consent" value="1"> Je confirme les montants déclarés et autorise la revue du résumé salarial.</label><button class="nx-connect-button">Déposer pour revue</button></form>';}
        return $out.'</section>';
    }
}
