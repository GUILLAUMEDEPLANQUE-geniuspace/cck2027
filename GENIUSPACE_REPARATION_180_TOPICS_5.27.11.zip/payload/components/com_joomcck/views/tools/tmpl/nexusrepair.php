<?php
defined('_JEXEC') or die;
require_once JPATH_ROOT.'/components/com_joomcck/library/php/geniuspace/bootstrap.php';
$app=\Joomla\CMS\Factory::getApplication();$u=$app->getIdentity();
if(!$u->id||$u->block||!$u->authorise('core.admin'))throw new \DomainException('Accès administrateur requis.',403);
$app->getDocument()->setMetaData('robots','noindex, nofollow');$app->setHeader('Cache-Control','private, no-store',true);$e=[\Geniuspace\Text::class,'escape'];
$entry=\Joomla\CMS\Uri\Uri::root().($app->isClient('administrator')?'administrator/index.php':'');
echo HTMLFormatHelper::layout('navbar');
?>
<section class="card p-4 nx-repair" data-publication-recovery>
<h1>Publications et comptes importés</h1>
<p>Vérifiez les articles et les discussions enregistrés, restaurez les dossiers manquants et retirez le lot des comptes historiques importés. Les textes déjà modifiés et leurs commentaires sont conservés.</p>
<form action="<?= $e($entry) ?>" method="post">
<input type="hidden" name="option" value="com_joomcck"><input type="hidden" name="task" value="geniuspace.repairPublications">
<?= \Joomla\CMS\HTML\HTMLHelper::_('form.token') ?>
<button type="button" class="btn btn-primary" data-repair-action="diagnose">Vérifier les publications</button>
<button type="button" class="btn btn-primary" data-repair-action="complete">Réparer les douze univers avec leurs images</button>
<button type="button" class="btn btn-success" data-repair-action="restore" disabled>Restaurer les articles et topics manquants</button>
<p>La restauration fonctionne par univers. Installez d’abord les deux packs d’images 5.27.6 pour garantir les couvertures des 240 articles.</p>
<hr><h2>Comptes importés par l’outil Geniuspace</h2>
<p>Seuls les comptes désactivés portant la trace exacte de cet import et leur fiche privée peuvent être retirés. Une sauvegarde privée précède la suppression. Toute activation, modification de droits ou nouvelle activité bloque l’opération pour préserver les publications.</p>
<button type="button" class="btn btn-outline-danger" data-repair-action="remove" disabled>Supprimer le lot importé identifié</button>
<hr><h2>Votre import a été exécuté directement en SQL</h2>
<p>Choisissez votre fichier <strong>geniuspace_450_membres_joomcck.sql</strong>. Il est lu comme des données, jamais exécuté. Ce fichier contient aussi 45 anciens topics associés à des types, sections et champs fixes ; leur réparation les raccorde aux vrais champs et univers du forum avant le retrait des comptes.</p>
<label>Fichier SQL original <input type="file" name="legacy_sql" accept=".sql,text/plain" data-repair-sql></label>
<button type="button" class="btn btn-primary" data-repair-action="sql-diagnose">Identifier les comptes de ce SQL</button>
<button type="button" class="btn btn-success" data-repair-action="sql-topics" disabled>Raccorder et conserver les 45 anciens topics</button>
<button type="button" class="btn btn-outline-danger" data-repair-action="sql-remove" disabled>Retirer les comptes SQL identifiés</button>
<output role="status" aria-live="polite" style="display:block;white-space:pre-wrap;margin:1rem 0" data-repair-status></output><ol data-repair-receipts></ol>
</form>
<a href="<?= $e(\Joomla\CMS\Uri\Uri::root().'hub?nx_mode=blog&nx_blog_category=0') ?>">Ouvrir le Multi-Blog</a>
</section>
<?= \Geniuspace\PublicationRepair::panel() ?>
<script type="module" src="<?= $e(\Joomla\CMS\Uri\Uri::root().'media/com_joomcck/nexus/publication-recovery.js?v=5.27.11') ?>"></script>
