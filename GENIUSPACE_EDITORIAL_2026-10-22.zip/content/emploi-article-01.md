# Lire une offre d’emploi : distinguer missions, conditions et critères éliminatoires

Une offre d’emploi est utile si elle permet de comprendre le travail et de décider s’il vaut la peine de poursuivre l’échange. Le titre du poste et une liste de qualités ne suffisent pas. Pour la lire, séparez trois choses : ce qui sera fait, les conditions dans lesquelles ce sera fait et la manière dont une candidature sera évaluée.

## Transformer chaque formule en question concrète

« Autonome », « dynamique » ou « à l’aise dans un environnement exigeant » décrivent peu le quotidien. Cherchez l’action observable derrière la formule. L’autonomie signifie-t-elle préparer une proposition, décider seul dans un périmètre défini ou conduire une mission sans accompagnement ? Ces situations demandent des informations différentes.

Pour chaque mission, demandez un exemple des premières semaines : un livrable, un interlocuteur, un outil et une règle de validation. Le but est de comprendre l’organisation, sans exiger de l’entreprise qu’elle rende publics des documents internes ou l’identité de ses clients.

## Séparer les exigences qui n’ont pas le même statut

| Élément de l’annonce | Question à poser | Conséquence pour la candidature |
|---|---|---|
| Prérequis présenté comme obligatoire | Dans quelle situation doit-il être maîtrisé dès l’arrivée ? | Préparer une preuve ou vérifier si la candidature est pertinente |
| Compétence souhaitée | Peut-elle être acquise pendant la prise de poste ? | Montrer une capacité d’apprentissage et un point de départ |
| Condition de travail | Quelle est la règle et quelles exceptions sont possibles ? | Vérifier la compatibilité avec sa situation |
| Étape de recrutement | Quel résultat sera évalué et sur quels critères ? | Préparer l’entretien ou l’exercice sans deviner les attentes |

Une compétence absente d’un CV n’est pas automatiquement une absence de capacité. Une candidature peut expliquer ce qui est déjà démontré, ce qui est transférable et ce qui reste à apprendre. Cette distinction est plus honnête que l’ajout de mots-clés sans exemple.

## Préparer une matrice de preuves courte

Prenez une mission de l’annonce : « améliorer le suivi des demandes clients ». Une preuve possible peut être un tableau anonymisé, la description d’une réorganisation ou un exercice construit pour montrer le raisonnement. Présentez le contexte, votre rôle exact, le résultat et les limites de ce que le document démontre.

Ne transformez pas une contribution collective en résultat individuel. Si les données sont confidentielles, expliquez la méthode sans publier les fichiers. Une preuve bien délimitée est plus crédible qu’un chiffre spectaculaire impossible à vérifier.

## Lire aussi les conditions et le processus

Conservez séparément rémunération, localisation, présence attendue, horaires, déplacements et modalités de candidature. Une formule comme « télétravail possible » mérite une semaine type : jours de présence, contraintes d’équipe, période d’intégration et règle de modification.

Pour un exercice de recrutement, demandez le temps attendu, le livrable et les critères. Il faut pouvoir distinguer une démonstration de compétence d’un travail opérationnel dont le périmètre ne serait pas annoncé. Les points juridiques précis se vérifient auprès des sources officielles adaptées au pays et au contrat ; cette grille est une méthode de lecture, pas une consultation juridique.

## Poser une question qui aide aussi les autres

Au lieu de « Votre offre est-elle sérieuse ? », citez la condition concernée : « Vous indiquez une présence régulière à Paris : quelle semaine type correspond à ce poste ? ». Une question attachée à la phrase conserve son contexte et évite de répéter le même échange dans plusieurs candidatures.

Avant de postuler, cherchez donc une mission comprise, des conditions suffisamment explicites et une preuve adaptée. Ce trio rend la décision plus solide, même si l’annonce ne répond pas encore à toutes les questions.
